# **02\. 流媒体视频艺术（Streaming Video Art）**

# **006 YouTube的创立与早期发展**

*The Founding and Early Development of YouTube (2005–2010)*

[Сегодня YouTube отмечает 20 лет: каким было первое видео и как выглядел в 2005 году \| Українські Новини](https://images.openai.com/static-rsc-4/-MWpaszVz_YKhSSEVgMm65d6MYH7imYbbYM-6kSu1Wcxbqpj_w6mDkfJD_hG4ExSEgVyP_V2_X_YkX8nWIDCzwWd6euXAxubQRqzwZYKzYIMHtbNBRmHLfa0Kw_RVyDP6xZSii8g9r3wcXdZtBRzpcSqTmA8r21OvMVLOCBhJD8?purpose=inline)

[ukranews.com](https://ukranews.com/news/1064448-sogodni-youtube-vidznachaye-20-rokiv-yakim-bulo-pershe-video-ta-yak-viglyadav-u-2005-rotsi?utm_source=chatgpt.com)

## **导言：YouTube如何改变互联网影像文化**

2005年，YouTube的出现改变了互联网视频的发展方向。

在此之前，互联网已经具备视频传输、视频下载和在线视频播放能力，但普通用户制作和发布视频仍然存在不少困难。用户需要解决视频格式、服务器空间、文件传输和网页嵌入等技术问题。

YouTube的重要创新，是把这些原本分散的技术环节整合进一个普通用户能够使用的平台。

用户只需要注册账户、选择视频文件并上传，就可以让其他人通过网页观看。

这一变化带来了一个深刻的文化转变：

**视频不再只是由电视台、电影公司和专业制作机构生产的内容，也成为普通互联网用户可以生产、发布和传播的个人表达形式。**

YouTube的历史因此不仅属于互联网产业史，也属于数字影像文化史、传播史和当代艺术史。

本章主要研究2005年至2010年YouTube早期的发展，重点包括创立背景、创始团队、早期网站、视频上传技术、Google收购、用户生成内容、商业化和平台文化的形成。

## **第一节 YouTube诞生之前的互联网视频环境**

### **1.1 互联网已经能够播放视频**

YouTube并不是第一个互联网视频网站，也不是第一个流媒体平台。

在它出现之前，互联网已经存在多种视频传播方式。

1990年代，RealNetworks、Microsoft和Apple等公司已经开发了网络媒体播放技术。

例如：

* RealVideo：早期互联网视频流媒体技术。  
* QuickTime：Apple开发的多媒体技术。  
* Windows Media：Microsoft开发的数字媒体技术。  
* MPEG：数字视频压缩标准体系。  
  [RealPlayerの新バージョン「RealPlayer 7」β版登場](https://images.openai.com/static-rsc-4/y33Q1GYi7-tpKbiJ5SoT-ajBwLQ8ovPE-ffSu3TZaHBTkjRwvTPwAWJeGx5jFH1nhAPbWvOvd2-_tdr9140faaYULcWY3IfN5-tdQSQ570AmCH0keN_yhbe1IxF5n4tofu_SGNw4JROVlKSVBJcjcUr2OsaeeN0S3yfqIng5B1w?purpose=inline)  
  [internet.watch.impress.co.jp](https://internet.watch.impress.co.jp/www/article/1999/1108/real7.htm?utm_source=chatgpt.com)

这些技术使用户能够在计算机上播放网络视频。

但当时存在一个关键问题：视频播放技术的发展，并没有自动解决普通用户发布视频的问题。

### **1.2 个人发布视频为什么困难？**

在YouTube出现之前，如果一个普通用户希望把自己拍摄的视频放到互联网上，通常需要完成以下工作：

1. 使用摄像机拍摄视频。  
2. 将视频导入计算机。  
3. 将视频转换为适合网络传播的格式。  
4. 寻找能够存储视频的服务器。  
5. 上传视频文件。  
6. 建立网页并放置视频播放器。  
7. 将网页地址分享给其他用户。  
   [DV Video digitalisieren – Anleitung, Technik & Tipps](https://images.openai.com/static-rsc-4/CE623ZgCRVtfNaOx0XeLs_FT0qRffnoMG0ii8q2BEmyYWxiACiLa--R6s5onagBLxnVAqm3x5W2XO39HVtwfnhnn6bklt4sANZvUGHJNlSRVXWT8nU_pi7-iRKKaCvI2vxEgKC8S2r3Ys3lBc8BLb6f1_SIx2_MNX_vwWzGhvFQ?purpose=inline)  
   [film-retter.de](https://www.film-retter.de/dv-video-digitalisieren.html?utm_source=chatgpt.com)

这一过程涉及摄影设备、视频编码、文件管理、网络服务器和网页制作等多个技术环节。

对于专业视频制作人员来说，这些工作并非不可完成。

但对于普通用户而言，整个流程相当复杂。

YouTube解决的正是这一问题：它把视频托管、编码、播放和分享整合成了一个相对简单的用户流程。

### **1.3 数码摄像机与个人影像生产**

YouTube诞生前后，消费级数字摄像设备逐渐普及。

例如：

* MiniDV摄像机。  
* Digital8摄像机。  
* 数码相机的视频拍摄功能。  
* 电脑摄像头。  
* 早期手机摄像设备。  
  [Sony Handycam DCR-TRV17E Mini DV Camcorder for sale online \| eBay](https://images.openai.com/static-rsc-4/Gq1ENgE5TiBojE6MTduvCt2R9C4QHY1I_alcfP0RimdCW4rWXKNZDYGygzyFNoUzigI5lbJmXN5KKpD-Cpt94X5lcUR4JdXDGFAJp7rHnPHSFmrKV1BNPv3X6WY0hXq4FVJkmUVewBNKznHwb9OLtWahB61w-FZptbPyViWGy-o?purpose=inline)  
  [ebay.com](https://www.ebay.com/p/100040858?utm_source=chatgpt.com)

MiniDV等数字摄像设备使普通家庭能够以数字形式记录生活。

与此同时，个人计算机的视频编辑能力也逐渐提高。

用户可以使用桌面软件剪辑影像、添加音乐和字幕，并将视频转换为适合网络传播的格式。

因此，YouTube的出现并非孤立事件，而是消费级数字影像设备、家庭宽带和互联网平台共同发展的结果。

## **第二节 YouTube的创立：三位创始人与最初的构想**

### **2.1 三位创始人**

[Historia de Youtube \| Portal Inmobiliario](https://images.openai.com/static-rsc-4/eVOn3WWxAIcfACcdzNKaphnRAipX-H4aZgXB1ueJ-UEyUanA08BxPcSyCs-L6vSeSwax_cKPanlexMA0UAZ9celWGI3xF5j0tXVejJDUVX4e6PfMH7jR_N9xzkuDlviKYacWIQ6NCjeuIPr7j7IGbmBvXgTr7fWb8jeK1Nc4jiM?purpose=inline)

YouTube由三位曾经在PayPal工作的年轻技术人员创立：

| 创始人 | 主要经历与职责 |
| ----- | ----- |
| Chad Hurley | 设计师，参与网站界面和产品设计 |
| Steve Chen | 软件工程师，负责重要的技术开发 |
| Jawed Karim | 软件工程师，参与早期技术开发和产品构想 |

三人此前都曾在PayPal工作。

这段经历很重要，因为PayPal本身是一家互联网金融服务公司，三位创始人已经熟悉互联网产品开发、用户账户、在线服务和商业运营。

他们并不是从传统电影产业进入视频网站，而是从互联网软件和在线服务领域进入视频行业。

### **2.2 YouTube最初是一个约会网站吗？**

这是YouTube早期历史中很有趣的一段。

关于YouTube最初的构想，三位创始人后来曾在不同采访中回忆过早期计划。

其中一种说法是，他们最初考虑建立一个视频约会网站。

当时互联网上已经有Hot or Not一类网站，用户可以上传照片，由其他用户评价。

创始人曾考虑将这种模式应用到视频上：用户上传自己的视频，其他人观看并进行评价。

[CoHoL](https://images.openai.com/static-rsc-4/ibqSB6ORszX9LIKdz1WuZa92NQJOxzWzIxKFNk3F9_nRUn535LR5vDaEme507DS9PCquBgdpbKjXZi6ajyGzDyDDV4Op0M6RXoCOnz7foB0a4vbQbHi8UAmNp0KMirapDtR9HmXBxto51ljRTlUO2mc1Zzig_lCUPSa79TQVknE?purpose=inline)

[hotornot.carrd.co](https://hotornot.carrd.co/?utm_source=chatgpt.com)

但最初的约会网站构想并没有发展成最终的YouTube。

Steve Chen后来回忆，团队在2005年推出早期服务后，最初并没有获得预期的用户上传量，于是决定改变方向。

Jawed Karim也曾解释，团队最终决定不再把网站限制在约会视频，而是允许用户上传各种类型的视频。

这一转变非常关键。

它使YouTube从一个可能面向特定用途的网站，转变为一个开放的视频分享平台。

不过，历史研究需要注意：关于最初约会网站构想的细节，主要来自创始人事后的回忆。不同创始人的叙述并不完全相同，不能把它简单理解为YouTube全部历史的唯一解释。

Sequoia Capital+1

### **2.3 YouTube名称的含义**

YouTube这个名称由两个英文词构成：

* You：你、个人用户。  
* Tube：电视机的俗称，源自早期阴极射线显像管（Cathode-Ray Tube）。

在美国英语中，tube曾经是电视机的非正式称呼。

因此，YouTube这个名称可以理解为一种带有个人化意味的电视媒介：

**你的电视，你自己的影像。**

这一名称与平台早期的文化理念十分吻合：不再只有电视台能够生产和传播视频，普通人也可以通过互联网向其他人展示自己的生活。

### **2.4 2005年2月14日：YouTube正式注册**

2005年2月14日，YouTube的网站正式注册。

这是YouTube官方后来确认的重要历史日期。

当时的YouTube还不是今天这个规模庞大的全球视频平台，而是一个刚刚开始开发的互联网创业项目。

[20 años de YouTube: de la red social más cruda al asalto definitivo a la televisión](https://images.openai.com/static-rsc-4/PCWoJtej1AhsY0uxJ2UTE4AOGYCebpac5NvJy0JZb9HWM7UDp9WzKAOv8_Gzp4XoRUaPXxAAXVzILYgGigTSsGAQWgf0frV3L21xRtpCFYmWZD9n3rUl5-WrE0o__STHJotllzffsWSqqFsTDXCHcTwR2trQSJpJe86mz6gxeEE?purpose=inline)

[eldiario.es](https://www.eldiario.es/tecnologia/20-anos-youtube-red-social-cruda-asalto-definitivo-television_1_12244873.html?utm_source=chatgpt.com)

创始团队随后开始开发网站，建立视频上传和播放系统。

2005年5月，YouTube推出早期测试版本（Beta）。

同年12月，网站正式向公众开放。

YouTube Blog+2

## **第三节 2005年：YouTube早期网站与技术设计**

### **3.1 早期YouTube的网页界面**

[10 things at 10: YouTube celebrates its first decade \| WTM Global Hub](https://images.openai.com/static-rsc-4/9J4cS-JUr4PNUxjm0ZbMvkJQQcSC7f791oKDtz2-3IRDGWWOT8_DzzrdLumIMIg0jMwa1nd3XT0Q5KCGTIZnqHCQZB485YipAaOb_u7W4vDOj3cNuTWw9_3MpTTyyzxE3cAJseHmWpseuHPBv5AojbATgimwrIKPtzTKRgHJV7M?purpose=inline)

[hub.wtm.com](https://hub.wtm.com/10-things-at-10-youtube-celebrates-its-first-decade?utm_source=chatgpt.com)

2005年的YouTube与今天的界面差异很大。

当时的网站设计相对简单，主要围绕视频浏览和分享组织。

用户可以：

* 浏览视频。  
* 上传视频。  
* 输入标题。  
* 添加标签。  
* 对视频进行评价。  
* 发布评论。  
* 将视频发送给朋友。

早期YouTube的口号是：

*Upload, tag and share your videos worldwide\!*

即：上传、标记并向全世界分享你的视频。

这个口号准确体现了YouTube最初的产品理念。

### **3.2 视频上传机制**

YouTube最重要的技术创新之一，是将视频上传过程简化。

用户不必自行搭建视频服务器。

一般流程如下：

1. 用户注册账户。  
2. 选择本地视频文件。  
3. 填写标题和描述。  
4. 添加关键词标签。  
5. 上传视频。  
6. 等待服务器处理。  
7. 获得可以分享的视频页面。  
   [How youtube’s web design has changed over the years. \| by Lohjeng \| Medium](https://images.openai.com/static-rsc-4/rk2d7E98WDNVixl2nv2qv25l0_47GCo22h5S0uDhdJOtCJCSpCg8ZRwQOdxZDiXLtmL1wnP7s3sEiG_0Q-W7tytDjcwXF-nnGO6BkO6R_7Zpy19ilIyGZqcAz_Kunw0zigmkYB6PIbemouJfje9IUgJiEWOeaJ0pP28wkM6A1wQ?purpose=inline)  
   [medium.com](https://medium.com/%40lohjeng/how-youtubes-web-design-has-changed-over-the-years-4d5b866dbde8?utm_source=chatgpt.com)

这套流程看起来很普通，但在2005年的互联网环境中具有很大的意义。

它把过去需要一定技术能力才能完成的视频发布工作，转变为普通用户也能使用的在线服务。

### **3.3 视频转码：为什么不同格式都能播放？**

早期数字摄像机和视频编辑软件产生的文件格式并不统一。

用户可能上传：

* AVI。  
* MOV。  
* MPEG。  
* MPG。  
* 其他常见视频文件。

如果平台直接要求观众安装各种播放器，用户体验就会很差。

YouTube因此发展出服务器端视频转码机制（Video Transcoding）。

[Design YouTube \- System Design Interview](https://images.openai.com/static-rsc-4/xs78rKsMVjoBLBo6xFBEqcRrMQqFOBpuate1Tvr5h7rTR_PQsAO9uaAyDsPmMiuWfZaXfJyty-aAf73Biaq28AlgvDMHPxk5AqkOWFudyWQOaESWuFYi5saNrHnafL2RAtDGZsiUPfSN2liuLPpE4Or0p8tuIMpME45sZkbFAMA?purpose=inline)

[blog.algomaster.io](https://blog.algomaster.io/p/design-youtube-system-design-interview?utm_source=chatgpt.com)

基本流程是：

**原始文件上传 → 服务器解码和处理 → 转换为平台支持的播放格式 → 生成缩略图 → 发布视频页面。**

这意味着用户上传一个文件之后，平台会在后台完成大量工作。

早期YouTube尤其依赖Flash Video技术。

它将上传的视频转换为适合Flash Player播放的形式，使不同用户能够在浏览器中获得相对统一的观看体验。

### **3.4 Flash Player与YouTube**

[How Your Favorite Websites Changed Over the Years \- Tutorialzine](https://images.openai.com/static-rsc-4/pE_H7MPT62TbZQrpYGkZR6KUzciJwfTnCuJbzKEsQl8ktUTk8mWh1rH9HBW9DsMr7mv7pPn64mkD8VUEKR6ZqG0Vf03H6v5hCPVj_c_KOgdX_j4J6BhOYXdbk1XaljfNYFYAh4e1Rsw0zSn4xUnDaxcn4DaDh0sTyYu-rEni1_w?purpose=inline)

[tutorialzine.com](https://tutorialzine.com/2015/03/how-your-favorite-websites-changed-over-the-years?utm_source=chatgpt.com)

2000年代中期，Flash Player已经在大量个人计算机上安装。

YouTube利用这一普及程度，让用户能够直接在网页中观看视频。

这种方式减少了用户安装不同播放器、处理不同视频格式的麻烦。

Flash在YouTube早期发展中具有非常重要的地位。

但需要区分：

* Flash是网页多媒体运行环境。  
* FLV是早期常用的视频封装格式。  
* YouTube是视频分享平台。

三者相互配合，但并不是同一种技术。

### **3.5 视频缩略图与搜索**

YouTube还为上传的视频生成缩略图（Thumbnail）。

缩略图使用户不必逐个打开视频，就能够初步判断视频内容。

[21 Years of YouTube Website Design History \- 39 Images \- Version Museum](https://images.openai.com/static-rsc-4/bm45i8oTQR4iR0co5m0RAnrS2gavYqXJotv-3iIzPhQwdDmPiBGpvQENxmfpIiPntrIVcK4YWLWndQe6e0vHI6oWE99In37cQcQmNe7WpnncF2qIuDFqYHNVa-PH_Y4POR0oNv_0wDrhDddi_Z2ZjDRS42uepT3gNaqfCMdsEdM?purpose=inline)

[versionmuseum.com](https://www.versionmuseum.com/history-of/youtube-website?utm_source=chatgpt.com)

标题、标签、缩略图和分类共同构成早期视频发现机制。

这看起来只是网站设计问题，实际上对影像文化有深远影响。

传统电视的节目通常由电视台安排。

而在YouTube中，用户面对大量可选择的视频，需要通过标题、图像和分类判断观看对象。

于是，影像作品开始与搜索、索引和数据库系统紧密结合。

## **第四节 《Me at the zoo》：YouTube的第一部视频**

### **4.1 视频的基本信息**

[Me at the zoo, a 20 años del primer video subido a YouTube](https://images.openai.com/static-rsc-4/GXsDLVzVR6t3CBoaICelabjiX_kDsRa_HMa1jBnCEF-4BsOP8BMlTEAbqlbMjkBSBYSf4Mq2in59LLRKBBBZG7jcN-jN7clktJ_wXxc6hz2Jc6wG3nNhg_MmF7QuI0_w9JzjECeuf1Zi7NyTva2T5ZnRbl1QhUQJzOGWd4qLCbA?purpose=inline)

[ambito.com](https://www.ambito.com/tecnologia/me-at-the-zoo-20-anos-del-primer-video-subido-youtube-n6137689?utm_source=chatgpt.com)

**《Me at the zoo》**

| 项目 | 信息 |
| ----- | ----- |
| 上传日期 | 2005年4月23日 |
| 上传者 | Jawed Karim |
| 时长 | 约19秒 |
| 拍摄地点 | 美国加利福尼亚州圣迭戈动物园 |
| 内容 | 大象及其鼻子的简单介绍 |
| 历史地位 | YouTube第一部上传的视频 |

视频原始页面：[Me at the zoo](https://www.youtube.com/watch?v=jNQXAC9IVRw&utm_source=chatgpt.com)

2005年4月23日，Jawed Karim上传了《Me at the zoo》。

这段视频只有约19秒。

它记录了Karim站在动物园的大象围栏前，对着摄像机讲话。

内容非常简单。

他介绍自己所在的位置，谈到动物园里的大象，并对大象的鼻子发表了一句随意的评论。

它没有复杂的剪辑、音乐、灯光或叙事结构。

但它成为了互联网视频文化史上最有代表性的早期作品之一。

YouTube官方在2015年的十周年回顾中，将这段视频称为平台历史的起点。

blog.google+1

### **4.2 为什么它具有历史意义？**

《Me at the zoo》的意义不在于它具有很高的艺术技巧。

它的重要性在于，它展示了YouTube最初希望建立的传播关系：

一个普通人可以拿起摄像机，拍摄自己的生活，然后通过互联网让其他人观看。

在传统电视时代，普通人的日常影像很难直接进入大规模公共传播系统。

家庭录像带通常只在亲友之间播放。

而在线视频平台使这些私人影像有可能进入全球公共空间。

这使个人生活第一次以如此低的技术门槛，大规模进入网络影像传播体系。

### **4.3 它算不算视频艺术？**

这是一个值得讨论的问题。

从形式上看，《Me at the zoo》具有视频记录、人物出镜和日常影像表达等特征。

但它最初并不是以艺术创作为目的制作的。

因此，我们不应该仅仅因为它是YouTube第一部视频，就将它归类为视频艺术。

更准确的说法是：

**它是一件具有重要媒介史意义的普通用户视频，也是网络个人影像文化的早期代表。**

它的历史价值在于展示了新媒介如何改变影像生产者与观众之间的关系。

## **第五节 2005—2006年：YouTube的快速成长**

### **5.1 从小型网站到大众平台**

YouTube最初并没有立即获得巨大成功。

2005年5月推出测试版本之后，平台需要不断调整产品设计，改善视频上传、播放和分享体验。

[Populaire websites toen \- RV Websolutions](https://images.openai.com/static-rsc-4/12kEdgY8X-RmjD-U-8wWL2dsizrW7DFy05d8114w3tU02PtEGIRRJL8sFRZsx2pN9sL7jCEAOKtSORic-g9CLWmxAGdqN0BOnX6FMYCHvQ86x1M6Dz8nKgnnnz5ml8nQHXYfDltDaCQgKM15swtuV2omzyQ2hR-OTYKri3k_HCk?purpose=inline)

[rvwebsolutions.nl](https://www.rvwebsolutions.nl/blog/populaire-websites-toen?utm_source=chatgpt.com)

早期发展中有几个重要变化：

* 网站逐渐允许用户上传各种类型的视频。  
* 视频页面增加了评论和评价功能。  
* 相关视频功能使观众能够继续发现内容。  
* 外部嵌入功能使视频可以出现在其他网站。  
* 平台逐渐形成自己的用户社群。

其中，相关视频（Related Videos）尤其重要。

用户看完一段视频之后，网站可以向其展示其他相关内容。

这使观看行为不再局限于用户最初选择的一个视频，而开始形成连续观看。

### **5.2 视频嵌入功能与跨网站传播**

[How to Embed a Video Into Instructables : 3 Steps \- Instructables](https://images.openai.com/static-rsc-4/8KQw-trJXBd8lydK6amt6XhFoWgkXLy1_naz5ZSlTWvthfKzHd4nouGO2HBNwrH31zOZk_lf6xSim9dlbEWmCyHLwiqvIHOwHYY8Bx-fS8dUw0MibA0BnIEs55zy3JTSaHcTHP3izvVIA6aVxoIEvNtjWPKiFD8wTaAv2rKMWhk?purpose=inline)

[instructables.com](https://www.instructables.com/How-to-embed-a-video-into-Instructables/?utm_source=chatgpt.com)

YouTube早期发展的一个关键因素，是视频嵌入功能。

用户可以把YouTube视频放入自己的博客、论坛或个人网站。

例如：

* 博主可以在文章中插入一段视频。  
* 新闻网站可以引用YouTube视频。  
* 个人网站可以展示自己制作的短片。  
* 社群论坛可以直接播放用户分享的影像。

这使YouTube的视频不再局限于YouTube网站内部。

它逐渐成为整个互联网可以调用的视频资源。

从媒介史角度看，这是一种重要的传播结构变化：

**视频文件存储在一个平台上，但观看行为可以发生在许多不同的网站上。**

### **5.3 病毒式传播（Viral Video）**

2005—2006年，YouTube逐渐出现了具有广泛传播影响力的视频。

这些视频通过邮件、博客、论坛和社交网络快速传播。

[Reconstruction of original YouTube page joins V\&A collection – The Irish News](https://images.openai.com/static-rsc-4/fiGhSjkxz0kFrlXrKiSSfQT684SQ2Y5dfrxo1Lk-FFCNmGAjJVoDSIMxucJ9y-rmyKH0xMk8yjkdsK5EABIcAvzd34uDSUeYmd_4JSiHM2d077sQZT2WuQhlLdJ4uPWdZFkrHxBA3fVpO4NXaxwXmmMq4jYfSLdyGewoBNTxc1I?purpose=inline)

[The first YouTube clip I wasever sent was "Lazy Sunday." I remember going back hometo... \- Ladies & Gentlemen... 50 Years of SNL Music \| Clip.Cafe](https://images.openai.com/static-rsc-4/SALQxPdawc5918guB2GDErtV4G-OBybnWEo7qckgERBryWPVyzv52gFebuUULpU5SSSTqDosj0rDCVBB7bEvvWnOHSUo0XMwk3TL6roqY3Hkrxu-CVDnEMO04Mx1G1yVN9VDlZCq8oX38hUw_XRo5btI6ywVAVZMFNFrgXLbRLU?purpose=inline)

[OneTouch Labs (@onetouch\_labs) on X](https://images.openai.com/static-rsc-4/NFiMEm_OPjZaTAL-66iDKL1TTJUUENhGc00Teo1SeiL1s4HmsbEAYmmRF9iSfGjZCR0V3HhvKkFzx6QZ_D2dOyZ3_6bzsVPpuS4azDPc7W4kCXIpWug78XVqgMiEk92oZnOOmQaWOn6Sa1Ilxwi0LapO-5Cuk34TEr-Ak_2gcN0?purpose=inline)

7

这一时期具有代表性的早期网络热门视频包括：

**《Lazy Sunday》（2005）**

这是美国电视节目《Saturday Night Live》中的喜剧短片。

它通过网络迅速传播，成为早期YouTube文化的重要案例。

**《The Evolution of Dance》（2006）**

由Judson Laipply表演，展示了不同年代流行舞蹈的变化。

这段视频成为早期YouTube极具代表性的热门视频之一。

这些作品说明，网络视频可以突破传统电视节目的传播范围。

一些原本只属于电视节目或个人创作环境的影像，可以在网络平台上获得新的观众。

不过，早期热门视频也引发了版权争议。例如，《Lazy Sunday》曾涉及NBC对其传播和版权的管理。

### **5.4 2006年：YouTube进入全球互联网产业中心**

[20 лет YouTube. Как появился и развивался самый популярный видеохостинг в мире](https://images.openai.com/static-rsc-4/RrzRG5q9VQe22iNYaAVeQ68eQ3KQsMApzVyt21ZG2W1E728UpdBLl6--vsWXGbs86chulBoMwizagfXeI3x6lyNUbjCfOYNCGDPL3n3V_Zm20SPsxhT7G89aUujzKtrsJLfPrfZLD0ir3woVG6YsiJptk-To9p33uwHb3IGMa_E?purpose=inline)

[vgtimes.ru](https://vgtimes.ru/articles/120555-20-let-youtube.-kak-poyavilsya-i-razvivalsya-samyy-populyarnyy-videohosting-v-mire.html?amp=1&utm_source=chatgpt.com)

随着视频数量和用户规模增长，YouTube逐渐成为互联网产业的重要公司。

平台开始面对新的问题：

* 如何承担不断增加的视频存储成本？  
* 如何处理大规模视频传输？  
* 如何管理版权争议？  
* 如何建立商业收入？  
* 如何吸引更多原创内容创作者？

这些问题推动YouTube从一个视频分享创业项目，逐渐发展为大型数字媒体平台。

## **第六节 2006年：Google收购YouTube**

### **6.1 收购背景**

[知道 Youtube 創辦人嗎 ? 陳士駿創業以 15 億美元賣給 Google \| 報時光](https://images.openai.com/static-rsc-4/6hhM8GeP7kqg0pTsDgL432VddpzxSMicswK0sYcITroWUR-cKODwT1m-b_OGnUwm8PtRWGdFSCrq5hLws6OjFdcDLFisnFxgpfYlrIbGeF6gn59lZhVEAjoV8GuTsw6YZT99hHxoH0c97X_yiXYlI-SDTe1WqFe0KPR2IPyppX4?purpose=inline)

[time.udn.com](https://time.udn.com/udntime/story/122833/9437581?utm_source=chatgpt.com)

2006年10月9日，Google宣布收购YouTube。

交易价格为16.5亿美元，以Google股票支付。

这笔交易在当时引起了互联网产业的广泛关注。

原因在于YouTube成立仅约一年多，就获得了如此高的估值。

Google当时已经拥有搜索引擎、广告系统和大型互联网基础设施。

YouTube则拥有快速增长的视频内容和用户社群。

两家公司结合之后，形成了更强大的在线视频传播体系。

### **6.2 为什么Google愿意收购YouTube？**

可以从四个方面理解。

**第一，视频是互联网的重要发展方向。**

随着宽带普及，在线视频的用户规模不断扩大。

Google认识到，视频将成为未来互联网内容的重要组成部分。

**第二，YouTube拥有庞大的用户社群。**

用户不仅观看视频，也持续上传新内容。

这种用户参与机制具有很强的增长潜力。

**第三，Google拥有成熟的广告系统。**

Google可以利用自己的广告技术，探索在线视频商业化。

**第四，YouTube具有平台网络效应。**

视频越多，用户越容易找到想看的内容；用户越多，创作者越愿意上传视频。

这种相互促进的关系，使平台具有持续增长的潜力。

### **6.3 收购完成**

2006年11月13日，Google正式完成对YouTube的收购。

[YouTube's video boom 'a social phenomenon'](https://images.openai.com/static-rsc-4/TAxXyI9lpDZtNniqbV1iSku8lezfMLzAL-9scjDNWkohL04HlO0axk0DRvyEB4gmjHPi9FbyX6s4Pk3uDyDgktfSEjRTNxavOYsXNOZ5_M7Bur-qCtqf86eVVsXdkKvwREYjLgr0VoFXN818ayEdP4HnkW9OYrCOWsYnuQUv5to?purpose=inline)

[sfgate.com](https://www.sfgate.com/news/article/youtube-s-video-boom-a-social-phenomenon-2468467.php?utm_source=chatgpt.com)

值得注意的是，Google并没有立即将YouTube完全改造成Google Video。

YouTube继续保留自己的品牌和平台社区。

这说明Google认识到，YouTube最重要的资产不只是视频技术，还包括已经形成的用户文化和创作者网络。

收购公告和完成交易的正式资料可以在美国证券交易委员会的文件中查阅。

sec.gov+1

## **第七节 版权危机：用户生成内容与传统媒体的冲突**

### **7.1 用户上传的视频不一定拥有版权**

YouTube的开放上传机制带来了一个重大问题。

用户可以上传自己的视频，也可能上传其他人制作的内容。

例如：

* 电影片段。  
* 电视节目。  
* 音乐录影带。  
* 体育赛事。  
* 商业广告。  
* 动画作品。  
  [Youtube layout: beta \| Peter Forret \| Flickr](https://images.openai.com/static-rsc-4/AsDG3SSqAtffFEskq3R4N0SQViLeuytyOJIHBNx08qXi_9OtVX1xtL3WmE-hNzWY3XYk2qI1vWqWcLMHzhcyDRfrBr2IyhQ8xxBh70UrHHAvd2eB5vl8FQfaUj6Wm9SRS3amN9wyBZLGhT_DfJe0-jINhI_fGABbUZOEVYCpEO8?purpose=inline)  
  [flickr.com](https://www.flickr.com/photos/pforret/547121331/?utm_source=chatgpt.com)

这使传统媒体机构开始关注YouTube。

一方面，平台为影视作品提供了新的传播渠道。

另一方面，未经授权的内容上传可能侵犯版权持有人的权利。

### **7.2 Viacom诉YouTube**

2007年，媒体集团Viacom对YouTube及Google提起诉讼。

Viacom认为，YouTube存在大量未经授权上传的受版权保护内容，并要求承担相应法律责任。

[YouTubeに対するバイアコムの著作権訴訟はまたしてもYouTubeに軍配 \- GIGAZINE](https://images.openai.com/static-rsc-4/HPkbOaZql6LtpLLsmZ9xsL6Sww4-NYggtiR0Z4yg9VEoBiJOSdQAUzFeWp0UouA31MfXt5a3oOh8uVXEkFQmDYpXR8myO8D1yhdxdK65vwa9cGXE8faQHYwNlk7MyJ-Y1K9Uz1eEbl8EllBFQKcA42YEx-ydXEPPrLb06SVUxlY?purpose=inline)

[gigazine.net](https://gigazine.net/news/20130419-youtube-win-over-viacom-lawsuit/?utm_source=chatgpt.com)

这场诉讼成为早期在线视频产业的重要法律事件。

它涉及一个核心问题：

当用户上传侵权内容时，平台应该承担什么责任？

平台是否只是一种提供存储和传播服务的技术中介？

还是应该对用户上传的内容承担更积极的管理义务？

这类问题后来成为互联网平台法律制度的重要组成部分。

### **7.3 DMCA与平台责任**

美国《数字千年版权法》（Digital Millennium Copyright Act，DMCA）于1998年通过。

其中的第512条规定了符合特定条件的网络服务提供者可以适用的责任限制机制。

它包括通知与删除（Notice and Takedown）等制度。

简单来说，版权持有人可以向平台提交符合要求的侵权通知，平台需要按照法律规定处理。

但DMCA并不是允许平台不受任何限制地传播内容。

平台是否能够获得相关责任限制，需要满足法律规定的条件。

### **7.4 Content ID的出现**

随着平台规模扩大，单纯依靠人工处理侵权通知已经越来越困难。

YouTube后来发展出Content ID系统。

[How to use the YouTube Copyright Match Tool](https://images.openai.com/static-rsc-4/F2sQms8t5sU3ifKMSK55guGCpyinp_iAC-JjgoA2Lex_POpVWnGTcjc2Pj4v9xAZBAQb7YtWZeqf09V5hvtOsmdfy2F6rPSAUGXsq1PMlE-nIvyHNUEt4s3Sq-0QgkvxIxTdcwrwPXFpJiHtNGVr_BtR9YGqeyhxS2UdOW4cy4g?purpose=inline)

[peggyktc.com](https://www.peggyktc.com/2020/10/how-to-use-youtube-copyright-match-tool.html?utm_source=chatgpt.com)

Content ID通过识别上传视频中的音频和视频信息，与版权持有人提供的参考文件进行比对。

如果发现匹配，版权持有人可以根据自己的政策：

* 追踪视频观看数据。  
* 对视频进行商业变现。  
* 在某些地区限制播放。  
* 要求移除相关内容。

Content ID后来成为YouTube管理版权的重要工具。

从艺术史角度看，这一技术带来了新的问题：

如果艺术家利用电影、电视和网络影像进行拼贴、挪用和重新创作，平台的自动版权识别机制会怎样影响这些作品？

这使版权管理不再只是法律问题，也成为数字艺术传播环境的一部分。

## **第八节 2007年：YouTube开始建立创作者经济**

### **8.1 YouTube Partner Program**

[Timeline: History of YouTube \| Timetoast](https://images.openai.com/static-rsc-4/VUh6EwT8NjIvqyJcABLlbN_vuY0sADyag17Xca69HLKti94HO5cmmuPYKN_shaFmkrn-byXa3i8sLsTyE5gV21QENVAy7y0sTWJVn7SyKRPZdBFQ6J-MzxmKTL1q7c4cdsIsonREma1uVxgmqScEXHHqWp4kuIhQXx1UTbP62x4?purpose=inline)

[timetoast.com](https://www.timetoast.com/timelines/history-of-youtube?utm_source=chatgpt.com)

2007年，YouTube开始推出合作伙伴计划（YouTube Partner Program，YPP）。

它允许符合条件的原创视频创作者通过视频广告获得收入。

2007年12月，YouTube宣布扩大计划，使美国和加拿大符合条件的创作者能够申请加入。

这意味着YouTube开始从单纯的视频分享平台，逐渐转向能够支持职业内容生产的商业生态。

### **8.2 创作者经济的形成**

在传统电视产业中，节目制作人员通常依靠电视台、制作公司和广告商获得收入。

而在YouTube环境中，个人创作者也可以通过自己的频道建立观众群体，并参与广告收入分配。

[¿Cuál fue el primer video que se subió a YouTube y cuántas vistas tiene? \| El Informador](https://images.openai.com/static-rsc-4/7V0SRXlF-80I7P9Dwk3dhLzUGBPOPAM-gNjQVpkDdwhIrrcdRlINuLIfbFx0Vq5mEewOgvte6nj2gOc6he5GVAWUlidfg5ZelUx6cVxcCFQGlxQ1FQQSmpFDQiuVBeKq5yf_YWimWmKbiMzHcyDvZAiJPUuFpw-n2-g_gnQ86sw?purpose=inline)

[informador.mx](https://www.informador.mx/tecnologia/cual-fue-el-primer-video-que-se-subio-a-youtube-y-cuantas-vistas-tiene-20260331-0095.html?utm_source=chatgpt.com)

这带来了几种新现象：

1. 个人创作者开始形成自己的频道。  
2. 创作者与观众建立持续关系。  
3. 视频发布逐渐形成固定频率。  
4. 部分创作者开始以视频制作作为职业。  
5. 观看量和订阅者数量成为创作者关注的指标。

   ### **8.3 视频创作者成为新的文化生产者**

这一变化对文化生产结构具有重要影响。

过去，普通人很难独立建立一个具有广泛影响力的电视节目。

YouTube使个人能够通过持续发布视频建立自己的观众群体。

这种模式后来发展为网络创作者（Content Creator）和视频博主（YouTuber）文化。

它也影响了艺术家。

艺术家不再只能依靠美术馆、画廊和艺术节展示影像作品，也可以建立自己的频道，持续发布作品和创作过程。

不过，商业化同时带来了新的限制：创作者可能需要考虑播放量、广告适宜性和平台规则。

**这意味着创作者获得了新的传播自主权，但同时也进入了新的平台依赖关系。**

资料：YouTube于2007年12月10日发布的合作伙伴计划扩展公告。

youtube.googleblog.com+1

## **第九节 2008—2010年：YouTube逐渐成为大众文化基础设施**

### **9.1 视频类型的多样化**

[How the world changed around Far Lands or Bust \| Bevan Philip](https://images.openai.com/static-rsc-4/a3S3EAVIqLDzbfR1NHKy1fE-pWkLMukhTpzawoN_co58QkDusbt_IBI60o7iCQPEVozUpKKvQYcwFkZMf0_Ia0-OgV20gsomf-vQNVs2_BDax33_oDjlPMx_VpFMOgg0LWYG7WDFHtcKfg2mRyDR8jlDyx_AUABatXgV3j6nzuk?purpose=inline)

[ClioMakeUp conquista 1 milione di iscritti su YouTube](https://images.openai.com/static-rsc-4/BN4NEkyf3NSxjFROUtl2k0Z84yGD2N659xNOaD7_b-rUQ0y6rK2voqWLTOTAB4B9OzeDSGGDmw2dZkuzwBjlO3sq5EkuAu7kXljdrEH79EBetHxB8qv-ZmgMGY7Rxw1H-b61id3ULB1XFEfbQ3L4Hg22khZyqj8LrpZ8rwfjbdg?purpose=inline)

[OneTouch Labs (@onetouch\_labs) on X](https://images.openai.com/static-rsc-4/NFiMEm_OPjZaTAL-66iDKL1TTJUUENhGc00Teo1SeiL1s4HmsbEAYmmRF9iSfGjZCR0V3HhvKkFzx6QZ_D2dOyZ3_6bzsVPpuS4azDPc7W4kCXIpWug78XVqgMiEk92oZnOOmQaWOn6Sa1Ilxwi0LapO-5Cuk34TEr-Ak_2gcN0?purpose=inline)

10

随着用户规模扩大，YouTube上的视频类型逐渐多样化。

主要包括：

**个人生活影像**

用户记录自己的日常生活、旅行、家庭和个人经历。

**游戏视频**

用户录制游戏过程、攻略和评论。

**音乐视频**

个人音乐表演、翻唱和音乐创作开始获得大量观众。

**教育视频**

用户通过视频讲解知识、技能和专业内容。

**动画与独立短片**

独立动画师和电影创作者利用平台传播自己的作品。

**评论与文化批评**

用户通过面对镜头讲话、剪辑和影像拼贴表达观点。

这些内容逐渐形成一种不同于传统电视的网络视频文化。

### **9.2 视频博客（Vlog）的发展**

[lonelygirl15: The Pleasures and Perils of Participation – Flow](https://images.openai.com/static-rsc-4/oj8p8bEzqKeUpmcTn0zIo6AQ-wmDaFWd77VFrUZ_P0NFfqJQlGF4VXY4aX5cEbqNTuugnqV8k4e8ywiQxb__rYgTZBX3yFoIu1AOx2FkAGaKCVuabZhEaha8T2joPKYFX1Fho46FobaKxeTGqkYdMxvNf8eZYcbeF5uLFk1n1cQ?purpose=inline)

[flowjournal.org](https://www.flowjournal.org/2006/09/feature-lonelygirl15-the-pleasures-and-perils-of-participation/?utm_source=chatgpt.com)

Vlog逐渐成为YouTube早期的重要视频形式。

创作者经常直接面对摄像机讲话，记录自己的生活、观点和个人经历。

与传统电视节目相比，早期Vlog通常具有：

* 较低的制作成本。  
* 较强的个人表达。  
* 较少的专业制作流程。  
* 更直接的观众交流。  
* 持续更新的内容形式。

Vlog改变了观众与影像创作者之间的关系。

观众不再只是观看一个完成的节目，也可能长期关注某个创作者的生活和个人经历。

从艺术史角度看，这种变化使身体、身份、日常生活和自我展示成为网络影像的重要主题。

### **9.3 观看行为的变化**

传统电视通常通过节目表组织观看行为。

YouTube则让用户自主选择观看内容。

[21 Years of YouTube Website Design History \- 39 Images \- Version Museum](https://images.openai.com/static-rsc-4/TVjl0SXl8vlMlb-qFX6Kigd9WTpDzUX-6zGk7PacJrGN3zZT1Ccpi7z6QYFae5O8Qm7uBcX2B3v1zWMUlHh27Bp-ywbM3pW4IQwlHNUv9VwXq-eHdLjUDaFM_tO1CXum5keZopVf0mFhtEsvnLhzpIuU9LY9zSNTN2rFbtcjmxs?purpose=inline)

[versionmuseum.com](https://www.versionmuseum.com/history-of/youtube-website?utm_source=chatgpt.com)

用户可以：

* 搜索视频。  
* 观看相关视频。  
* 收藏视频。  
* 订阅频道。  
* 发表评论。  
* 将视频分享给其他人。

这使观看行为从一次性的节目消费，逐渐转变为持续性的网络活动。

平台开始通过用户行为建立内容推荐机制。

这种机制后来对现代互联网文化产生了极大的影响。

### **9.4 2009年：YouTube进入高清时代**

随着网络带宽、摄像设备和视频编码技术的发展，YouTube逐渐提高视频播放质量。

[21 Years of YouTube Website Design History \- 39 Images \- Version Museum](https://images.openai.com/static-rsc-4/Vmle37yoyA43RdbghDOVCCDnS5QJHUH6ag6CvSIP-91L1Kc8BIzpLGB7WyKctf_pe0-IqdAxXV_5D5S1l2cwWMZSHip_N9ytzpRBWQXVviVT2mkrINZ77ZZ7yYRrV2s6wgsYPkaZEyxh9fwVTRD--KBd8tvV53HQDIEUTNviaew?purpose=inline)

[versionmuseum.com](https://www.versionmuseum.com/history-of/youtube-website?utm_source=chatgpt.com)

YouTube在2009年前后开始支持更多高清视频播放能力。

这使网络视频不再局限于早期的小尺寸、低分辨率影像。

对于艺术家而言，这具有重要意义。

过去，网络视频常常因为画质有限而难以承担复杂的视觉表现。

高清播放逐渐改善了这一限制，使独立电影、实验动画和视觉艺术作品能够获得更好的网络展示条件。

### **9.5 2010年前后的平台文化**

到2010年前后，YouTube已经从一个新兴的视频分享网站发展为重要的大众文化平台。

它开始同时承担多种角色：

* 视频托管服务。  
* 大众娱乐平台。  
* 个人影像传播渠道。  
* 创作者经济平台。  
* 网络社交空间。  
* 文化档案和资料库。

YouTube也逐渐成为传统媒体的重要竞争者和合作伙伴。

电视节目、音乐公司、电影制片机构和新闻媒体开始更加重视网络视频传播。

## **第十节 YouTube与当代视频艺术**

这一节是本章最重要的艺术史部分。

YouTube本身并不是一个专门的视频艺术平台，但它改变了视频艺术的创作和传播环境。

### **10.1 传统视频艺术的展示方式**

在YouTube出现之前，视频艺术主要通过以下方式展示：

* 美术馆。  
* 画廊。  
* 艺术节。  
* 独立电影节。  
* 录像带和DVD。  
* 艺术机构收藏。  
* 专业艺术出版物。  
  [Media Preservation Initiative \| Whitney Museum of American Art](https://images.openai.com/static-rsc-4/GiH1rFhz459fKQrxHfDC8Xl0_gyPPyHxyok7vHu8wldHkXHtUEsQOiuDn8aTBNgtOIyca729_gHYL07r-AqaVTGSmJ3pLUixyJUsjQmqhnHOaA-NBjVf9JwpUrBc8sB40Sr0XejAUjPoinUtedHKvs3P3ovbhxKPs2cdxISPgss?purpose=inline)  
  [whitney.org](https://whitney.org/conservation/mpi?utm_source=chatgpt.com)

例如，白南准（Nam June Paik）的录像装置作品通常需要通过多台显示器、电视机、影像设备和特定空间布局进行展示。

作品的意义不仅来自视频内容，也来自显示设备与观众身体之间的空间关系。

YouTube无法完全替代这种展示方式。

但是，它能够使艺术家通过网络向更多观众传播作品片段、记录和相关资料。

### **10.2 影像作品从展览空间进入个人屏幕**

[25 jaar WWW: van krakerig inbellen naar supersnel streamen](https://images.openai.com/static-rsc-4/abHoee3E-nUGwYi1sqHe1AxC0G-xG6IQJcnR59crhL8YrXdmDg3ngbS1WGeJNxihA_DvfeOcE07NQ6rsHQu-UNYaHCf_4OVK6VIjlgpi325k4JlDiG0s3DaJ8bMpqIsvyk4jAczz5qXIhjxSt5FDf7h5io6Nz_i7R-twZcL60rU?purpose=inline)

[nos.nl](https://nos.nl/artikel/2127737-25-jaar-www-van-krakerig-inbellen-naar-supersnel-streamen?utm_source=chatgpt.com)

YouTube使观众可以通过自己的计算机观看视频艺术。

这种变化产生了几个重要影响：

第一，观众不必前往特定展览地点。

第二，作品可以在较长时间内持续访问。

第三，艺术家可以直接建立自己的传播渠道。

第四，作品能够通过链接在不同网站之间传播。

第五，观众可以通过评论参与作品讨论。

但是，个人计算机观看和美术馆观看并不是相同的艺术经验。

例如，一件大型多屏幕录像装置被压缩成一个小型网页视频之后，可能失去原来的空间关系。

因此，艺术作品的网络传播需要考虑作品原有的展示形式。

### **10.3 Found Footage与网络影像再创作**

Found Footage（拾得影像）是利用已有影像材料进行重新剪辑、组合和创作的艺术实践。

[Non-Aligned Histories Converse at NTU CCA Singapore \| Ocula](https://images.openai.com/static-rsc-4/IGKH6uGMXmooqNz8txl2oSCtlhjbdWoe66L_fxlfV3yw4UAu0ELUjCpPf5Pz6LTcj79RICXu-_Z2JFWSLHOCiv5pi7R9J-Au54CZRugEbuu2Ly8l9NyvT0KZXdns0VsX1SkmpmDnFy6DBIzuYdR9w76T7L3tK0cehiKrTJ1iqpM?purpose=inline)

[ocula.com](https://ocula.com/magazine/spotlights/non-aligned-at-ntu-cca-singapore/?utm_source=chatgpt.com)

YouTube的出现，使大量历史影像、个人录像、新闻片段和大众文化材料更加容易被发现。

艺术家可以从网络上寻找：

* 历史新闻录像。  
* 电视节目。  
* 广告片段。  
* 家庭录像。  
* 个人拍摄视频。  
* 互联网流行影像。

然后将这些材料重新组织，形成新的作品。

这种创作方式与传统电影拼贴和录像艺术存在历史联系。

但网络平台也带来了版权和作品来源方面的新问题。

### **10.4 YouTube作为数字档案**

YouTube上保存了大量具有历史价值的影像。

例如：

* 早期个人录像。  
* 电视节目片段。  
* 历史事件记录。  
* 独立电影。  
* 网络表演。  
* 早期动画。  
* 个人创作。  
  [Victoria and Albert Museum Inangkin ang Unang YouTube Watch Page na “Me at the zoo” \| Hypebeast](https://images.openai.com/static-rsc-4/4f2eh6nfv_FKGCaVzIhZfNsjKs-GKtJJJrnzDoR8eAgslk2KeiGjncL1X5QCfQg-4QUvfysWw_gMco0ueGkZREOQa3k_o3xjYAk-8PNV6F9I2K0ZVMe9lplet8inf8Oiz_Xym3GqpcceyGHGxrtOjyT0c2P5hCi3wZ7dCUnjcEA?purpose=inline)  
  [hypebeast.com](https://hypebeast.com/ph/2026/2/victoria-and-albert-museum-acquires-an-early-youtube-watch-page-me-at-the-zoo-video?utm_source=chatgpt.com)

这使YouTube在某种程度上成为数字文化档案。

但它并不是一个可靠的永久档案馆。

视频可能因为版权问题、用户删除、账户关闭、平台政策和技术变化而消失。

因此，研究者不能将YouTube上的视频简单视为永久保存的历史资料。

对重要的网络艺术作品，需要进一步保存原始视频文件、元数据、创作说明、网页截图和作品运行环境。

## **第十一节 YouTube早期发展时间线**

[Thumbnail Ninja (@thumbnailninja) on X](https://images.openai.com/static-rsc-4/RXBG5PFBEDLLJnYLh9Vf03gkgiGZ2A9i-QfIjF1CkH8aBmL0Qusdm9qsfr8TkL-CII9P4akDUgtBVafEkxnelDhOi3FCUI3YSf-dBil92tD3_9_fyhqBje21Vs8NkOvyfRfHRiE_uPQyzSeUHH7BjHggHAteLoC9Gj9mPMYs5E8?purpose=inline)

[x.com](https://x.com/thumbnailninja/status/1992553196007616643?utm_source=chatgpt.com)

| 时间 | 重要事件 | 历史意义 |
| ----- | ----- | ----- |
| 2005年2月14日 | YouTube注册成立 | 平台正式开始发展 |
| 2005年4月23日 | 《Me at the zoo》上传 | 第一部YouTube视频 |
| 2005年5月 | Beta测试版上线 | 早期用户测试 |
| 2005年12月 | 向公众正式开放 | 平台进入公开发展阶段 |
| 2006年10月9日 | Google宣布收购 | 交易估值16.5亿美元 |
| 2006年11月13日 | Google完成收购 | YouTube进入Google体系 |
| 2007年 | YouTube Partner Program试点 | 创作者商业化开始 |
| 2007年12月 | 合作伙伴计划扩大 | 创作者收入机制发展 |
| 2008年 | 视频内容与创作者群体进一步扩大 | 大众网络视频文化形成 |
| 2009年 | 高清视频播放能力发展 | 网络影像质量提升 |
| 2010年 | YouTube成为重要大众文化平台 | 平台化视频传播逐渐成熟 |

## **第十二节 本章总结：YouTube真正改变了什么？**

YouTube最重要的历史贡献，不是发明了视频，也不是发明了流媒体。

它改变的是视频的生产、传播和观看组织方式。

可以从六个方面总结。

**第一，降低了视频发布门槛。**

普通用户不再需要自行建立视频服务器和播放器。

**第二，建立了全球视频分享环境。**

视频能够通过链接、嵌入和分享功能在不同网站之间传播。

**第三，改变了影像生产者的身份。**

普通用户也可以成为视频创作者。

**第四，改变了视频的商业模式。**

广告和合作伙伴计划使个人视频创作逐渐具备职业化可能。

**第五，改变了影像的发现方式。**

搜索、相关视频和推荐机制开始影响观众接触作品的路径。

**第六，改变了艺术作品的传播环境。**

艺术家获得了新的展示渠道，同时也开始受到平台规则、版权管理和商业机制的影响。

### **本章最重要的历史判断**

YouTube不是流媒体技术的发明者，也不是网络艺术的起点。

它的重要性在于，将已经存在的数字视频、宽带网络、Flash播放器和用户上传机制整合为一种大众化的平台服务。

由此，互联网视频从技术性的网络应用，逐渐发展成为一种日常文化实践。

对于流媒体视频艺术而言，YouTube带来的最大变化是：**网络开始成为艺术作品生产、展示、传播和接受的完整社会环境。**

## **主要参考资料**

以下资料优先采用YouTube官方历史记录、美国证券交易委员会文件和博物馆档案。

1\. YouTube官方：《YouTube at 15: My personal journey and the road ahead》，2020年。

[YouTube成立15周年历史回顾](https://blog.youtube/news-and-events/youtube-at-15-my-personal-journey/?utm_source=chatgpt.com)

2\. YouTube官方：《YouTube A to Z》，2015年。

[《Me at the zoo》与YouTube早期历史](https://blog.google/products-and-platforms/products/youtube/youtube-to-z-happybirthdayyoutube/?utm_source=chatgpt.com)

3\. 美国证券交易委员会：Google收购YouTube公告，2006年10月9日。

[Google To Acquire YouTube for \$1.65 Billion in Stock](https://www.sec.gov/Archives/edgar/data/1288776/000119312506206884/dex991.htm?utm_source=chatgpt.com)

4\. 美国证券交易委员会：Google完成收购YouTube，2006年11月13日。

[Google Closes Acquisition of YouTube](https://www.sec.gov/Archives/edgar/data/1288776/000119312506238320/dex991.htm?utm_source=chatgpt.com)

5\. YouTube官方：《Partner Program Expands》，2007年12月10日。

[YouTube合作伙伴计划扩展公告](https://blog.youtube/news-and-events/partner-program-expands/?hl=lt&utm_source=chatgpt.com)

6\. 维多利亚与艾尔伯特博物馆（V\&A）：YouTube早期网页与第一部视频的收藏研究。

[Acquiring an early YouTube watch page and its first-ever video](https://www.vam.ac.uk/articles/acquiring-an-early-youtube-watch-page-and-its-first-ever-video?utm_source=chatgpt.com)

7\. Steve Chen联合创始人声明，Viacom诉YouTube案件相关法律文件。

[Steve Chen关于YouTube创立过程的声明](https://cases.justia.com/federal/district-courts/new-york/nysdce/1%3A2007cv02103/302164/225/3.pdf?utm_source=chatgpt.com)

## **下一章**

**007 Vimeo与独立网络影像文化的形成（Vimeo and the Development of Independent Online Video Culture）**

下一章将重点研究Vimeo，而不是重复YouTube的历史：

* Vimeo的创立背景与早期定位。  
* Vimeo与YouTube的产品和文化差异。  
* 独立电影与实验影像创作者。  
* Staff Picks与策展机制。  
* Vimeo与艺术院校、电影节和视觉设计产业的关系。  
* Vimeo如何成为网络影像艺术的重要展示渠道。

这一章之后，我们将进一步研究网络视频平台如何从大众视频分享工具，发展为独立艺术家和专业影像创作者的展示空间。

