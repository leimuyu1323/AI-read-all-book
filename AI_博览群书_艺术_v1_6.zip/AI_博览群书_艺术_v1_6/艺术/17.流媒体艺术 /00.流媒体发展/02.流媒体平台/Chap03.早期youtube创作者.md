# **02\. 流媒体视频艺术（Streaming Video Art）**

# **007 早期YouTube创作者与视频文化**

*Early YouTube Creators and Video Culture (2005–2010)*

[The V\&A adds YouTube's first video to its digital archive \| Wallpaper\*](https://images.openai.com/static-rsc-4/gF2oTb9NfKS1YUhF9mIm32xUf5_GhlZAUEfROjHksZo25US9BB1cRJ_5KT_tFeSirahQfGfVyGgB3NiVzuXrVAzXz6miZN51fcS10XUaywQIx5svc2cRihfZFI-ktxz1Tc71mdosMry-EAfrcfNQT0Ch0kYUUyTcDlhsRJLjaSY?purpose=inline)

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s](https://images.openai.com/static-rsc-4/08pspF-ANFfll6Yf3iO3W0DP7TMjgdKueRuTLDVQohlJkZ4e3yYBzY-lkdJwYdGihGRBwVR6zgcU8FiL92tM6SJOpFeYThLLOSPFn1y1At4sjiN8e_tzPDQcpoGWaKCxnjgL1Yfyw6rh9THie-Qn3px8FkKiwfSYZNvo1XaWS0w?purpose=inline)

[Two Israeli Women Attract Over Ten Million Viewers On "You Tube"](https://images.openai.com/static-rsc-4/BU4iMNK4zxilBTQZ_zBEhlpX0TKPe2a4YS40sYntI2wXRiDWyznHA-oho-_kiuy4Zj3KJFUfRmChMqpYD-ihqLeYGNLCHp4PGBCqvh0Rr3XjuhoLw8QyqZWvtkJINLKaRlxCDj5tE7AsziWmSOCMQ0HOKI_6y8Fh77pxWDmLFAPDHxGobWwG_1K_vSh0kPlL?purpose=inline)

12

## **导言：普通人如何成为影像创作者？**

2005年YouTube出现之后，互联网视频传播发生了一个重要变化：普通用户不再只是视频的观看者，也开始成为视频的生产者。

在传统电视产业中，视频制作通常需要摄影设备、制作团队、电视台、发行渠道和商业机构。个人当然也可以拍摄家庭录像，但这些影像通常只在私人空间中传播。

YouTube改变了这种状况。

一个普通人只需要一台摄像机、一台计算机和互联网连接，就可以制作视频、上传作品，并向全球观众展示。

2005年至2010年，YouTube逐渐形成了早期创作者文化（Early Creator Culture）。这一时期出现了许多具有代表性的视频类型：

* 个人视频博客（Vlog）。  
* 个人喜剧和表演视频。  
* 网络模仿与恶搞视频。  
* 音乐翻唱和原创音乐。  
* 游戏录像与游戏评论。  
* 教学与知识分享。  
* 家庭录像和日常生活记录。  
* 独立动画与实验影像。

这一时期最重要的变化，不只是视频数量增加，而是影像创作者的社会身份发生了改变。

普通人开始能够建立自己的频道、培养固定观众，并逐渐形成一种新的职业身份：YouTuber。

从流媒体视频艺术史的角度来看，这一时期也具有特殊意义。个人影像、身体展示、日常生活、网络身份和观众互动，开始成为互联网影像文化的重要组成部分。

本章将重点研究2005—2010年的早期YouTube创作者、代表性视频和创作类型，并区分大众网络视频文化与严格意义上的视频艺术。

## **第一节 早期YouTube创作者的形成**

### **1.1 从普通用户到视频创作者**

在传统媒体体系中，影像生产者通常具有相对明确的职业身份：

* 电影导演。  
* 电视节目制作人。  
* 摄影师。  
* 记者。  
* 电视台主持人。  
* 广告制作人员。

YouTube出现以后，影像创作者的范围迅速扩大。

普通学生、家庭用户、业余演员、音乐爱好者和游戏玩家都可以制作视频。

[Jovens, vídeos e fama no YouTube \- RTP Ensina](https://images.openai.com/static-rsc-4/8DzhXte7_r4tWQzbV5FULnas548gYbzbbJajvVKfsUOffYJA4rjhMElTEUUU4icEdp6kTJ6gIdj1SaJsRsNDkksjiNBxcq4ypeZIQ9Lp-8DQ1RrmwAUIyIeuM4cj71dQi44A8C60JL2VETd9aTRTIcBkPJh3ZVquIejJtm0pQ14?purpose=inline)

[ensina.rtp.pt](https://ensina.rtp.pt/artigo/jovens-videos-e-fama-no-youtube/?utm_source=chatgpt.com)

早期YouTube创作者通常使用相对简单的设备：

1. 电脑摄像头（Webcam）。  
2. 数码摄像机。  
3. MiniDV摄像机。  
4. 数码相机。  
5. 个人计算机上的视频编辑软件。  
6. 普通麦克风。

很多早期视频并没有专业灯光、录音设备或复杂的剪辑。

创作者直接面对镜头讲话，或者记录自己的生活。

这种低成本制作方式使影像生产逐渐脱离专业媒体机构的垄断。

### **1.2 个人计算机与家庭影像工作室**

[DV Video digitalisieren – Anleitung, Technik & Tipps](https://images.openai.com/static-rsc-4/CE623ZgCRVtfNaOx0XeLs_FT0qRffnoMG0ii8q2BEmyYWxiACiLa--R6s5onagBLxnVAqm3x5W2XO39HVtwfnhnn6bklt4sANZvUGHJNlSRVXWT8nU_pi7-iRKKaCvI2vxEgKC8S2r3Ys3lBc8BLb6f1_SIx2_MNX_vwWzGhvFQ?purpose=inline)

[film-retter.de](https://www.film-retter.de/dv-video-digitalisieren.html?utm_source=chatgpt.com)

早期YouTube创作者的制作环境通常是家庭或卧室。

一个典型的制作过程是：

* 使用摄像机拍摄。  
* 将视频导入计算机。  
* 使用编辑软件剪辑。  
* 添加音乐、字幕和片头。  
* 将视频转换为适合网络上传的格式。  
* 上传到YouTube。

当时常见的个人视频编辑软件包括：

* Windows Movie Maker。  
* iMovie。  
* Adobe Premiere。  
* Final Cut Pro。

这些工具的普及，使普通用户能够在家庭环境中完成相对完整的视频制作。

### **1.3 创作者与传统电视制作人的区别**

早期YouTube创作者与传统电视节目制作人存在一些重要区别。

| 比较维度 | 传统电视制作 | 早期YouTube创作 |
| ----- | ----- | ----- |
| 制作主体 | 电视台、制作公司 | 个人或小团队 |
| 制作预算 | 通常较高 | 通常较低 |
| 发布渠道 | 电视广播 | 网络平台 |
| 发布频率 | 按节目安排 | 创作者自主决定 |
| 观众互动 | 相对有限 | 评论、订阅、回复 |
| 内容控制 | 受机构制度影响 | 创作者具有较多自主权 |
| 传播范围 | 受广播网络影响 | 可跨地域传播 |

但是，YouTube并没有完全消除传统媒体的影响。

许多早期热门视频实际上来自电视节目、商业广告和其他专业媒体内容。

因此，早期YouTube文化既包括普通用户的原创影像，也包括传统媒体内容在互联网中的重新传播。

## **第二节 个人视频博客（Vlog）的兴起**

### **2.1 什么是Vlog？**

Vlog是Video Blog的缩写，中文通常称为视频博客。

它是将个人博客的表达方式转化为动态影像的一种形式。

传统博客主要通过文字和图片记录个人生活，而Vlog则通过视频展示创作者的日常活动、观点、经历和情绪。

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s](https://images.openai.com/static-rsc-4/08pspF-ANFfll6Yf3iO3W0DP7TMjgdKueRuTLDVQohlJkZ4e3yYBzY-lkdJwYdGihGRBwVR6zgcU8FiL92tM6SJOpFeYThLLOSPFn1y1At4sjiN8e_tzPDQcpoGWaKCxnjgL1Yfyw6rh9THie-Qn3px8FkKiwfSYZNvo1XaWS0w?purpose=inline)

[gizmodo.com](https://gizmodo.com/heres-what-people-thought-of-youtube-when-it-first-laun-1832019272?utm_source=chatgpt.com)

早期Vlog常见的形式是：

创作者坐在房间里，面对电脑摄像头讲话，向观众介绍自己最近的经历或表达某种观点。

这种视频制作非常简单，但它建立了一种新的媒介关系。

观众不再只是观看一个由专业机构制作的节目，而是持续观看某个具体个人的生活和表达。

### **2.2 Vlog的主要视觉特征**

早期Vlog具有几个比较明显的视觉特点。

**第一，正面镜头。**

创作者通常直接面对镜头讲话，形成一种类似面对面交流的感觉。

**第二，固定机位。**

许多视频使用电脑摄像头拍摄，机位通常不会移动。

**第三，家庭空间。**

卧室、书房和客厅成为常见的拍摄场所。

**第四，低成本制作。**

视频不一定经过复杂剪辑，甚至可能保留停顿、口误和环境噪声。

**第五，个人化叙述。**

内容围绕创作者自己的经历、感受和观点展开。

[Lonelygirl15 : la première star de YouTube était un hoax](https://images.openai.com/static-rsc-4/ELFnO-tT33yBa3oor-OaCFLgbpTo4TwBrLwkI7PK__uasz4xPmNuiikDz8KYNFlVdagpfhl5aLLGOSN2hvSAhCYQUkov2FG5v9kjaGXD7fv4s6-0qjTEzlSMfwjsXR88nR5yLJMgUxPgTDXUE_tICI-kokTXp-0iFIsEO1UqkP0?purpose=inline)

[lemonde.fr](https://www.lemonde.fr/festival/article/2017/08/02/lonelygirl15-la-premiere-star-de-youtube-etait-un-hoax_5167647_4415198.html?utm_source=chatgpt.com)

### **2.3 Lonelygirl15：网络身份与虚构现实**

[The Pandemic Has Been Very, Very Good for the Creator Economy \- Bloomberg](https://images.openai.com/static-rsc-4/_2Fe8Y3yzXYw6IFmxnysFVTq804aoaW6GO5Hc283COpaZOWh88AulDYEPoJosGSCezs6QXRVF_1dG45Pa6F3OqQHDVHIWRwPGys8GqZCdZwhjYcdTgkodRwmrWc_P4DmO4fpLJ0WHVEid3dOIeq6cIcHGhk13ppOEiEixFa3Foc?purpose=inline)

[bloomberg.com](https://www.bloomberg.com/news/newsletters/2021-08-29/the-pandemic-has-been-very-very-good-for-the-creator-economy?utm_source=chatgpt.com)

2006年，一个名为Lonelygirl15的YouTube频道开始引起关注。

频道中的主要人物名为Bree。

早期视频采用个人视频博客的形式，Bree坐在卧室中面对摄像机讲话，分享生活、家庭和个人情绪。

视频具有一种非常真实的私人记录感。

观众最初普遍将其理解为一个普通年轻女孩的网络日记。

但后来逐渐揭示：Lonelygirl15实际上是一部经过编排的网络连续剧，Bree的角色由演员Jessica Rose扮演，视频背后有专业创作团队。

这一事件成为早期YouTube文化中极具代表性的案例。

它引发了几个重要问题：

1. 网络视频中的人物是否真实？  
2. 观众如何判断个人影像的真实性？  
3. 当虚构故事采用个人博客形式时，它与真实生活记录有什么区别？  
4. 网络观众是否会主动参与故事的解释和传播？

从艺术史角度来看，Lonelygirl15值得研究，因为它模糊了个人影像、表演、虚构叙事和网络身份之间的界限。

它也可以被放在网络表演（Network Performance）和跨媒体叙事（Transmedia Storytelling）的历史背景中理解。

### **2.4 Vlog与自我表演**

Vlog并不是简单地记录一个人的真实生活。

创作者选择拍摄什么、不拍摄什么，如何组织语言，如何面对镜头，实际上都涉及自我呈现（Self-presentation）。

摄像机成为个人展示身份的工具。

因此，Vlog具有一种特殊的媒介结构：

**创作者既是影像的生产者，也是影像中的表演者，同时还是自己生活的叙述者。**

这一点使早期Vlog与录像艺术中的身体表演、自我记录和身份探索形成了值得研究的联系。

但两者仍然不能直接等同。录像艺术通常具有更明确的艺术创作语境，而普通Vlog首先属于网络个人影像文化。

## **第三节 早期YouTube喜剧与表演视频**

除了个人Vlog，喜剧和表演视频是早期YouTube最重要的内容类型之一。

这一类视频通常不需要复杂的制作条件。创作者可以在家中、学校、办公室或公共场所完成拍摄，通过夸张表演、模仿、肢体动作和剪辑制造娱乐效果。

### **3.1 Smosh：早期网络喜剧组合**

[Watch Smosh season 1 episode 108 streaming](https://images.openai.com/static-rsc-4/802tfqiQER4ZGeYIlDhhWruRw-V0OUZrn6EBkXKgg0DQUutRLs10DtIoOLqQPH_aQidH37f3DP6APNUaWYJQqL888zpOXXLpsozofKYIDoUjM8xHj7OHtGCJI5jUQHuaVxYFHqZdRsLCzS4IB3tW6PXrjpi8QBL9Mm6IroAAm2E?purpose=inline)

[betaseries.com](https://www.betaseries.com/en/episode/smosh/s01e108?utm_source=chatgpt.com)

**Smosh**

Smosh是早期YouTube最具代表性的创作者组合之一，由Anthony Padilla和Ian Hecox组成。

两人最初通过个人网站发布喜剧内容，后来进入YouTube。

2005年，他们开始在YouTube上传视频。

早期作品主要包括：

* 对流行文化的恶搞。  
* 夸张的角色表演。  
* 个人喜剧短片。  
* 音乐和影视作品模仿。  
* 两人之间的情景喜剧。

其中最著名的早期作品之一，是他们对《宝可梦》主题曲的恶搞表演。

[Ian And Anthony Smosh Quotes. QuotesGram](https://images.openai.com/static-rsc-4/8PYlceB94c2sN1vbA1GZ4Bk-QuMNZSI5Jew3LBddJ9HFL7r9tqbgQIJKNlvJ1CpdRw8qs_wnSu8g5x1DMGLPYOz6eqx4cLoakDR9pMy8hO4gEab5-j29sJlphjB98DqXf3-5y6jHM1MF9QYqcitPpkXTk1S6XpvmrirmNVL7Oo8?purpose=inline)

[quotesgram.com](https://quotesgram.com/ian-and-anthony-smosh-quotes/?utm_source=chatgpt.com)

这类作品的制作方式非常简单：创作者在家中拍摄，利用剪辑和夸张表演制造喜剧效果。

但它们体现了一种重要变化：

传统电视喜剧通常由制作公司、编剧、演员和电视台共同完成，而Smosh这样的网络组合可以依靠两个人和一台摄像机建立自己的观众群体。

Smosh后来成为早期YouTube职业创作者文化的重要代表。

从艺术史角度来看，Smosh的作品属于网络喜剧文化，而不是严格意义上的视频艺术。不过，它们展示了低成本数字影像如何形成新的表演和传播方式。

### **3.2 Brookers：早期女性网络创作者**

[Brooke Brodack Content Feed](https://images.openai.com/static-rsc-4/FFDLKIsKbqUaQbOPEwktLJs9vNLRlmqKUIhopn4ViSpxJ8U4w4aJ-A5_TJUfbJ3A7cO8j18myLVhygPHHgdYdb0DAbdqYegzWtveyAEhkT6Hiu7AWgzsLROnd7nFsJl_JpAbIujmqxEycksRrKjAezR6GFIJV4Bx8E-Ho734NEQ?purpose=inline)

[brookebrodack.net](https://brookebrodack.net/content?utm_source=chatgpt.com)

**Brookers**

Brookers是早期YouTube创作者Brooke Brodack使用的网络名称。

她在2005年加入YouTube，并通过个人喜剧视频、模仿和面对镜头的表演吸引观众。

她的作品通常具有以下特点：

* 个人化表达。  
* 夸张的面部表情。  
* 直接面对摄像机。  
* 简单的剪辑。  
* 具有鲜明个人风格的表演。

Brookers的意义在于，她是YouTube早期女性个人创作者文化的代表之一。

在当时，视频网站尚未形成后来成熟的创作者产业，因此早期创作者往往依靠个性、表演能力和社群互动建立知名度。

### **3.3 LisaNova：模仿、角色与网络表演**

[YouTube to block artists from paid music service: report](https://images.openai.com/static-rsc-4/FbCCGdv_q-qzsKaGbxL9RLiUJlJFtX23q8Auz0MtdeQ9CT7ZRT6wgtduScgViUtA9QNnwCYQGrhKZQLVfw0sNo7jWX0-lZUek6BHrjpT9YpiFjgnDGqSAC_tbfL-u2i9qcZMZf8xrhgbEUqw2AXqKv34WWYYVNtYm16B-szU1TU?purpose=inline)

[livemint.com](https://www.livemint.com/Consumer/BvWnHdtf849ZPqWc2PShfK/YouTube-to-block-artists-from-paid-music-service-report.html?utm_source=chatgpt.com)

**LisaNova**

LisaNova是创作者Lisa Donovan使用的网络身份。

她在早期YouTube上发布喜剧表演、角色模仿和网络短片。

与直接记录日常生活的Vlog不同，LisaNova的作品更加重视角色塑造。

创作者可以通过服装、语气、面部表情和剪辑，在同一视频中扮演不同人物。

这种创作方式与传统电视喜剧、独立短片和网络表演之间存在联系。

它也展示了YouTube早期的一种重要创作可能性：个人创作者可以利用低成本视频制作建立自己的表演角色和虚拟身份。

### **3.4 Fred：声音、角色与夸张表演**

[Fred From YouTube Now: What Is Lucas Cruikshank Up To?](https://images.openai.com/static-rsc-4/fot4ka2jdgAtSb-IEmDRcxrBzZNTiFN5_6QniszfxKtLUqSjlGXT5g3DgZ6aaRz6ehrFc-jNy9uEhV_iBBTcMNHfZM5pLuBsJ90B4ebnJOs2I0lic7QpnqzVbKeJsSpmyd-7WMyFBME5XchEVY0tEmC5It9by4QvhBCfrvwSVZk?purpose=inline)

[distractify.com](https://www.distractify.com/p/fred-from-youtube-now?utm_source=chatgpt.com)

**Fred**

Fred是Lucas Cruikshank创造的喜剧角色。

2006年，Cruikshank开始在YouTube发布以Fred为中心的视频。

Fred的形象具有明显的夸张风格：

* 极高的声音。  
* 快速的语速。  
* 强烈的情绪变化。  
* 夸大的面部表情。  
* 具有连续性的角色故事。

Fred的作品尤其值得注意，因为它不再只是创作者本人面对镜头讲话，而是形成了一个可以持续发展的网络虚构角色。

这使YouTube逐渐成为个人角色、连续故事和网络表演的创作空间。

## **第四节 病毒式视频与早期网络流行文化**

### **4.1 什么是病毒式视频？**

病毒式视频（Viral Video）是指通过互联网用户之间的分享，在较短时间内获得大量观看和传播的视频。

早期YouTube的病毒式传播与今天的推荐算法存在明显区别。

2005—2007年，许多视频主要通过以下方式传播：

* 电子邮件。  
* 即时通信软件。  
* 个人博客。  
* 网络论坛。  
* 新闻网站。  
* 社交网站。  
* YouTube首页和热门视频列表。  
  [What Went Wrong With Yahoo\!? \| TechSpot](https://images.openai.com/static-rsc-4/B3wUPU4xLpSefb4IsAs-3vP6DYgbdgEYXGvt12hM_tgcLppyV7BPdvhKKJzeXU7B5uNgXgF_SgKsJ1_j29eSqGP9cCbwrDXqevm9umu2RiJXMYtaJmJ4FA3Z_x9-PKw9UWlTpXdscaoD2Y3e6Fk3dwYgbDljZh9J8yABZnFDwNQ?purpose=inline)  
  [techspot.com](https://www.techspot.com/article/2744-yahoo-what-went-wrong/?utm_source=chatgpt.com)

早期网络视频的传播往往具有明显的社交性质。

一个人看到有趣的视频后，将网址发给朋友；朋友再将它分享给其他人。

这种传播方式使一些制作成本很低的视频获得了远超创作者预期的观众规模。

### **4.2 《The Evolution of Dance》（2006）**

[Evolution of Dance: The video that changed the internet](https://images.openai.com/static-rsc-4/KOxbAdVpoUwrbVn7paPZcNEjUln032Iuy5NxnMXVeWskB9If87upmnsUQPah1SIaX-unkNLXNm6qpTUUUGzi_AjgE0z1-ajaOrZfLVixq6j1pD4TrTBXaPQNTislExgvjmIhU873XuLlubw_rZdHed3fQLs0uqtqd0BFy53xe7o?purpose=inline)

[9news.com.au](https://www.9news.com.au/9stories/evolution-of-dance-the-video-that-changed-the-internet/ad3abc82-7019-426a-a708-fd2722bca6fd?utm_source=chatgpt.com)

**《The Evolution of Dance》**

* 表演者：Judson Laipply  
* 上传日期：2006年4月6日  
* 时长：约6分钟  
* 类型：喜剧表演、舞蹈混剪

这段视频是早期YouTube最著名的热门作品之一。

Judson Laipply在舞台上连续表演多个年代的流行舞蹈动作，通过舞蹈变化呈现流行文化的发展。

作品从早期摇滚舞蹈开始，逐渐进入后来的流行舞蹈和大众文化。

它的魅力在于：

第一，观众能够迅速识别不同年代的舞蹈。

第二，作品不需要复杂的场景和摄影设备。

第三，表演者通过连续动作建立了完整的视觉节奏。

第四，观众容易将视频分享给朋友。

[Evolution of Dance: The video that changed the internet](https://images.openai.com/static-rsc-4/Rfb7cCUUw_NAde5z2U-3bWuft04cBb2qapJHwMbrfEGtmTC4UxnqS4bkD8JnSAbjlwied9Tvia90GwX0ctOhXnBSZGtjVOgsPc-OwiYGbEFwlDSjsJAUokg7Jusqzq0tVW6MzdrNNXEcDVE12tOpNr-6mgWUJTfzNMsqtp_Rnys?purpose=inline)

[9news.com.au](https://www.9news.com.au/9stories/evolution-of-dance-the-video-that-changed-the-internet/ad3abc82-7019-426a-a708-fd2722bca6fd?utm_source=chatgpt.com)

这段视频曾长期位于YouTube观看量排行榜前列，是早期网络视频突破传统传播规模的重要案例。

WebAfterlife+1

从艺术史角度来看，它不是实验影像，而是一件典型的网络表演视频。

它说明，网络平台可以让原本在学校、公司或现场演出中表演的内容，进入全球大众传播环境。

### **4.3 《Where the Hell is Matt?》（2005—2008）**

['Where the Hell is Matt?' Meet the Seattle man who danced his way into early YouTube fame](https://images.openai.com/static-rsc-4/fg2wpeHgaQiKMWTwRwqJbK86WziYVLnD_SpOTrMrxPhbsOTDpNFbToq0lGqk0n0AbsLVdHupxdFGTzU-JkHA4WzpJSTc1i6ooBSHm3CwHZEGGSWPF4NkHhr-vKWmBGx42v92so-PTBLpDL8xsK_6SgklPElXF4l-l5U2TIeS8LY?purpose=inline)

[seattlerefined.com](https://seattlerefined.com/lifestyle/where-the-hell-is-matt-meet-the-seattle-man-who-danced-into-youtube-fame-20-years-ago-first-early-viral-star-silly-jig-dancing-around-the-world-matt-harding-pnw?utm_source=chatgpt.com)

**《Where the Hell is Matt?》**

创作者：Matt Harding。

这是一组具有代表性的旅行舞蹈视频。

Matt Harding在不同国家和地区拍摄自己跳舞的影像，并将这些片段剪辑在一起。

2005年的早期版本主要展示他独自在不同地点跳舞。

后来，作品逐渐发展为全球参与式项目。

[Where the Hell is Matt?](https://images.openai.com/static-rsc-4/cUulj7y5zopjnnYTWE9wL2Gnp0X91iQP0Pxquuu0SamLpaKVGUW9EyOCmjyU_oiyGK54ybPh2deswrPC8CQSTyztVqJTAohIvEYUhdqdOlVQOYstoETG87R6tVY1S3z3A-BvImVSd7LKJmzHzp28JCTqdcIhLoP5oDw-pyOi3e4?purpose=inline)

[blog.ohheyworld.com](https://blog.ohheyworld.com/where-the-hell-is-matt/?utm_source=chatgpt.com)

2008年的版本中，来自不同国家和地区的人们开始与他一起跳舞。

这使作品从个人旅行记录转变为具有全球参与特征的网络影像项目。

它的艺术史意义在于：

* 将不同地理空间连接在一个视频中。  
* 通过重复动作形成视觉统一性。  
* 将普通人纳入影像创作。  
* 利用互联网传播建立跨国参与关系。

这类作品已经不仅仅是简单的个人录像，而是涉及全球化、身体表演、文化交流和网络协作的影像实践。

### **4.4 《Charlie Bit My Finger》（2007）**

["Charlie Bit My Finger" video will be taken off YouTube after NFT sells for \$760,000 \- CBS News](https://images.openai.com/static-rsc-4/Gqtb9AXBVnwSO7mNcRpb9KszfkpOG5qaPKBFhoJ4iR1-gzMoHOdaog2tWXuT8F0-RefVeGoNS-m4YUfKSYSnhwn025jKJgfVJuH84J7VnE0wRPp9-bddkIzInejxrwYkwH2bB8wrQrt1R3yte_EmExvzxScU2U_oqdVU7XIXMMs?purpose=inline)

[cbsnews.com](https://www.cbsnews.com/news/charlie-bit-my-finger-video-deleted-youtube-nft/?utm_source=chatgpt.com)

**《Charlie Bit My Finger》**

这是一段2007年上传的家庭录像。

视频记录了两个兄弟Harry和Charlie之间的一次日常互动：较小的Charlie咬了哥哥的手指。

整个视频非常短，没有复杂的剪辑，也没有专业制作。

但它在YouTube上获得了极大的传播量。

它体现了早期网络视频文化的一个重要特点：

普通家庭录像也可以成为全球范围内广为传播的公共影像。

传统家庭录像通常服务于家庭记忆，而YouTube改变了这种影像的传播范围。

家庭生活由此成为大众网络文化的一部分。

### **4.5 早期病毒视频的共同特征**

| 特征 | 说明 |
| ----- | ----- |
| 低制作成本 | 不需要大型制作团队 |
| 易于理解 | 内容通常具有直观的视觉效果 |
| 情绪鲜明 | 搞笑、惊讶、感动等情绪容易传播 |
| 短小精悍 | 观众可以快速观看 |
| 易于分享 | 适合通过链接传播 |
| 个人化 | 经常来自普通用户的生活和表演 |

早期病毒视频证明，网络传播能力并不完全取决于制作预算。

一段普通家庭录像，也可能获得比专业电视节目更广泛的网络关注。

## **第五节 音乐、翻唱与网络表演**

### **5.1 音乐翻唱（Cover Videos）**

[Auffällig aufmüpfig](https://images.openai.com/static-rsc-4/PRTJfSou_3Vb0hmFQskqj79RkLQi0JrNCck_aj3NvXrbbOCqKz9s-v0F5hxToCUvRsLZdABK2JHdpym7P6bgY_vm1WsiW5VXksmmsEeCQ0BoDgbg0EqHB_CYkIa48TQhqmKS5zPsastQsxfI4XpvNhj7wQMQY8KG_v8xqwd4owo?purpose=inline)

[stuttgarter-zeitung.de](https://www.stuttgarter-zeitung.de/gallery.justin-bieber-auf-deutschlandtour-auffaellig-aufmuepfig.64f5897c-5f70-4361-80cb-64fd34c14396.html?utm_source=chatgpt.com)

音乐翻唱是早期YouTube最重要的创作类型之一。

在传统音乐产业中，歌手通常需要通过唱片公司、演出机构和音乐媒体获得传播机会。

YouTube则允许普通音乐爱好者直接上传自己的演唱和演奏。

早期音乐视频主要包括：

* 吉他弹唱。  
* 钢琴演奏。  
* 流行歌曲翻唱。  
* 无伴奏演唱。  
* 个人原创音乐。  
* 多轨录音和视频合成。

这使音乐创作逐渐出现一种新的传播模式：创作者可以不依赖传统唱片发行体系，直接通过网络寻找听众。

### **5.2 多重角色与多轨视频**

[Man makes Bohemian Rhapsody video with one note and 13 seconds of footage \| Louder](https://images.openai.com/static-rsc-4/ianHcYoAi_Oxt82uN0Zqi01vflF1BBefkDMYCixnrM7R98VZE508iurpqn4sfJJxTV8s-e_XMXUNwuOsLeIeAgvqyW01lLPKj5rHq_W5vvnHUDDztV92rH9DPOFkQc9u756veT2GN57KTVZZzUZ32SWXMaR8TumK-AIkyOuHwlk?purpose=inline)

[loudersound.com](https://www.loudersound.com/features/man-makes-bohemian-rhapsody-video-with-one-note-and-13-seconds-of-footage?utm_source=chatgpt.com)

一些创作者开始使用多轨录音和分屏技术，让自己在同一视频中扮演多个音乐角色。

例如，一个人可以分别录制：

* 鼓。  
* 吉他。  
* 贝斯。  
* 键盘。  
* 人声。

然后通过视频剪辑将这些表演组合在一起。

这种制作方式将音乐录音、视频剪辑和个人表演结合起来。

它也是早期网络视频中一种很有代表性的视觉实验。

### **5.3 网络音乐创作者的出现**

YouTube逐渐使音乐创作者建立独立的观众群体。

这意味着音乐传播不再完全依赖唱片公司、电视音乐节目和广播电台。

不过，翻唱作品也涉及版权问题。

创作者使用已有歌曲时，可能受到音乐版权持有人的授权、平台政策和地区法律影响。

因此，早期YouTube音乐文化的发展，同时推动了网络音乐传播和数字版权制度的变化。

## **第六节 美妆、教学与知识分享视频**

早期YouTube创作者并不只是拍摄娱乐内容。

另一个非常重要的变化，是个人开始利用视频分享知识、技能和专业经验。

### **6.1 Michelle Phan：早期美妆视频的代表人物**

[Famous YouTubers \- How Much YouTubers Have Changed from First and Last Videos](https://images.openai.com/static-rsc-4/col9LXvQPsgZyMOXZgzxxENPklfXumEPsF1XewVeXjHuqsCtbBuT5WET5UXspTTFFwIigPYQnxCRLL21Xd6rTsuJaUGDHYRdTIdBHarBrKOAsvnbkvc2opRZmbyXBQR47RvNs3LGrmRHJXTTFcPVD3YIRtgUp1z_ZrLl9E8p81E?purpose=inline)

[seventeen.com](https://www.seventeen.com/celebrity/g2873/youtubers-changed-first-and-last-videos/?utm_source=chatgpt.com)

**Michelle Phan**

Michelle Phan是早期YouTube美妆创作者文化的代表人物之一。

2007年5月，她上传了《Natural Looking Makeup Tutorial》。

这段视频展示了如何通过化妆产品完成自然妆容。

她使用非常简单的拍摄方式，在个人环境中向观众讲解化妆步骤。

这段视频在发布后的短时间内获得了大量观看，帮助她逐渐建立网络观众群体。

allure.com+1

[How to Create a 5 minute fresh makeup look with Michelle Phan \<\< Makeup :: WonderHowTo](https://images.openai.com/static-rsc-4/oZwl4J9cg0Al8-XDNzCclBtkyHrr56JV2riTVNrENDZjm3vdLgAfm0L9c3zA5PbdjMMHiZIpt8o9I4l7qbThy3afEoGjLdHzW_ODhwvYO-K79c_M4OvMk-IZiK6ypXLp9-d_NOoMUf7UJIAdWoaeyu60GcJFPcJFiMsB3w5_GnA?purpose=inline)

[makeup.wonderhowto.com](https://makeup.wonderhowto.com/how-to/create-5-minute-fresh-makeup-look-with-michelle-phan-272963/?utm_source=chatgpt.com)

Michelle Phan的早期视频具有几个重要特征：

1. 直接面对观众讲解。  
2. 使用近距离镜头展示面部。  
3. 将操作步骤分解为连续画面。  
4. 通过口头说明传递知识。  
5. 让观众能够按照视频模仿操作。

这使视频成为一种新的教学媒介。

与文字教程相比，视频能够直接展示动作、颜色、工具和操作过程。

### **6.2 教学视频与知识传播**

[Anyone miss the old days of Youtube that only had an ad banner at the upper right corner? Video ads at the beginning of videos is why many users started using Ad Block. : r/youtube](https://images.openai.com/static-rsc-4/XuFWRJ35LtM-US0IERRK1BrzlCsovdXQG4JihR68TzhmC83YAbHihTFUWqarMmH-wpNfxtYIARt-ZgdRaA1hPqO_e8WdvbSeCJXBE_2pS2bPX-jCBurBPG7PjhjNTAoKwCvaiVkKrARuWjCPgESCpfYVBCWpruYnKnY0xh-FJYs?purpose=inline)

[reddit.com](https://www.reddit.com/r/youtube/comments/3gjxwc/anyone_miss_the_old_days_of_youtube_that_only_had/?utm_source=chatgpt.com)

早期YouTube教学视频涉及：

* 化妆。  
* 绘画。  
* 乐器演奏。  
* 计算机软件。  
* 手工制作。  
* 语言学习。  
* 学校课程。  
* 日常生活技能。

这些内容改变了知识传播的方式。

传统教学通常依赖学校、教师、书籍和专业培训机构。

在线视频则允许个人将自己的知识和经验制作成影像，供其他人随时观看。

### **6.3 教学视频与艺术教育**

对艺术史和视觉文化研究而言，教学视频的发展也很重要。

艺术家可以通过网络展示：

* 绘画过程。  
* 雕塑制作。  
* 摄影技术。  
* 数字艺术软件。  
* 动画制作。  
* 视频剪辑。  
* 装置艺术搭建。

这使艺术教育逐渐进入网络环境。

同时，创作者不再只是展示最终作品，也可以展示创作过程。

这改变了艺术作品与制作过程之间的关系。

## **第七节 游戏视频与新的网络娱乐形式**

### **7.1 早期游戏视频**

[How the world changed around Far Lands or Bust \| Bevan Philip](https://images.openai.com/static-rsc-4/a3S3EAVIqLDzbfR1NHKy1fE-pWkLMukhTpzawoN_co58QkDusbt_IBI60o7iCQPEVozUpKKvQYcwFkZMf0_Ia0-OgV20gsomf-vQNVs2_BDax33_oDjlPMx_VpFMOgg0LWYG7WDFHtcKfg2mRyDR8jlDyx_AUABatXgV3j6nzuk?purpose=inline)

[bphilip.uk](https://bphilip.uk/blog/2025-10-05-how-the-world-changed-around-far-lands-or-bust/?utm_source=chatgpt.com)

游戏视频是早期YouTube逐渐形成的重要内容类型。

最初的游戏视频通常通过计算机屏幕录制、游戏录像功能或外部采集设备制作。

常见内容包括：

* 游戏通关过程。  
* 游戏技巧。  
* 游戏漏洞展示。  
* 游戏评论。  
* 游戏模组。  
* 游戏比赛录像。

游戏视频改变了游戏与观众之间的关系。

传统电子游戏主要是玩家与游戏系统之间的互动。

而网络视频使游戏过程能够被其他人观看、评论和讨论。

### **7.2 游戏实况（Let's Play）**

['Minecraft' documentary released, seeks feature-length funding \| The Independent \| The Independent](https://images.openai.com/static-rsc-4/ngHKvhG6u9OI1cXbVYS1GvHUfOlZVeNkIZ0kxMWUXvU9yE63cIXRulBQN4c22LUEikPO6OUHkn7dWZE42ppSQBVGm91duU0UinR3saFSkCyAbnNlMkwPyeI-N3SsSg-dqI6mIzrq1tjAuUKPODq9W5crNc3tVMf1xTT82jQFddQ?purpose=inline)

[independent.co.uk](https://www.independent.co.uk/tech/minecraft-documentary-released-seeks-featurelength-funding-2223047.html?utm_source=chatgpt.com)

Let's Play是一种由玩家录制游戏过程，并通常配合讲解或评论的视频形式。

它的特点包括：

第一，展示实际游戏过程。

第二，创作者可能持续进行口头解说。

第三，视频可以分成连续多个部分。

第四，观众能够通过评论与创作者交流。

这种形式逐渐发展成后来游戏实况和游戏直播文化的重要基础。

### **7.3 游戏视频作为表演**

游戏视频并不只是展示游戏本身。

创作者的语言、情绪、反应和行为也构成了视频内容。

因此，观众观看的实际上是两层影像：

* 游戏世界中的虚拟事件。  
* 现实创作者对游戏事件的表演和反应。

这使游戏视频成为一种结合屏幕录制、个人表演和互动传播的网络影像形式。

## **第八节 早期YouTube创作者的代表性人物**

下面整理一些2005—2010年早期YouTube文化中值得研究的人物。

[the EVOLUTION of YOUTUBE \- 2005](https://images.openai.com/static-rsc-4/TarHJ7PSe6wADSIhPUidxwhYc4F5Kxtw1r6hgTAsOEL2hxSNXICkDAY_j2_zcYcnSxTou5pkVopTV0QsG_vBYbHTI3BEMl80l490yVb5aCrhcv60LtrpKUYXHaOdKxWBSah0dOHc9iUH7avQs_I0CQQWCzOWTXr3Q9ES6-gMgg4?purpose=inline)

[OneTouch Labs (@onetouch\_labs) on X](https://images.openai.com/static-rsc-4/NFiMEm_OPjZaTAL-66iDKL1TTJUUENhGc00Teo1SeiL1s4HmsbEAYmmRF9iSfGjZCR0V3HhvKkFzx6QZ_D2dOyZ3_6bzsVPpuS4azDPc7W4kCXIpWug78XVqgMiEk92oZnOOmQaWOn6Sa1Ilxwi0LapO-5Cuk34TEr-Ak_2gcN0?purpose=inline)

[How to Create a 5 minute fresh makeup look with Michelle Phan \<\< Makeup :: WonderHowTo](https://images.openai.com/static-rsc-4/oZwl4J9cg0Al8-XDNzCclBtkyHrr56JV2riTVNrENDZjm3vdLgAfm0L9c3zA5PbdjMMHiZIpt8o9I4l7qbThy3afEoGjLdHzW_ODhwvYO-K79c_M4OvMk-IZiK6ypXLp9-d_NOoMUf7UJIAdWoaeyu60GcJFPcJFiMsB3w5_GnA?purpose=inline)

7

| 创作者 | 早期活跃时期 | 主要创作类型 | 代表意义 |
| ----- | ----- | ----- | ----- |
| Jawed Karim | 2005 | 个人影像 | 第一部YouTube视频 |
| Smosh | 2005起 | 网络喜剧 | 个人喜剧组合 |
| Brookers | 2005起 | 喜剧、Vlog | 早期女性创作者 |
| Judson Laipply | 2006 | 舞蹈表演 | 早期病毒视频 |
| Lonelygirl15 | 2006起 | 虚构Vlog | 真实与虚构身份 |
| LisaNova | 2006起 | 喜剧表演 | 网络角色创作 |
| Matt Harding | 2005起 | 旅行、舞蹈 | 全球参与式影像 |
| Lucas Cruikshank | 2006起 | 角色喜剧 | 网络虚构人物 |
| Michelle Phan | 2007起 | 美妆教学 | 个人知识型创作者 |

这份名单不是按照观看量排名，而是按照早期创作形式和文化影响进行选择。

此外，早期YouTube创作者的历史还包括大量已经停止更新、删除频道或无法恢复原始视频的人物。研究这一时期时，需要注意数字档案的不完整性。

## **第九节 早期YouTube影像的视觉语言**

这一节需要从艺术史角度进行更深入的分析。

早期YouTube视频并不是一种统一的视觉风格，但它们逐渐形成了若干具有代表性的影像特征。

### **9.1 低分辨率与数字影像质感**

[YouTube: este es el primer video y quién lo publicó](https://images.openai.com/static-rsc-4/vl0RAmBTYH45HYiRH5BSpKmSL33zzNVd4zjt_dbqXXjd-heVTi5zKflDSanQWbQize3TMfo2q-xZx3byVBcpaR_OOIhqQzAGhJjlTgBFyl-eDuGzeCUWHmqey2aAyyG2YcW-EbMgV06bmhYAr73CFwQoIRYmKAv7UMao9Dq5GBs?purpose=inline)

[radionica.rocks](https://www.radionica.rocks/mundo-geek/primer-video-youtube?utm_source=chatgpt.com)

早期YouTube视频经常使用低分辨率影像。

原因包括：

* 家庭网络带宽有限。  
* 摄像设备性能有限。  
* 视频文件需要压缩。  
* 平台播放条件有限。

这种低分辨率画面具有明显的时代特征。

它与传统电影的高清摄影风格存在差异。

### **9.2 固定镜头与正面凝视**

[lonelygirl15: The Pleasures and Perils of Participation – Flow](https://images.openai.com/static-rsc-4/oj8p8bEzqKeUpmcTn0zIo6AQ-wmDaFWd77VFrUZ_P0NFfqJQlGF4VXY4aX5cEbqNTuugnqV8k4e8ywiQxb__rYgTZBX3yFoIu1AOx2FkAGaKCVuabZhEaha8T2joPKYFX1Fho46FobaKxeTGqkYdMxvNf8eZYcbeF5uLFk1n1cQ?purpose=inline)

[flowjournal.org](https://www.flowjournal.org/2006/09/feature-lonelygirl15-the-pleasures-and-perils-of-participation/?utm_source=chatgpt.com)

早期Vlog常使用固定机位。

创作者面对摄像头讲话，观众则通过屏幕观看创作者。

这种观看方式形成一种特殊的视觉关系：

创作者仿佛正在直接与观众交谈。

这与传统电影中通过剪辑、场景和人物关系组织观看的方式不同。

### **9.3 卧室与私人空间**

[¿Lo recuerdan? Así fue el primer video viral de Werevertumorro – Metro World News](https://images.openai.com/static-rsc-4/jVicFx4TshZIa5sZVbaK23IXk2OVP01-5gGtZUqlX5s9-7z3onyJJsIoy43w5KXo6i2r0VFmgDymIVRpy2HbKLBWrLBOZOqbtLMBskNUHyh-RqXh2KcmwsDgGq5lgDpauRMuwNmPqPY_luB1dLAoMMrxfCrm8lwSX5JdmccoKzE?purpose=inline)

[metroworldnews.com](https://www.metroworldnews.com/entretenimiento/2022/09/06/asi-fue-el-primer-video-viral-de-werevertumorro/?utm_source=chatgpt.com)

早期Vlog大量使用卧室和家庭空间。

卧室原本属于私人生活空间，但通过摄像机和互联网，它逐渐变成公开表演的场所。

这一变化值得特别研究。

在传统电视节目中，家庭空间通常经过布景和设计。

而早期Vlog中的家庭环境往往更加日常化。

房间里的家具、墙面、床铺和个人物品，都可能成为影像的一部分。

学术研究者将早期YouTube Vlog的卧室背景视为一种逐渐形成的视觉惯例。2006年春季至夏季，越来越多创作者开始采用这种家庭环境拍摄视频。

NECSUS

### **9.4 直接面对观众**

早期YouTube视频中的创作者往往直接对着镜头讲话。

这种形式与传统电视主持人有些相似，但两者的传播关系不同。

电视主持人通常面对一个广泛但无法直接回应的观众群体。

YouTube创作者则可以通过评论、回复视频和订阅关系与观众持续交流。

这种关系逐渐形成一种新的媒介亲密感（Mediated Intimacy）。

观众可能长期观看同一个人的视频，逐渐熟悉其声音、表情、生活环境和个人经历。

## **第十节 早期YouTube与录像艺术的关系**

早期YouTube创作者文化与录像艺术（Video Art）之间存在联系，但两者不能混为一谈。

### **10.1 共同点**

[YouTube: este es el primer video y quién lo publicó](https://images.openai.com/static-rsc-4/vl0RAmBTYH45HYiRH5BSpKmSL33zzNVd4zjt_dbqXXjd-heVTi5zKflDSanQWbQize3TMfo2q-xZx3byVBcpaR_OOIhqQzAGhJjlTgBFyl-eDuGzeCUWHmqey2aAyyG2YcW-EbMgV06bmhYAr73CFwQoIRYmKAv7UMao9Dq5GBs?purpose=inline)

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s](https://images.openai.com/static-rsc-4/08pspF-ANFfll6Yf3iO3W0DP7TMjgdKueRuTLDVQohlJkZ4e3yYBzY-lkdJwYdGihGRBwVR6zgcU8FiL92tM6SJOpFeYThLLOSPFn1y1At4sjiN8e_tzPDQcpoGWaKCxnjgL1Yfyw6rh9THie-Qn3px8FkKiwfSYZNvo1XaWS0w?purpose=inline)

[VVEBCAM \| Net Art Anthology](https://images.openai.com/static-rsc-4/6c5a3L6AR83yVm05hJWOUuLncIyH5L16dpgpI7DQFs_Nguu9VwDMULHAnuP0OrLqM1_rvJBWQlXAI8Dy0WQHVAX2w6C-n92Vp01EWmR9d6w5aEMAHjOb5Iq2KcYySNYfbcWJ2Llmva8jCDPJo0P-FI_qnhokjetoh-IqrR4B8vU?purpose=inline)

5

两者都可以利用：

* 摄像机记录身体。  
* 直接面对镜头。  
* 日常生活作为影像材料。  
* 重复动作和持续时间。  
* 自我表演。  
* 个人身份探索。

例如，早期录像艺术家Vito Acconci曾利用摄像机研究身体、凝视和表演。

早期YouTube Vlog创作者也会通过摄像头展示自己的身体和身份。

从形式上看，两者确实存在值得比较的地方。

### **10.2 根本区别**

| 比较维度 | 录像艺术 | 早期YouTube视频 |
| ----- | ----- | ----- |
| 主要历史背景 | 1960年代以来的当代艺术 | 2005年后的互联网文化 |
| 主要媒介环境 | 录像设备、电视监视器、展览空间 | 个人计算机、摄像头、互联网平台 |
| 创作目的 | 艺术观念与形式实验 | 多样，包括娱乐、记录、表达和教学 |
| 传播方式 | 美术馆、画廊、艺术机构 | 网络平台与用户分享 |
| 观众关系 | 展览观看和艺术批评 | 观看、评论、订阅和互动 |
| 作品保存 | 艺术机构与影像档案 | 平台服务器、个人档案和网络存档 |

最重要的区别是创作语境。

普通人面对摄像机讲话，并不意味着他正在创作录像艺术。

同样，使用YouTube发布视频，也不自动使作品成为流媒体视频艺术。

但YouTube确实为艺术家提供了新的创作环境，使网络身份、平台机制、用户互动和数字传播可以成为艺术作品的一部分。

## **第十一节 早期YouTube文化的历史意义**

2005—2010年，YouTube逐渐从一个新兴视频分享网站，发展成为具有全球影响力的文化平台。

这一时期形成了五项重要变化。

**第一，个人影像生产大众化。**

普通人获得了直接发布视频的能力。

**第二，个人身份成为网络影像的重要主题。**

创作者通过Vlog、角色表演和生活记录建立自己的网络身份。

**第三，表演形式发生变化。**

喜剧、音乐、舞蹈、游戏和知识分享都逐渐形成新的网络视频类型。

**第四，观众与创作者的关系发生变化。**

评论、订阅和回复使观看成为持续互动的过程。

**第五，平台开始影响创作。**

视频上传、推荐、版权、广告和数据分析逐渐参与影像文化的形成。

从艺术史角度来看，这一时期最重要的变化，是普通人的生活和表演开始成为一种全球传播的数字影像资源。

## **主要参考资料**

1\. Elena Cresci，*Lonelygirl15: how one mysterious vlogger changed the internet*，The Guardian，2016。

[Lonelygirl15与早期YouTube文化](https://www.theguardian.com/technology/2016/jun/16/lonelygirl15-bree-video-blog-youtube?utm_source=chatgpt.com)

2\. *From the bedroom to LA: Revisiting the settings of early video blogs on YouTube*，NECSUS，关于早期Vlog拍摄空间的学术研究。

[早期YouTube Vlog的卧室视觉文化](https://necsus-ejms.org/from-the-bedroom-to-la-revisiting-the-settings-of-early-video-blogs-on-youtube/?utm_source=chatgpt.com)

3\. *Michelle Phan on Influence (and How to Use It)*，Allure。

[Michelle Phan的早期美妆视频与创作者经历](https://www.allure.com/story/michelle-phan-the-original-beauty-vlogger-interview?utm_source=chatgpt.com)

4\. *The Evolution of Dance*，Judson Laipply，2006。

[The Evolution of Dance历史资料](https://www.webafterlife.net/grave/evolution-of-dance?utm_source=chatgpt.com)

5\. *YouTube HISTORY 101\!*，William Hyde，2010。

[2010年早期YouTube创作者群体回顾](https://www.youtube.com/watch?v=r-VHGKltRQQ&utm_source=chatgpt.com)

## **下一章**

**008 网络视频亚文化、恶搞与迷因影像（Internet Video Subcultures, Parody and Meme Culture）**

下一章将重点研究：

* 早期互联网恶搞文化。  
* YouTube迷因（Internet Memes）的形成。  
* Rickrolling与网络音乐恶搞。  
* 早期网络动画和Flash文化。  
* 网络鬼畜与重复剪辑。  
* 二次创作、挪用和影像拼贴。  
* 网络迷因如何从大众娱乐发展为数字艺术的创作材料。

我们将进一步研究一个重要问题：**当普通视频被反复复制、剪辑、模仿和重新传播时，它还能不能被看作一件独立的作品？**

