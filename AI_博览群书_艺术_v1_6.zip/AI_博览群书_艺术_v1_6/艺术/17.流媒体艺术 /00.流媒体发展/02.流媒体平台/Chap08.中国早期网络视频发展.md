# **009 中国早期网络视频网站的发展**

**The Development of Early Chinese Online Video-Sharing Platforms**

本章属于网络影像艺术史（History of Internet Video Art）中的中国发展部分，主要研究中国互联网早期的视频网站、用户上传视频文化、网络影像传播方式，以及这些平台如何逐渐形成独立的网络视频生态。

本章讨论的重点是**互联网原生视频、用户生成视频、网络短片、个人影像创作和视频分享平台**，不讨论电影史，也不把传统影视作品的网络播放简单等同于网络视频艺术。

中国早期视频网站的发展具有特殊的历史意义：它不仅改变了影像的传播方式，还使普通互联网用户逐渐成为影像的生产者、传播者和评论者。网络视频由此从少数专业创作者掌握的媒介，逐渐转变成大众参与的文化形式。

## **009.001 中国早期网络视频传播的技术与社会背景（约1995—2004年）**

中国早期视频网站的出现，并不是突然发生的。它建立在互联网普及、宽带网络发展、数字摄像设备普及以及个人电脑视频处理能力提高的基础之上。

在视频网站诞生之前，中国互联网已经出现了个人主页、论坛、聊天室、Flash动画和个人数字影像等网络文化形式。这些早期媒介为后来的视频分享平台准备了用户群体和传播环境。

### **一、互联网接入条件的变化**

20世纪90年代，中国互联网仍处于发展初期。早期用户主要通过拨号网络（Dial-up Internet）接入互联网。

拨号网络的主要特点是：

* 连接速度较低。  
* 网络连接稳定性有限。  
* 视频文件下载耗时较长。  
* 在线连续播放视频十分困难。

因此，早期网络影像主要以静态图片、GIF动画、Flash动画和可下载的视频文件形式传播。

随着ADSL宽带和其他宽带接入方式逐渐普及，用户开始能够更方便地下载、上传和观看视频。

### **二、数字影像设备的普及**

数字摄像机、数码相机、手机摄像功能和个人电脑视频编辑软件的发展，使普通人逐渐具备了制作数字视频的能力。

影像生产不再完全依赖专业影视机构。

普通用户可以拍摄：

* 日常生活记录；  
* 校园活动；  
* 搞笑表演；  
* 音乐与舞蹈；  
* 个人实验影像；  
* 动画和数字特效；  
* 网络恶搞与模仿作品。

这为后来用户生成内容（User-Generated Content，UGC）的兴起奠定了基础。

### **三、早期网络影像的传播形式**

当时的视频传播还没有完全形成后来熟悉的在线视频平台模式。

主要有三种方式：

1. **文件下载（Video Download）**：用户从网站下载视频文件，再使用本地播放器观看。  
2. **论坛传播（Forum-based Distribution）**：用户在论坛发布视频文件、下载地址或嵌入代码。  
3. **个人网站传播（Personal Website Distribution）**：个人站长将视频文件放置在自己的服务器上，供其他用户访问。

这三个阶段共同构成了中国网络视频分享平台出现之前的技术和文化基础。

## **009.002 第一批专业视频网站的出现（2004—2006年）**

[年代考古计划：68个互联网遗址发掘现场\|界面新闻 · JMedia](https://images.openai.com/static-rsc-4/IpucXyJMckaFExUcWKhm-8Y6IbYI4dCdyxJPcM_d_nDVgo5L0RLELBzXL1qN94632qFawkjhVxeZ8l2A3m9b1rvcAw_PMlBoBEsHLEvBataPqL4VAJpRp54ZS2MKOJAWTQ3xC5XGtos0USYU9w5mnzftV28dRiF6ItjN4IG2OTM?purpose=inline)

[Internet pioneers \| Features \| Screen](https://images.openai.com/static-rsc-4/_kpMoyUKgbmpGP0ZAVrDIrc8XZUbPr0gkmIuZAD1fJu3w0vHaxvumVYeaWOSNZ1L_SN4S5FI2YH_3hBp4QHafE89UqCyR7Gh54RK0i4YD_OnHu0bmThUyys_HFe6L2N0_tVBKJfF7XFcTUDrKanFoqOqUzdDVVA-BVH-3oLfrRU?purpose=inline)

[史上最悲催的视频网站——56网\_\_财经头条\_\_新浪财经](https://images.openai.com/static-rsc-4/aJfnQWCeBlGLsqbX4BCTbaTsHG9AH2_Ao3q0O6wGyb1KSPQ9hxH0G5tMYa34yuW9ipvUorgb6GvJmlLLuX1NRuJlj203hzsPO7RzjvdxfleLxjSZ8z0d8Apqc37yrn7alkAZFzuvK4iHV6aWhuKtnBqwybfAMniIAXvgDEWnLV4?purpose=inline)

2004—2006年是中国专业视频网站的萌芽阶段。这一时期出现了一批具有不同商业模式和内容定位的视频网站。

### **一、乐视网（2004年）**

[年代考古计划：68个互联网遗址发掘现场\|界面新闻 · JMedia](https://images.openai.com/static-rsc-4/IpucXyJMckaFExUcWKhm-8Y6IbYI4dCdyxJPcM_d_nDVgo5L0RLELBzXL1qN94632qFawkjhVxeZ8l2A3m9b1rvcAw_PMlBoBEsHLEvBataPqL4VAJpRp54ZS2MKOJAWTQ3xC5XGtos0USYU9w5mnzftV28dRiF6ItjN4IG2OTM?purpose=inline)

**乐视网（LeTV）**

2004年11月成立，是中国早期专业视频网站的重要代表。

乐视网与后来以用户上传为核心的视频分享网站有所不同。它较早采用了以影视内容发行和在线播放为中心的发展思路。

其早期模式主要包括：

* 引入影视节目资源；  
* 提供网络视频观看服务；  
* 探索网络版权发行；  
* 通过广告和内容运营获得收入。

因此，乐视网代表了中国早期网络视频产业中的专业内容运营路线，而不是典型的纯UGC视频分享模式。

### **二、土豆网（2005年）**

[Internet pioneers \| Features \| Screen](https://images.openai.com/static-rsc-4/_kpMoyUKgbmpGP0ZAVrDIrc8XZUbPr0gkmIuZAD1fJu3w0vHaxvumVYeaWOSNZ1L_SN4S5FI2YH_3hBp4QHafE89UqCyR7Gh54RK0i4YD_OnHu0bmThUyys_HFe6L2N0_tVBKJfF7XFcTUDrKanFoqOqUzdDVVA-BVH-3oLfrRU?purpose=inline)

**土豆网（Tudou）**

2005年4月上线，是中国早期最有代表性的视频分享网站之一。

土豆网的出现具有重要意义。它将用户上传视频作为平台发展的重要基础。

其基本运行方式是：

1. 用户拍摄或者制作视频。  
2. 将视频文件上传至网站。  
3. 网站处理视频并提供在线播放。  
4. 其他用户观看、评论和分享。  
5. 平台通过广告等方式获得收入。

土豆网使普通网民能够直接参与网络影像的生产和传播。

它所承载的内容包括个人生活记录、校园影像、搞笑视频、动画、音乐表演、实验短片和各种网络原创作品。

### **三、56网（56.com，2005年）**

[史上最悲催的视频网站——56网\_\_财经头条\_\_新浪财经](https://images.openai.com/static-rsc-4/aJfnQWCeBlGLsqbX4BCTbaTsHG9AH2_Ao3q0O6wGyb1KSPQ9hxH0G5tMYa34yuW9ipvUorgb6GvJmlLLuX1NRuJlj203hzsPO7RzjvdxfleLxjSZ8z0d8Apqc37yrn7alkAZFzuvK4iHV6aWhuKtnBqwybfAMniIAXvgDEWnLV4?purpose=inline)

**56网**

2005年创立，后来成为中国早期视频分享领域的重要平台。

56网特别强调视频分享与社区传播。

用户不仅可以上传自己的作品，也可以通过个人空间、视频分类和社交互动建立自己的网络影像展示空间。

这种模式逐渐改变了传统网络媒体中编辑负责内容生产、用户负责观看的单向传播结构。

用户开始同时具有三个身份：

* 影像创作者；  
* 内容发布者；  
* 网络观众。

  ### **四、酷6网（2006年）**

  [Top 10 Most Popular Alternatives to YouTube in China 2025 \- Extrabux](https://images.openai.com/static-rsc-4/dMep2SWQ6KlQXA-8BMYmv8TpT222fyUWOVDorTKQsRUusALpNY9EY-gCkGkq5fneo45ol7bI-4190fVJnYl6ytExtnnIexV-V71Ro6kK9lNRmDd7pJsSd_dgI7ziRjUDrsi2fSefBWAzzqjG3PPBNfnC8oPX-n3GkpC_qnR5jtU?purpose=inline)

**酷6网（Ku6）**

2006年进入中国视频网站市场。

酷6网最初同样具有视频分享平台的特征，鼓励用户上传和观看网络视频。

它后来逐渐向专业化视频内容运营转型，并经历了资本收购、上市等产业变化。

### **五、优酷网（2006年）**

[10 Alternative Sites Like YouTube \- HubPages](https://images.openai.com/static-rsc-4/tR1B0lOheCaHypumnzkGcUbXBmMPs5xJc02AYmjztCabcai3BWJ0rHf9vpJWpzA7BHb1-fjmSH9B2nfzZQPZ-8kPCmZuvqfdLBL2aat9viyX9FM88WkMxmmXO5f-EohbWZrnGgUKju5ROKZb8KOsUfe7vHjix7Ve5ENfh4m0Doo?purpose=inline)

**优酷网（Youku）**

2006年成立，是中国早期网络视频产业的重要参与者。

优酷网在发展初期借鉴了YouTube式的视频分享模式。

它逐渐建立起用户上传、视频播放、内容分类、搜索和分享等服务体系。

其重要特点是将大量不同来源的视频集中到一个平台，使用户不必自己寻找分散在各个个人网站上的视频文件。

### **六、六间房（2006年）**

[六间房-快懂百科](https://images.openai.com/static-rsc-4/jlGL1VQW133LI2djfmn5Er7MB6OG_UiFCmum8vzBkp87V7YHtiLI6KW4rTOhyKx5ccixd-PiLzN80Zai83-wMoj0MaciobUGp0a9BcOuawmnWitDVax5NSAzld8ogsY4lvHPXrZz3bB6rtH9iwRX90cDUdx6-50Al1NUQ5rPFQ8?purpose=inline)

**六间房（6.cn）**

2006年前后进入视频分享市场。

六间房也是早期中国网络视频分享文化的重要组成部分。它的发展后来逐渐向网络互动、视频表演和直播方向延伸。

这也说明早期视频分享网站并不只是视频存储空间，它们还是后来网络直播和视频社交文化的重要探索者。

### **七、早期主要平台对照**

| 平台 | 出现时间 | 早期主要定位 |
| ----- | ----- | ----- |
| 乐视网 | 2004 | 专业内容与影视发行 |
| 土豆网 | 2005 | 用户视频分享 |
| 56网 | 2005 | 视频分享与社区 |
| 激动网 | 2005 | 专业视频与网络传播 |
| PPTV | 2005年前后 | P2P网络电视 |
| PPS | 2005年前后 | P2P网络视频播放 |
| 酷6网 | 2006 | 视频分享 |
| 优酷网 | 2006 | 用户视频分享 |
| 六间房 | 2006年前后 | 视频分享与互动 |

需要注意，PPTV和PPS主要采用P2P流媒体技术，与土豆网、优酷网以用户上传和分享为核心的模式并不完全相同。

RIRT+2

## **009.003 UGC文化与中国网络原创视频的兴起（2005—2008年）**

[������˽���ڣ�С����Ϸ׬Ǯ ���������ݷֱ�-�Ѻ�����](https://images.openai.com/static-rsc-4/ZMDbmtxUTNmuvYb50rkgf_vn27UT8srXKmZ8v2_c4bcUvAY2x30OfCTkqdApc7o_jw5kchNEavJ-uEUQXTnPUQ89hmTUWAASdUgBZ5Faka1-lEN0VRLYbfNLjPmJO34UylZPsOF4noioiBky7KDcEp294hcFtMFs0NtQ7awybjI?purpose=inline)

[一个小人物和一位大导演之间的“血案”\_胡戈](https://images.openai.com/static-rsc-4/m3PhDNnAkmWZCre_3Q55FL8BYeOhrPtboP8B7NfUA4PlW3vlDqY7y1oPrsU-Vj6Vfs7pLo-714JIhDA8X2JO4IjOxmUe6edUQPnYTtBW30zJhFSr-LvNzcUUCHvjmj7eE20MwspsjIA2pLzL5cb0RlyaGT23WCodI9c4BKBj8aw?purpose=inline)

[Internet pioneers \| Features \| Screen](https://images.openai.com/static-rsc-4/_kpMoyUKgbmpGP0ZAVrDIrc8XZUbPr0gkmIuZAD1fJu3w0vHaxvumVYeaWOSNZ1L_SN4S5FI2YH_3hBp4QHafE89UqCyR7Gh54RK0i4YD_OnHu0bmThUyys_HFe6L2N0_tVBKJfF7XFcTUDrKanFoqOqUzdDVVA-BVH-3oLfrRU?purpose=inline)

6

UGC（User-Generated Content，用户生成内容）是理解中国早期网络视频文化的核心概念。

在传统电视传播体系中，节目通常由电视台、影视制作公司或专业媒体机构制作，再由广播电视网络传递给观众。

而UGC改变了这种结构：普通人也可以制作视频，并直接将其发布到互联网上。

### **一、个人影像生产的普及**

早期网络原创视频的制作成本相对较低。

一台数码摄像机、一台个人电脑和简单的视频编辑软件，就能够完成一部网络视频作品。

由此出现了多种新的创作形式：

**1\. 生活记录视频**

用户记录自己的家庭、校园、旅行和日常生活。

这些作品通常没有专业摄影和复杂的后期制作，却体现了个人影像表达的兴起。

**2\. 网络搞笑视频**

用户通过表演、模仿、配音和剪辑制作娱乐内容。

这种类型的视频往往具有较强的传播性。

**3\. 音乐与表演视频**

用户上传翻唱、乐器演奏、舞蹈和个人表演。

网络视频平台成为非专业表演者展示自身能力的新空间。

**4\. 实验性网络影像**

一些创作者开始利用数字剪辑、特效、动画和网络素材进行影像实验。

这类作品与传统影视制作不同，其传播、互动和创作方式更加依赖互联网。

### **二、后舍男生与网络表演文化**

[后舍男孩凭“对口型”火爆全网，如今现状怎么样？\_韦炜\_后舍男生\_黄艺馨](https://images.openai.com/static-rsc-4/-iXlW_bo2QGQS_zSlfL6nHee7U1yYnjQBZ5u89pW3eIc3VsHSdf8eDhpxJDSGT3-_0eW7qTRsg64LDk2EPdf4-ImAAMqLL1rRLp7xFEFyrgpzEcMBC1iQDDYTUMs4PNPbT-gZHbV_2NfW-15OxK0BcIPdkVI3zM5kDlAIx9y910?purpose=inline)

[sohu.com](https://www.sohu.com/a/540778505_494347?utm_source=chatgpt.com)

\*\*后舍男生\*\*是中国早期网络视频文化中具有代表性的网络表演组合。

他们通过对口型、表情模仿和夸张肢体动作制作音乐表演视频。

作品的特点包括：

* 低成本的个人视频制作；  
* 强调面部表情和身体表演；  
* 利用音乐与画面形成喜剧效果；  
* 通过网络传播获得大量观众。

后舍男生的走红说明，互联网可以使普通个人表演者绕过传统电视媒体的筛选机制，直接获得大众关注。

### **三、胡戈与网络恶搞影像**

[一个小人物和一位大导演之间的“血案”\_胡戈](https://images.openai.com/static-rsc-4/m3PhDNnAkmWZCre_3Q55FL8BYeOhrPtboP8B7NfUA4PlW3vlDqY7y1oPrsU-Vj6Vfs7pLo-714JIhDA8X2JO4IjOxmUe6edUQPnYTtBW30zJhFSr-LvNzcUUCHvjmj7eE20MwspsjIA2pLzL5cb0RlyaGT23WCodI9c4BKBj8aw?purpose=inline)

[sohu.com](https://www.sohu.com/a/477736551_481665?utm_source=chatgpt.com)

2005年，网络创作者\*\*胡戈\*\*制作的《一个馒头引发的血案》在互联网上广泛传播。

作品通过重新剪辑、配音、字幕和重新组织素材，形成了具有喜剧效果的网络影像。

它的重要意义不仅在于娱乐性，还在于展示了数字视频技术带来的创作可能：

* 现有影像素材可以被重新组织；  
* 声音、字幕与画面可以产生新的意义；  
* 网络用户可以通过二次创作表达观点；  
* 视频可以脱离原始传播渠道，在网络社区中独立传播。

从媒介艺术史的角度来看，这类创作与挪用艺术（Appropriation Art）、拼贴艺术（Collage）和再混合文化（Remix Culture）存在值得研究的联系。

不过，不能把所有网络恶搞视频都直接归类为艺术作品。它们首先是一种网络影像文化现象，其中部分作品具有明确的艺术实验性质。

### **四、网络原创视频的传播机制**

早期视频网站不仅提供播放功能，也改变了作品的传播路径。

传统电视传播主要依赖电视台的节目编排和播出时间，而网络视频逐渐形成了以下传播方式：

**个人创作者**

拍摄、剪辑、制作视频

**视频网站**

上传、转码、存储、审核和播放

**网络观众**

观看、评论、收藏和分享

**二次传播与再创作**

转载、模仿、剪辑和衍生创作

这种传播结构逐渐形成了网络视频的社会化传播机制。

一个普通用户制作的视频，有可能在短时间内获得大量观看。作品的传播能力不再完全取决于电视台或专业媒体的发行渠道。

### **五、土豆映像节与网络影像创作者群体**

[土豆今天15岁了，可它像个“活死人”-Jiemian Global](https://images.openai.com/static-rsc-4/BaNkgVOrXpO9YgxrI9R0xtx1U5KNJnWlevpziabty1hjyVZ2Mj2pDNxwL3WIELuztO154mX86hErrmNAOinWIyFedY3hdpOcE_WxOzsGJwhgjISqRbuObWGszvVBvI2rOVSr1SuoOSzpJjXMWCUFLpLSzIBkW41voVtj8zrj2Ws?purpose=inline)

[en.jiemian.com](https://en.jiemian.com/article/4256654.html?utm_source=chatgpt.com)

\*\*土豆映像节（Tudou Video Festival）\*\*是中国早期网络原创影像文化中值得重点研究的活动。

它为网络原创视频创作者提供了展示作品和获得认可的机会。

这一类活动的意义在于：

1. 将分散的个人创作者聚集起来。  
2. 使网络视频逐渐形成相对独立的创作群体。  
3. 让原创视频获得评选、展示和讨论的机会。  
4. 推动网络视频从个人娱乐向具有一定组织形式的文化生产发展。

早期视频网站因此不仅是传播工具，也开始承担网络影像文化组织者的角色。

## **009.004 中国早期视频网站的商业模式与技术发展（2006—2009年）**

这一阶段，中国视频网站开始从技术实验和用户增长阶段，进入商业化竞争阶段。

### **一、广告商业模式**

早期视频网站普遍尝试通过广告实现盈利。

主要包括：

* 页面展示广告；  
* 视频播放前的贴片广告；  
* 页面横幅广告；  
* 品牌推广和商业合作。

视频网站希望通过大量免费内容吸引用户，再利用用户流量获得广告收入。

但这种模式存在一个重要矛盾：视频观看人数越多，服务器、带宽和存储成本也可能越高。

因此，用户增长并不意味着平台一定能够盈利。

### **二、视频压缩与转码技术**

用户上传的视频来自不同设备，格式、分辨率、编码方式各不相同。

平台需要将这些文件转换为适合网络传播的格式，这一过程称为视频转码（Video Transcoding）。

早期视频网站需要解决：

* 不同视频格式的兼容问题；  
* 视频文件过大的问题；  
* 不同网络速度下的播放问题；  
* 视频存储和服务器负载问题；  
* 播放过程中的缓冲问题。

这些技术条件直接影响了网络视频艺术的表现形式。

例如，早期创作者经常需要考虑视频文件大小和网络加载速度，不能像今天一样轻易上传高分辨率、长时间的视频作品。

### **三、流媒体技术的发展**

流媒体（Streaming Media）使用户能够在数据持续传输的过程中观看视频，而不必等待整个文件下载完成。

其基本原理是：

1. 视频被编码和分割成适合传输的数据。  
2. 数据通过网络持续发送。  
3. 播放器接收一定量的数据并建立缓冲。  
4. 播放器在接收后续数据的同时播放已经收到的部分。

这使网络视频逐渐从单纯的文件下载转向在线即时观看。

需要区分的是，PPTV、PPS等平台较早采用P2P技术分发视频，而土豆网、优酷网则更加突出用户上传、视频分享和在线播放。两者虽然都属于网络视频发展史，却不是完全相同的技术路线。

### **四、资本投入与市场竞争**

[优酷换logo，网友：怀念土豆视频？ \- 广告狂人](https://images.openai.com/static-rsc-4/1900GSAD7NUe-BZLddgOTjYjHFHansJuFdBHjVA1EW_EAkgvKEo897TZJQtsXsJC0pWekoEvnuDULOcQHiJ8Jlhxv-3lcigW1rCbb3MFtLP8CuOwPO-dSm2WSceq0pIZ_-r41-Ytf_GEr70HDp3xUscwfzW9-_uujNW0RVAp8lk?purpose=inline)

[Internet pioneers \| Features \| Screen](https://images.openai.com/static-rsc-4/_kpMoyUKgbmpGP0ZAVrDIrc8XZUbPr0gkmIuZAD1fJu3w0vHaxvumVYeaWOSNZ1L_SN4S5FI2YH_3hBp4QHafE89UqCyR7Gh54RK0i4YD_OnHu0bmThUyys_HFe6L2N0_tVBKJfF7XFcTUDrKanFoqOqUzdDVVA-BVH-3oLfrRU?purpose=inline)

[酷6网 \| 新传界](https://images.openai.com/static-rsc-4/yqaF_VZh2nLUzkT-_1ItlsqFiwaGXtpiwMtz3OjcJEKkTrY094WjAqFcKAlIbEGWvJbqAnanPXEiDGXCkC3v5oW0m1XSdJujmKNHTgTJVYgTMm6CYRsR1O4j-l2jiAiE-Gi7hpSuk4MM6fDVr6pdjsV1HFqVaJZ2w6uxjypz-W0?purpose=inline)

6

2006年以后，国内视频网站数量迅速增加，风险投资开始进入这一行业。

投资者希望复制YouTube等平台的成长模式，通过大量用户和广告建立商业价值。

但是，行业面临几个突出问题：

* 视频存储和带宽费用较高；  
* 免费用户规模大，但收入有限；  
* 用户上传内容的版权情况复杂；  
* 大量平台之间竞争激烈；  
* 内容质量和审核管理难度不断提高。

这使中国早期视频网站在2007—2009年间经历了激烈的市场竞争与商业模式调整。

yicai.com+2

## **009.005 版权制度与视频网站的转型（2007—2010年）**

2007年以后，中国网络视频行业的制度环境和商业模式逐渐发生变化。

### **一、网络视频管理制度的发展**

2007年12月，相关部门发布《互联网视听节目服务管理规定》，并建立网络视听节目服务的管理和许可制度。

这标志着视频网站开始进入更加明确的行业管理框架。

### **二、版权问题逐渐成为核心问题**

早期视频网站中的视频内容来源非常复杂。

其中既有用户自己制作的原创作品，也有未经授权转载的影视、电视和音乐内容。

随着网络视频商业价值提高，内容版权逐渐成为平台经营中的重要问题。

视频网站开始更加重视：

* 正版视频内容采购；  
* 内容授权；  
* 版权保护；  
* 侵权投诉和内容下架；  
* 自制视频节目。

  ### **三、从UGC向专业内容转型**

  [Los dos grandes 'YouTubes' chinos se fusionan](https://images.openai.com/static-rsc-4/PQjDQ9AfCnj5S12hQWo6bmbeiK1q4GNJgo-cFScrXr3OGoAPBGrRbCGfA1xT3SyvsU7BLRKOjqN3fx3ThV06AKME2ybTumkP9d41KjhHJpAE1NU6nQWmakwUXeBa0aACMOOxAtwebpryV33IKGZkgmXL6PqRDvaj74Cj5chV3Xc?purpose=inline)  
  [rtve.es](https://www.rtve.es/noticias/20120312/dos-grandes-youtubes-chinos-se-fusionan/506812.shtml?utm_source=chatgpt.com)

2008年以后，许多视频网站逐渐扩大正版内容和专业制作内容的比例。

平台开始同时发展两种内容生产模式：

**UGC（User-Generated Content）**

用户自行拍摄、制作和上传视频。

**PGC（Professionally-Generated Content）**

由专业团队、媒体机构和制作人员生产视频内容。

这两种模式并不是完全相互排斥的。视频网站可以同时容纳个人原创视频和专业制作节目。

不过，随着版权内容采购成本上升，部分早期平台逐渐将经营重心转向长视频、电视剧、综艺节目和专业内容。

从网络视频艺术史的角度来看，这一变化具有特殊意义：视频网站最初提供的个人影像创作空间，开始与商业化、专业化的内容产业相互竞争。

cdn.vidchina.cn+2

## **009.006 中国早期视频网站对网络影像艺术的影响**

中国早期视频网站的历史价值，不仅在于建立了一个新的互联网产业，也在于改变了影像艺术的生产、展示和传播条件。

### **一、影像创作主体的大众化**

在传统影像生产体系中，专业摄影师、电视台和影视制作机构占据重要位置。

视频网站出现以后，普通人也能够制作和发布影像作品。

这使影像创作逐渐从专业机构向社会大众扩展。

网络影像创作者开始包括：

* 独立影像艺术家；  
* 大学生和青年创作者；  
* 网络表演者；  
* 动画制作爱好者；  
* 数字影像实验者；  
* 普通网络用户。

  ### **二、影像艺术展示空间的变化**

传统艺术展览通常依赖美术馆、画廊、艺术节等实体空间。

网络视频网站则提供了另一种展示环境。

作品可以通过网页直接呈现，观众不必亲自进入美术馆。

这使网络空间逐渐成为一种新的影像展示场所。

不过，视频网站的商业展示逻辑与美术馆的艺术展示逻辑并不完全相同。视频平台往往更重视播放量、用户参与和广告收益。

### **三、影像创作形式的变化**

早期网络视频文化推动了几种重要创作方式的发展：

| 创作形式 | 主要特点 |
| ----- | ----- |
| 个人影像 | 记录日常生活与个人经验 |
| 网络表演 | 通过镜头进行个人表演 |
| 数字拼贴 | 重新组合已有影像和声音 |
| 网络动画 | 使用数字工具制作动画 |
| 实验影像 | 探索剪辑、声音与影像形式 |
| 互动影像 | 逐渐探索观众参与和网络互动 |

这些形式为后来中国网络影像艺术、网络行为艺术、数字艺术和互动媒体艺术的发展提供了文化与技术基础。

### **四、从视频分享走向网络视觉文化**

早期视频网站还推动了网络视觉文化的形成。

视频不再仅仅是一个需要下载的文件，而成为可以评论、传播、模仿和重新加工的网络文化对象。

用户不仅观看作品，也可能通过自己的创作参与作品的传播和再生产。

这与后来社交媒体影像文化、短视频文化以及网络直播文化之间存在历史联系。

## **009.007 中国早期网络视频网站发展年表**

[Internet pioneers \| Features \| Screen](https://images.openai.com/static-rsc-4/_kpMoyUKgbmpGP0ZAVrDIrc8XZUbPr0gkmIuZAD1fJu3w0vHaxvumVYeaWOSNZ1L_SN4S5FI2YH_3hBp4QHafE89UqCyR7Gh54RK0i4YD_OnHu0bmThUyys_HFe6L2N0_tVBKJfF7XFcTUDrKanFoqOqUzdDVVA-BVH-3oLfrRU?purpose=inline)

[Los dos grandes 'YouTubes' chinos se fusionan](https://images.openai.com/static-rsc-4/PQjDQ9AfCnj5S12hQWo6bmbeiK1q4GNJgo-cFScrXr3OGoAPBGrRbCGfA1xT3SyvsU7BLRKOjqN3fx3ThV06AKME2ybTumkP9d41KjhHJpAE1NU6nQWmakwUXeBa0aACMOOxAtwebpryV33IKGZkgmXL6PqRDvaj74Cj5chV3Xc?purpose=inline)

[史上最悲催的视频网站——56网\_\_财经头条\_\_新浪财经](https://images.openai.com/static-rsc-4/aJfnQWCeBlGLsqbX4BCTbaTsHG9AH2_Ao3q0O6wGyb1KSPQ9hxH0G5tMYa34yuW9ipvUorgb6GvJmlLLuX1NRuJlj203hzsPO7RzjvdxfleLxjSZ8z0d8Apqc37yrn7alkAZFzuvK4iHV6aWhuKtnBqwybfAMniIAXvgDEWnLV4?purpose=inline)

4

| 时间 | 重要事件 |
| ----- | ----- |
| 2004年11月 | 乐视网成立 |
| 2005年 | 土豆网、56网等平台出现 |
| 2005年 | 中国网络原创视频文化开始快速发展 |
| 2006年 | 优酷网、酷6网等进入市场 |
| 2006年 | 中国视频网站数量迅速增加 |
| 2007年 | 视频分享平台竞争加剧 |
| 2007年 | 《互联网视听节目服务管理规定》发布 |
| 2007年前后 | 网络原创视频展示与评选活动发展 |
| 2008年 | 版权意识增强，平台开始调整内容模式 |
| 2009—2010年 | 专业内容、正版内容和商业化运营进一步发展 |

以上时间是产业发展节点，不代表每个平台的唯一上线或转型日期。

Wreport+2

## **009.008 本章的历史定位**

中国早期视频网站的发展，可以放在全球网络影像艺术史的大背景下理解。

**中国网络影像文化的发展脉络**

1. **早期个人网络影像（1995—2004）**  
   个人主页、论坛、Flash动画和可下载视频。  
2. **视频网站与UGC兴起（2004—2006）**  
   乐视、土豆、56网、优酷等平台逐渐出现。  
3. **网络原创影像文化发展（2006—2009）**  
   网络表演、恶搞视频、个人创作和视频分享文化发展。  
4. **专业化与商业化转型（2008—2012）**  
   正版内容、专业制作和视频网站产业逐渐成熟。  
5. **移动视频与社交影像发展（2012年以后）**  
   手机拍摄、社交视频、直播和短视频逐渐改变网络影像生态。

**本章最重要的历史结论：**

2004—2009年，中国早期视频网站建立了互联网原生影像传播的重要基础。它们使普通用户从单纯的影像消费者转变为影像生产者，并逐渐形成一种以个人创作、网络分享、数字传播和用户互动为特征的新型视觉文化。

这一时期的网络视频并不全部属于严格意义上的艺术创作，但它为网络影像艺术提供了新的生产工具、展示空间、创作者群体和文化环境。

**本章相关平台与人物索引**

* 平台：乐视网、土豆网、56网、优酷网、酷6网、六间房。  
* 创作者：胡戈、后舍男生。  
* 重要概念：UGC、PGC、流媒体、视频转码、网络影像、数字拼贴、Remix Culture。

**下一章建议：**

**010 中国网络直播的兴起与早期实时影像艺术（The Rise of Chinese Online Live Streaming and Early Real-Time Video Art）**

这一章将研究中国早期网络直播、秀场直播、网络实时表演和观众互动影像的发展，继续保持与电影史的独立划分。

