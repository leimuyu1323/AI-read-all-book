# **011 中国移动短视频的兴起与网络影像文化的转型**

**The Rise of Chinese Mobile Short Video and the Transformation of Online Visual Culture**

[今日头条、秒拍、美拍短视频平台分析和运营建议-AR创业网](https://images.openai.com/static-rsc-4/q2zL00BiAmwVP8Z58bQ31X__I0t8DOyGyeFQHR6Q21oPEKzK9J7JDEEsLXZW-sBNB2GVS8CL6vtFWlLeyQj6FtE11sp6HYlnhBzN0lu6VdUYdvyWvcvlwZeXJ9Xduks8EXc9xK9DA2MSyQjrvWXW2aNVTpAdVRL1lN5-od1fw4k?purpose=inline)

[短视频应用要发展需深思的两个问题 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/qzPuZBWTo02DOpzzNBIGB3CKH35G6lhRaeLb11jKXWS1Hxdp8ng2uOHDF9lOZK17vDixHvTp7TckMG-rrz30uFjadAUpeauDTGPcN5-BUMzAA5gNABYxKy9gVRsf3ZfL-OCRZhx0MdXkfRhIV-NKcabkSCBWIVpSPfWyFMvlzQ0?purpose=inline)

[快手怎么看自己上没上热门-百度经验](https://images.openai.com/static-rsc-4/W68xnKSz30t-54OY7Q0pX5SEm5a6CFxrLa8I8fObEE1gQZlS0c2B4GlWITCPUQxWVrbbv5j1EqCSQX7Sw2fAo1XkQERc4Nk4iCApAaSTmEx0Re9J7XnjSSmu_4tX9dPJFXeOBQDU26xgOGnBaQ4dDUE99RKrGLdn8RvSOW1UCXA?purpose=inline)

9

本章属于中国网络影像艺术史（History of Chinese Internet Video Art）的重要组成部分，主要研究智能手机普及以后，中国短视频平台的出现、移动影像生产方式的变化、算法推荐机制的形成，以及短视频如何改变中国互联网的视觉文化。

本章与前两章存在明确的历史联系：

* **009 中国早期网络视频网站的发展**：研究个人电脑时代的视频上传、分享和网络原创视频。  
* **010 中国网络直播的兴起与早期实时影像艺术**：研究实时影像传输、视频聊天室、网络表演和直播互动。  
* **011 中国移动短视频的兴起**：研究智能手机环境下的短视频拍摄、编辑、推荐和传播。

三者虽然存在技术与文化上的联系，但属于不同的网络影像传播形态。

尤其需要注意：本章研究的不是电影史，也不是传统电视节目史，而是以智能手机、移动互联网和平台化传播为基础的互联网原生影像文化。

## **011.001 移动短视频兴起的技术与社会背景（2007—2013年）**

### **一、智能手机改变影像生产方式**

[Revisitando a história: Todos os modelos de iPhone já apresentados pela Apple](https://images.openai.com/static-rsc-4/zhfOwmWvwZuAzGpCRBAD9I13RnhbmVUrzzuDUf_kpWDqyzZBP78S8bNpbTBOiCOjz0PB7IQuwz6tRbMp0wxgjyGMonAxntPbL1XkCIVn5mIEzY-y49kDiOWz--OjyW_eed2eAx_GS4qJY6rLMItXulJQ_b0JKJNgX6uUh2p_K2Q?purpose=inline)

[iPhone 3GS raises YouTube mobile uploads 400 per cent \| The Independent \| The Independent](https://images.openai.com/static-rsc-4/WzWKTXY_xz-jXdeSyP4HlKpo_hnr96eS4PZQ1ckEHvz4JsVbfWMfrX0hNySY1vvIpUdbKA7pbzChDvcXAotxVBQteQPZYvC0ipnHUBEXqzQ1QZwigEHCQ76Dj3x80geM0jRaAjaLBKBLVKKuH7BA5pvJNromXGoNVqRPF4uhm9c?purpose=inline)

[iPhone 4 preview \| iMore](https://images.openai.com/static-rsc-4/oJlHqTuM6efxhw8L_raH85ZUlevuUJtNBo3lKKFkbUxbDMgX4Dx8AnTEZXm038VVnzWetFUIXDOw1F5nrYif352smMNJLpU9GnyQekYsNgdaY32WJUeVJ6NrtrSv6SZ7eAhZlQJsMmNAAZV7KolhxXPKOm_ShTRdYLgehFL8kyQ?purpose=inline)

5

移动短视频的兴起与智能手机的发展密切相关。

在传统个人电脑时代，制作视频通常需要经过几个步骤：使用数码摄像机拍摄、将视频导入电脑、使用编辑软件处理、转换视频格式，最后上传到视频网站。

这种生产方式存在一定的技术门槛。

智能手机逐渐将这些功能整合到同一台设备中。

2007年，苹果发布第一代 iPhone；2009年，iPhone 3GS加入视频拍摄功能；2010年，iPhone 4进一步提升了移动影像拍摄和处理能力。

与此同时，Android智能手机也开始快速发展。

智能手机逐渐具备以下能力：

1. 摄像头拍摄数字视频。  
2. 本地处理和剪辑视频。  
3. 添加滤镜、音乐和字幕。  
4. 通过移动网络上传视频。  
5. 使用应用程序直接观看和分享视频。

这意味着用户不再需要依赖个人电脑完成整个视频生产过程。

**拍摄设备、编辑工具、传播渠道和观看终端开始集中于同一部手机。**

这是移动短视频能够迅速发展的重要技术条件。

### **二、移动互联网的发展**

[China To Expect Ubiquitous 3G Communications Network](https://images.openai.com/static-rsc-4/gjDuNewyUhUAi63xcq-Q1jU-81s-n6d0Fk2obsDUSXEVItb1xhBTZvrl3hB7HzJUnjhryZXdycUmg7Q8DmBKbtnEloY7qCGAtpE1N-r2YPwCT1I1c8V4rthc3horME22I2pqDrLUJ6IFv6F-SSmoxyy6Wt242knVYhdOw0hR6DU5-izO9DPw-TMDJWon3nee?purpose=inline)

除了智能手机，移动通信网络的发展也十分重要。

中国移动互联网经历了从2G、3G到4G的技术演进。

| 网络阶段 | 主要特点 | 对移动视频的影响 |
| ----- | ----- | ----- |
| 2G时代 | 数据传输速度有限 | 视频观看和上传受到限制 |
| 3G时代 | 移动数据传输能力提高 | 手机视频分享逐渐可行 |
| 4G时代 | 更高带宽与更低延迟 | 短视频观看和上传更加便利 |

2013年，中国正式向相关运营商发放4G牌照，移动互联网进入新的发展阶段。

4G网络的普及使用户能够更加方便地上传视频、观看在线视频和进行实时互动。

### **三、移动影像生产的大众化**

在传统视频生产模式中，创作者通常需要准备摄像机、电脑和视频编辑软件。

移动短视频则将生产过程大幅简化。

一个普通用户可以：

* 拿起手机拍摄；  
* 在应用程序内剪辑；  
* 添加音乐和滤镜；  
* 直接上传；  
* 立即分享给其他用户。

这种变化使影像生产逐渐从专业创作者向普通互联网用户扩展。

与此同时，手机摄像头也改变了人们记录生活的方式。

日常生活中的吃饭、旅行、购物、校园活动、街头景象和个人表演，都逐渐成为可以被拍摄和传播的影像内容。

因此，移动短视频不仅是一种新的娱乐形式，也是一种新的日常影像记录方式。

## **011.002 中国早期移动短视频应用的出现（2011—2013年）**

[网信办约谈后，快手扩招3000人审核团队](https://images.openai.com/static-rsc-4/al8o2xQdmYM1uBVHdjCsVNDpctqZIA3bVHZxUoEdwuoOCq5gWB82MyGIiLilkv35UM0XK5er8PvszSKvDspDYZ9fOfngR-Qzga67JGF2oIACVtV4cyBUUuTZz87jyQEvZo28e6XHboLptE1oFBdS-NhMTjJA6nL-FaQXZ7AyAeY?purpose=inline)

[今日头条、秒拍、美拍短视频平台分析和运营建议-AR创业网](https://images.openai.com/static-rsc-4/q2zL00BiAmwVP8Z58bQ31X__I0t8DOyGyeFQHR6Q21oPEKzK9J7JDEEsLXZW-sBNB2GVS8CL6vtFWlLeyQj6FtE11sp6HYlnhBzN0lu6VdUYdvyWvcvlwZeXJ9Xduks8EXc9xK9DA2MSyQjrvWXW2aNVTpAdVRL1lN5-od1fw4k?purpose=inline)

[Weishi, A Chinese Vine-Like App, Chalks Up 160M Views In A Day](https://images.openai.com/static-rsc-4/aPoapKwJqmYmxizMOezTsHx4Zd3N5EPHOmtiz3xaJLEFxNvn7uiqgJ7F9cBaaxfoZgA0mljZ1ta_yPNIOIwgZ0RoUyieIzDVZVJpOFPZK2XqPe6gDbbL5e6j8a_9b-UUVCOe7FInpSEyoNJou9ls2n_4N8WY4e8-WVlb9pb7inc?purpose=inline)

7

2011—2013年是中国移动短视频的萌芽阶段。

这一时期的短视频应用还没有形成后来抖音、快手那样成熟的内容生态。许多产品最初是视频拍摄工具、GIF制作工具或社交软件的附属功能。

它们共同探索了一个新问题：

**如何让用户使用手机，在几十秒甚至更短的时间内完成影像创作，并立即将作品分享给其他人？**

### **一、GIF快手：从动态图片工具到短视频社区**

[快手(GIF快手):發展歷程,融資記錄,產品特點,影響評價,相關事件,\_中文百科全書](https://images.openai.com/static-rsc-4/DhHOOm6jMCGcq9F-fUzqRZhtFNzn5uDAVtEWhgffPOP3ZmUGLP4RHmZMRHRuSE-YkrUawyNCfdSflDGTRkemN_dfrbTJSJWOyEwWtTjFUwqz2rKKLM-8ITlXPHwEJbGkxHo8iBCWXse0lChxIic7BSHVXmH57hwqTR6p65SGI9g?purpose=inline)

**GIF快手**

2011年3月诞生，是中国移动短视频发展史上具有代表性的早期产品。

GIF快手最初并不是一个完整意义上的短视频社区，而是一款制作和分享GIF动态图片的手机应用。

GIF（Graphics Interchange Format）是一种支持多帧动画的图像格式。

用户可以将连续画面制作成循环播放的动态图片。

例如：

* 动物动作；  
* 搞笑表情；  
* 人物动作；  
* 日常生活中的短暂瞬间；  
* 网络表情包。

GIF快手最初主要满足用户制作和分享动态图片的需求。

但这种产品形态也具有一个潜在的发展方向：如果用户能够直接拍摄连续影像，那么动态图片工具就可以逐渐发展成视频创作平台。

**2012年11月，GIF快手开始从单纯的工具应用向短视频社区转型；2013年进一步发展短视频社交功能。2014年11月，产品正式去掉名称中的GIF，改名为快手。**

kuaishou.com+1

这一过程展示了移动短视频平台的一条重要发展路线：

**动态图片制作工具**

**手机短视频制作工具**

**用户短视频社区**

快手的早期发展也说明，移动影像文化并不完全起源于传统视频网站。它还可以从动态图片、表情文化和移动社交工具中生长出来。

### **二、秒拍：短视频与社交媒体的结合**

[Security Verification](https://images.openai.com/static-rsc-4/sybwRM8SJPKbVh4m20hpf0ucjNl9ayDG1QGygp_64pS2c3HtcA9cMFrmz8Kl5QC2ly3UrwndY8QAy5rf5c7BLpYll4Xdv3aczU8Cm-mBwymGFnnvCU75Xt6oXQ0NF7-nTEzmF9KLZ5LxnCb_-9ispGXpHVuQiynnw19G6HMSYDI?purpose=inline)

**秒拍（Miaopai）**

2013年推出，由一下科技开发，后来与新浪微博生态形成紧密联系。

秒拍的一个重要特点是强调短视频的快速拍摄和社交分享。

与传统视频网站不同，秒拍希望让用户直接在手机上拍摄短视频，再通过微博等社交网络传播。

它的主要功能包括：

* 手机直接拍摄短视频；  
* 视频滤镜与简单编辑；  
* 视频上传；  
* 社交平台分享；  
* 明星和网络创作者的视频发布。

秒拍的发展说明，短视频可以不依赖一个完全独立的社交网络。

它也可以依托已有的社交关系传播。

例如，一个用户拍摄的视频可以通过微博转发，使原本只在小范围内传播的内容获得更多观众。

这种模式将短视频与社交媒体结合起来。

### **三、腾讯微视：社交平台对短视频的探索**

[腾迅微视logo矢量图 \- 设计之家](https://images.openai.com/static-rsc-4/9g7X9o1Uvp8RFcsbY6sL9uyYlkpvpuAjrgJ8PlEZP4Tyd_MNcxTep8PSWs5iyuUQA2YecV-dkIN7KWfkKKQJ1BN_8s5oY2syrtlK6XYs5O-ckvavFFEN4k6_AeHaoTgsNu1pwlKOHTHq5sahrW06uG7sunUYqB1TtLmJRJvyL-A?purpose=inline)

**腾讯微视（Tencent Weishi）**

2013年9月推出，是腾讯早期探索移动短视频的重要产品。

微视试图将短视频制作与社交关系结合起来。

用户可以拍摄短视频、添加音乐、进行简单编辑，再分享给好友。

它的主要特点包括：

1. 强调短视频的社交传播。  
2. 与腾讯已有的社交产品生态存在联系。  
3. 鼓励用户通过短视频表达个人生活。  
4. 尝试将短视频纳入移动社交体验。

微视后来经历业务调整和重新发展。它的早期探索说明，即时通信和社交平台也希望将视频变成一种新的日常交流语言。

### **四、三种早期发展路线的比较**

| 平台 | 最初的产品特点 | 主要发展方向 |
| ----- | ----- | ----- |
| GIF快手 | 动态图片制作 | 短视频社区 |
| 秒拍 | 手机短视频拍摄 | 社交媒体传播 |
| 腾讯微视 | 短视频社交应用 | 腾讯社交生态 |

这三种路线代表了中国移动短视频早期发展的三个方向：

* 工具型影像生产；  
* 社交网络视频分享；  
* 综合性短视频应用。

它们为2014年以后短视频行业的快速发展奠定了基础。

流媒体网+2

## **011.003 美拍与移动影像美学的形成（2014—2016年）**

[《美拍Meipai》用iPhone也能拍出10秒如MV般的小短片 \| 梅問題．教學網](https://images.openai.com/static-rsc-4/bCcYY94HCMcWl1C1QqQqXNmM13lEbXVUvfZ0UL19HUmaGyylLP0eCh9ksV5mgqLbsg9PR94BRdt_71eHhvpuzOB7EU4udMMOn6-2rhk-Ff4mCKqTAPtgEhll_9jOBSEHX33qG6h86x3IK6uoD0FWU-DdrHkFc_-O6cqxPc8wcso?purpose=inline)

[从图片杀入视频领域，美图秀秀推短视频应用美拍，让用户10秒也能拍大片-36氪](https://images.openai.com/static-rsc-4/3-XCtKTJsbSatEUuFuoNcviZfKPJkDvRfP5R13u-2rozuYXfADz2z1QqkSuTPIMuTWnmWt3wvEuC6Ya9n2KV1MLfE9l6mOIKkn2PlmeE-In1izwyqd0L2jKJKa8Esj8rR3aY4GClaxq6c2XN5NpqKTvL9sZa94zvG19n90DTBlc?purpose=inline)

[从土味视频到土味情话，“土”为何令人着迷？ \- 每日头条](https://images.openai.com/static-rsc-4/IMm2oxZ2vUCg6VMDfJdJHk1A06xZ9bQTc1tLsTr0ReJsSbyCgLOPF8dpV3PWnTaD4-AHU2lf7yhRI5mb_Cq6eZ9vDU1m9PeZbrr-Hlz55f3-kpS20TI3fgpg7KFkKFdovN5WijYEqgoN8vzfFrTJKy02bPTXXTQZrMWzzMwbOoo?purpose=inline)

7

2014年是中国移动短视频发展史上的重要年份。

这一时期，智能手机、4G网络和移动应用市场共同推动了短视频产品的发展。

其中，\*\*美拍（Meipai）\*\*是值得重点研究的平台。

### **一、美拍的诞生**

[美拍中发布语音照片的具体流程介绍-天极下载](https://images.openai.com/static-rsc-4/ALkNc-rwn_sdglEnIfUmXFVS7xI9cqNkexWu8ZsaciWvXstXReWkCPpkPbpDB19vlTZf2HXFoR7oFq1mLcMdK9yXvqZu6rUnPKWX_j8U-cqbmoX3lswpCg8wmQuh_u2cLc15vdjwj1qiY17Iglh3fcvHNtTvtmrT-pyC8wkDYiw?purpose=inline)

**美拍**

2014年5月推出，是美图公司在移动视频领域的重要产品。

美拍与早期一些以简单视频上传为主的产品不同，它特别重视影像的视觉效果。

用户可以在拍摄过程中使用滤镜、特效和音乐，使普通生活影像变得更加具有观赏性。

其主要功能包括：

* 视频滤镜；  
* 人像美化；  
* 音乐配乐；  
* 视频剪辑；  
* 特效处理；  
* 社交分享。

美拍的出现体现了一个重要变化：手机不再只是记录现实的工具，也成为加工和美化现实影像的工具。

### **二、移动影像美学的形成**

[从图片杀入视频领域，美图秀秀推短视频应用美拍，让用户10秒也能拍大片-36氪](https://images.openai.com/static-rsc-4/3-XCtKTJsbSatEUuFuoNcviZfKPJkDvRfP5R13u-2rozuYXfADz2z1QqkSuTPIMuTWnmWt3wvEuC6Ya9n2KV1MLfE9l6mOIKkn2PlmeE-In1izwyqd0L2jKJKa8Esj8rR3aY4GClaxq6c2XN5NpqKTvL9sZa94zvG19n90DTBlc?purpose=inline)

[36kr.com](https://www.36kr.com/p/1641870573569?utm_source=chatgpt.com)

在传统摄影中，用户通常需要通过专业相机、镜头、灯光和后期处理来获得特定的视觉效果。

美拍等移动应用则将部分图像处理功能直接整合到手机应用中。

用户能够在拍摄前或拍摄后调整：

* 肤色；  
* 亮度；  
* 对比度；  
* 色彩；  
* 面部特征；  
* 画面风格。

这使移动影像逐渐出现一种新的视觉倾向：影像不仅记录人物，也主动塑造人物的网络形象。

从视觉文化研究角度看，这涉及一个重要问题：

**手机摄像头所记录的现实，与用户希望展示给他人的自我形象，是否已经成为两种不同的东西？**

### **三、全民社会摇与模仿式影像传播**

[从土味视频到土味情话，“土”为何令人着迷？ \- 每日头条](https://images.openai.com/static-rsc-4/IMm2oxZ2vUCg6VMDfJdJHk1A06xZ9bQTc1tLsTr0ReJsSbyCgLOPF8dpV3PWnTaD4-AHU2lf7yhRI5mb_Cq6eZ9vDU1m9PeZbrr-Hlz55f3-kpS20TI3fgpg7KFkKFdovN5WijYEqgoN8vzfFrTJKy02bPTXXTQZrMWzzMwbOoo?purpose=inline)

[kknews.cc](https://kknews.cc/zh-sg/media/4xpv3nx.html?utm_source=chatgpt.com)

2014年，美拍等平台推动了网络舞蹈和模仿类短视频的传播。

其中具有代表性的现象是全民社会摇。

社会摇视频通常具有以下特点：

1. 采用节奏鲜明的音乐。  
2. 使用重复性较强的身体动作。  
3. 画面以人物表演为中心。  
4. 拍摄和剪辑方式相对简单。  
5. 其他用户可以模仿相同动作并制作自己的版本。

这种传播方式使视频不再只是一个独立作品，而是可以被大量用户复制、修改和重新表演的文化模板。

2014年，美拍发起的全民社会摇活动在微博等社交网络上广泛传播。

流媒体网+1

从网络艺术史角度看，这与行为艺术中的重复表演、流行文化中的模仿，以及数字艺术中的再创作具有一定联系。

### **四、短视频中的表演身体**

美拍时代的短视频逐渐发展出一些典型的视觉表达方式：

* 自拍表演；  
* 对口型；  
* 舞蹈；  
* 变装；  
* 美妆展示；  
* 日常生活表演。

这些作品通常不需要复杂的叙事结构。

它们的重点可能只是一个动作、一段音乐、一种表情或者一种视觉效果。

这使短视频逐渐形成区别于传统影视作品的影像语言。

### **五、小咖秀与对口型文化**

[小咖秀势力领衔 盘点那些一夜成名的APP\|APP\|热门\_新浪科技\_新浪网](https://images.openai.com/static-rsc-4/SghWukW4YZ9JI8AvFhON3zqyRMo_y49uewISi_WNW8xLwtn0Fzj9vuR9my0tPVL38dXqRngbqzgBiKKK2SuOLD-jvmqcRq4ELifYw-cvqazHGmqv1rKDs-smj_-Vh9cYVBTIZ0zbp3_fdrJSjgOhwfmukzSrVfbXbdY3sn_AfMk?purpose=inline)

[Miaopai: from a Vine clone to a tech unicorn in 2 years \| by All Tech Asia \| All Tech Asia \| Medium](https://images.openai.com/static-rsc-4/yoKzFw6_siqQ5JWXhDxH3R7W4MzF1w58WsAlJv82kgGn9Ub8aWd-gcon1IxdUM5AU56dxHgeK4ek-naBfYPnavpLq364lx6BT5tBdV2m8mVGlBkYyJWNrtHK1X9XRLPfd08hqjepgUG5QaW-kqs-8R6FnaFEpW8DhgwtE_Rtslg?purpose=inline)

[小咖秀手机客户端下载\_小咖秀手机客户端苹果版下载\[表演飙戏\]-下载之家](https://images.openai.com/static-rsc-4/UOu2lSk4oF-oGGjt-WRsmCrVQu3y9OkOUNOktn7fNYYDNKPn1Q01lRpuSzJfFQPSiRx7PDxOKLLJFFsGclI4Ah0LNBC65XxGXNbxehSJQA-7es9PCrXAICU1uYprhqKpNRsno_ITJvxxV9TZ0Z4xl6zseZG6eJwNjMmfDjPol6k?purpose=inline)

7

\*\*小咖秀\*\*于2015年5月推出。

它的核心玩法是：用户选择一段已经录制好的声音或台词，然后对着手机摄像头进行表演。

用户通过模仿原始声音的语气、表情和动作，制作具有喜剧效果的短视频。

其创作方式通常包括：

1. 选择音频素材。  
2. 播放原始声音。  
3. 用户进行同步表演。  
4. 应用程序录制用户画面。  
5. 生成可以分享的短视频。

小咖秀的重要意义在于，它将声音素材、身体表演和移动视频制作结合起来。

用户不需要自己创作完整剧本，也能够参与网络表演文化。

从艺术史角度看，这与配音表演、模仿艺术、身体表演以及再混合文化（Remix Culture）存在联系。

## **011.004 快手与草根移动影像文化的发展（2013—2017年）**

[快手APP的产品逻辑及盈利模式 \- 每日头条](https://images.openai.com/static-rsc-4/tCThEpmu2Q_xxfmjYGDpgrEC4lqD6A8fF1hBq2QB8t9N3yBIXpT-wmoK2ZUyqHfHriFqZPt-DCeLOn2LG3cXL6ov924wxUYDGDkhVJ8RoaxZdwgll4cxG3yMNdkUWNEmwfZuXEsuTXPOJUhfmmH1CkW0a3aimL9-y9-lgMIGAlA?purpose=inline)

[Video App Highlights Growing Divide in China \- WSJ](https://images.openai.com/static-rsc-4/KQMkPhFL1rc_UYoOdMffACVMUZrdPNQ5rqq6sYu0Q8iL5EvdebvPqZ3fvssmSdYyCEpAKLwUozbFGbD9Uejn_vCiBzm7tErrbOWgEvfmMS52XCMsJSHJ9_eAeF6xeCzDy_zpWXJpClGPc4dDRzA9jqPokUr9NALih5avtknxmms?purpose=inline)

[赤峰老张靠诙谐日常走红快手，真实记录乡村生活吸引近25万网友追更\_张静\_视频\_女儿](https://images.openai.com/static-rsc-4/d2S9C-zFo7KYruI_ffkWAhYOZjo7fepKDjkVNjYIakiVWjtDYEeL3n2l-_F8ymrk46WifkNeW2gpU5BOAk_Eyk-g_G1bl_bdF8NBHFdFRLZkDS7ufg1XYUi9WGKIh5DgNDVNZY0nd0sp0S9px15LeFaF0vKICreh01MFeTVKUL4?purpose=inline)

10

快手与美拍代表了中国移动短视频发展中的两种不同文化路径。

美拍早期特别强调滤镜、美化和视觉效果，而快手逐渐发展出以日常生活记录和用户社区为重要基础的影像文化。

这里并不是简单地将两者划分为高雅和通俗，而是研究不同平台如何组织用户、影像内容和传播关系。

### **一、快手从工具向社区转型**

前面已经介绍，快手起源于GIF快手。

2012年11月，它开始转向短视频社区，2013年进一步完善短视频社交功能，2014年更名为快手。

2015年，快手用户规模和视频上传量迅速增长。

快手官方资料记录，2015年6月其用户规模突破1亿，单日视频上传量突破260万。

kuaishou.com

这说明平台逐渐不再只是提供拍摄工具，而是形成了大量用户持续生产内容的社区。

### **二、日常生活成为影像内容**

[赤峰老张靠诙谐日常走红快手，真实记录乡村生活吸引近25万网友追更\_张静\_视频\_女儿](https://images.openai.com/static-rsc-4/d2S9C-zFo7KYruI_ffkWAhYOZjo7fepKDjkVNjYIakiVWjtDYEeL3n2l-_F8ymrk46WifkNeW2gpU5BOAk_Eyk-g_G1bl_bdF8NBHFdFRLZkDS7ufg1XYUi9WGKIh5DgNDVNZY0nd0sp0S9px15LeFaF0vKICreh01MFeTVKUL4?purpose=inline)

[The Chinese Farmer Who Live-Streamed Her Life and Made a Fortune \| The New Yorker](https://images.openai.com/static-rsc-4/_8R7WSLuoc4ZmFQJKAuVyCO19j793cu3n9EgQnCVEIL11FbuHpuSkZDZBTvd0eQGVtRn3rqYfABq5pgOMGa8sWuUGp70Asp_1RnWz7oX36UnPSurIA8XMy6ViEjkolNCSwLip2k1yW2n3Jb7Sn34KY-jvD4hU7fWFBoNA5H3Ml8?purpose=inline)

[45天涨粉429万，这届年轻人爱上了东北姥姥丨AgeClub](https://images.openai.com/static-rsc-4/0hH-epSzmuVDqpCIzgOohX50R81K2lDYd0CnMfXUPGgP_DGVq90z0_G_uVThtF-3dOS3g3et30P9RF2FEY0wqygWvubIqB2XI6W_18-3JEbJ14JONBdLmehKCZlxKTcm410TrJgy-0zQ1AXdHoBwjSPB_ktiEs-0dPxM3kS_iks?purpose=inline)

7

快手的一个重要特点，是大量普通用户将自己的日常生活作为视频内容。

这些内容可能包括：

* 农村生活；  
* 家庭劳动；  
* 街头小吃；  
* 手工制作；  
* 农业生产；  
* 地方文化；  
* 日常娱乐；  
* 个人才艺。

这些影像与传统媒体中的城市中心视角存在一定差异。

在传统媒体中，许多普通人的日常生活很少有机会成为大规模传播的内容。

而移动短视频平台降低了影像生产和传播的门槛，使更多地区、职业和生活环境进入网络视觉空间。

### **三、草根影像文化**

所谓草根影像文化（Grassroots Visual Culture），是指普通社会成员利用相对低成本的设备和传播工具，记录、表达和传播自身生活经验所形成的影像文化。

快手的发展使这一文化形式得到更大规模的展示。

其主要特征包括：

1. 普通用户可以成为创作者。  
2. 生活经验可以成为视频题材。  
3. 影像制作不必遵循专业影视规范。  
4. 用户之间能够形成持续互动。  
5. 地方性文化能够通过网络获得更广泛的传播。

   ### **四、快手的社区关系**

快手早期的社区文化强调用户之间的关系。

观众不仅关注视频本身，也可能持续关注某位创作者的生活。

例如，用户可能长期观看某个家庭、某个村庄或某个手工艺人的视频。

这使短视频逐渐具有一种连续性。

它不再只是孤立的影像作品，而可能成为一个人或一个群体日常生活的持续记录。

### **五、快手与影像记录的社会价值**

从视觉人类学（Visual Anthropology）的角度看，快手等平台上的生活视频具有一定的研究价值。

它们能够保存：

* 地方性生活方式；  
* 民间手工技艺；  
* 日常劳动过程；  
* 地方语言和表达方式；  
* 家庭与社区生活；  
* 普通人的自我叙述。

当然，平台视频并不等于完整、客观的社会档案。拍摄者的选择、平台推荐机制和视频剪辑都会影响最终呈现的内容。

但这些视频确实为研究当代中国日常视觉文化提供了新的材料。

## **011.005 抖音与算法驱动的短视频文化（2016—2018年）**

[Chinese tiktok app download \- ondemandopl](https://images.openai.com/static-rsc-4/hEOrcchiBzSUnrH5QR7AIXmEjnYPQPWiGFDsvO_ZcDiAPFOS34FaxQANFt0vbAK3W4dak8r2pLZ4cNVcu-SYbqfBBybrigwkXB-PLIq5sK4cU2-ATZQbMm7UufowIcm9Kmyi0hRupkvxpqv9ujaRrS-LjsKm1psGmYH0emalIfo?purpose=inline)

[浅析现阶段音乐短视频的三种玩法 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/dZ7hCuK2nIpxuxHK6ijHBPmQY2KAwe6wSQvzRLCHx85l_oBqeBfRLtE79FIoqYssjAjFH26R1eM8WOLjX0YiP33kSnY1-VdalLVVfr1ibsFhBj-PQsZC4n4qbaJhnGPLgadGDJLwRvbTMYNUt1ERO4ixmVtLl2r1-qcw7GBrVWg?purpose=inline)

[抖音：短视频万军丛中杀出的一匹黑马 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/vE9Cp9aj_LNmQZ-eWAl5dna93VN9o2GBXxYcZgsDuhuUDAtvK729i-t0ILq4uED6LKhDoRyfCEV5JbblgpfMI2lKIqMVPQoFrxzqrJCI-8laeTIFg1rv1moMdMVKoQStJKfgJm9hwHXH0rZy1nVi_pdOnzBFWhIMknwSw0VLCkA?purpose=inline)

7

2016年是中国短视频产业发展史上的重要转折点。

此前，许多短视频应用主要依靠用户主动关注、社交关系和外部链接传播视频。

而2016年以后，以抖音为代表的平台逐渐强化个性化推荐和信息流传播。

这改变了短视频的生产、分发和观看方式。

### **一、抖音的出现**

[Logo Douyin \| Get-picto](https://images.openai.com/static-rsc-4/1w1EzBFwy3vIqgLccJaL3XoPKPPliCG8bkhMgKOCBmvOYyTKijEKwc9dUHab5sGTd1BZDUSiSqCyBcAKIZ5_1pElWHkfOuNh03XsffeKhadDee_DANjJFKGCeczmCUwIzQ71dcZp12Ea-2beS9j08aULPOHtyxyI-0PIaXliZVA?purpose=inline)

**抖音（Douyin）**

2016年9月上线，最初定位于音乐创意短视频平台。

抖音由字节跳动推出。

其早期产品强调音乐、节奏、滤镜和短视频表演。

用户可以通过手机拍摄短视频，并使用应用程序提供的音乐、特效和剪辑工具进行创作。

早期抖音的主要内容包括：

* 音乐短视频；  
* 对口型表演；  
* 舞蹈；  
* 搞笑表演；  
* 视觉特效；  
* 创意模仿；  
* 生活记录。

2016年9月，抖音正式上线。

sf26-sign.douyinstatic.com+1

### **二、音乐短视频的视觉语言**

[抖音，再难出“千万爆款”？\_壹览商业](https://images.openai.com/static-rsc-4/O3bzSPc9qk7V6928Jt0c8hEZq42vjciG7KPIUaG-eJg2LTIPOAjDtXT-_kS6MFTM6AEMdfZ0slDWqfsypPbqkTwE3QVEviMwjY-0QXTurLMQCsB5gMLpGFg-okLnbb46xp3JOE7OGmdeVPO2Bg3WoyUgrnW-VHmD9QWdvTd3C6c?purpose=inline)

[yilantop.com](https://www.yilantop.com/article/17821?utm_source=chatgpt.com)

抖音早期的一个重要特征，是将音乐与短视频紧密结合。

传统音乐传播主要依靠音频作品、音乐视频和现场表演。

音乐短视频则将音乐变成个人表演的背景和组织工具。

创作者可以选择同一段音乐，然后根据音乐节奏设计动作、表情和镜头变化。

这使音乐具有了新的传播方式。

一段音乐可能因为某个用户的表演而流行，其他用户再使用相同音乐创作自己的视频。

由此形成了音乐、动作和模仿之间的传播关系。

### **三、算法推荐的出现**

[抖音：短视频万军丛中杀出的一匹黑马 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/vE9Cp9aj_LNmQZ-eWAl5dna93VN9o2GBXxYcZgsDuhuUDAtvK729i-t0ILq4uED6LKhDoRyfCEV5JbblgpfMI2lKIqMVPQoFrxzqrJCI-8laeTIFg1rv1moMdMVKoQStJKfgJm9hwHXH0rZy1nVi_pdOnzBFWhIMknwSw0VLCkA?purpose=inline)

[woshipm.com](https://www.woshipm.com/evaluating/850961.html?utm_source=chatgpt.com)

抖音发展的关键变化之一，是强化了算法推荐（Algorithmic Recommendation）。

在传统视频网站中，用户通常需要通过搜索、分类目录或订阅来寻找视频。

而推荐算法可以根据用户的行为，自动选择可能感兴趣的内容。

其基本过程可以简化为：

**用户观看视频**

**系统记录行为**

观看时长、点赞、评论、分享、关注等

**推荐模型进行计算**

预测用户可能感兴趣的内容

**生成个性化信息流**

**新的用户行为反馈**

系统持续更新推荐结果

这形成了一个持续反馈过程。

例如：

1. 用户观看一条舞蹈视频。  
2. 用户观看了较长时间。  
3. 用户又点赞了类似视频。  
4. 系统根据这些行为更新用户兴趣模型。  
5. 后续推荐中可能出现更多舞蹈视频。

抖音的算法公示资料也说明，其推荐系统会利用用户的点击、观看时长、点赞、评论、分享等行为信息，预测不同内容可能获得的互动，并据此进行排序和推荐。

beian.cac.gov.cn+1

### **四、从关注式传播到推荐式传播**

这一变化对网络影像文化产生了深远影响。

传统社交媒体主要依赖用户之间的关注关系。

例如，用户发布一条视频，主要由好友、粉丝和转发者看到。

算法推荐则允许平台将视频分发给尚未关注创作者的用户。

这意味着：

* 新创作者有机会获得陌生观众；  
* 作品传播不完全依赖个人社交关系；  
* 用户可能观看从未主动搜索过的内容；  
* 平台成为影像传播的重要组织者。

从媒介史角度看，这是短视频传播结构的一次重要变化。

### **五、竖屏视频与全屏观看**

[Что такое Douyin и как использовать его для бизнеса в Китае \[Гайд от Asia Pacific\]](https://images.openai.com/static-rsc-4/yRkS0khhCA-xSWKonR198clar_9IPQv4mbUikdbckkqp6CNpQKqpBM63Kd6HQHROWonSci-eaaoipvVEba0qK32M0FB9qCwFW4qTkeTKJs8TRG2DkTPi9k40WYDxm-VtQLmUk_uHlz-nczr9HNtODz0Hqir0aTO17bcNzOwtyEs?purpose=inline)

[黑马抖音的突围，不一样的产品分析 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/tOFb7DpbRqb_ILA9T4tmn5mj2K5NkFrMeQLDpAYqHhGk3km4bBWq7ig31Gm1-XnWmIMcFKRWMkYyC7-5dxdu72IZRpxqQNWE3xiEHkPs-2vK_aq47Zh_aEbIc_OvCp4yr3Dk9P_SprkHUPZtthu3oyIXj8e0W44s-EmQZtsn_Ro?purpose=inline)

[为什么刷抖音会上瘾？ \| 人人都是产品经理](https://images.openai.com/static-rsc-4/7rZgWOnLLQ4Q5lajSprOmbtdOwborKVMHNTM2wMlj8FE0NwOoIdevsqm06MY7rICiPVzDxNi3ebS-EQWdlSLqs5FLTvUIJTE9YclMSoEvKDcOU6ZINpLa8175Cj6MLM6eSrn5QzF-EBI77WGz1L1-zOTGRkVxAXPZCY-Pa0FE6M?purpose=inline)

7

移动短视频逐渐形成了以竖屏为主的视觉形式。

传统电视和电脑视频通常采用横向画面。

而手机天然具有竖向持握的使用习惯。

竖屏短视频的特点包括：

1. 充分利用手机屏幕的纵向空间。  
2. 适合展示人物面部和身体。  
3. 方便单手操作。  
4. 可以采用上下滑动切换视频。  
5. 使用户连续观看不同作品。

竖屏不只是画面比例的变化，它还影响了创作者的构图、拍摄角度和表演方式。

### **六、上下滑动的信息流**

短视频平台逐渐形成一种特殊的观看方式：

用户不必主动选择下一个视频，只需要向上滑动屏幕，系统就会自动呈现下一条内容。

这种设计使视频观看从主动搜索逐渐转向连续浏览。

它改变了用户与影像之间的时间关系：

传统视频观看通常围绕一部完整作品展开，而短视频信息流则由大量彼此独立、连续出现的短片构成。

从视觉文化研究角度看，这可以理解为一种新的影像消费结构。

## **011.006 西瓜视频、火山小视频与短视频平台的多元化（2016—2018年）**

[新榜——新媒体，找新榜](https://images.openai.com/static-rsc-4/use_wNM_ZPpusnUqvTeRz5osRLrNkUOC4yC57CxkqlW7PW9J-azopj-QqdXPCNGbFLn0VOQSn6EeS3pf7PZXoDVwMdhJODXNU1Us_VBJUL34STucm9wKIfO57T93m7qgks4977w7q2QpdA4pKDS0_mHrUCm-zlyPZ9T6s40HkEs?purpose=inline)

[腾讯微视发布新LOGO，你看好吗？\_新浪新闻](https://images.openai.com/static-rsc-4/Tts36_grC0fcsarNOH2y9bp40J9Hmhib4dtl9MYi0H_eoxQi5SGtXQ6RxM6IbIfwN_VfXX7yttsSmLwkqTCnOfoGNdMQbtZyk6IWRazq0brhQZK6_Pfrah2Uub-DzcfjvbcYWeqTGuIp67sFvh1GbesbfClvCfVdIIJX0t0gLNQ?purpose=inline)

[火山小视频下载老版本-火山小视频旧版app下载 \- 京华应用库](https://images.openai.com/static-rsc-4/Z34DTsZQPz4AC1knD-1ciIMlp_6k853zlDSxQaA1_udqvVxWCJylDlzc66nyFCbXKERT8n4OWxdZcNorkK2qdZrHeGL6UDvf5z_15uocuZd3vd-ipKFfnX2DXznsWVU_ydzUTlz-7Gi9XW-YxCECX1NEJezLvqcAdUdiNUuIxKk?purpose=inline)

6

2016年以后，中国短视频行业不再只有单一的发展方向。

不同平台开始探索不同长度、不同题材和不同用户群体。

### **一、西瓜视频：从短视频向中视频发展**

[新榜——新媒体，找新榜](https://images.openai.com/static-rsc-4/use_wNM_ZPpusnUqvTeRz5osRLrNkUOC4yC57CxkqlW7PW9J-azopj-QqdXPCNGbFLn0VOQSn6EeS3pf7PZXoDVwMdhJODXNU1Us_VBJUL34STucm9wKIfO57T93m7qgks4977w7q2QpdA4pKDS0_mHrUCm-zlyPZ9T6s40HkEs?purpose=inline)

**西瓜视频（Xigua Video）**

其前身为头条视频，2017年升级为西瓜视频。

西瓜视频的发展与抖音有所不同。

抖音主要强调短时长、快速传播和音乐化表达。

西瓜视频则逐渐发展出较长的视频内容，包括：

* 生活记录；  
* 知识讲解；  
* 科普；  
* 纪录性视频；  
* 美食；  
* 文化内容；  
* 专业创作者制作的视频。

它说明移动视频并不必然意味着所有作品都越来越短。

移动平台同样可以承载较长的叙事、知识传播和创作内容。

### **二、火山小视频：强调生活记录和用户创作**

[手机火山小视频 应用图标logo设计PNG图片素材下载\_图片编号8113932-PNG素材网](https://images.openai.com/static-rsc-4/BCGS-_PXceLFNczfzAa-HbiHZSsq2x7bSvbAIqliRQBIwIQ1eLmNzGqANtW_JAXWcoFgWlXzFXKhv6rrdqaTX35SpVlQDAZISGowaBJEl_twnLNmCX0sc-VdKEopWzA4fQRGdu6GL52VSVuryJBviJqFgQ-SJwbi1r0cCc7B4vs?purpose=inline)

**火山小视频**

2016年推出，后来发展并更名为抖音火山版。

火山小视频早期强调用户拍摄、生活记录和社区互动。

它与快手一样，都探索了普通用户持续创作短视频的可能性。

### **三、梨视频：新闻与纪实短视频**

[梨视频-有故事的短视频 \- News App \| MWM](https://images.openai.com/static-rsc-4/K-xCljhIFoZ5z7gelNnlnbdjT0vvM5bdEwHyLxHOQ0QkvjR27fLhbKzcdszgfV_5qxIfEB_iDiuFDdB1Mqb0KGQSq6NxbXipS2zBq0LpUM0e7jz-B_fgFxo612R2i6KntpQgfAHZMLg4H_OiiCInpWGDfLezPa7RxuHPqb9gENg?purpose=inline)

**梨视频（Pear Video）**

2016年上线，重点发展资讯、社会事件和纪实类短视频。

梨视频体现了另一种移动视频发展方向：将新闻和社会纪实内容制作成适合移动设备传播的短视频。

其内容包括：

* 社会新闻；  
* 城市生活；  
* 人物故事；  
* 突发事件；  
* 现场记录；  
* 国际新闻。

与主要依赖个人娱乐表演的平台相比，梨视频更强调新闻采编和专业内容生产。

它体现了短视频与新闻传播之间的结合。

### **四、不同平台的发展方向**

| 平台 | 主要内容特色 |
| ----- | ----- |
| 快手 | 日常生活、社区创作 |
| 美拍 | 美化影像、才艺表演 |
| 抖音 | 音乐、创意、算法推荐 |
| 西瓜视频 | 较长视频、知识和生活内容 |
| 火山小视频 | 普通用户生活记录 |
| 梨视频 | 新闻、社会纪实 |
| 微视 | 社交短视频与娱乐内容 |

这些平台共同构成了中国移动短视频产业的早期多元化格局。

bpi.edu.cn+2

## **011.007 B站与青年视频创作文化**

[B站十年回忆录 \| 运营派](https://images.openai.com/static-rsc-4/vUR-ZY3OjoTQHKgvvtsBZr-6kmkHipJHn98qlQfHMxgaNewN19F259rKL-XowpgfN3Ax4y7tvsBIGQ5Z-yaeE26G2vDwjOFcrCNvoNKoRmJmdJtyMxxXofWl2xI8CjHyQCd5DT-xnYJczxkLe-n4GbSGoXsmuk_0Ns0jMxmw80w?purpose=inline)

[B站「彈幕破百億條」 了解這5大類型彈幕 看片時更有感！ – 史塔夫科技事務所](https://images.openai.com/static-rsc-4/RAfv4cRfUDe24bVL3CTe3JPWvQ7QXDxE1f0asDBd-X0ScGjMXw-YqPIDUbK-T0wVQQf1GQH8_6UABP_BOXIwsid7Q_d6yZKv9qxbMJ8R9Q1-IX9C1HXyaCRlc5dk4gAMz9DC-bRuFqEhhrKiqw2JAu9xs4UIaGYbMfJC11JmVP4?purpose=inline)

[今天你在 B 站学到了什么？ \| 极客公园](https://images.openai.com/static-rsc-4/-AonbZCMN8C3aS0_BIwRejjYlTzK9rVUEqCWGS-oLcXMXppB0PfGENDhSMv7woF3EtVORwUO5mQ21lIJd8afR4xFnn9qyspdMCOXAun206g0k17hGsJMXSy6RNululvfHu-NbI3ijappiN56_4r1S4Cz7DScIWa34IdeQNiGrdw?purpose=inline)

8

\*\*哔哩哔哩（Bilibili，简称B站）\*\*需要在本章中特别讨论。

不过，必须明确：B站并不是以短视频为起点的平台，也不应直接归类为典型的早期短视频应用。

它最初主要以动画、漫画、游戏和青年亚文化视频为重要内容。

但随着移动互联网发展，B站逐渐成为中国网络视频创作生态的重要组成部分。

### **一、UP主与用户创作**

B站的重要文化现象之一是UP主（Uploader）文化。

用户不仅观看视频，还能够持续制作自己的内容。

UP主创作的内容包括：

* 游戏视频；  
* 动画；  
* 音乐；  
* 科普；  
* 生活记录；  
* 知识讲解；  
* 数码评测；  
* 二次创作。

与许多早期短视频应用相比，B站保留了较强的社区文化和创作者身份认同。

### **二、弹幕文化与互动观看**

[B站：最佳氛围社区的互动还有提升空间吗？ \| 人人都是产品经理](https://images.openai.com/static-rsc-4/cn5vJfS8RvyLGWpM2cGYDFp6KUUdVi8Bs-i9OcUOkPp7vQI34XmhkWY5ZfV9B04uk5foGFIRkR81_0s4jdB7WB1qRAnY51T3Hf8XYuRBXYH5kwAb-gOHGJxMhR9VoYurl-ewLUavJykvLZVDBFUD-aj_ueHP9soGg-q2Az9ndzM?purpose=inline)

[woshipm.com](https://www.woshipm.com/operate/4183031.html?utm_source=chatgpt.com)

B站的弹幕（Danmaku）文化值得从网络视觉文化角度研究。

观众发送的评论可以在视频播放过程中以文字形式出现在画面上。

这使观众的评论直接进入影像的视觉空间。

它具有几个特点：

1. 观众评论与视频同时出现。  
2. 不同时间的观众可以通过弹幕形成交流。  
3. 评论成为画面的一部分。  
4. 观看行为具有一定的集体参与性质。

弹幕使视频观看不再只是个人面对屏幕的行为，也可能成为一种集体性的网络文化活动。

### **三、B站与短视频文化的关系**

B站与抖音、快手之间存在一定差异。

| 维度 | B站 | 典型短视频平台 |
| ----- | ----- | ----- |
| 早期内容结构 | 兴趣社区、长视频 | 短视频信息流 |
| 主要创作者 | UP主 | 短视频创作者 |
| 观看方式 | 搜索、订阅、推荐 | 连续推荐信息流 |
| 互动方式 | 评论、弹幕、社区 | 点赞、评论、分享 |
| 内容特点 | 多样时长、系列化创作 | 短时长、快速传播 |

后来B站也逐渐增加短视频形式，但其原有的社区创作传统仍然是理解其文化的重要基础。

因此，B站应被视为中国移动视频文化的重要参与者，而不是简单的短视频平台。

## **011.008 移动短视频的视觉语言与艺术形式**

[新晋抖音网红被游戏大神光速复刻\_3DM网游](https://images.openai.com/static-rsc-4/6QkD59GQuUK-5maO2337mxdPPsAkEmgG86GQc8LOICdx-wNAo_BUQvtXTV4YuZtCloRmCDlHbYmzncpySx3pVZKxkNFOg5MtcESF4quOQQMX-qPKxPtSutAq40eOgHqD1GuftCocbh1WdEQyEPqyIhwizXT99DUzcDZ-tnK5EsY?purpose=inline)

[抖音特效师认证｜像塑-抖音AR特效开放平台](https://images.openai.com/static-rsc-4/SNGLnTlIbvYRM9QdMHw_sSlrWkevk-SO9dnbMrKeDBYzBhDsWRbQlHY9-vOTVRL8sstAABhuHew-ZG4rwTMwjfUZTYh7VjUXPDLFLX7ip7o8tz35QSfwjX2IrHx2-SUnNxN6Q29hZPctKNddJFhQPGW4I3QOBaeyfQAWTdx4etk?purpose=inline)

[抖音创作者平台抖音云剪使用教程 \- 短视频助手](https://images.openai.com/static-rsc-4/BWGqMwmHjKC375O3CBnsJEprqVLPwq8SczWAQaKtiho8JFtH7wcER3OYLuXa8i7QNqVYqC4TkGDDfMuSsiEvNKMLMK2fNbKGfCTG8MRQ_UPDnMmbPdusDEaJFIo1hfMzFb63v-KfYJrVgEMKQJOzPBv4LRJcRFvg8qwcQvXGGM8?purpose=inline)

10

移动短视频不仅创造了新的传播渠道，也逐渐形成了区别于传统影视和早期网络视频的视觉语言。

这一节重点讨论短视频作为一种影像媒介，究竟改变了哪些艺术表达方式。

### **一、碎片化叙事（Fragmented Narrative）**

传统影视作品通常具有相对完整的叙事结构。

例如，一部故事片可能包含：

* 人物介绍；  
* 背景交代；  
* 情节发展；  
* 冲突；  
* 高潮；  
* 结局。

而许多短视频只表现一个具体瞬间。

例如：

* 一次搞笑表演；  
* 一段舞蹈；  
* 一个生活场景；  
* 一次视觉转换；  
* 一个令人意外的结果。

短视频逐渐形成了以单一事件、动作和视觉效果为核心的叙事方式。

这种结构可以称为碎片化叙事。

但碎片化并不意味着完全没有叙事。创作者仍然可以通过反转、悬念、重复和视觉对比，在很短的时间内构建完整的表达。

### **二、循环影像（Loop Video）**

[320,661 Seamless loop Stock Videos, 4K & HD Footage \| DepositPhotos](https://images.openai.com/static-rsc-4/Pzaoo6RJN3vx3FWUCD7yYqAqvCFC0NO7KoXlwLp6Lf6rOitg_aaghqO8pQpRk4JJenNqDPiZE3bzbjcQP5mFK9kD9FiZPeG3DsHJ1nfptPISo6AxaoIOOQyBo_o2YadGijluvoH3H6bzcR52nYsVIwSuzVXg6QdmzBs7Z1IUWJ8?purpose=inline)

[depositphotos.com](https://depositphotos.com/videos/seamless-loop.html?utm_source=chatgpt.com)

循环影像是移动短视频中常见的一种形式。

它通过将视频的开头和结尾设计成能够衔接的画面，使作品能够连续重复播放。

例如：

* 一个不断变化又恢复原状的物体；  
* 一段重复的舞蹈动作；  
* 一个循环的视觉错觉；  
* 一个人不断进入和离开画面。

这种形式与早期GIF动画存在明显的历史联系。

从艺术史角度看，循环影像也可以与录像艺术、实验电影和数字动画中的重复时间结构进行比较。

它改变了传统叙事作品中时间必须向前推进的观念。

### **三、转场艺术（Transition Effects）**

[SNSで話題の不思議な動画はどうやって撮っているの？ 人気映像クリエイターぞのさんっ直伝スマホ撮影テクニック \- ITをもっと身近に。ソフトバンクニュース](https://images.openai.com/static-rsc-4/cpQPUpRHTAhsl2qufD47ui8f394tJzRJVbN9vAnnNRSIEhp31SnrUXszcrCFXSM9qwi0le6GoTC8ECabNxPQo63TsbaeW2cUSbyOxRrVS3LdJps61ezQkY-3VqXxYlWE_x3mULMoTgeaP-uuBRBeoLNEXRkRijQw23AteIVn1Ik?purpose=inline)

[Costume Changes on the Subway is China’s Latest Crazy TikTok Challenge \- RADII](https://images.openai.com/static-rsc-4/S7lYAttKGvCcFjJK2YoAkxmMX4M1hfnT1RmOXIWrVnoiwvtfW8KNao3I_M-R7yLx-q7FwBF4vomJxR_RwTY51YFo-7Owc2uVmio-3UzOjCifgvGy7WnaVYt_EtVWR-YLvpHpRomIPKcbXUDcMGWK3tudT7JsjveiDNbpp0oth_E?purpose=inline)

[转场变装怎么拍？教你一招轻松搞定！\_影视工业网-幕后英雄APP](https://images.openai.com/static-rsc-4/cXOPk3OnxWYh-wSjZqWDWN-ZkgqhCp-BWb_dvjUnm8a-9FVrFfyANUUK_uxjKdfzesk0x26xcmZJQl2LmLdS39Ebs0adLgn1GKbGEscg-6fnlRroQ69X5ykFrOERFellB0tZ_42U-QU-BCgr3FHUcFm5u2LHspPsYvB8ktYu7Lw?purpose=inline)

13

转场是短视频视觉表达的重要手段。

创作者可以通过动作、遮挡、镜头运动和数字特效，让不同场景之间产生连续的视觉变化。

常见形式包括：

* 遮挡转场；  
* 旋转转场；  
* 跳跃转场；  
* 变装转场；  
* 镜头推拉；  
* 画面匹配；  
* 数字特效转换。

短视频平台提供的模板和编辑工具降低了这些视觉技巧的使用门槛。

原本需要较多后期技术才能完成的效果，普通用户也可以通过手机应用实现。

### **四、滤镜艺术与数字身体（Digital Body）**

[These viral selfie apps with 1 billion downloads are shaping China’s start-up culture \- The Washington Post](https://images.openai.com/static-rsc-4/TA3nNUyWl0K0Nh6CV4u3_rUg4upirW46l6i-nYgU0c_dXYRgwy4svYxBJ4_hgdNbkM60KwmiG5qiLk4-PY4x-RqHFxzmH7YNxcIYCJ8thGoqAkXKu1H0-7wmZWNS5c0W-w1w31dIaeeZOeX1SKGZFcmKlroQpq85pqWAUZhshTw?purpose=inline)

[washingtonpost.com](https://www.washingtonpost.com/world/asia_pacific/a-viral-selfie-app-with-1-billion-downloads-is-shaping-chinas-start-up-culture/2016/08/03/c89e985a-4348-11e6-b34c-ced7e11f0ca6_story.html?utm_source=chatgpt.com)

移动短视频将滤镜从单纯的摄影修饰工具，扩展成一种视觉表演工具。

用户可以改变自己的面部、身体和周围环境。

例如：

* 面部美化；  
* 虚拟妆容；  
* 动物面具；  
* 年龄变化；  
* 面部变形；  
* 虚拟人物形象；  
* AR特效。

这使真实身体与数字形象之间的关系变得复杂。

用户出现在屏幕上的形象，不一定等同于现实中的身体，而可能是经过数字技术重新塑造的身体。

这一现象可以与数字艺术中的虚拟身份、赛博格（Cyborg）和后人类身体（Posthuman Body）理论联系起来研究。

### **五、短视频与再混合文化（Remix Culture）**

短视频平台非常容易形成模仿、复制和重新创作。

一个用户创作的动作、音乐或表演形式，可以被其他用户重复使用。

这种传播方式产生了：

* 舞蹈挑战；  
* 音乐模仿；  
* 表情模仿；  
* 角色扮演；  
* 同款视频；  
* 合拍与二次创作。

这里存在一个值得研究的现象：

**短视频作品不一定是一件封闭的、独立的艺术品，也可能是一个可以不断被其他人重新创作的影像模板。**

这与网络艺术中的参与式艺术（Participatory Art）和再混合艺术具有一定联系。

## **011.009 短视频平台化与商业影像生产（2017—2020年）**

[李子柒背后的“大佬”——MCN\_平台](https://images.openai.com/static-rsc-4/pCqSGE5KHFGkYop6o7grcHc49A3dz2ttOfpwI67iMwHH9ieRUicAjQgxTWOS7A0BF0RhPDSv9emTDeXVSP3cxGKmG5Y68apmOQ8W3ePPTaQH3osyWn0Qf9IVMJd8Bd_S_tCeUPkuMKK7NRjSCoLQ0VOqnVw1tjc1Jeoh0tmA21c?purpose=inline)

[Inside The Rapid Rise and Reign of Douyin \- Jing Daily Culture](https://images.openai.com/static-rsc-4/91iONgQco4lmnoZkAZA31buj8gTPopieeB6AoIIGzhL3rN6r5onIoudCy65nHt4iHeI6worYA-7RQs48jviz8f6p5UKJ-sUs2xJzf2LmO2UU_Hi7JbcB2oK6TmakSX9A-MFEEsYPfjj-cnIUBTf6uvnLfi4Nd2bb56ASLNazoAs?purpose=inline)

[快手带货奥利给-品玩](https://images.openai.com/static-rsc-4/8pOI0q0rWane5lI84Rro9KN1aGP3AcR5A6DSCmgl8MXG6MCDNVcSG52b9SiddlAByd9W72TW7poOaweHPXs8pDLxuqU7n8kdAOIIQ90A8t3Mv7_b2lEs-uyo2qeNKSs_oRl1dPlhlLa9ScM9bYKxF0IIxkNrG89JmGJJEh1gzjw?purpose=inline)

9

2017年以后，中国短视频行业逐渐从早期的个人创作和社交分享，转向更加成熟的平台化内容生产。

### **一、专业创作者进入短视频领域**

早期短视频主要由普通用户制作。

随着平台用户规模扩大，越来越多专业创作者开始进入这一领域。

其中包括：

* 专业摄影师；  
* 视频剪辑师；  
* 新闻媒体；  
* 艺术创作者；  
* 自媒体团队；  
* 商业内容制作公司。

这些创作者开始提高视频的制作质量，发展更加成熟的内容形式。

### **二、MCN机构的出现**

MCN（Multi-Channel Network）是一种组织和管理网络创作者的机构模式。

MCN通常为创作者提供：

* 内容策划；  
* 视频制作；  
* 账号运营；  
* 商业合作；  
* 广告推广；  
* 创作者管理。

它使短视频创作逐渐从个人兴趣活动，发展成具有专业分工的内容生产产业。

### **三、短视频商业化**

[直播发货快起来！万里牛助力嘉兴服装仓库“衣销四方”- 大数跨境](https://images.openai.com/static-rsc-4/Up4VKL8FNmV9v1Bs7BiDoFDflvP71eI6BqPfvWfiGeZTQB-Y6F7PPNAnsyNIteSib8l3r5EhQW5O4Cpx-iH1Flpwkk_3QSPkjK2VjIKf5oanylc-smLhmagmj9II9btpLhc3bgKbJRFmz6q5KEdjkCeIKxFIm4SAANIXanl1iug?purpose=inline)

[10100.com](https://www.10100.com/article/1507672?utm_source=chatgpt.com)

短视频平台逐渐形成多种商业模式。

| 商业模式 | 主要形式 |
| ----- | ----- |
| 广告 | 品牌植入、信息流广告 |
| 直播 | 直播互动与虚拟礼物 |
| 电商 | 视频展示商品并引导购买 |
| 知识付费 | 教学课程与专业内容 |
| 内容合作 | 品牌与创作者合作制作视频 |
| 平台补贴 | 平台扶持创作者生产内容 |

这意味着短视频不再只是用户之间的娱乐和交流工具，也成为商业传播和消费活动的重要媒介。

### **四、短视频与直播的融合**

[Estas son las 20 apps más descargadas en China. Y sí, son todas chinas](https://images.openai.com/static-rsc-4/Q59_KVdPMxL-1pOG9UPiMIpdh2pzOOQzLKqUEhS-x0_poe4xi57_t5lHseLFEJxsi0TLmFX1qXLvlk5n_oeyp-Hhs7xdM8AdM4VwTU3-Q0jWMMoqTBLf7bxnLDCwTnDZhbHSx4Og8TP9SBcjtkFFs-JkmnSGa1hYln5yOmx8CNI?purpose=inline)

[The design behind TikTok’s largest short video competitor: KuaiShou \| by Alexis Liu \| Bootcamp \| Medium](https://images.openai.com/static-rsc-4/eBsM7vntGfX42e1bv0nHvIzzPgw5d5X5HQTQyVx5LDpE2ixqvP4n2peZmKQzWyxffxwQ2OH9TeXCVzRV3sQUt5TB1swQY80xLgxnvqJieBnapIFuDywfVKZzqIOsDa5j5uI0B-f9i6xHe9-QFN6lBTKWtlee6gG8WpIo1FlryCo?purpose=inline)

[快手电商流量增长方案及策略 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/SvYxwv1B7zmO1LekFMcGfKiv8H8U8FHuTv0xdu8G-5RquPeKE0nH9FHcatdwdNoGd0bTTrxoWU8MTA9XF6E-UkR6M6VJ7_KgzGvVyTe6YWXaQGjbSR7TvHxzLOs2U8jZr0HnIziQYzocg4CZcbhD_CymMsjYev-6PXHI-lT27io?purpose=inline)

8

短视频与直播最初具有不同的内容结构：

* 短视频通常先制作，再发布。  
* 直播通常实时产生、实时传播。

但随着平台发展，两者开始融合。

例如：

1. 创作者先发布短视频吸引观众。  
2. 观众关注创作者。  
3. 创作者进行直播。  
4. 直播内容被剪辑成短视频。  
5. 短视频再次吸引新的观众。

这形成了短视频与直播之间的相互促进关系。

从网络影像史角度看，009、010和011三章所讨论的三种传播形式，在这一阶段开始出现明显的产业融合。

## **011.010 移动短视频对中国社会与视觉文化的影响**

### **一、日常生活的影像化**

[People \- Candid or Street \- PentaxForums.com](https://images.openai.com/static-rsc-4/_zWN2p_E4C9NGCodQqPmJ6N8r3SS-mCGz35znMh42ndmWM4qS2JzpzoMnwVU7aZSQ45T12vuSMQn8VJVLEftevLvfjzoCZhd7HEhxojThjQHCzGAfQubMcwUporYGb6k1oEFAFlWSTRI7Y-Q40hie1DbNxBwSsdTVCTmwUmsp9I?purpose=inline)

[pentaxforums.com](https://www.pentaxforums.com/forums/18-monthly-photo-contests/365687-people-candid-street.html?utm_source=chatgpt.com)

移动短视频使日常生活越来越容易被记录和展示。

过去，人们通常只会在旅行、节庆、重要家庭活动中拍摄视频。

智能手机普及以后，普通生活中的许多瞬间也能够成为视频内容。

例如：

* 早餐和晚餐；  
* 上课与学习；  
* 工作与劳动；  
* 购物与旅行；  
* 家庭活动；  
* 城市街景；  
* 个人情绪和生活感受。

日常生活由此逐渐成为一种持续生产的网络影像内容。

### **二、地方文化的传播**

短视频使一些过去主要依赖地方性传播的文化形式获得了更广泛的观众。

例如：

* 地方戏曲；  
* 民间舞蹈；  
* 传统手工艺；  
* 地方饮食；  
* 民俗活动；  
* 方言和地方生活方式。

这使短视频具有一定的数字文化记录价值。

### **三、网络身份与自我展示**

短视频也改变了个人在网络空间中的身份建构方式。

用户可以通过服装、妆容、语言、音乐、场景和动作，塑造自己希望展示的形象。

一个人可能拥有多个网络身份：

* 日常生活中的身份；  
* 工作中的身份；  
* 网络创作者身份；  
* 表演中的角色身份。

因此，短视频不仅是记录工具，也是个人身份展示和社会互动的媒介。

### **四、算法与视觉注意力**

算法推荐使用户接触到大量个性化视频。

这改变了内容创作者的生产策略。

创作者开始更加重视：

* 视频开头；  
* 画面吸引力；  
* 内容节奏；  
* 完播情况；  
* 用户互动；  
* 传播效果。

与此同时，推荐系统也可能造成信息重复、兴趣集中和内容同质化。

这带来了网络视觉文化中的一个重要问题：

当创作者越来越依赖平台推荐时，作品的创作方式是否也会受到算法偏好的影响？

这不仅是一个商业问题，也是数字艺术和媒介理论值得研究的问题。

### **五、短视频对艺术创作的影响**

短视频平台为艺术家提供了新的展示渠道。

例如：

* 摄影艺术家可以发布动态摄影作品；  
* 动画创作者可以展示短动画；  
* 行为艺术家可以发布表演片段；  
* 数字艺术家可以展示视觉特效；  
* 视觉设计师可以展示动态设计；  
* 独立创作者可以直接与观众互动。

但是，需要区分平台内容与艺术作品。

并非所有短视频都是艺术作品。短视频是一种媒介形式，而艺术性取决于创作目的、表达方式、形式探索和具体语境。

## **011.011 中国移动短视频发展年表**

[快手(GIF快手):發展歷程,融資記錄,產品特點,影響評價,相關事件,\_中文百科全書](https://images.openai.com/static-rsc-4/DhHOOm6jMCGcq9F-fUzqRZhtFNzn5uDAVtEWhgffPOP3ZmUGLP4RHmZMRHRuSE-YkrUawyNCfdSflDGTRkemN_dfrbTJSJWOyEwWtTjFUwqz2rKKLM-8ITlXPHwEJbGkxHo8iBCWXse0lChxIic7BSHVXmH57hwqTR6p65SGI9g?purpose=inline)

[Security Verification](https://images.openai.com/static-rsc-4/sybwRM8SJPKbVh4m20hpf0ucjNl9ayDG1QGygp_64pS2c3HtcA9cMFrmz8Kl5QC2ly3UrwndY8QAy5rf5c7BLpYll4Xdv3aczU8Cm-mBwymGFnnvCU75Xt6oXQ0NF7-nTEzmF9KLZ5LxnCb_-9ispGXpHVuQiynnw19G6HMSYDI?purpose=inline)

[美拍中发布语音照片的具体流程介绍-天极下载](https://images.openai.com/static-rsc-4/ALkNc-rwn_sdglEnIfUmXFVS7xI9cqNkexWu8ZsaciWvXstXReWkCPpkPbpDB19vlTZf2HXFoR7oFq1mLcMdK9yXvqZu6rUnPKWX_j8U-cqbmoX3lswpCg8wmQuh_u2cLc15vdjwj1qiY17Iglh3fcvHNtTvtmrT-pyC8wkDYiw?purpose=inline)

4

| 时间 | 重要事件 |
| ----- | ----- |
| 2011年3月 | GIF快手诞生 |
| 2011年11月 | 秒拍相关产品出现 |
| 2012年11月 | 快手开始转型短视频社区 |
| 2013年7月 | 快手短视频社交功能发展 |
| 2013年9月 | 腾讯微视上线 |
| 2013年 | 秒拍与微博生态结合 |
| 2014年5月 | 美拍上线 |
| 2014年10月 | 微信增加小视频功能 |
| 2014年11月 | GIF快手正式更名为快手 |
| 2015年5月 | 小咖秀上线 |
| 2015年 | 移动短视频用户规模进一步扩大 |
| 2016年9月 | 抖音正式上线 |
| 2016年 | 火山小视频、梨视频等发展 |
| 2017年 | 西瓜视频升级，短视频竞争加剧 |
| 2017—2018年 | 算法推荐、MCN和专业化创作发展 |
| 2018—2020年 | 短视频与直播、电商融合 |

时间节点主要依据平台资料、行业报告和公开历史记录整理。

kuaishou.com+4

## **011.012 本章的历史定位：中国移动影像文化的形成**

中国移动短视频的发展，可以概括为四个相互联系的阶段。

1. **工具探索阶段（2011—2013年）**  
   GIF快手、秒拍、微视等应用出现，移动视频制作与分享开始形成。  
2. **社交与视觉美学发展阶段（2014—2015年）**  
   美拍、小咖秀等产品推动滤镜、音乐、舞蹈和模仿式表演的发展。  
3. **算法推荐与产业爆发阶段（2016—2018年）**  
   抖音等平台发展，推荐信息流成为重要传播方式，短视频内容生产逐渐专业化。  
4. **平台化与商业融合阶段（2018—2020年）**  
   短视频与直播、电商、广告和专业内容生产进一步融合。

   ### **本章最重要的历史结论**

中国移动短视频的兴起，代表网络影像从个人电脑时代进入智能手机时代。

它带来了五个重要变化：

1. **生产方式变化**：普通用户能够直接使用手机拍摄、编辑和发布影像。  
2. **画面形式变化**：竖屏、短时长、循环播放和快速转场逐渐成为常见形式。  
3. **传播机制变化**：从社交关系和主动搜索，逐渐发展出算法推荐信息流。  
4. **创作主体变化**：普通用户、专业创作者、MCN和商业机构共同参与影像生产。  
5. **观看方式变化**：从主动选择单个视频，逐渐转向连续浏览个性化视频流。

从艺术史角度看，移动短视频使影像成为一种高度日常化、移动化和参与式的视觉表达媒介。

它既延续了早期网络视频的用户创作传统，也吸收了网络直播的实时互动文化，并进一步形成了新的平台化影像生态。

## **本章重要研究对象索引**

| 类别 | 研究对象 |
| ----- | ----- |
| 早期工具 | GIF快手、秒拍 |
| 社交短视频 | 微视、微信小视频 |
| 美化与表演 | 美拍、小咖秀 |
| 草根影像 | 快手 |
| 算法短视频 | 抖音 |
| 资讯短视频 | 梨视频 |
| 综合视频 | 西瓜视频 |
| 青年创作社区 | B站 |
| 核心技术 | 智能手机、4G、视频编码、推荐算法 |
| 核心理论 | 碎片化叙事、数字身体、参与式文化、算法文化、再混合文化 |

## **延伸阅读与研究资料**

1. [快手官方：关于快手](https://www.kuaishou.com/about.htmlamd%201%3D1?utm_source=chatgpt.com)——快手早期发展历程及产品转型记录。  
2. [人民网：2018年中国移动短视频行业发展概述](https://media.people.com.cn/n1/2019/0815/c429251-31297514.html?utm_source=chatgpt.com)——移动短视频产业的历史与社会影响。  
3. [中国短视频行业发展历程](https://lmtw.com/mzw/content/detail/id/181747?utm_source=chatgpt.com)——2011—2018年短视频平台发展阶段。  
4. [字节跳动社会责任报告（2018）](https://sf26-sign.douyinstatic.com/welfare-admin/4ca73135932148d0920efaaf9b8f9662.pdf?lk3s=f5cdeb29&x-expires=1778122267&x-signature=IjpTzNmanbWsrAw9jr0m%2FV3hjBA=&utm_source=chatgpt.com)——抖音及相关产品的发展节点。  
5. [抖音个性化推荐算法公示资料](https://beian.cac.gov.cn/api/static/fileUpload/principalOrithm/additional/user_9b84b02a-0c7f-4bd4-81f2-5cad879ad4ab_96ed08c8-0ed8-4ab5-b04d-46cccf4c00ab.pdf?utm_source=chatgpt.com)——理解算法推荐的技术机制。  
6. [TalkingData：美拍与短视频社交应用的发展](https://mi.talkingdata.com/report-detail.html?id=401&utm_source=chatgpt.com)——早期移动短视频社交文化。

   ## **中国网络影像艺术史：下一阶段**

至此，009—011三章已经分别研究了三种重要的网络影像形式。

| 章节 | 研究对象 | 核心传播方式 |
| ----- | ----- | ----- |
| 009 | 中国早期网络视频网站 | 上传与点播 |
| 010 | 中国网络直播 | 实时传输与互动 |
| 011 | 中国移动短视频 | 手机创作与算法推荐 |

**下一章建议：**

# **012 中国网络视频创作者文化与独立网络影像艺术的发展**

**The Development of Chinese Online Video Creators and Independent Internet Video Art**

建议重点研究：

* 012.001 网络原创视频创作者群体的形成  
* 012.002 独立网络影像创作与个人表达  
* 012.003 网络恶搞、拼贴与再混合艺术  
* 012.004 网络动画与个人动画创作  
* 012.005 网络纪录影像与民间影像记录  
* 012.006 B站与青年亚文化影像创作  
* 012.007 网络影像艺术节与线上展览  
* 012.008 独立影像艺术家的平台化生存  
* 012.009 中国网络原生影像艺术的历史定位

这样可以从前面三章的传播技术史，进一步进入真正的网络影像创作者、作品和艺术运动史。

