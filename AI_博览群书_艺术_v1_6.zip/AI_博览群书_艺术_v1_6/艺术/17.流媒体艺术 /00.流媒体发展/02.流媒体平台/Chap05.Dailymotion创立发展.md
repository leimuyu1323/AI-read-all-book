# **02\. 流媒体视频艺术（Streaming Video Art）**

# **008 Dailymotion与欧洲网络视频文化的发展**

*Dailymotion and the Development of European Online Video Culture (2005–2015)*

[Comment télécharger Dailymotion en streaming? \- Vite une solution Doc \!](https://images.openai.com/static-rsc-4/GYGlS1Tfz9KPyh_izHtyriTPVua4sZP-sPYUy0Ti8SqWEcP0u90wXyKIWTt-X5t1o_mUIe0n4lyR0gOsryEnbqR9zvisRKdT1iSetAHjpcy8uabrLLruJEjmE-ZzLpxN1lxrWzNEz7JZZI6_aJhaJTxy4fcR6pJCsSr6qyBTryc?purpose=inline)

[Dailymotion Online](https://images.openai.com/static-rsc-4/fR6Ye4tZlCKIlc7ZpcitAICwlM0le2Rnl9sUSlMsBJu81bmCcjHa-EpNq8ERoJWnRnDHTGLlsDLgIsV5JHHPnO3TtXOpDRcEpnt0VK90Ol8gDOzmSreqKtnG2KqgPckc0MQJSMnAZ-yO5Kzd9klPL_q4xaPlUcEaYhd4GFHfYlE?purpose=inline)

[FRANCE-ECONOMY-INTERNET-DAILYMOTION](https://images.openai.com/static-rsc-4/5gONA_dvUZnQW70oQ0vTJKgO6v9s5CRRJwTznhaCMacRFADPgfVb2QRWyFLuQ3-uwI0Xg5ebKDjiMl4md0Nz598-3gJ8Ag-iqk7celHhNOmKLedFkfT3LcrcGDkVuX3Mmnnx2pr-JQHIjhyA2XYtjWvcgZlpwdExx4paFd7EFdakBseXFmNUyZyJyVSGgUUe?purpose=inline)

8

## **导言：欧洲如何建立自己的在线视频文化？**

2005年，互联网视频产业开始进入一个重要的发展阶段。

美国的YouTube迅速扩大了大众视频分享的影响力，而欧洲也出现了自己的在线视频平台。其中，法国的Dailymotion是最具代表性的早期平台之一。

Dailymotion于2005年在法国巴黎创立。它与YouTube几乎同时进入市场，最初同样以用户上传、视频分享和在线播放为主要功能。

但是，Dailymotion的发展具有不同的文化背景。

它诞生于法国互联网产业和欧洲数字媒体环境之中，后来逐渐与欧洲新闻机构、电视台、电影制作机构和专业视频创作者建立联系。

因此，研究Dailymotion不能只把它看成另一个YouTube。

我们还需要研究几个更广泛的问题：

1. 欧洲为什么需要自己的在线视频平台？  
2. 法国互联网产业如何参与全球视频传播？  
3. Dailymotion如何连接普通用户与专业媒体机构？  
4. 欧洲的文化政策、版权制度和语言环境如何影响网络视频？  
5. 网络视频如何成为欧洲电影、纪录片和当代艺术的传播渠道？

本章主要研究2005—2015年Dailymotion及其所处的欧洲网络视频环境，并适当延伸到后来的平台转型。

## **第一节 Dailymotion的创立背景**

### **1.1 2005年的欧洲互联网环境**

2000年代初期，欧洲互联网产业正在经历快速发展。

宽带接入逐渐普及，个人计算机的多媒体处理能力提高，数字摄像机和视频编辑软件开始进入普通家庭。

欧洲已经拥有成熟的电影、电视、新闻和广告产业，但这些传统媒体的传播方式主要依赖电影院、电视广播、DVD和实体发行渠道。

互联网为它们提供了新的传播可能。

[Young Parisians surf 28 June 2001 on Internet in t](https://images.openai.com/static-rsc-4/1vt1CeTj9jbP4tKaAgdDGRVeP1oKWy_tdXu4KDcw0_Q3T21drnHMRGF5CiqgvOhPHaY4K4Z9qxzhDvW0_vqugupes73TvQas4QJNKogaZ8qLkeJd9UHziQnFenvT8MjcBgN3wtyjSbdYT6GfsqAEvDIuCIT169yvd-wLr7VrOHE2sLKGxJdkvsLVddHVEUU2?purpose=inline)

当时的欧洲具有几个值得注意的特点：

**第一，多语言环境。** 欧洲互联网用户使用法语、英语、德语、西班牙语、意大利语等多种语言。

**第二，成熟的公共广播体系。** 欧洲许多国家拥有历史悠久的公共电视和广播机构。

**第三，独立电影传统。** 法国、德国、英国、意大利等国家拥有独立电影、艺术电影和纪录片创作传统。

**第四，文化产业政策。** 欧洲各国及欧盟长期关注本土文化生产、电影发行和视听产业发展。

因此，欧洲网络视频产业并不是简单复制美国模式，而是在自身的语言、文化和媒体制度中发展。

### **1.2 Dailymotion的创立**

[Intégration multimédia \- M1 Web Editorial](https://images.openai.com/static-rsc-4/2TDjHK-z5MWbEN5j1U4_QOAkrpr_YPwfsPV96wLx6kJy1fnh6IZur6RbH56QZkb9-0j9yaQfeElq-qhzkok8d5eHHypOIBEUv4z_6YwtZ_5EqxHpOo_TIU5FP4LqilDVCA4YDhuJBBfmo7o9T5DXWr1HWirS3zeS9P5Y84RdNBI?purpose=inline)

[webetu.net](https://webetu.net/multimedia/?utm_source=chatgpt.com)

Dailymotion 于2005年3月15日在法国巴黎创立。

其创始人包括Benjamin Bejbaum和Olivier Poitrey。

两人希望建立一个能够让用户方便上传、观看和分享视频的网站。

Dailymotion最初的核心功能与早期YouTube相似：

* 用户上传视频。  
* 平台处理视频文件。  
* 用户通过网页观看。  
* 视频可以被分享。  
* 用户可以评论和浏览其他作品。

它的出现说明，在线视频分享并不是某一家美国公司的独有创新，而是当时互联网技术发展推动的一种全球性趋势。

### **1.3 Dailymotion名称的含义**

Dailymotion由Daily和Motion两个词组成。

* Daily：日常的、每日的。  
* Motion：运动、动态影像。

这个名称强调日常生活中的动态影像。

它与早期互联网视频文化的一个重要理念相吻合：影像不必只属于专业电影制作机构，普通人的生活、表演和记录同样可以成为网络视频。

### **1.4 Dailymotion的早期定位**

[Comment télécharger Dailymotion en streaming? \- Vite une solution Doc \!](https://images.openai.com/static-rsc-4/GYGlS1Tfz9KPyh_izHtyriTPVua4sZP-sPYUy0Ti8SqWEcP0u90wXyKIWTt-X5t1o_mUIe0n4lyR0gOsryEnbqR9zvisRKdT1iSetAHjpcy8uabrLLruJEjmE-ZzLpxN1lxrWzNEz7JZZI6_aJhaJTxy4fcR6pJCsSr6qyBTryc?purpose=inline)

[vite-une-solution-doc.blogspot.com](https://vite-une-solution-doc.blogspot.com/2013/02/comment-telecharger-dailymotion-en.html?utm_source=chatgpt.com)

早期Dailymotion主要面向普通互联网用户。

用户可以上传各种类型的视频，而不必依赖传统媒体机构。

这些视频包括：

* 个人生活录像。  
* 音乐和表演。  
* 体育影像。  
* 新闻片段。  
* 动画。  
* 独立短片。  
* 搞笑视频。  
* 纪录片片段。

Dailymotion很快发展为法国最重要的在线视频平台之一，并逐渐扩大国际影响力。

它的历史价值在于：欧洲本土互联网公司也能够建立具有国际传播能力的视频平台。

## **第二节 Dailymotion与YouTube的竞争**

### **2.1 两家平台几乎同时出现**

[Dailymotion, le YouTube à la française](https://images.openai.com/static-rsc-4/npWQJTc60UXBj7Dmozfu-Xevpy5TF0nkgqDJfO0ElTla_VSGkzRFVx7qbu413NAsR2cfAPv4d9nK7Vvzy8Jq1Es7dCP_DVHmvQw8a7Y8-TPgy0YmIICvUUGbm9lLeuDAltLix84CcATPd6-jWYbmERZbdDr6WFCqolBJxrlhiMM?purpose=inline)

[21 Years of YouTube Website Design History \- 39 Images \- Version Museum](https://images.openai.com/static-rsc-4/bm45i8oTQR4iR0co5m0RAnrS2gavYqXJotv-3iIzPhQwdDmPiBGpvQENxmfpIiPntrIVcK4YWLWndQe6e0vHI6oWE99In37cQcQmNe7WpnncF2qIuDFqYHNVa-PH_Y4POR0oNv_0wDrhDddi_Z2ZjDRS42uepT3gNaqfCMdsEdM?purpose=inline)

[Comment télécharger Dailymotion en streaming? \- Vite une solution Doc \!](https://images.openai.com/static-rsc-4/GYGlS1Tfz9KPyh_izHtyriTPVua4sZP-sPYUy0Ti8SqWEcP0u90wXyKIWTt-X5t1o_mUIe0n4lyR0gOsryEnbqR9zvisRKdT1iSetAHjpcy8uabrLLruJEjmE-ZzLpxN1lxrWzNEz7JZZI6_aJhaJTxy4fcR6pJCsSr6qyBTryc?purpose=inline)

5

Dailymotion和YouTube的出现时间非常接近。

* Dailymotion：2005年3月成立。  
* YouTube：2005年2月注册，2005年12月正式向公众开放。

两者都试图解决同一个问题：如何让普通互联网用户方便地上传和观看视频。

但它们的早期发展环境有所不同。

YouTube迅速建立了庞大的国际大众用户群体；Dailymotion则首先在法国市场建立影响力，并逐渐向其他欧洲国家扩张。

2006年10月，《世界报》（Le Monde）发表了题为《Dailymotion，法国版YouTube》的报道，说明当时法国媒体已经将Dailymotion视为YouTube的重要竞争者。

lemonde.fr

### **2.2 2007年欧洲在线视频市场**

[Why You Can’t Compete with Google: The Deplatforming of LiveVideo.com \| Techpost](https://images.openai.com/static-rsc-4/y1y3CzlkrILJQsmOMpTmhyMteUUzpKo25KHox7AG0DPW2_8wgmSXULsri5UJbU3UekH0xURr4GvH9aDqzYV0NGn4ka5oIgmgK0X7dyOHqoJ5537E4s6kqOLzErV2t4VRIWndYu2XHlhbnttzb4o-ff3fHVkb_jnmhasY2nl70_I?purpose=inline)

[techpost.io](https://techpost.io/why-you-cant-compete-with-google-the-deplatforming-of-livevideo-com/?utm_source=chatgpt.com)

欧洲广播联盟（EBU）2007年的互联网研究报告记录了当时欧洲视频分享网站的访问情况。

2007年5月欧洲视频分享网站访问量统计

| 排名 | 网站 | 独立访问者（千人） |
| ----- | ----- | ----- |
| 1 | YouTube | 67,707 |
| 2 | Google Video Search | 19,210 |
| 3 | Dailymotion | 16,349 |
| 4 | Metacafe | 9,425 |
| 5 | Yahoo\! Video | 6,138 |
| 6 | Clipfish | 5,284 |

来源：EBU，《Broadcasters and the Internet》，2007年。统计口径为报告采用的欧洲网站访问量数据。

tech.ebu.ch

这组数据说明，Dailymotion在早期欧洲在线视频市场中已经具有相当重要的地位。

它并不是一个只在法国本土使用的小型视频网站，而是当时欧洲最重要的国际视频分享平台之一。

### **2.3 Dailymotion为什么没有被YouTube完全取代？**

这需要从几个方面理解。

**第一，地域优势。** Dailymotion拥有法国本土的用户基础，与法国媒体机构和内容创作者建立了联系。

**第二，语言优势。** 它能够服务法语用户，同时通过多语言界面向其他国家扩张。

**第三，专业内容。** Dailymotion逐渐加强与新闻媒体、电视台和专业视频制作机构的合作。

**第四，技术服务。** 它不仅提供网站播放，也向其他网站提供视频托管和嵌入式播放器。

这些因素帮助Dailymotion形成了不同于YouTube的竞争路径。

## **第三节 MotionMaker：鼓励创意视频的计划**

这一部分是Dailymotion历史中非常值得注意的内容。

### **3.1 什么是MotionMaker？**

[My Animation is on Dailymotion’s French Homepage \| Seth Welton](https://images.openai.com/static-rsc-4/bC76sW6lVHJsn7poRsNnanPWpdtFui05UsvzwNvxONfDTsDopbzGCfwczIi6eYt4SuvFe4Ok8mi_dl0Dl9YOUf6yA9RQc8azFZJe96a4tgykYy-fgzUHRELMzKU01aM7aSrdbmDNWYPqSuaGiiZToCVtUmSVBpna6uk4UZr_H9w?purpose=inline)

[sethwelton.wordpress.com](https://sethwelton.wordpress.com/2009/06/19/my-animation-is-on-dailymotions-french-homepage/?utm_source=chatgpt.com)

Dailymotion曾推出名为MotionMaker的创作者计划。

MotionMaker可以理解为创意影像创作者计划。

它希望从普通用户上传的视频中，识别和鼓励具有较强创作性的作品。

这些作品包括：

* 独立电影短片。  
* 实验动画。  
* 音乐视频。  
* 视觉设计作品。  
* 创意广告。  
* 个人电影制作。  
* 实验影像。

这与单纯依靠视频播放量组织内容存在一定差异。

平台不仅希望用户上传视频，也希望吸引具有创作能力的影像生产者。

### **3.2 MotionMaker的历史意义**

[PRE ROLL PARTAGEABLE \- Vidéo Dailymotion](https://images.openai.com/static-rsc-4/SddFcw_-Yq04Bx7hg0YxvF4nyM4XPrkab0TBEVh57yaGQDaFbOW_2UNAsP75cFxf28JsVy5GO57Xqzt9p7kBPv7gxNRjg6VLE224gY_e8mr2mS5SYKKBqJjS7so7IU_xvM6PLM3Vl06YFPUfLBupX-MrSm7y5CLSHgVv_9L2qBE?purpose=inline)

[dailymotion.com](https://www.dailymotion.com/video/x2gbc06?utm_source=chatgpt.com)

法国文化部2008年发布的一份互联网服务提供商研究报告，对Dailymotion的早期运营进行了记录。

报告指出，当时Dailymotion已经形成三类不同的视频来源：

1. 普通用户上传的视频（UGC）。  
2. MotionMaker计划中的创意视频。  
3. Official User计划中的官方合作伙伴视频。

报告还记录，当时MotionMaker创作者约有7000人，其中约5000人在法国；部分优秀短片还会进入电影院进行放映。

Prestataires- version finale 21 juin 2008

这一信息尤其重要。

它说明Dailymotion并没有把创意视频完全限制在互联网内部。

一些网络作品能够进一步进入传统电影放映空间。

这形成了一条新的传播路径：

**个人创作**

独立电影、动画、实验影像

**Dailymotion上传与展示**

创作者社群与网络传播

**作品筛选与推荐**

创意作品获得额外曝光

**线下放映与进一步传播**

电影放映、活动及其他展示空间

这使Dailymotion成为早期网络视频与独立电影文化之间的一个连接点。

### **3.3 MotionMaker与Vimeo Staff Picks的比较**

[Programme de soutien pour les créateurs – About Dailymotion](https://images.openai.com/static-rsc-4/V4CqBP7srMe5Xd0MYAIzTNchQauG3BopublsRhc-Sz1V7tWbVtOOGkzAPGOgnLD5hc-3RnSzT1if6UQyBJ2sZTvrsa7NJlw9GUfKfq9wZ_lonLh87oh3Q_gh2oU20_5UL0UMDb2NxdcfvHa7gEEqiQTvfUEoswvNSn6xhP496YM?purpose=inline)

| 比较项目 | Dailymotion MotionMaker | Vimeo Staff Picks |
| ----- | ----- | ----- |
| 基本形式 | 创作者计划 | 编辑精选 |
| 主要目的 | 鼓励创意视频生产 | 发现和推荐优秀视频 |
| 参与方式 | 创作者参与计划 | 编辑团队选择作品 |
| 内容类型 | 创意短片、动画等 | 独立电影、动画、设计等 |
| 文化意义 | 支持创作者生产 | 建立网络视频策展机制 |

两者都体现了早期网络视频平台对创意作品的重视，但制度形式并不相同。

MotionMaker更接近创作者扶持计划，Staff Picks更接近平台编辑策展。

## **第四节 Official User：专业媒体机构进入网络视频平台**

### **4.1 普通用户之外的另一类内容生产者**

[Dailymotion, le YouTube à la française](https://images.openai.com/static-rsc-4/npWQJTc60UXBj7Dmozfu-Xevpy5TF0nkgqDJfO0ElTla_VSGkzRFVx7qbu413NAsR2cfAPv4d9nK7Vvzy8Jq1Es7dCP_DVHmvQw8a7Y8-TPgy0YmIICvUUGbm9lLeuDAltLix84CcATPd6-jWYbmERZbdDr6WFCqolBJxrlhiMM?purpose=inline)

[lemonde.fr](https://www.lemonde.fr/technologies/article/2006/10/10/dailymotion-le-youtube-a-la-francaise_822036_651865.html?utm_source=chatgpt.com)

Dailymotion逐渐意识到，单纯依靠普通用户上传内容，并不能完全满足平台的长期发展需求。

新闻机构、电视台、电影制作公司和音乐公司拥有大量专业影像资源。

这些机构也希望进入互联网视频市场。

因此，Dailymotion发展了Official User计划。

这一计划面向官方内容合作伙伴，例如新闻媒体和专业内容生产者。

2008年法国文化部报告提到，Rue89和Libération等媒体机构已经通过Official User模式在Dailymotion展示视频。

Prestataires- version finale 21 juin 2008

### **4.2 新闻媒体为什么进入Dailymotion？**

[Rue89 primé aux Etats-Unis](https://images.openai.com/static-rsc-4/D9up-48jjzlxLgDcd1yy9Wc8GwNuZw5zDA-KseEilJezPfUcha65frkh9fJMLMqt4wqHUmItB8Sx7N-JnMVkENUocveiarxAz03GGNn0PlekRfpmqhAWR2uouhER6hT-nBq88dFBP8QPLSfLPx__m8DGgnNr53DuXu39YMjRODI?purpose=inline)

[lemonde.fr](https://www.lemonde.fr/actualite-medias/article/2012/09/23/rue89-prime-aux-etats-unis_1764204_3236.html?utm_source=chatgpt.com)

传统新闻媒体过去主要依靠报纸、广播和电视传播信息。

在线视频平台出现之后，它们获得了新的传播渠道。

例如，一家新闻网站可以：

* 上传新闻采访。  
* 发布事件现场录像。  
* 展示电视节目片段。  
* 制作专题纪录片。  
* 发布记者现场报道。  
* 将视频嵌入新闻文章。

这使新闻机构能够把文字报道和影像报道结合起来。

### **4.3 视频嵌入（Video Embedding）**

[Un clip provocateur de Justice fait débat](https://images.openai.com/static-rsc-4/3JXoiQWb17RTTc5fl0Ua0AxQskdvcLRhn9H3DGr4KGr6e08kpVFe7hJOnTGY9S1uuV49CEuEJH16lsWByF4H3Ogq9z39lVtABiL6ieMrkTR_pIbttohok5RZEIJEzDG-y5GINQ0Mp6Jt8nX3UM6XxcFJIjqwpPC-A9355UzZrsA?purpose=inline)

[lemonde.fr](https://www.lemonde.fr/culture/article/2008/05/10/un-clip-provocateur-de-justice-fait-debat_1043374_3246.html?utm_source=chatgpt.com)

Dailymotion的另一个重要功能是视频嵌入。

例如，一家法国报纸可以将Dailymotion播放器嵌入自己的新闻网页。

读者打开新闻文章时，不必离开原网站，就能直接观看视频。

这一技术产生了一个重要变化：

视频文件可以存储在Dailymotion的服务器上，但观看发生在合作媒体的网站中。

法国文化部2008年的报告指出，当时约有30%的相关视频观看发生在Dailymotion平台之外。

Prestataires- version finale 21 juin 2008

这说明Dailymotion已经不仅是一个视频观看网站，也成为其他网站的视频技术服务提供者。

## **第五节 Flash技术与早期欧洲网络视频传播**

### **5.1 Flash改变了什么？**

[23 Pictures That Will Make You Say "Wow, I Miss Windows XP"](https://images.openai.com/static-rsc-4/G3CuN2mmiLqjXOGc28dV97Zz7nRJlFP6PAk8EQ7jLP3lMX5HA9Iw76VGltfHdAOLmKbcss7TIXFfzZzH5DQxJeSqfpWgSY7t-6ezfTETel7uN_WTayO9T3AzvHDj1jY6QT0imUc5-npDKOyWRg08_Hk2qPMM8ULGVbTftODy0Tc?purpose=inline)

[buzzfeed.com](https://www.buzzfeed.com/daves4/intense-windows-xp-memories?utm_source=chatgpt.com)

2000年代中期，Adobe Flash是网络视频传播的重要技术。

在Flash广泛应用之前，用户观看网络视频通常需要处理播放器安装、文件下载和格式兼容等问题。

Flash提供了一种相对统一的网页播放环境。

Dailymotion利用Flash技术，让视频能够直接嵌入网页。

它的基本工作过程可以理解为：

1. 用户上传视频。  
2. 服务器处理视频文件。  
3. 视频转换为适合网页播放的格式。  
4. 用户打开网页。  
5. 浏览器中的Flash Player播放视频。

早期Dailymotion的视频播放主要依赖Flash Video等技术。

### **5.2 FLV与网页视频**

[Pin by noahchartier on 2000s \| Old websites, Youtube website, History design](https://images.openai.com/static-rsc-4/n2ByeNoA933r9MF8HHgBm-NLIJXq2soPVgW4lPkLVNpNap0k1xe1nZs5343zlyu129miEtXIqsgqI6RZiFG4NKkpt7VwzdgIQCJ-fKlP7hIydNFvx_NcR1UpulX7SZss48x6u9ZBgWo5zlsOKkwq5MC94F4Ssr_Q5MsNuSkLjoU?purpose=inline)

[br.pinterest.com](https://br.pinterest.com/pin/310607705554716887/?utm_source=chatgpt.com)

FLV（Flash Video）是当时常见的视频封装格式。

它与Flash Player配合，使网络视频能够在网页中播放。

这种技术有几个优点：

* 不需要观众自行下载完整文件。  
* 能够嵌入其他网站。  
* 可以通过网络逐步传输。  
* 相对容易统一不同用户的播放体验。

需要注意，FLV是一种视频封装格式，而Flash Player是播放环境，两者不是同一概念。

### **5.3 网络视频与CDN**

[Best CDN for Video Hosting and On-Demand Streaming](https://images.openai.com/static-rsc-4/wzjmbShhLcxB56zp_wRe9PqkwuPO_eB0y9ofJGWi4qkibPBm6qzXcJYqR_ty1lUACqRiVx1I1Fmgy7VVtp2o0PZRwOmJrMVpLAjTvnpTfaZEv6dlJk-9HfSzs7O4bPzkyJjOnJS_aNb0YHYx24bJqKvaSwDAhHYivGPD12f0d6w?purpose=inline)

[blog.blazingcdn.com](https://blog.blazingcdn.com/en-us/best-cdn-video-hosting-on-demand-streaming?utm_source=chatgpt.com)

随着Dailymotion用户规模扩大，视频传输成本也不断增加。

假设一部视频只有几百个观众，服务器压力可能相对有限。

但如果一段热门视频在一天内被数百万用户观看，服务器就必须承担大量数据传输。

这时，内容分发网络（Content Delivery Network，CDN）变得非常重要。

CDN通过分布在不同地理位置的服务器缓存和分发内容，让用户能够从相对接近自己的节点获得视频。

例如：

一位巴黎用户和一位东京用户观看同一段视频时，不一定需要从同一个原始服务器获取全部数据。

这种分布式传输方式改善了播放速度，也降低了中心服务器的负担。

### **5.4 从Flash到HTML5**

[Embedding and Optimizing Video in HTML for Modern Web Development \| Cloudinary](https://images.openai.com/static-rsc-4/icMK5ott4jJO3g9AQqp4070w-VPTJqkol6UGMmuqrs4sp9M5e16-CpRSJ2FEmu99FhAunPm2ShXJbkZonMmws37CsG0gsSg4o5mKh_yooPvN4EUyWanEnQ3aBac-PUaz-Q7SwZAzqJq3aSHSl72B7qfleu2qmdkkoYnVSWT0Ggo?purpose=inline)

[cloudinary.com](https://cloudinary.com/guides/front-end-development/video-in-html?utm_source=chatgpt.com)

2010年代，HTML5逐渐成为网页视频播放的重要技术。

与依赖Flash插件的旧式播放方式相比，HTML5的video元素能够让浏览器直接支持视频播放。

这带来了几个变化：

* 减少对外部插件的依赖。  
* 更好地支持移动设备。  
* 改善浏览器兼容性。  
* 与现代网页技术结合。  
* 方便开发自适应视频播放系统。

这一转变并不是Dailymotion单独推动的，而是整个互联网视频产业的技术演进。

对于网络艺术来说，这也意味着作品逐渐从依赖特定浏览器插件的环境，转向更加标准化的网页播放环境。

## **第六节 法国文化产业与网络视频政策**

这一节是理解Dailymotion欧洲特色的关键。

### **6.1 法国为什么重视本土数字媒体产业？**

[Paris : ministère de la culture (Ministry of culture)](https://images.openai.com/static-rsc-4/2oKyfo3ZP9k0o-CO2Li0C1WC5Z4IOh-afM_U2zHbDCDO342Ym_ar6etE9EuvApNOwnJfubpjVoBxEflERQFO33yuKHOPO-pLs6IPamnYv8QSRVm78uhJWw9wMcC-_VDq__MbiLcOnK_ustudWfh6EZRDLSqS0jgHdTUT4BAid7ksHouOSCHuc3hlEFptcTDR?purpose=inline)

法国长期重视本国电影、电视和文化产业的发展。

法国文化政策具有几个重要传统：

* 支持法国电影制作。  
* 保护法语文化。  
* 维持本土文化生产能力。  
* 支持独立电影和艺术创作。  
* 鼓励文化产品进入国际市场。

这种政策传统在互联网时代也产生了影响。

Dailymotion作为法国本土成长起来的互联网视频企业，自然进入了法国数字文化产业发展的讨论范围。

### **6.2 2009年：法国国家资本参与**

Dailymotion的发展不仅受到私人投资者关注，也逐渐具有产业战略意义。

根据Dailymotion官方历史资料：

* 2006年：完成首轮融资。  
* 2008年：开始国际化扩张。  
* 2009年：获得法国国家投资支持。  
* 2011年：Orange成为重要股东。  
  About Dailymotion+1  
  [FRANCE-US-TECHNOLOGY-INTERNET-POLITICS-ECONOMY](https://images.openai.com/static-rsc-4/mGqFmH8AvV8zXosv8McRDPEs39HqBc4GIjKFUmEp9Q2aH7YqBjhVAImKAkr7GwYSX9KtgDYbZ-hS8gkS1Zd2XljEMgOTkaIKsAw5gUpdxx5TDmiaqBhn3QtnAAqPNoGHJAn9Coj4ZKqpjZc4TGqtgHDwPbhyjsp6Dx3s2VAwOBB-x5bNuZsbzg22eJ-EsbOw?purpose=inline)

这说明法国方面希望保留具有国际竞争力的本土互联网视频企业。

但需要注意，国家资本参与并不意味着Dailymotion成为政府直接经营的公共电视台。它仍然是一家商业互联网公司。

### **6.3 2013年：Dailymotion收购争议**

2013年，Yahoo曾希望收购Dailymotion的控股权益。

这一计划引起法国政府关注。

法国方面担心，本土重要数字媒体企业可能失去法国和欧洲的产业控制权。

[French Lessons: Why Dailymotion-Yahoo\! Deal Went Sour \- Worldcrunch](https://images.openai.com/static-rsc-4/rQRD4_5KPwgkbX_Hzehk7kNXpU_o0mhCtvFhjoMGVNhnPCfcEyEH0xsBYMWgTI_c6U3xwDhtWsg6YeZvAytx_sc3JS5xlyP60qjFYYIvLI0MZyafLyUO_eUlqLrKkbZWGOEuLSSnGMvTeyM_tCVgig9YFe9R40V2CyeNn_Fhrlk?purpose=inline)

[worldcrunch.com](https://worldcrunch.com/business-finance/french-lessons-why-dailymotion-yahoo-deal-went-sour/?utm_source=chatgpt.com)

这场争议体现了一个重要的欧洲数字产业问题：

互联网平台虽然能够在全球市场竞争，但它们的技术、企业总部、资本结构和文化影响力仍然涉及国家产业政策。

因此，Dailymotion不仅是视频网站，也被视为法国数字产业的一项重要资产。

### **6.4 欧洲数字单一市场与文化多样性**

[Notes from the IAPP Europe: DSA and elections in Europe, first AI Factories and more \| IAPP](https://images.openai.com/static-rsc-4/--BnOLTC7Q5mgt5bKS1f-FRK5pcoW2WmPobqLoa7d5tHM1PykiKyYYGGl4nGFyBvz4LzLGPQy_thYQsd3jyfAFwCM-UZSGLB821bkTQFRqWJfhZkhibYFQoRwtZ3jStyZKJCnd6E4jxisMoJe0rbiDJ33rF31ub2cfNFLy4dIok?purpose=inline)

[iapp.org](https://iapp.org/news/a/notes-from-the-iapp-europe-dsa-and-elections-in-europe-first-ai-factories-and-more?utm_source=chatgpt.com)

欧盟长期推动数字单一市场（Digital Single Market）。

其目标之一是减少成员国之间数字服务发展的障碍，促进数字内容跨境传播。

但是，欧洲同时也重视文化多样性和本土视听作品的生产。

这形成了两种需要协调的目标：

* 促进跨国数字服务与市场竞争。  
* 保护欧洲各国的语言和文化生产能力。

在线视频平台的发展使这两个目标之间的关系更加复杂。

## **第七节 欧洲视听媒体政策与在线视频平台**

### **7.1 从电视广播到网络点播**

[FRANCE-MEDIA-TELEVISION-FRANCE 24](https://images.openai.com/static-rsc-4/qMMt_uGGExcvOtHaOL4RrRY_tBwM0OD2h-c300r1JPngpIK86LOEJXohKGs30Zdb7sf8DbQT-8-kbTFNdfgh154zMP8bge8tm3iS0ZQ2B7kdcjPXFNVidioPR1qcxxf_9iH_JUXi9QRu-tZ1wBaPORbuCtRtaD228v7RGStV0qpUHRzYci3RIGUF3jKjCb07?purpose=inline)

欧洲的视听媒体政策最初主要针对传统电视广播。

1989年，欧洲共同体通过《无国界电视指令》（Television without Frontiers Directive）。

它试图建立欧洲电视广播的共同规则。

随着互联网视频服务出现，传统电视法规逐渐无法覆盖所有新型传播方式。

例如：

* 视频点播。  
* 网络电影。  
* 在线电视节目。  
* 用户上传视频。  
* 视频分享平台。

这些服务不完全符合传统电视广播的组织方式。

### **7.2 2007年：视听媒体服务指令修订**

2007年，欧盟修订原有的电视广播政策，开始将视频点播等新型服务纳入视听媒体监管框架。

[QUOTAS AND PROMINENCE. HOW IS TELEVISION GOING TO CHANGE IN EUROPE WITH THE NEW AVMSD? by Manuel José Damásio \| CST Online](https://images.openai.com/static-rsc-4/mLWnN4yYfvPvrwuq5Ebu3FT2Jnhde7jMDwizPRi1fd_cwLlT-HV-rZu8f2ge1Xs4e2FJIJrw8HnTWp7PybSqeguxD37fwc8dSbJeFimgml3jqpWxy5OHMTDL15J2KqnIkJKwwSDBZ58VDmJae6-4kltFPeNl8RDIaFuKhIvfZdg?purpose=inline)

[cstonline.net](https://cstonline.net/quotas-and-prominence-how-is-television-going-to-change-in-europe-with-the-new-avmsd-by-manuel-jose-damasio/?utm_source=chatgpt.com)

这项政策后来发展为《视听媒体服务指令》（Audiovisual Media Services Directive，AVMSD）。

2010年，该指令完成编纂。

2018年，欧盟进一步修订规则，将部分视频分享平台纳入更加明确的监管范围。

European Parliament+1

### **7.3 欧洲作品配额**

欧洲视听媒体政策的一个重要内容，是促进欧洲作品的传播。

2018年修订的AVMSD规定，相关视频点播服务的目录中，欧洲作品至少应占30%，并应确保这些作品具有适当的展示突出程度。

EUR-Lex

这里需要区分：

* 视频点播服务（VOD）。  
* 用户上传视频分享平台（VSP）。  
* 传统电视广播服务。

它们在法律上的分类和义务并不完全相同。

不能把30%的欧洲作品配额简单理解为所有视频分享网站的统一配额。

### **7.4 这一政策与艺术影像有什么关系？**

[transmediale](https://images.openai.com/static-rsc-4/1TGvjpjLqCC95c4iV0BUN0wcGZ1up3jk4HwjQu-qWYLLNFY6bd8iJeAzisnLP3pc_BJgvc2XNmlHKT9O-P7_gmXvNwZkp4Uybu14nm9Mf6wd15efB03uycxroHXw9-CLbzDtoL8oYCd8KBpQGGJJn03K0U4BHXwtGsQAUWnQt2g?purpose=inline)

[transmediale.de](https://transmediale.de/de/media/silvia-dal-dosso-clusterduck-collective-the-future-ahead-will-be-weird-af-the-ultimate-ai-corecore-experience-part-one-part-two?utm_source=chatgpt.com)

这些政策对于欧洲独立电影和艺术影像具有间接影响。

如果欧洲作品能够在大型视频点播平台中获得展示机会，独立电影、纪录片和本土语言作品就有可能接触更多观众。

但法规并不能自动保证实验艺术作品获得关注。

艺术作品能否被发现，还取决于平台分类、推荐机制、版权许可和策展实践。

因此，欧洲文化政策为影像创作提供制度环境，而平台自身的组织方式决定了作品如何进入观众视野。

## **第八节 Dailymotion与欧洲新闻影像文化**

### **8.1 新闻视频的网络化**

[Accueil \| Campus France](https://images.openai.com/static-rsc-4/euyOFzs1-495nF1IP3Pesyvcb25iFcLiBBQsZzVEp09gPDLgnfeUWnxMp0fIUZb87WOQqhmlQFIQtEna6-a3-b-9UKM5_jWUpEkEvEUKFDP4qa1VMiOob8av3kF_e5cg_2ixVpK54d1P9eisThUwKA33zK_khOmorhIbVyddXVY?purpose=inline)

[benin.campusfrance.org](https://www.benin.campusfrance.org/?utm_source=chatgpt.com)

Dailymotion在早期发展中逐渐吸引新闻机构。

法国的报纸、新闻网站和电视媒体开始将在线视频作为报道形式的一部分。

这带来了新闻传播结构的变化：

过去，新闻视频主要依赖电视广播。

后来，新闻网站可以直接嵌入视频，让读者在阅读文章时观看采访和现场录像。

### **8.2 现场影像与公民新闻**

[When the Disenfranchised Use Counter-Narratives for Justice](https://images.openai.com/static-rsc-4/22JwcYVA0fn2fta2Bg5ONaHkKQVPo4nAHexaJ9ruO-8zv37k851XKMNtm-lPVsQyrCPnqi5UJr2_zj8XR1mrs-f2Occ9EoAImhXz6Crxzvh5rZ2RHHdT8EY229Cy0SGESDj5xW0lCrpnwpLlDyWJ91p9LyWotC1ti6zfVDSPdK0?purpose=inline)

[governing.com](https://www.governing.com/now/When-the-Disenfranchised-Use-Counter-Narratives-for-Justice.html?utm_source=chatgpt.com)

互联网视频传播也使公民新闻（Citizen Journalism）得到发展。

普通人能够使用摄像机记录公共事件，再通过网络平台传播。

这类影像可能涉及：

* 示威活动。  
* 城市公共事件。  
* 社会冲突。  
* 自然灾害。  
* 环境问题。  
* 日常社会生活。

Dailymotion等平台使这些视频能够进入更广泛的公共讨论。

不过，新闻影像与艺术影像仍然需要区分。

新闻影像通常强调事件记录和信息传播；艺术影像则可能通过剪辑、构图和媒介实验重新组织现实材料。

两者也可以交叉，例如艺术家使用新闻录像进行拾得影像创作。

### **8.3 电视机构与网络平台的融合**

[La nouvelle chaîne d'info publique fait son entrée dans le PAF \- ladepeche.fr](https://images.openai.com/static-rsc-4/6ZnGF6-beCI9pV9rki5Y9V6OXOrO8QPvujayDhR70CZ9p_qvhleFLBl81PZCqielT89wZpcb-_BPCY3Kb7nbNENY4osFm_z55Jd9XN027maFfTdp3K8qzy4k21t5bU8vfVoLGqjgmimqq-fmJz-Oy6hbol5alFNH-UvLzOYClLE?purpose=inline)

[ladepeche.fr](https://www.ladepeche.fr/article/2016/09/01/2410065-jour-franceinfo-rideau-leve-nouvelle-chaine.html?utm_source=chatgpt.com)

随着网络视频市场扩大，电视机构逐渐意识到在线视频平台不仅是竞争者，也可以成为合作伙伴。

电视台可以通过平台传播节目片段、新闻报道和专题视频。

平台则获得更加稳定的专业内容来源。

这种合作逐渐形成新的媒体生态：

传统电视台负责内容制作，互联网平台负责托管、分发和网络传播，广告商则通过视频内容接触观众。

Dailymotion由此逐渐从单纯的用户视频分享网站，发展为连接专业媒体与网络观众的基础设施。

## **第九节 版权争议：Dailymotion与法国互联网法律**

### **9.1 用户上传视频带来的版权问题**

[Prehome Orange du 10.03.2010 \- Vidéo Dailymotion](https://images.openai.com/static-rsc-4/eMPOoxMZgeGYssLGs3YAAIVjIQclX0N0uhrpA0Jk-zmRtVkKT-p6BaF-YP09oX7BNpPPUObkYDVMXmpwBd63UZPs4nGEBdIHW5Ga_CzsQOO_5TnRqmdq3FbPL-jodvR4bHcQNOwcTRE_-rcmQWbz8qWNodplMCmQoVtrg2TcVUQ?purpose=inline)

[dailymotion.com](https://www.dailymotion.com/video/xciszq?utm_source=chatgpt.com)

与YouTube一样，Dailymotion的开放上传机制也产生了版权问题。

用户上传的视频可能包含：

* 电影片段。  
* 电视节目。  
* 商业音乐。  
* 喜剧表演。  
* 体育赛事录像。  
* 动画作品。  
* 新闻影像。

这引发了一个重要法律问题：

当用户上传侵权视频时，视频平台应该承担什么责任？

### **9.2 2007年：电影《Joyeux Noël》诉讼**

2007年，Dailymotion因网站上出现未经授权传播的法国电影《Joyeux Noël》（《圣诞快乐》）而遭到诉讼。

[Joyeux Noel (\#1 of 5): Mega Sized Movie Poster Image \- IMP Awards](https://images.openai.com/static-rsc-4/01-kxjutvSswA9ZDhDIKoSJQ9hGI4NNOVkwrJAePwHTepkzVpEl4KUUsk5Z1YuN8U_zw-YLgD6DJ9K19cQKkIrhub2Gm_nsD7M7mYHmlxkTqZ0YFzG53PDRXgBMKLyOHneTRRuc_kncQ3CGz5jHYgC2SZGSGufhkZ5iGZC7LEmI?purpose=inline)

[impawards.com](https://www.impawards.com/2006/joyeux_noel_xxlg.html?utm_source=chatgpt.com)

这部电影由法国导演Christian Carion执导，于2005年上映，讲述第一次世界大战期间1914年圣诞停战的故事。

案件涉及Dailymotion究竟是单纯的技术托管服务，还是应当承担更积极的内容管理责任。

2007年，巴黎法院曾作出不利于Dailymotion的判决。

2009年，巴黎上诉法院在相关案件中改变了此前的处理结果，确认平台在相应法律条件下可以作为内容托管服务提供者，而不必自动承担用户上传内容的全部责任。

European Digital Rights (EDRi)+1

### **9.3 法国LCEN法律**

这一问题与法国2004年的《数字经济信任法》（Loi pour la confiance dans l'économie numérique，LCEN）有关。

该法律建立了法国互联网服务提供者和内容托管服务的部分责任规则。

其中的重要思想是：

平台并不必然因为用户上传的所有内容而自动承担与内容出版者相同的责任。

但当平台获得符合法律要求的侵权通知后，仍然需要依法采取相应措施。

这与欧洲电子商务指令所建立的互联网中介责任框架存在联系。

### **9.4 版权制度与网络影像艺术**

[Was anderes machen (The Home and the Movie): Towards A Library Of Images: Thinking TV Archives Public \- silent green Kulturquartier](https://images.openai.com/static-rsc-4/FHRhjSwJ8_tpvggRNsKT-_FYP0Xs68CM0Ve9EJfCnE5OVVoDa515RO7tlJTA9rw6uIRKYhlwR7YG_al04DoXMh7fSRLXpPRK9ZGqIbmYJvF69NoZ-k4uloDIBb2Ab358-LNE2KfCiXUVbPyMqaSW_CtWylAEC6PnShBNBGginP8?purpose=inline)

[silent-green.net](https://www.silent-green.net/en/programme/detail/2023/6/6/was-anderes-machen-the-home-and-the-movie-towards-a-library-of-images-thinking-tv-archives-public?utm_source=chatgpt.com)

这一问题对实验影像艺术尤其重要。

艺术家可能通过重新剪辑已有的电影、电视和新闻影像，创造新的作品。

例如：

* 将不同年代的新闻录像组合起来。  
* 将商业广告重新排列。  
* 将电影镜头转换为抽象视觉材料。  
* 通过重复和变形改变原有影像意义。  
* 将历史影像与当代影像并置。

这些创作涉及拾得影像、挪用艺术和影像拼贴。

但艺术上的再创作并不意味着自动获得版权豁免。

因此，网络平台的版权制度会直接影响部分艺术作品的展示与传播。

## **第十节 2011—2015年：Dailymotion的资本与商业转型**

### **10.1 Orange进入Dailymotion**

[FRANCE-US-TECHNOLOGY-INTERNET-POLITICS-ECONOMY](https://images.openai.com/static-rsc-4/gry5K6Ka0VtYlphLDpQKHdDO_4nnKnpdF5q3qGRmJzNhB7QXGTRoweN-QuC5qQdqWxux1UOFcDCRz1Mgv39iBz0dLrJoajegmBMlpLDQmpv-K4Q5jGDxrvcdhUuMPD3aFH7yxnAB_nmYiQzR-R9q6_iAIUMjq83T0wQ7w3oxGFSJuRCgkmtkXvNvy21bxzDC?purpose=inline)

2011年，法国电信运营商Orange成为Dailymotion的重要股东。

Orange最初收购了Dailymotion约49%的股份。

这项交易具有重要意义。

Orange不仅是一家电信公司，也拥有网络基础设施、用户资源和数字媒体业务。

通过资本合作，Dailymotion获得了更强的产业支持。

### **10.2 2013年：Yahoo收购计划受阻**

2013年，Yahoo曾尝试收购Dailymotion的控制权。

但这一计划受到法国政府反对，最终未能按照原方案完成。

这反映出法国政府对本土数字产业控制权的重视。

Dailymotion已经不再只是一个普通视频网站，而被视为具有战略意义的法国数字企业。

### **10.3 2015年：Vivendi收购Dailymotion**

[Vivendi Buys Dailymotion for \$242 Million \- TheWrap](https://images.openai.com/static-rsc-4/OK-L0z4iEibbgc_AsPIs4OU9wrfYQMYicNiIlXnHYZa_RGMzLonBIKPGdHdn-zQcbpp6Va3HwxVc1HNOJRyAWmhbzNbNL7FVmJBRY57-JJXa2rziKpTKundJkQ49lWvhXdFmLySQfIagE5F_etuie_BIAOYWwYAgrEqmrPJuN9A?purpose=inline)

[thewrap.com](https://www.thewrap.com/vivendi-buys-dailymotion-for-242-million/?utm_source=chatgpt.com)

2015年，法国媒体集团Vivendi收购Dailymotion约80%的股份，随后进一步提高持股比例。

Vivendi拥有音乐、电视、影视和其他媒体产业资源。

此次收购使Dailymotion进入一个更大的媒体集团。

这也推动其商业模式进一步调整。

Dailymotion开始更加重视：

* 专业媒体合作。  
* 企业视频服务。  
* 视频托管技术。  
* 广告商业化。  
* 专业内容分发。  
* 视频播放器服务。

Dailymotion官方历史资料将2015年视为其从创业公司转向集团化经营的重要节点。

About Dailymotion+1

### **10.4 Dailymotion后来发生了什么？**

[Dailymotion Video Platform \- Upload, Share, and Monetize Videos](https://images.openai.com/static-rsc-4/kA_iw1DPwegACajRUVcn4hs_vse3r_jOqIHNavby7haBmqkjSYiuWWWwcVENr7ZJ0ly6SH98SSXbIYtaT8fPXjvrAohDqbgrF5WE1B9-3GrUyi44WyN7SEYLAqwPhhpsbmYdryCiZTZD95eZKUbbA_LzZtY4NPfBIVAfbOgex9g?purpose=inline)

[thetoolpicker.com](https://www.thetoolpicker.com/tool/dailymotion?utm_source=chatgpt.com)

Dailymotion并没有消失。

它后来逐渐从以普通用户视频分享为中心的服务，发展为面向专业媒体和企业的视频技术平台。

2024年，Dailymotion正式加入Canal+集团。

这使它进一步进入法国大型视听媒体产业体系。

About Dailymotion

因此，我们在研究Dailymotion时必须区分两个时期：

* 2005—2015年：用户视频分享、创作者社群与欧洲网络视频文化形成。  
* 2015年以后：专业媒体合作、企业服务和视频技术平台转型。

本章主要关注前一个时期。

## **第十一节 Dailymotion与欧洲独立影像艺术**

这是本章最重要的艺术史部分。

### **11.1 网络视频平台成为艺术作品的展示渠道**

[Marwa Arsanios. The Land Shall Not Be Owned](https://images.openai.com/static-rsc-4/taFOH98n2wevIht6Rzp0DtzBbr-91cGkbLNzSbCNJHpabXhwcIhrAPiJBDnNGIA5203CX7Qe-EUe5GgK1WjreT0DwnArks9uWVBtX9YujvbE0QLGs90iAlwzn5b1RTjYlJUjsaMTif_km6h-cQksDK9W47JYb2yjiJiDOQ_26uc?purpose=inline)

[artium.eus](https://artium.eus/en/exhibitions/item/61990-marwa-arsanios-the-land-shall-not-be-owned?utm_source=chatgpt.com)

Dailymotion的出现，为欧洲独立影像创作者提供了新的传播条件。

传统视频艺术通常需要通过美术馆、画廊和艺术节展示。

独立电影则主要依赖电影院、电影节和发行机构。

在线视频平台使这两种创作类型都获得了额外的传播渠道。

艺术家可以将作品上传到平台，使观众在个人计算机上观看。

### **11.2 单频道影像与多频道影像**

[Da Hito Steyerl al Premio Strega: la nuova stagione del MACRO di Roma](https://images.openai.com/static-rsc-4/pSztojO83vJ3H0eRvaPgsvhhQ-_1P-p9Fi4l7JJh2fNTZm1c8UrdZEXZ1fXiMMDAgLUcpSfZfH-NivldAPF3pEES7UKA4INFVHv9GPHJXiOYBBhZ5W3F85_gqwRbttoEA_89C8l-ybpHNEd-AXRniiG1q4ukyYegD_ZVH_EwBpQ?purpose=inline)

**单频道影像（Single-channel Video）**

主要通过一个视频画面呈现作品。

[Bani Abidi, Funland (Karachi Series \- II), 2014 \| Experimenter](https://images.openai.com/static-rsc-4/YOCzsh6O0T0b_s6_l7qG18WsRMxsLkZkgTanPHeR5L8EhWYDPfxX3raUfOaMZA2PX65DNd1JTmlhy0RuYVLh8ijZGnlgOVS4SwGenNC2K1YbkY3ifBZIhny4E_NcS9OilWZlcfMGZHipArOwEj-9aK2LF2w_Y64Z1pFVGe4_uqI?purpose=inline)

**多频道影像（Multi-channel Video）**

通过多个屏幕或投影组织作品。

Dailymotion这样的网络视频平台更适合展示单频道影像。

因为普通网页播放器通常以一个视频画面为中心。

而多频道影像装置可能需要多个屏幕同步播放，并通过空间位置建立视觉关系。

因此，网络传播不能完全替代美术馆展示。

### **11.3 网络影像与实验电影**

[Train Again / Directed by Peter Tscherkassky — Encounters](https://images.openai.com/static-rsc-4/lA4IeYh6Ox0b-8QPv49fWxHbfhCvPp_anb775ojsukz1BHxqG95hMU0JZAwS4RyZER_Nhct_Iuy8LBvbJav3WjVmR5NfeEKLOioLtc4S2hroz0sEkClPPtQzAmSpupxqF5kNDXR31Sg9aYX_werKYLQ2AvSdlJ-_LHD2ws6iY2Y?purpose=inline)

[encounters.film](https://www.encounters.film/train-again?utm_source=chatgpt.com)

欧洲具有悠久的实验电影传统。

从法国先锋电影、德国实验电影，到英国结构电影和欧洲当代影像艺术，都形成了丰富的创作历史。

Dailymotion提供了一个新的传播渠道，使这些作品能够接触传统电影节之外的观众。

不过，我们不能认为Dailymotion创造了欧洲实验电影。

更准确的说法是：

**Dailymotion为既有的欧洲独立电影与实验影像传统提供了新的网络传播环境。**

### **11.4 网络视频与艺术档案**

[Dalla pellicola al digitale: in 320mila bobine la storia della tv e dell’Italia \- la Repubblica](https://images.openai.com/static-rsc-4/bDepzbhz9LHyNKqqDNUHdRdNE8r3yZwJGrEPdolggxfr9FduRVl5JtvCLwzTFfy_gedU6TvJtRJrW3j42EzbAUIrKVFzICd7LMBbeWIRYp0Cw8yi_PeDhyGDNxmYbX-zu3kLhttIjfYl9BGhgxXM8tVtJlfTbbFchyReex8vYb4?purpose=inline)

[torino.repubblica.it](https://torino.repubblica.it/cronaca/2025/11/06/news/dalla_pellicola_al_digitale_in_320mila_bobine_la_storia_della_tv_e_dell_italia-424964339/?utm_source=chatgpt.com)

网络视频平台还产生了新的档案问题。

一件艺术作品可能在平台上获得大量观看，但如果创作者删除视频、平台改变政策或作品受到版权限制，原有页面就可能消失。

因此，数字艺术保存不能仅仅依赖在线视频平台。

研究者还需要保存：

* 原始视频文件。  
* 视频编码信息。  
* 创作时间。  
* 作者信息。  
* 作品说明。  
* 展示环境。  
* 原始网页截图。  
* 作品的版权信息。

这对于研究2000年代早期网络影像尤其重要。

## **第十二节 欧洲网络视频平台的历史比较**

2000年代欧洲并不是只有Dailymotion一个视频平台。

当时还存在许多本土视频服务。

[Comment télécharger Dailymotion en streaming? \- Vite une solution Doc \!](https://images.openai.com/static-rsc-4/GYGlS1Tfz9KPyh_izHtyriTPVua4sZP-sPYUy0Ti8SqWEcP0u90wXyKIWTt-X5t1o_mUIe0n4lyR0gOsryEnbqR9zvisRKdT1iSetAHjpcy8uabrLLruJEjmE-ZzLpxN1lxrWzNEz7JZZI6_aJhaJTxy4fcR6pJCsSr6qyBTryc?purpose=inline)

[Youtube & Co: Die fünf besten Musikvideo-Portale – laut.de – Seite 13/33](https://images.openai.com/static-rsc-4/3Vhiup0-JbgFqNtLykdgFcPr7EsY_Lly0gHmxIDOsKYmZ38VNFlBcRSqdm7iX8s-Vgpd91s9NOfsh-7jNTuLBDjnLuryPSPV56GOp_sPwZiAEgLD8MsCPZ0JOOAB3hvsQV3vF6FwokALCBpnLedgsKVMfLmSG3NeGjphFq9owjY?purpose=inline)

[sevenload zeigt die besten Filmtrailer im Netz, Magic Internet Holding GmbH, Story \- PresseBox](https://images.openai.com/static-rsc-4/zpLgbsFWvihQ8-a8IKyldo-jncNRPZs6TwYw4f1vPJ3XsSALwBbygFssq1FXWFuCB3-7TJ8RiHT4vvHibzDNKxdJ8feNZh7QVRJEzoFIpoIRXLeSr_U8srrm6x7uftSZ1Y8KcwN5HYrR8gBw1DERr6GcajjFpR6drubwzscR9ic?purpose=inline)

7

| 平台 | 国家或地区 | 早期特点 |
| ----- | ----- | ----- |
| Dailymotion | 法国 | 国际化视频分享 |
| Clipfish | 德国 | 德语视频分享 |
| Sevenload | 德国 | 图片与视频分享 |
| Wat.tv | 法国 | 网络视频与大众娱乐 |
| YouTube | 美国 | 大规模大众视频分享 |

这些平台说明，早期欧洲在线视频生态具有多中心特点。

不同国家形成了自己的视频平台、语言社区和媒体合作网络。

但随着全球平台规模扩大，许多本土平台逐渐失去竞争优势，Dailymotion则通过商业模式调整继续发展。

## **第十三节 本章历史时间线**

[Dailymotion : le devenir média d’une plateforme. Analyse d’une trajectoire sémio-économique (2005-2018)](https://images.openai.com/static-rsc-4/3hr3F0n1usA2JZ4XuGZ_8rpj9A0Mw0M5zARISNRktQJZX-nFo658p2A6lZfbqOaXxXJrT81YKkFkWVcFKjM63o_aHubEGBf33PvHCVo5S2XYO5tSTW14O3kG7Xe2C3jhS7bMZjOXF3RASZlPAuZGN4nvRQpQj6cqHJnjwpnwDo0?purpose=inline)

[journals.openedition.org](https://journals.openedition.org/ticetsociete/3540?lang=en&utm_source=chatgpt.com)

| 时间 | 事件 | 历史意义 |
| ----- | ----- | ----- |
| 2005年3月 | Dailymotion在法国成立 | 法国本土视频平台出现 |
| 2006年 | 首轮融资 | 创业项目获得资本支持 |
| 2007年 | 扩展专业内容合作 | 从用户视频走向媒体合作 |
| 2007年 | 欧洲视听政策修订 | 视频点播逐渐进入监管框架 |
| 2008年 | 国际化发展、MotionMaker和Official User计划发展 | 创作者与媒体生态扩大 |
| 2009年 | 获得法国国家投资支持 | 企业战略地位提高 |
| 2009年 | 相关法国版权诉讼出现重要判决 | 平台责任制度进一步明确 |
| 2010年 | AVMSD正式编纂 | 欧洲视听监管框架完善 |
| 2011年 | Orange成为重要股东 | 电信产业资本进入 |
| 2013年 | Yahoo收购计划受阻 | 数字产业主权问题凸显 |
| 2015年 | Vivendi取得控制性股权 | 平台进入媒体集团体系 |

## **第十四节 本章核心概念**

| 英文术语 | 中文名称 | 含义 |
| ----- | ----- | ----- |
| Dailymotion | 法国在线视频平台 | 2005年成立的视频分享服务 |
| MotionMaker | 创意视频计划 | 鼓励原创影像创作 |
| Official User | 官方合作用户 | 专业媒体和机构合作计划 |
| User-generated Content | 用户生成内容 | 用户自行制作并上传的内容 |
| Video Embedding | 视频嵌入 | 将外部视频播放器放入其他网页 |
| Flash Video | Flash视频 | 早期网页视频技术 |
| CDN | 内容分发网络 | 分布式视频传输基础设施 |
| Citizen Journalism | 公民新闻 | 普通人参与公共信息记录和传播 |
| AVMSD | 视听媒体服务指令 | 欧盟视听媒体监管框架 |
| Digital Sovereignty | 数字主权 | 国家或地区对数字基础设施和产业的自主能力 |
| Video SaaS | 视频软件服务 | 通过软件服务提供视频技术 |

## **第十五节 本章的艺术史结论**

Dailymotion的历史说明，网络视频文化并不是由YouTube单独创造的。

在2000年代，欧洲也出现了自己的在线视频平台、创作者社群和专业媒体合作体系。

Dailymotion的特殊性在于，它同时连接了三个不同的领域：

**普通用户与独立创作者**

个人录像、短片、动画、实验影像和创意视频。

**传统媒体与专业内容机构**

新闻报道、电视节目、纪录片和专业视频。

**国家文化政策与欧洲数字产业**

本土媒体产业、文化多样性、版权制度和数字基础设施。

从艺术史角度看，Dailymotion最重要的意义并不是它创造了一种全新的艺术形式，而是它展示了在线视频平台如何连接个人创作、专业影像生产和传统文化机构。

它帮助我们理解：

**网络视频平台不仅是技术工具，也是由创作者、媒体机构、资本、法律制度和文化政策共同构成的影像传播环境。**

