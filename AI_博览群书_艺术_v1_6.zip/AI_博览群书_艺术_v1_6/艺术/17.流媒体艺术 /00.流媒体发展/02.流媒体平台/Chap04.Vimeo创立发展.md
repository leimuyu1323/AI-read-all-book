# **02\. 流媒体视频艺术（Streaming Video Art）**

# **007 Vimeo与独立网络影像文化的形成**

*Vimeo and the Development of Independent Online Video Culture*

[Vimeo Online](https://images.openai.com/static-rsc-4/bqFDe6Bpqf2vDhNnGymqvQZbeUK8vPOae0F1C6eyLFrchy72aQxc3kC_KrxP3HG80FYHY-bejmMIKDR75H3W-_FEaZnlh23JGwUgcG2WwdJI03d9oPWdytDqoK3mnbjXvz1FQmQjss9-K-EaR154DkF98YZt5f_fTNPdSM9MrzI?purpose=inline)

[vimeo.softonic.com](https://vimeo.softonic.com/aplicaciones-web?utm_source=chatgpt.com)

## **导言：从大众视频分享走向独立影像创作**

2005年，YouTube的出现使普通互联网用户能够更加方便地上传和分享视频。但在线视频文化的发展并不只有大众娱乐这一条道路。

在YouTube逐渐发展为大型大众视频平台的同时，另一种网络影像文化也在形成：独立电影、实验动画、视觉设计、摄影、纪录片和艺术影像创作者开始利用互联网建立自己的作品展示空间。

Vimeo正是在这一历史背景下发展起来的。

与早期以大众视频分享为核心的YouTube相比，Vimeo逐渐形成了更加重视原创视频、影像质量和创作者作品集的文化形象。

它为独立创作者提供了一种新的可能性：不必完全依赖电视台、电影发行机构和传统艺术展览，也能够通过互联网展示自己的作品。

从流媒体视频艺术史的角度看，Vimeo的重要性不仅在于它是一个视频网站，更在于它帮助形成了一个由独立电影制作者、实验影像艺术家、动画师、摄影师和视觉设计师共同参与的网络创作环境。

本章将研究Vimeo的创立背景、早期平台设计、独立创作者文化、视频策展、艺术影像传播，以及它与YouTube之间的历史关系。

## **第一节 Vimeo的创立背景**

### **1.1 Vimeo诞生于什么样的互联网环境？**

2000年代初期，互联网视频技术正在快速发展。

数字摄像机逐渐普及，个人计算机开始具备更强的视频编辑能力，家庭宽带也在逐渐扩大覆盖范围。

与此同时，独立电影和数字影像创作者开始寻找新的传播渠道。

传统电影产业的发行体系具有较高门槛。

一部独立短片即使制作完成，也未必能够进入电影院、电视台或大型电影节。

艺术家的实验影像也面临类似问题：作品可能只在有限的展览空间中展示，观众范围受到地理位置和展览时间限制。

互联网提供了另一种传播可能。

[Houston director Jonathan Caouette, who made a splash with the cinematic memoir ‘Tarnation,’ is ready to turn the page](https://images.openai.com/static-rsc-4/e0-nKR5YrnKuVvSxi-JAFO0qj1SDcfiKbzpmA-Xhu0NXjApH-csNudbmySTKVH_eYWMBxB6e8Tt-RbLJgw5RH9wbe3H_2NDB-bjU2GnEMGZP0ztpRikaZICw6WYsGeeW-FL_cqQ80QRprApfHWlQP7iGVESZJRmoIF29ZsDSVYM?purpose=inline)

[houstonchronicle.com](https://www.houstonchronicle.com/entertainment/movies_tv/article/Houston-director-Jonathan-Caouette-who-made-a-14105851.php?utm_source=chatgpt.com)

创作者可以使用数字摄像机拍摄视频，通过计算机完成剪辑，再将作品上传到网络。

不过，当时的视频分享服务还处于早期阶段，上传、存储、播放和作品展示的体验并不成熟。

Vimeo正是在这样的环境中出现的。

### **1.2 Vimeo的创立**

[La biografia di Jake Lodwick e Zach Klein, i papà di Vimeo \- FASTWEBPLUS](https://images.openai.com/static-rsc-4/lE0Nmx4LIHL5LjZdUIY5sHCECL-hm9S9Ql44ybsUCiLCrBfxY0XhrVWfVs7MAQHNoqYUvlwd4d7KDgNqg1asSJerGggI5_OMrgA-bUhyQtNRQIG2jXQKJtVrTWRm5yocB7qF5gS_Si7_a8yNiWfIaWMkotPUwQaa1Ab0sNaWe5w?purpose=inline)

[fastweb.it](https://www.fastweb.it/fastweb-plus/digital-magazine/la-biografia-di-jake-lodwick-e-zach-klein-i-papa-di-vimeo/?utm_source=chatgpt.com)

Vimeo于2004年由Jake Lodwick和Zach Klein共同创立。

两位创始人都具有互联网产品和数字媒体方面的背景。

Vimeo最初与Connected Ventures有关联。Connected Ventures是一个互联网创业团队，后来还参与发展CollegeHumor等网络媒体项目。

2005年，Vimeo正式推出网站服务。

与后来发展起来的大型在线视频平台相比，早期Vimeo规模较小，但它很快形成了自己的创作者社群。

### **1.3 Vimeo这个名称的含义**

Vimeo这个名字是由两个英文词组合而成的：

* Video：视频。  
* Me：我。

它表达了一种个人化的影像理念：视频不仅是电视台和电影公司生产的内容，也可以是个人表达自己的媒介。

从这个意义上说，Vimeo与早期网络视频文化中的个人创作理念存在密切联系。

不过，Vimeo从一开始就不只是个人生活记录平台。它逐渐吸引了大量重视影像形式、摄影质量和原创制作的创作者。

### **1.4 Vimeo与YouTube的时间关系**

| 项目 | Vimeo | YouTube |
| ----- | ----- | ----- |
| 创立时间 | 2004年 | 2005年 |
| 正式推出 | 2005年 | 2005年 |
| 早期定位 | 个人视频分享、原创创作 | 大众视频分享 |
| 重要创作者 | 独立电影、设计、动画创作者 | 大众用户、个人创作者 |
| 主要文化形象 | 创作者作品展示 | 大众网络视频文化 |

需要注意，这种区别是两家平台早期形成的文化倾向，而不是绝对的分类。

YouTube也有大量实验影像和独立电影，Vimeo也不只是艺术视频平台。

两者的发展轨迹在后来发生了许多交叉。

## **第二节 Vimeo早期的平台设计与影像文化**

### **2.1 早期网站界面**

[【動画共有サイト】Vimeoのアカウントの獲り方とオリジナルファイルのDL方法【海外】 \- Ψ(｀∀´)Ψｹｹｹ と (´･ω･\`)ｼｮﾎﾞｰﾝ](https://images.openai.com/static-rsc-4/0RfsWeB9sZK1HR4Dzhej7FO7tOyUixBUP7Z85kJrdKEdgeruePo7chNY-BBf_1s5W1DbgdFCxRvOXDc841moeLtreqNYr_eOYAInGW_u6fJe0vBYu4JUyBXwbDBUWhMPm79jj7c8dYTEG5XVKP-EK1DMN0Hy8xzn8ahu4I6Y2S4?purpose=inline)

[madeinpc.blog.fc2.com](https://madeinpc.blog.fc2.com/blog-entry-303.html?sp&utm_source=chatgpt.com)

早期Vimeo的主要功能包括：

* 用户上传视频。  
* 视频播放。  
* 个人主页。  
* 视频分享。  
* 评论和社群互动。  
* 浏览其他创作者的作品。

与传统电影发行体系相比，这些功能降低了独立创作者展示作品的门槛。

一个独立电影制作者可以建立个人账户，上传短片，并通过自己的个人页面展示作品。

### **2.2 个人主页与创作者身份**

[Hosting & Promoting Video Online](https://images.openai.com/static-rsc-4/z2aUb3B7vTaThpV-YrGQHTMi88XFcZ3nriWuev7a3nslXd57BxbLc1SeGEtQRN9kUQBeOTnk3xyi5S2a9T0UEGESfD0eBpOA6NKaL7bMFG0kyxiwqsO5I9MoXTlLk3MBRJBwTyVeBXb2MQS7KeQwuewVDE-MDFYm9VmPts9IoNk?purpose=inline)

[soundonsound.com](https://www.soundonsound.com/techniques/hosting-promoting-video-online?utm_source=chatgpt.com)

Vimeo的个人主页逐渐成为创作者展示身份的重要空间。

用户可以在主页中组织自己的作品，展示个人信息和创作经历。

这种形式与传统艺术家的作品集（Portfolio）具有一定相似性。

传统艺术家通常通过作品集向画廊、策展人、电影节和潜在合作伙伴展示自己的创作。

Vimeo则使作品集可以直接通过互联网访问。

这对独立电影制作者和视频艺术家尤其重要。

他们不必每次都通过DVD、录像带或大型文件发送作品，而可以直接提供网络播放页面。

### **2.3 视频页面与作品展示**

[\#006 JoinVimeo \| Videos & Movies on Vimeo](https://images.openai.com/static-rsc-4/mvkPajHTUHm1IeuyWyQWa4upDqGuFXwu-rOTOMEcjpgBxdoTLIwGDNGX9JwIZMTfYnTjukT0FcQQUnN35pGDNzKD8E2gj3CGKTBSkpY1JEcHNJ8Av5NhqyLIXkEFQZXyBb9Yge8mMcGBUsQ6Mrk-89PVkZTqIy1b7dtb2TzBNgU?purpose=inline)

[vimeo.com](https://vimeo.com/1223924?utm_source=chatgpt.com)

Vimeo的视频页面不仅承担播放功能，也逐渐成为作品展示空间。

视频标题、简介、作者信息、评论和播放界面共同构成观众接触作品的环境。

这一点对于艺术影像很重要。

一件艺术作品的传播不仅取决于视频文件本身，还取决于作品如何被介绍、分类和理解。

例如，一段实验动画如果被放在创作者作品集中，与被放在普通娱乐视频列表中，观众可能会形成不同的观看预期。

因此，视频平台的界面设计也参与了作品意义的形成。

## **第三节 Vimeo与高清影像革命**

这是Vimeo发展史上最重要的技术节点之一。

### **3.1 2007年：Vimeo推出高清视频播放**

[Vimeo \| global2](https://images.openai.com/static-rsc-4/dShanBfntftA6U_nqPTovk9Bp8zWTnMSKd8PoAHrbKdyUQxJEQJUYVQv17wTBqhAMWTMnc8DY21RxKWDKsgBUQGTBVdEdXPFQA2D3W_IDD8YU2KMsQ4EAx2xHfOjDojjaO5zJ9sPmBo0UWeiwkJNiqxbd-Kj5WBcKEweiWzp-xc?purpose=inline)

[global2.vic.edu.au](https://global2.vic.edu.au/2009/05/22/vimeo/?utm_source=chatgpt.com)

2007年，Vimeo推出高清视频（High Definition，HD）播放功能。

Vimeo官方将其描述为第一个提供高清视频播放的视频分享网站。

vimeo.com+1

这一变化具有特殊意义。

当时许多视频网站仍然以低分辨率视频为主。早期YouTube视频经常采用较小的画面尺寸和较低的码率。

这对于普通娱乐视频来说已经足够，但对于专业影像创作者而言，存在一些问题：

* 摄影画面的细节难以充分展示。  
* 色彩和光影层次受到压缩影响。  
* 复杂的视觉构图容易变得模糊。  
* 动画中的细小线条可能出现失真。  
* 电影摄影的画面质感难以完整呈现。

Vimeo提高视频播放质量之后，吸引了更多重视影像质量的创作者。

### **3.2 为什么高清对独立电影特别重要？**

[Le soleil chante à l'horizon](https://images.openai.com/static-rsc-4/kYxMNlb46O4YWmwgQH0HdUqbFbQVC6Ua0R3KmH3nfsN0snImg9Mh0jFrKPDeYXMRCShZI-OU3lfHm6OeVyc5l4TDIPhuUF44_zuKHNd7uDogDbQmzL8wNVVT6zXAlpQ2II4V2YRCEtBU72ceDYX07qV08j8m_zkE2uVda6T6vJQ?purpose=inline)

[cotecourt.org](https://www.cotecourt.org/film/le-soleil-chante-a-l-horizon?utm_source=chatgpt.com)

电影摄影不仅仅是记录事件。

它还涉及：

* 光线组织。  
* 色彩关系。  
* 镜头运动。  
* 景深。  
* 构图。  
* 画面细节。  
* 运动影像的节奏。

当视频被压缩到很低的分辨率时，这些视觉特征可能受到损害。

例如，一部以暗部细节和微妙色彩变化为主要视觉特征的实验短片，如果只能以低分辨率播放，作品的视觉结构可能难以完整呈现。

高清播放改善了这一问题。

### **3.3 HD与艺术影像的展示**

[OMEGA \- A Stop Motion Animated Short](https://images.openai.com/static-rsc-4/z1_uN33T20jPa7c2MhyehNH18Vjq2Kzj2jQLb6LaWSzJGsVojfCjgCHym6HudGwyjYPz5j-uwytdOE2Jdyr3K_9WEEnr325xRVd_eWKeJj8p74HmCTdTHtfDlJhsSjzb5VmS4v6GTshhxp83R9c2HSgD23F7ppe6h8anQFdCZOE?purpose=inline)

[vimeo.com](https://vimeo.com/92022684?utm_source=chatgpt.com)

高清技术对以下创作类型尤其重要：

**独立电影：** 能够更完整地展示摄影、灯光和构图。

**实验动画：** 可以呈现复杂的运动细节和视觉纹理。

**数字艺术：** 能够更准确地展示计算机生成的图像。

**纪录片：** 能够呈现人物面部、环境和物体细节。

**视觉设计：** 能够展示精细的字体、图形和动态效果。

但是，高清并不意味着作品必然具有更高的艺术价值。

低分辨率、模糊、噪点和压缩失真同样可能是艺术家主动选择的视觉语言。

因此，Vimeo的高清功能更重要的意义在于：它扩大了艺术家可以选择的影像展示条件。

## **第四节 Vimeo Staff Picks：网络视频策展机制的形成**

### **4.1 什么是Staff Picks？**

[Foster the People \- "Coming of Age" — BRTHR](https://images.openai.com/static-rsc-4/EMdTCYR4IEatSXZLeRAcL7txFBVoAJEdUEp25OzNHPR4XAYG43ONfojfwpulxb6BYLcRIeu_77OmBj2EZa4R_RschmgAzA5P9Rnx1C3S19GFFcHeRADnCBB7Qr7O31lryRXpSxQEz29obxP46ApvSnNyarLCsjB1YhhMzDTu4eI?purpose=inline)

[brthr.net](https://brthr.net/foster-the-people-coming-of-age?utm_source=chatgpt.com)

2008年，Vimeo推出了著名的Staff Picks项目。

Staff Picks可以翻译为编辑精选或员工精选。

它由Vimeo的工作人员和策展团队挑选具有创作价值的视频，并向平台观众推荐。

Vimeo官方资料指出，该项目最初由Blake Whitman和dalas verdugo于2008年建立。

vimeo.com+1

这是一项非常重要的创新。

因为在线视频平台虽然能够容纳大量作品，但视频数量增加之后，观众也会面临新的困难：

**如何在海量视频中发现真正值得观看的作品？**

YouTube逐渐发展出以搜索和算法推荐为重要基础的内容发现机制。

Vimeo则通过Staff Picks建立了一种具有策展性质的推荐体系。

### **4.2 Staff Picks与传统艺术策展**

[7 Best Video Platforms for Businesses (That Aren’t YouTube) 2025](https://images.openai.com/static-rsc-4/suWVzImCylWQZERgz1VeXv2zlztWIgpOpyHcvaBYaXTYUnBYqqmWWLzxbZ1fiX0lWx96DiHxIdSH2mutrwsC675xkT0cisAcJ9ASAirV6_ZruzQgTkikQl7nzOcv826EjNIjFX--uuYdbDHF5QcNJHxnWgCS5yMPGYFtq0pno20?purpose=inline)

[switcherstudio.com](https://www.switcherstudio.com/blog/business-video-platforms?utm_source=chatgpt.com)

传统美术馆和电影节通常由策展人选择作品。

策展人会根据作品的艺术形式、主题、创作背景和历史价值组织展览或放映活动。

Staff Picks将部分策展机制引入在线视频平台。

它具有几个特点：

1. 由编辑和策展人员选择作品。  
2. 强调原创性和影像表达。  
3. 向全球观众推荐独立作品。  
4. 为创作者提供额外曝光。  
5. 逐渐形成具有辨识度的作品评价体系。

这意味着在线视频平台不再只是存储和播放作品的地方，也开始承担类似电影节和艺术机构的部分筛选功能。

### **4.3 Staff Picks如何影响创作者？**

[Creator Spotlight: Sofia Camargo and Joseph Longo](https://images.openai.com/static-rsc-4/Mag_9wRB7FrthnHyyJY64wF-JRb9DJ3qvDdGPPE0mu-5NWyX5V9JZWGgFDxh0pVSgSQBDVL3Ga2Vg8Tk8o5Xdx0ry506gejVtk4mzJff2utrMyilCbuFtzbbaXrC5K9449HFlNsrxT-lzYo8q-4EqFWzJT91K52c5HKZSj6SyKk?purpose=inline)

[vimeo.com](https://vimeo.com/1064380406?utm_source=chatgpt.com)

获得Staff Pick意味着作品得到Vimeo编辑团队的认可。

这可能带来：

* 更多观看量。  
* 新的观众群体。  
* 其他创作者的关注。  
* 潜在的商业合作。  
* 电影节和行业人士的发现。  
* 创作者职业发展的机会。

Vimeo后来将Staff Picks发展为具有国际影响力的品牌，并增加了年度精选和首映等形式。

vimeo.com+1

### **4.4 Staff Picks与算法推荐的区别**

这是一个值得深入研究的问题。

| 比较维度 | 人工策展 | 算法推荐 |
| ----- | ----- | ----- |
| 主要决策者 | 编辑、策展人 | 推荐系统 |
| 选择依据 | 艺术判断、创作质量、主题 | 用户行为、内容特征等 |
| 主要目标 | 发现和展示作品 | 提高内容匹配与分发效率 |
| 文化意义 | 建立艺术评价和审美标准 | 组织大规模观看行为 |
| 主要局限 | 选择数量有限、存在主观性 | 可能强化已有观看偏好 |

两种机制并不是完全对立的。

现代平台往往同时使用人工编辑和算法推荐。

但Staff Picks的重要意义在于，它保留了一种不同于纯粹流量竞争的作品发现方式。

**作品可以因为创作质量和视觉实验获得推荐，而不只是因为已经拥有大量观众。**

## **第五节 Vimeo与独立电影文化**

### **5.1 什么是独立电影？**

独立电影（Independent Film）通常指在制作、融资、发行或创作决策方面，相对独立于大型商业电影制片体系的电影。

独立电影不一定意味着完全没有商业资金，也不一定意味着预算很低。

它的核心在于创作和生产体系具有一定独立性。

[Here are some essential tips for working with actors](https://images.openai.com/static-rsc-4/pKcLKQmTkYRn7EQpNqQtvuJCjKYV9Du4V-cvh99d7XC_uJ7vh3mdDZ9vhySl9sMfQ-5br61ez7XbjpRw97ZOdip8GzknZKOHcOAy4kkQjomOonPUgXwTOF7vLZDHTGVUP7RWzycA7FuMxx12NwVzDTG40Ij6HBvsB-YIqq0j2Qw?purpose=inline)

[redsharknews.com](https://www.redsharknews.com/production/item/6450-here-are-some-essential-tips-for-working-with-actors?utm_source=chatgpt.com)

独立电影的题材和形式非常广泛：

* 实验电影。  
* 独立纪录片。  
* 艺术短片。  
* 剧情短片。  
* 动画电影。  
* 社会议题电影。  
* 个人影像。  
* 先锋电影。

Vimeo为这些创作者提供了一个方便的网络展示渠道。

### **5.2 短片成为重要的网络创作形式**

[Norn (Short 2018\) \- IMDb](https://images.openai.com/static-rsc-4/AMl59mWToooRlx66GyPu94S8Zd8DhYZkL5rzLbmnCRrWO0ZSvWojpnKQdv4H_-e0RQcwDds2rzpGG5DSbA_iSr1pLFKtSUukPPf9KYoHktH1dIq52nb3NzYLhSvQRo2nVGCMC5hJR53AZNDu-OwVT2HN7wsr_5nXoDCSc8kNwvQ?purpose=inline)

[imdb.com](https://www.imdb.com/title/tt9037600/?utm_source=chatgpt.com)

与商业电影相比，短片更容易通过互联网传播。

一部几分钟至二十分钟左右的短片，可以在网络上直接展示。

观众不必前往电影院，也不需要购买DVD。

这使短片逐渐成为独立网络影像文化的重要形式。

尤其是一些实验性短片，它们不一定具有传统电影的完整叙事结构，而可能更重视：

* 视觉构成。  
* 声音实验。  
* 时间结构。  
* 空间关系。  
* 非线性叙事。  
* 身体和动作。  
* 数字影像处理。

这些特征使Vimeo上的部分作品与当代艺术中的影像实践产生联系。

### **5.3 独立电影与视频艺术的区别**

[Exhibition: Annie MacDonell and Maïder Fortuné — Dazibao](https://images.openai.com/static-rsc-4/4lPsmDEG_YJZRthlaEk2XrPlzBq0N1qeGs5VOmf4073yFtntvaFk6cdqGLY8xZUjlNttAN6WmvR07L5V8gS-_xFa7swtQACXjd4VR7xysXkurUHlLqFfU241tUKmuT3b3xhIwxxrUHutQc4a5VOGFgMhQ5IJEL2G80w_UmzHjws?purpose=inline)

[en.dazibao.art](https://en.dazibao.art/exhibition-annie-macdonell-and-maider-fortune?utm_source=chatgpt.com)

需要特别区分独立电影与视频艺术。

| 维度 | 独立电影 | 视频艺术 |
| ----- | ----- | ----- |
| 主要历史来源 | 独立电影制作与电影工业 | 当代艺术与实验影像 |
| 主要展示方式 | 电影院、电影节、网络 | 美术馆、画廊、艺术空间、网络 |
| 叙事方式 | 可以采用传统叙事 | 常常探索非传统叙事 |
| 创作重点 | 电影表达与制作自主性 | 影像媒介、观念和展示方式 |
| 作品形式 | 短片、长片、纪录片 | 单频道、多频道、装置、互动影像 |

但两者之间并不存在绝对界限。

有些独立电影具有很强的实验艺术性质，有些视频艺术作品也具有完整的电影叙事结构。

Vimeo的重要作用之一，就是让这些原本分布在不同创作领域中的影像作品能够在同一个网络空间中相互接触。

## **第六节 Vimeo与实验动画文化**

### **6.1 为什么动画创作者喜欢网络视频平台？**

[The 8-minute animation tells more than 40 stories. It is the graduation work of the beautiful Hungarian girl Réka Bucsi \- iMedia](https://images.openai.com/static-rsc-4/m0CLbZZ1xpYwJfA2KBCGxvF4O78eJe2s2MuHsdFEmKRrPRiKEwtJtVkNJh59A0_ONyoKidmevZTIMg9QYjck-no2N9OdgN-R_Zo7V3-MsSfFvhVKfxtDg3se7694wueVWIi-HIDvMucBt7VoR1UNw3e22-cMxz-skxwB9tYYAbA?purpose=inline)

[min.news](https://min.news/en/comics/1f61325931bc644f2de53044e9940995.html?utm_source=chatgpt.com)

2000年代，数字动画制作工具逐渐普及。

独立动画师不再完全依赖大型动画工作室，可以使用个人计算机制作动画短片。

常见的创作工具包括：

* Adobe Flash。  
* Adobe After Effects。  
* Autodesk Maya。  
* Cinema 4D。  
* 3ds Max。  
* Blender。  
* Adobe Premiere。

这些软件分别支持二维动画、三维动画、动态图形、视觉特效和视频剪辑。

Vimeo为这些创作者提供了作品展示环境。

### **6.2 二维实验动画**

[Ishikeri-Kicking Rocks](https://images.openai.com/static-rsc-4/tXavnhvMPSYx1fICYQS29WiCrz3zLsc5RTmE3j0jbA3bhBe0NNUJyfTXcnqY0JKS0prEGdWpWIb6nZz52uNTZEFGKtZoYeiJlXESVETLfzLptGdyGs1WRkBwzAnHGKsaBM15gMECpO8_DbLbkw1fBIWkfVrbtIiKeRth1cM19_Y?purpose=inline)

[vimeo.com](https://vimeo.com/77555506?utm_source=chatgpt.com)

二维实验动画（Experimental 2D Animation）通常不完全遵循商业动画的叙事模式。

艺术家可能使用：

* 手绘图像。  
* 抽象几何形状。  
* 不规则线条。  
* 逐帧动画。  
* 影像拼贴。  
* 文字和图形组合。

这类作品有时不需要完整故事，而是通过图像变化、运动和声音建立视觉体验。

网络视频平台让这些作品可以直接接触全球观众。

### **6.3 三维动画与数字视觉实验**

[Fractal Cathedral VJ-Pack — Julius Horsthuis](https://images.openai.com/static-rsc-4/ajBv12Qu9lv5sZn5GnXdLr0x2tzr66uBCOeXq4q89FQJEyhMtnb5JbFBLrQIU8OQQtc3m9Lz4gF9oGbc4nMta5rYtGOJFrZ6pxpDEocP9qQdV91ztnZTpUEfDrx08uwLKzgwjnozAcW8n9CcIky8-bjBAODiCYiqPxEwwhZBTkI?purpose=inline)

[julius-horsthuis.com](https://www.julius-horsthuis.com/vj-loops/fractal-cathedral-vj-pack?utm_source=chatgpt.com)

三维动画也是Vimeo创作者文化的重要组成部分。

一些创作者利用计算机生成图像（CGI）探索：

* 虚拟建筑。  
* 抽象空间。  
* 物体变形。  
* 机械运动。  
* 非现实景观。  
* 数字生命形态。

这些作品往往具有强烈的视觉设计特征。

它们介于动画、设计、实验电影和数字艺术之间。

### **6.4 动态图形（Motion Graphics）**

[“Go, go, go”: how DIA messed with design theory, only to improve it](https://images.openai.com/static-rsc-4/g6NyHejGnu_t7C5hr9gY-jNgkJpNV8NiFMDlaJeHdwzNmjjyF-g3uFUEkYUC7-rcdb7U-gNZxiSt0jqjSlGvM5OYLF9X6cHG1zirBm8Ufbsc984Rl84YmM4CCp-ncXq6yfh9HNMoFFxdqShgQhMg-9aZymYc6mEXiS0Z6TnKVz4?purpose=inline)

[itsnicethat.com](https://www.itsnicethat.com/features/dia-mitch-paone-meg-donohoe-graphic-design-animation-typography-180918?utm_source=chatgpt.com)

动态图形（Motion Graphics）是将图形设计与时间、运动结合起来的一种创作形式。

它通常包括：

* 动态文字。  
* 几何图形。  
* 标志动画。  
* 抽象图案。  
* 三维图形。  
* 声音同步。

动态图形经常应用于广告、电影片头、音乐视频和艺术短片。

Vimeo上的动态图形作品帮助建立了一个跨越设计产业和艺术创作的国际网络。

## **第七节 Vimeo与视觉设计文化**

### **7.1 从视频艺术扩展到视觉设计**

[Philip von Borries \&ndash; Reel 2023 \| Videos & Movies on Vimeo](https://images.openai.com/static-rsc-4/wfSCd2BkH8zgDSTxQglMeAj6hC_S_b-a741a0-H9U48cn-KZ0DZpMV6uRawF-XLM2zP_komT5mpA870HtqGFcN5jLnOrX1ZPb_5dsDzLFg9rc4fSs8YEKIQdhh7_7gdY8g_xeWMTH8nSh9pdp6gf0anm59fvkxz4R1DeLyIYEOE?purpose=inline)

[vimeo.com](https://vimeo.com/733236562?utm_source=chatgpt.com)

Vimeo逐渐吸引了大量视觉设计师。

他们上传的不一定是传统意义上的电影，而可能是：

* 品牌动画。  
* 广告短片。  
* 电影片头。  
* 动态海报。  
* 产品动画。  
* 建筑可视化。  
* 视觉实验。  
* 设计工作室作品集。

这使Vimeo成为设计产业与网络影像文化之间的重要联系渠道。

### **7.2 设计工作室的作品展示**

[SHOWREEL 2024 \| Motion Design \- Ryan Turmel \| Videos & Movies on Vimeo](https://images.openai.com/static-rsc-4/NocbmdRCYGfKizw2BqPQPA0m2m8InWOgWiJPtq5G1yExhK3zBtktDi2ZGsmD3RwbyHRa4sFd3ASKd1Ueh7184KTRC1oPGGhdXuDRbCy0qcgkn17gzqRQd8u7fvp7-mCeIeg-0pIxbAIqqU1j9JrbxIDUX6C2Ir34H0zNUmmU7eo?purpose=inline)

[vimeo.com](https://vimeo.com/1015178406?utm_source=chatgpt.com)

对于设计工作室而言，视频可以同时展示多个方面：

第一，视觉设计能力。

第二，动画制作能力。

第三，品牌表达能力。

第四，音乐与声音设计能力。

第五，复杂影像制作能力。

因此，Vimeo逐渐成为一些视觉设计工作室展示Showreel（作品集短片）的重要渠道。

Showreel通常将一个创作者或工作室的代表性作品剪辑在一起，以便潜在客户和合作伙伴快速了解其创作水平。

### **7.3 视频作品集与艺术家职业发展**

[Introducing the new Profile page](https://images.openai.com/static-rsc-4/Pr8_1axVMkYXDpDw2IDOOsaQCDavBmmTtDnDstgnZR2fp0689Za7zWGtHXp5j8k7fUP085xtd2lx4DKKwSmygLRd8C9ByL2HIVaREMn1Snaz6a5v1A_CF1cFrr7NCPR0HLe9uZ4PYhERKXdWVgcPfOBKtE1XVVOKVWrhG-V7ThY?purpose=inline)

[vimeo.com](https://vimeo.com/blog/post/introducing-the-new-profile-page?utm_source=chatgpt.com)

传统艺术家需要通过展览、出版物和专业人脉展示作品。

Vimeo使视频创作者能够建立一个持续更新的数字作品集。

这改变了独立影像创作者的职业发展方式。

例如：

一位独立动画师可以通过Vimeo展示自己的动画作品；一位纪录片导演可以展示预告片和短片；一位视觉设计师可以展示商业项目和动态图形。

潜在合作伙伴可以直接观看作品，而不必首先联系创作者索取实体材料。

这使网络平台成为一种新的职业基础设施。

## **第八节 Vimeo与纪录片、社会影像**

### **8.1 独立纪录片的网络传播**

[Documentary on Dr. Ruth delves into the sex therapist’s Holocaust past \| The Times of Israel](https://images.openai.com/static-rsc-4/tnhYjYXhd4eSnVpqRcQx5pPuYLO3py4Biv-Ybe4lF133NodLVAn9LhjMYdgakurA4d_kutVuITKXf14bMoed9cIxeP-wow7UqunnI6FQXTZwgp802qKx-3N_GOyaysbGzvOquf1gOSC6oFVqmiq9a2fZi38dDJMnO1OI_b-oIj4?purpose=inline)

[timesofisrael.com](https://www.timesofisrael.com/documentary-on-dr-ruth-delves-into-the-sex-therapists-holocaust-past/?utm_source=chatgpt.com)

纪录片是Vimeo早期创作者生态中的重要内容类型。

独立纪录片制作者可能关注：

* 社会问题。  
* 城市生活。  
* 环境变化。  
* 人物经历。  
* 少数群体。  
* 地方文化。  
* 历史记忆。  
* 日常生活。

传统纪录片发行通常依赖电视台、电影节和专业发行机构。

网络视频平台提供了另一条传播渠道。

### **8.2 公民影像与个人记录**

[A man records a protest against Egyptian](https://images.openai.com/static-rsc-4/noKX0qti6VY0ayQ0YbEGPEsbkYV-5utI00qFi1UnGF04bSI2nKfTYmfwEKsFm0otQkfutF1SRoLBZujLAnXLWXAkJ0KDcx9ptgB_qDTaW0zs2v6xZXLHhFJGNGI4fpDVzHExhcXoftNM1kKQ916Fqq2eLoWXxRBtLX614gGyCHF6rZtpgoCNrNV6OFLWn0GW?purpose=inline)

网络视频平台还推动了公民影像（Citizen Video）的发展。

普通人可以记录身边发生的事件，并通过互联网向其他人传播。

这种影像生产方式在社会事件、环境问题和公共议题中具有重要意义。

但需要区分：

* 公民新闻：强调公共事件的信息记录和传播。  
* 纪录片：通过影像组织现实材料。  
* 视频艺术：通过艺术创作探索影像形式和观念。

它们之间可以重叠，但不能直接等同。

### **8.3 网络纪录片与艺术表达**

[An Evening Celebrating Stuart Hall, featuring John Akomfrah, with Cameron Bailey, Tina Campt, Kobena Mercer, and David Scott \| MoMA](https://images.openai.com/static-rsc-4/S3qsYYLXy14PQAeI_RzRw7CMm-2e1VpgVPpPvHaS7htmtoPvriMKSksky0cdijrjGQ9yo3T8edJfrKlolVNHUbp7c3osL0DDGwh7TDP9lWCdsbZTkYVDIlpqjBpmqvbof5bzEfJhvOArdPz-Ay4CXIwWh_KC-xvF6h-VXxdCIVg?purpose=inline)

[moma.org](https://www.moma.org/calendar/events/2870?utm_source=chatgpt.com)

一些纪录片创作者开始利用网络视频探索不同的表达方式。

例如：

* 将历史档案与现实影像结合。  
* 将不同地点的影像并置。  
* 使用个人录像讲述社会历史。  
* 将采访、表演和动画组合。  
* 使用非线性剪辑表达记忆。

这些实践使纪录片、实验电影和视频艺术之间的边界变得更加开放。

## **第九节 Vimeo社群与独立创作者之间的交流**

### **9.1 从上传平台到创作者社区**

[Vimeo \- 支援 HD 影片的高畫質影音網站，YouTube 外的另一選擇！ – 免費資源網](https://images.openai.com/static-rsc-4/LDXgAnhT-y-WxfrR1tzs243quVHU52WNP3qWcv9KoKBmlOqb5c9B77veYUZ5Sxx_W_jSlL4k_45530Maw-i9ke6obo10u8T9wX-zJP_xzIaCXhIPKHpBFk2EEwUO32iGwU6nvpc9qej6xAGNLxokbEZBOUrJVJf_tcUCHv_OR_I?purpose=inline)

[free.com.tw](https://free.com.tw/free-video-hosting-vimeo/?utm_source=chatgpt.com)

Vimeo的重要价值不仅在于视频托管。

它还帮助创作者形成交流网络。

创作者可以通过平台：

* 发现其他艺术家的作品。  
* 评论和评价视频。  
* 分享创作经验。  
* 交流制作技术。  
* 寻找合作伙伴。  
* 展示个人项目。  
* 参与创作者社群。

这使独立影像创作不再完全依赖地域性的艺术圈和电影圈。

一个生活在纽约的动画师，可以通过互联网与伦敦、东京、柏林或其他城市的创作者交流。

### **9.2 网络社群与审美传播**

[A small garden by the window – \>b's weblog](https://images.openai.com/static-rsc-4/2fGZthTkx0eC4_5vqA0HldnBqAdAUQHnJDh4ocQxglYCVNAhZ9mAZUZPpPEH6Avh7u6Ad8b06gU9prtwN7_vGzCUHg0W_meWIps6NU6_hxYxX6Vj1XH6QM4qPhC-ksOgU0t0CPnYXc2z7Rz1opolYtkLzbdUH4skk8HjFX7GrVw?purpose=inline)

[blog.fdik.org](https://blog.fdik.org/2024-05/s1715634750?utm_source=chatgpt.com)

当大量创作者集中在一个平台上时，某些视觉风格和制作方式可能逐渐形成共同的审美倾向。

例如：

* 极简主义动态图形。  
* 高度风格化的短片摄影。  
* 实验性声音设计。  
* 抽象三维动画。  
* 电影化的色彩处理。  
* 视觉特效与实拍影像结合。

这些风格并不是Vimeo独有的，但平台的创作者社群和作品推荐机制能够加速它们的传播。

因此，Vimeo不仅是影像作品的展示空间，也成为视觉风格交流和传播的网络环境。

## **第十节 Vimeo与版权：原创作品和平台治理**

### **10.1 为什么Vimeo重视原创内容？**

早期Vimeo与部分大型视频分享平台存在一个重要区别：它更加重视上传者与作品创作之间的关系。

2013年美国纽约南区联邦地区法院审理的 *Capitol Records, LLC v. Vimeo, LLC* 案件，对Vimeo早期的网站规则和运营方式进行了记录。

法院文件指出，Vimeo在早期要求上传者必须是视频的创作者，或者至少参与了视频的创作。

loeb.com+1

[Vimeo \- 支援 HD 影片的高畫質影音網站，YouTube 外的另一選擇！ – 免費資源網](https://images.openai.com/static-rsc-4/ohjg6YpDtFnRs8DljHSAB0F4-ZhTnzyFwuMAxAZyH_T6gBZai799B9Mghh6DiC3YQIv81y5p0JbA5rVXW5uAyL5tEWyxybZUaeFTiCitAKDiNNLsnoCv3d8419dIKPVpy1_H41aytzyv7riD812uKfSNY0GatU5Lj3CWPdVW9vg?purpose=inline)

[free.com.tw](https://free.com.tw/free-video-hosting-vimeo/?utm_source=chatgpt.com)

这一原则与Vimeo重视原创创作的文化形象相吻合。

但这并不意味着Vimeo上的所有视频都不存在版权问题。

视频可能包含商业音乐、摄影素材、影视片段和其他第三方内容。

### **10.2 Capitol Records诉Vimeo**

[Quinn Emanuel secured a significant victory for Vimeo, the well-known video-hosting platform, in a pivotal copyright case decided by the U.S. Court of Appeals for the Second Circuit. This legal… \| Quinn Emanuel](https://images.openai.com/static-rsc-4/Npsb2LdZua4-hcRoDrwU5p1wCfD9j0MrAdUVmTOtt0v_QgYmpvp3D-rv6u5AmpH5S0MRFidxzLFM8UKi4kkSjBbDs_n-tVZRRyiWj21In_hIJPN6LoNURFyLwfBWKcsv4Wi9tdmRNemBMLYja2VGmh-KFvolSs0smBMm3yYXGsA?purpose=inline)

[linkedin.com](https://www.linkedin.com/posts/quinn-emanuel_quinn-emanuel-secured-a-significant-victory-activity-7291108238190673920-v-Eu?utm_source=chatgpt.com)

*Capitol Records, LLC v. Vimeo, LLC* 是美国数字版权史中一个值得研究的案件。

Capitol Records等音乐版权持有人主张，Vimeo平台上的一些视频未经授权使用了受版权保护的音乐。

案件涉及网络平台是否可以依据DMCA第512条获得责任限制，以及平台工作人员对于侵权内容的知情程度等问题。

2013年，纽约南区联邦地区法院作出重要裁定，讨论了平台工作人员观看视频、识别音乐以及平台责任之间的法律关系。

这个案件说明：

即使一个平台强调原创视频，也无法完全避免数字影像中的版权问题。

### **10.3 版权与实验影像的矛盾**

[“Making Cinema Out of Cinema”: G.Baruchello and A.Grifi’s La… – SOCKS](https://images.openai.com/static-rsc-4/0Oj-ys-cGbsEolvaSV3ploDdqUG2tqZqCtVDR3fR3TobciOS0r2gF2j5ujvkLvOKZBwQx8efnDrWfisJMW3UIgA5_XcyPW5LlhGGJ_b2OvbABxnLrvg_ji7vMFOz-BLxF6YBoFFunUwxawDZV4IHdvXPNCUH66Huxy9sBm5CfVU?purpose=inline)

[socks-studio.com](https://socks-studio.com/2015/07/08/making-cinema-out-of-cinema-g-baruchello-and-a-grifis-la-verifica-incerta-1964-65/?utm_source=chatgpt.com)

这一问题对于视频艺术尤其重要。

实验影像艺术家可能使用：

* 旧电影片段。  
* 新闻录像。  
* 商业广告。  
* 电视节目。  
* 历史影像。  
* 网络视频。

这些材料经过重新剪辑和组合之后，可以形成新的艺术作品。

但是，平台的版权管理机制可能对这些创作造成限制。

因此，研究网络影像艺术时，不能只研究作品形式，还需要考虑作品使用的素材、版权许可和传播条件。

## **第十一节 Vimeo的发展转型：从独立影像社区到视频技术平台**

### **11.1 Vimeo的早期身份**

[The Evolving Paradigm of Motion Design — Brands In Motion](https://images.openai.com/static-rsc-4/2-ZH8Kzf8gJNjQcA6v82bviWQTXXy6okui6KI4vGqVngPcFFZ4172fRcaf2wf5JaiFTkmkae7r3pPYCIjmI9PmPdpDXtzPff77Guc0aeI02dga5TE-wKvmhYskgKga_RCd6l0vHGsW90ydOmbUL3cUHrvKUAQ-hB-C4uxrXldt4?purpose=inline)

[brandsinmotion.xyz](https://www.brandsinmotion.xyz/resource/reframe?utm_source=chatgpt.com)

Vimeo早期的文化形象主要与创作者社区、原创视频和独立影像展示有关。

但随着在线视频产业发展，视频托管服务逐渐成为一个更广泛的商业市场。

越来越多的企业、教育机构、媒体公司和专业制作机构需要视频服务。

Vimeo也开始发展面向这些客户的产品。

### **11.2 从内容平台转向视频软件服务**

[Navigating Vimeo just got better](https://images.openai.com/static-rsc-4/TuxVz3HQuyDn8MwVqXBqT4U1V4mXn2Vufv_8NcI0XsLdK1cJLh9YAOVAiiG0QuAyXcU8wee-WT0uNbEW7u1dfkvmqXtrLpTWLTdaZ_0I_YScX1obT0mMM4Ty_NhIMMFsd3zDL2Y-vfqNoY6BsKHxGDaXSHJ4KDvup-iS9I1JEvc?purpose=inline)

[vimeo.com](https://vimeo.com/blog/post/vimeo-homepage-update?utm_source=chatgpt.com)

Vimeo后来逐渐加强视频软件服务（Video SaaS）业务。

SaaS是Software as a Service的缩写，即软件即服务。

与传统视频网站不同，视频软件服务更重视为客户提供：

* 视频托管。  
* 视频管理。  
* 私密视频分享。  
* 视频嵌入。  
* 企业内部视频传播。  
* 在线活动。  
* 视频制作和编辑工具。  
* 数据分析。

2017年前后，Vimeo开始更加明确地调整商业方向，从以公开视频观看为核心的服务，转向视频技术和企业服务。

Vimeo在2021年从IAC分拆，成为独立上市公司。

sec.gov+2

### **11.3 这一转型意味着什么？**

这带来了一个值得注意的历史变化。

早期Vimeo的文化身份与独立创作者密切相关。

但后来，Vimeo越来越重视为企业和专业客户提供视频技术。

因此，不能简单地把今天的Vimeo等同于2005年的Vimeo。

两者在商业模式、产品结构和用户群体方面已经发生明显变化。

从艺术史角度来看，这也说明数字艺术平台可能经历一个过程：

**从创作者社群出发，逐渐发展为商业化的数字基础设施。**

## **第十二节 Vimeo与YouTube：两种网络影像文化的比较**

这是本章最重要的比较研究部分。

[21 Years of YouTube Website Design History \- 39 Images \- Version Museum](https://images.openai.com/static-rsc-4/fq9NiRBVW7jA8I2Xi7zsWaJedXUmYepP8n0IUSd3yZuRe65-6NvkJnEsh_QB9CbqShvasmXyl6z8baeztSpBiNcNFTuPJO4SuZhX0Yj6E8_5jtY1mk1SrlK-5KaGzoTBKqWhPgS2t--a5-8ofOnQD74MAKYlvoiA2-qAvl-Fx7M?purpose=inline)

**YouTube**

大众视频分享文化

[Vimeo Online](https://images.openai.com/static-rsc-4/2bcMcQOcb8VB_agjnWtiC99kr4So9JCUs2PewTaXKZJ1i8PwBzwLHp-vm2YD78prCM3mEUvAxGBNF8zZpBnQmfGSsPi5yxLj7IuJZIEvW_EgZdqc6-zMe0Yta6RPPSO9sxAvGfeD7-lOhsKuPoLDSPevQtD2veKEdSkCfiBPBCk?purpose=inline)

**Vimeo**

独立创作者与原创影像文化

### **12.1 平台文化差异**

| 比较维度 | YouTube | Vimeo |
| ----- | ----- | ----- |
| 早期主要定位 | 大众视频分享 | 原创视频分享 |
| 典型创作者 | 普通用户、网络表演者 | 独立电影人、设计师、动画师 |
| 典型作品 | Vlog、恶搞、游戏、音乐 | 短片、动画、实验影像 |
| 重要功能 | 搜索、分享、订阅 | 高清播放、作品展示、策展 |
| 内容发现 | 搜索和推荐 | 社群与人工精选 |
| 文化形象 | 大众互联网文化 | 创作者文化 |
| 商业发展 | 广告与订阅等 | 视频托管与SaaS服务 |

这张表描述的是两家平台在早期发展阶段形成的文化倾向，并不意味着它们今天仍然严格遵循这种分工。

### **12.2 两种平台代表了什么？**

YouTube代表了视频生产的大众化。

它使普通用户能够通过网络建立自己的观众群体。

Vimeo则代表了另一种发展方向：网络逐渐成为专业和独立影像创作者的作品展示空间。

这两种文化并不是互相排斥的。

一个艺术家完全可以同时使用YouTube和Vimeo：

* 在YouTube上扩大作品传播范围。  
* 在Vimeo上展示高质量作品和个人作品集。  
* 在美术馆中展示完整的影像装置。  
* 在电影节上放映作品。

这也说明，数字时代的艺术传播已经不再依赖单一渠道。

## **第十三节 本章的艺术史定位**

Vimeo的发展具有四个重要的艺术史意义。

### **13.1 网络成为独立影像的展示空间**

过去，独立电影和实验影像往往依赖电影节、艺术机构和专业发行渠道。

Vimeo使创作者能够通过互联网直接展示作品。

### **13.2 影像质量成为平台竞争的重要因素**

2007年的高清播放使网络视频能够更好地展示电影摄影、动画和视觉设计。

网络视频逐渐不再只是低分辨率的个人记录，也可以成为专业影像作品的展示媒介。

### **13.3 人工策展进入在线视频平台**

2008年Staff Picks的建立，使视频平台开始承担类似电影节和艺术机构的作品筛选功能。

它建立了一种不同于单纯播放量竞争的作品发现机制。

### **13.4 艺术家开始面对平台化的创作环境**

Vimeo使独立创作者获得新的传播渠道，但也使作品越来越依赖商业平台的技术、规则和运营环境。

这引出一个重要问题：

当艺术家的作品必须通过某个平台才能被观众看到时，平台是否已经成为艺术创作的一部分？

这个问题在后来的平台艺术和后互联网艺术中变得越来越重要。

## **第十四节 本章重要历史节点**

[美国视频技术与内容平台Vimeo全新品牌标识发布，视频平台品牌视觉识别系统升级解析 \- LogoDesign标设网-中国标志Logo设计及资讯网站](https://images.openai.com/static-rsc-4/pM_EdhDEDHYn2xEVBWzdB5CC34ROI9gJcDk4mKWRznjbRki8Q7HhU9aJWDrr_3aOTQJsTr_KL02eP_jFzsyiGVhsv3XiUv3bY-iD6bKr67ltltVkO_NSOXLgSF-nc-XboZudgz_BtFwbyBUV39WSqhNlKMbtSxajtERD-8R_NrM?purpose=inline)

[logodesign.cn](https://www.logodesign.cn/appreciate/2129.html?utm_source=chatgpt.com)

| 时间 | 重要事件 | 历史意义 |
| ----- | ----- | ----- |
| 2004年 | Vimeo项目开始发展 | 独立视频分享平台出现 |
| 2005年 | Vimeo网站推出 | 视频分享服务正式发展 |
| 2007年 | 推出高清视频播放 | 网络影像质量提升 |
| 2008年 | Staff Picks建立 | 人工视频策展形成 |
| 2009年 | Vimeo面临音乐版权诉讼 | 平台版权治理问题凸显 |
| 2010年代 | 创作者社群和专业视频服务发展 | 平台功能逐渐多元化 |
| 2017年前后 | 商业方向转向视频软件服务 | 企业视频服务地位提高 |
| 2021年 | 从IAC分拆并独立上市 | 公司进入新的发展阶段 |

这里的2004年是项目开始发展的时间，2005年则是网站正式推出的时间。不同资料对Vimeo的创立和上线日期采用了不同口径。

BFI+2

## **第十五节 本章核心概念**

| 英文术语 | 中文名称 | 含义 |
| ----- | ----- | ----- |
| Independent Film | 独立电影 | 相对独立于大型商业制片体系的电影创作 |
| Online Portfolio | 网络作品集 | 通过互联网展示个人创作 |
| High Definition | 高清影像 | 具有较高分辨率的数字视频 |
| Staff Picks | 编辑精选 | 平台工作人员策划推荐的作品 |
| Motion Graphics | 动态图形 | 将图形设计与运动结合 |
| Experimental Animation | 实验动画 | 探索非传统动画形式的创作 |
| Creative Community | 创作者社群 | 以创作交流为基础的网络群体 |
| Video Curation | 视频策展 | 对网络视频进行筛选、组织和展示 |
| Video SaaS | 视频软件服务 | 以软件服务形式提供视频工具和基础设施 |
| Found Footage | 拾得影像 | 使用既有影像材料进行再创作 |

## **主要参考资料**

以下资料用于核实Vimeo的历史、技术发展和艺术文化定位。

1\. **Vimeo官方历史介绍**

[About Vimeo：Vimeo的发展历史](https://vimeo.com/about/index?utm_source=chatgpt.com)

2\. **Vimeo Staff Picks历史**

[How to Get a Vimeo Staff Pick](https://vimeo.com/blog/post/how-to-get-a-vimeo-staff-pick?utm_source=chatgpt.com)

3\. **Vimeo Staff Picks十五周年回顾**

[15 Years of Vimeo Staff Picks](https://vimeo.com/blog/post/15-years-vimeo-staff-picks?msockid=1cb2eb6a7d9c63881605fd917c726261&utm_source=chatgpt.com)

4\. **美国纽约南区联邦地区法院：Capitol Records, LLC v. Vimeo, LLC**

[2013年案件判决书](https://www.loeb.com/-/media/files/publications/2013/09/capitol-records-llc-v-vimeo-llc/files/click-here-to-download-a-pdf-of-the-full-decision/fileattachment/capital-v-vimeo.pdf?hash=94EE04A4AE1F2FE26FDECAB010642166&rev=346ae6e4589a469897cf2db87bb033cf&utm_source=chatgpt.com)

5\. **英国电影协会（BFI）：All about online video and the third age of the moving image**

[在线视频与动态影像的第三个时代](https://www.bfi.org.uk/features/all-about-online-video-third-age-moving-image?utm_source=chatgpt.com)

6\. **Vimeo 2022年度股东信**

[Vimeo的商业模式转型与视频软件服务](https://www.sec.gov/Archives/edgar/data/1837686/000183768622000003/q42021ex992-lettertoshareh.htm?utm_source=chatgpt.com)

## **下一章**

