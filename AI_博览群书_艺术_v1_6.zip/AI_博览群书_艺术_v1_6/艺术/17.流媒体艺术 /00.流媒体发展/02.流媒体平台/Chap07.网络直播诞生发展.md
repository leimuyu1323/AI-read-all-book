# **02\. 流媒体视频艺术（Streaming Video Art）**

# **009 网络直播的诞生与早期实时影像艺术**

*The Birth of Internet Live Streaming and Early Real-Time Video Art (1990–2010)*

[The World’s First Livestream: Trojan Room Coffee Pot \| The Internet Says it's True](https://images.openai.com/static-rsc-4/49tYQgWTv__ETzHdREL9nXNOHS5z4ZRce_TJUx72dUlyK1yv3PvCZQb_-7o6qgDqU7Vta1XQPGh0RU2WGAA7H-hrSBfkgvzJLwMvo-8rrzLqwpPI3NGavn16xanoeUZubAicKf8Z5K4dqkkOFe4bBAtegiJ1Nqy4V5cDuWPTa7k?purpose=inline)

[Storiaolivetti \- I centri di ricerca](https://images.openai.com/static-rsc-4/_PgP4SfMxoQ0ILNuizQDLpecD1vsPI3nAknEI2nHmjw7q6_WIIGilT3JeiiUpfIidFZgl4L5ko6NDcs6t-IzGkPlcUhtafdjY54I7mcvELx8mJuLqOwlShLGcefZ--9SbTKlPsRwcxFiiohnB23NRTFdLv1WzniFBYO8H8WgfYw?purpose=inline)

[Paul Sermon \| ZKM](https://images.openai.com/static-rsc-4/1XZYr6jth75KV0HAxmOAKlHac1G_pvptlZdis9K1uUpU5VY_aXvagLYkVWfRXUi3WiLOWCWzURsHmA9RfcaJl0-Had-ERhlPblDjAZZyjAwuSIamne-1xio4Wjb_YzYRNrkE8Zae6VLQLj-gPps6MeyvMMZECIVRJZHA3D9P0VE?purpose=inline)

14

## **导言：从观看已经发生的影像，到观看正在发生的影像**

在前面几章中，我们研究了YouTube、Vimeo和Dailymotion等在线视频平台的形成。这些平台改变了视频的上传、存储、分享和观看方式。

但它们早期的主要传播模式有一个共同特点：

**创作者先制作视频，随后上传，观众再通过互联网观看。**

即使视频能够快速播放，创作行为和观看行为通常仍然发生在不同的时间。

网络直播（Live Streaming）的出现改变了这一关系。

通过网络直播，摄像机拍摄的影像可以在产生的同时传送到远方，观众能够观看正在发生的事件。

这意味着：

* 影像不必等到制作完成之后才能传播。  
* 创作者与观众可以在同一时间参与作品。  
* 不同地理位置的人能够共同观看一个事件。  
* 网络延迟、传输中断和技术故障可能成为作品的一部分。  
* 观众不再只是观看已经完成的影像，也可能参与正在发生的表演。

对于艺术史而言，这种变化非常重要。

传统录像艺术已经探索过实时摄像机、闭路电视、现场表演和多屏幕影像。但互联网使这些实践获得了跨地域传播能力。

因此，早期网络直播艺术并不是突然出现的一种全新艺术，而是录像艺术、网络艺术、表演艺术、通信艺术和互联网技术相互交汇的结果。

本章主要研究1990年代至2010年前后的网络直播历史，重点讨论网络摄像头、实时视频传输、网络表演、远程协作和实时影像艺术。

## **第一节 网络直播出现之前：实时影像艺术的历史基础**

### **1.1 什么是实时影像？**

实时影像（Real-time Moving Image）是指影像的采集、处理或展示在接近实际发生的时间内完成。

它与普通录像存在区别。

例如：

* 摄像机拍摄一场演出，现场显示器立即显示画面。  
* 两个房间通过摄像机相互传送实时影像。  
* 一位艺术家在纽约表演，另一位艺术家在伦敦实时观看。  
* 观众通过网络摄像头参与正在进行的作品。

这些实践都涉及实时影像。

不过，实时影像并不一定需要互联网。

在互联网出现以前，电视直播、闭路电视和录像艺术已经发展出丰富的实时影像实践。

### **1.2 闭路电视（Closed-Circuit Television）**

[Present Continuous Past(s) (Présent passé(S) continu(S)) \- Centre Pompidou](https://images.openai.com/static-rsc-4/Ai2j7wqhgyLad81MHF_LGpR7EkSqYn092k_FLXGLVv7trFwX4WBPCf1ZMoYrJ3U5-4XlVMOJwN1sVXVKdJ6-RsY964R7ifKU7qaoNX9wxORpoAxFkPf5UhZp-KfrRXh75nodSne5baHIFTEiDkF2yCvsZ6I9W5tGe7dz-qcZ_qE?purpose=inline)

[centrepompidou.fr](https://www.centrepompidou.fr/fr/ressources/oeuvre/cEebaM?utm_source=chatgpt.com)

闭路电视（CCTV）是一种通过封闭线路传输影像的系统。

它通常由摄像机、传输线路和显示器组成。

摄像机拍摄的影像可以直接显示在另一台监视器上。

与广播电视不同，闭路电视不一定向公众广播，而是在特定设备和空间之间传输。

艺术家很早就开始利用这种技术。

例如，一位艺术家可以把摄像机对准自己的身体，再把实时画面投射到墙面或显示器上。

观众看到的不再只是艺术家本人，而是艺术家身体经过电子媒介转换之后形成的影像。

这使摄像机、显示器和观众之间形成新的关系。

### **1.3 白南准与实时影像艺术**

[Nam June Paik’s TV Buddhas – His best-known work](https://images.openai.com/static-rsc-4/_y1er1cDYnLBXgrZEfJBAeVT54gNF-LAAgC1SWdtKxbQWiqbnvtet1Sp5alwftE9Ee6ZunXiesuBU7sdH8rjg2NsKHT4iLH3Wu80KCP6_IW9SKkRL3i62rKL6tcI4A4VspDCzwuMPmQDCI8i1GayUsUC3J0GSoKoG1B5Xo_W3lE?purpose=inline)

[publicdelivery.org](https://publicdelivery.org/nam-june-paik-tv-buddha/?utm_source=chatgpt.com)

白南准（Nam June Paik） 是录像艺术史上最重要的先驱之一。

1974年的作品《TV Buddha》（《电视佛》）是研究实时影像艺术的重要案例。

作品将一尊佛像与摄像机、电视监视器组合在一起。

摄像机拍摄佛像，电视屏幕则实时显示佛像的影像。

佛像似乎正在观看自己的电子影像。

这件作品涉及：

* 现实物体与电子影像的关系。  
* 观看与被观看。  
* 身体与技术。  
* 东方哲学与电子媒介。  
* 实时反馈。  
  [Artience](https://images.openai.com/static-rsc-4/IWDdv8LLhD2IVpoP1FAOtThPS9Wu5Glx3j9HVaDHE3t3YR6T77trf4RicIyerDo-3Q9O5O1aBZnsgapqJTQccsZQkU0IiG1GjymLOlQgf76lPXA_kbTj7tCpbodZQXNILO6REK2L18bSh_JkZg4_OhIWHtu3wQyASwnjOWqxUb0?purpose=inline)  
  [etri.re.kr](https://www.etri.re.kr/webzine/202407/sub03.html?utm_source=chatgpt.com)

《TV Buddha》并不是网络直播作品，因为它没有通过互联网进行远程传播。

但是，它为后来研究实时影像艺术提供了重要的艺术史基础。

### **1.4 丹·格雷厄姆与闭路电视装置**

[Present Continuous Past(s) (Présent passé(S) continu(S)) \- Centre Pompidou](https://images.openai.com/static-rsc-4/DFRkUI1YyZCGzGcA3XGi3xPnJyyXdLv9CUiBfp5ztVh0DgmezZQ821iNOjKsJRj1JB2oyn8qFs_O6dQZvcbJgm6dyzkHRGQccYzzhtp7BKIu2WFKEgcmwKfQ7tAsdYv0fncdiiM_Dl-URackFwWyLbNB4cRLS35-HMJzYxpJHz4?purpose=inline)

[centrepompidou.fr](https://www.centrepompidou.fr/fr/ressources/oeuvre/cEebaM?utm_source=chatgpt.com)

丹·格雷厄姆（Dan Graham） 是另一位重要的先驱。

1974年的《Present Continuous Past(s)》将镜面、摄像机、监视器和录像延迟结合起来。

观众进入装置空间后，可以看到自己当前的影像，也能看到稍早之前的自己。

作品通过影像延迟改变了观众对时间的感知。

这件作品的重要性在于：

**影像不仅能够记录时间，也能够通过技术重新组织时间。**

这一思想后来与网络直播中的延迟（Latency）、实时反馈和远程观看形成了重要联系。

需要注意，格雷厄姆的作品使用的是现场视频和延迟影像技术，而不是互联网直播。

## **第二节 1990年代：第一批网络摄像头与实时影像实验**

### **2.1 Trojan Room Coffee Pot：互联网最早的网络摄像头之一**

[First Webcam Ever: Coffee Pot That Changed Internet](https://images.openai.com/static-rsc-4/GRVk_bYNeC-QZa8wjPvear6oFJp-F3mSdifUXxKjKaPxqXH7_d27ZhRnH0FONho9lE8cpa24qsAJW4w4fy6MeS517enLkT1sdNwiOuQVSnqPqSgxZa2BcNTIVxumwVtIciqVyCymKm4O6L5Tc8Y1YSU6U_h2qgqxuOtWfjhK_8g?purpose=inline)

[Oldest Internet of Things Objects in the World](https://images.openai.com/static-rsc-4/VWBt1FkQ5P8v89yJlBGXhDpprvmMZ-TTo7L2SMbj4Go07slgAO3RESRg2qMG9ikpl4gz07-5nDnlczqCjuPsNQ8Dr69JQiGVHRNrdg1NbkIGQ_kN7KdROPE8P8iJFkz_o6lIdmACElV2pBXF1I4ULPFSVrI9JMPFDKjeY5OeHzk?purpose=inline)

[ライブカメラを見るのが好きな人 \| ガールズちゃんねる \- Girls Channel \-](https://images.openai.com/static-rsc-4/REIGSmVBASAbwGYTJ6dXik6gfBYR4y_wH7VUo_Ip3zawvwApC2BvaX4He8sVy-srR8Wtj8EarVNpvYWBQ9dbqjv7tDovHdEnPkE9YFVhw3-RgnjgF4jhq_cP8bcXlo8bqYVhSC3UBMXflHrGWmTlRKT-uxyfHYbexerhp8tUvRY?purpose=inline)

5

1991年，英国剑桥大学计算机实验室（University of Cambridge Computer Laboratory）的研究人员开始尝试使用摄像机监测实验室里的咖啡壶。

这个项目后来成为互联网早期历史上最著名的网络摄像头实验之一。

当时，实验室只有一台公共咖啡机。

研究人员经常需要走到另一个房间，结果发现咖啡已经喝完。

为了避免白跑一趟，他们将摄像机对准咖啡壶，通过计算机程序让其他研究人员能够查看咖啡壶的状态。

这一系统最初称为XCoffee。

1993年11月22日，咖啡壶的影像通过万维网向外部互联网开放。

这使全世界的互联网用户都能够查看实验室中的咖啡壶。

Gonville & Caius+1

### **2.2 这项实验为什么重要？**

从技术上看，最初的咖啡壶摄像头并不是今天意义上的连续高清直播。

它使用的是周期性更新的静态图像。

摄像机采集画面后，计算机将图像传送到网络服务器，浏览器用户可以查看最新图像。

但它具有一个重要特征：

**观众看到的是远方某个真实地点当时的状态，而不是一段已经制作完成的录像。**

这建立了早期网络实时影像的基本结构：

**现实场景**

剑桥大学实验室里的咖啡壶

**摄像机采集**

捕捉现场图像

**计算机与网络服务器**

处理并发布图像

**远程观众**

通过浏览器查看最新画面

这个实验最初并不是艺术项目，却意外地提出了后来网络艺术反复研究的问题：

* 我们是否能够通过互联网观察远方的现实？  
* 一个普通生活场景是否能够成为持续观看的对象？  
* 摄像机是否能够改变私人空间和公共空间之间的界限？  
* 当观众随时可以查看一个地点时，观看本身是否成为一种行为？

  ### **2.3 从咖啡壶到网络观看文化**

  [Oldest Internet of Things Objects in the World](https://images.openai.com/static-rsc-4/VWBt1FkQ5P8v89yJlBGXhDpprvmMZ-TTo7L2SMbj4Go07slgAO3RESRg2qMG9ikpl4gz07-5nDnlczqCjuPsNQ8Dr69JQiGVHRNrdg1NbkIGQ_kN7KdROPE8P8iJFkz_o6lIdmACElV2pBXF1I4ULPFSVrI9JMPFDKjeY5OeHzk?purpose=inline)  
  [blog.bismart.com](https://blog.bismart.com/en/oldest-internet-of-things-objects-in-the-world?utm_source=chatgpt.com)

咖啡壶摄像头逐渐成为互联网早期的文化现象。

原本只是实验室内部使用的小工具，意外获得了来自世界各地的关注。

人们开始主动打开网页，观察咖啡壶是否装满。

这件事看起来十分无聊，却具有一种特殊的吸引力。

因为观众知道，画面中的事情正在真实发生。

这与观看电影有很大不同。

电影中的事件已经发生并经过剪辑；咖啡壶摄像头则将观众连接到一个持续变化的现实场景。

2001年，随着剑桥大学实验室搬迁，这台著名摄像头停止工作。

The Guardian+1

今天，Trojan Room Coffee Pot通常被视为网络摄像头历史和早期网络实时影像文化的重要案例。

### **2.4 CU-SeeMe：从观看图像到远程视频交流**

[CU-SeeMe](https://images.openai.com/static-rsc-4/7NOCYOO4QekwUmWt1-MOPp7WWV7LwGmSIk624LiuJnENXUwBpGFlbg4kGrbDfZiIXxvTgdmx3dfdFKXtdmSjqs1fXvwY8CIIFOJO6ZjLcgX1ASXS-fo2RH3RA8ORJVlMfKVffM2sEtnkTh2ZDGN7_dTg46E7M2pF0hBw2ZLyESY?purpose=inline)

[video-software-house.com](https://www.video-software-house.com/CU-SeeMe.html?utm_source=chatgpt.com)

1992年前后，美国康奈尔大学（Cornell University）的研究人员开始开发CU-SeeMe视频通信软件。

CU-SeeMe是早期互联网视频会议技术的重要代表。

与咖啡壶摄像头不同，它不仅能够让用户查看远方的图像，还允许不同地点的用户通过摄像机进行实时交流。

早期系统的画面质量非常有限。

图像分辨率低，色彩表现有限，传输速度也受到当时网络条件的制约。

但它建立了一种重要的通信方式：

**一个地点的摄像机可以将现场影像传送到另一个地点，而远方的人也能够通过自己的摄像机作出回应。**

[The CEARCH CU-SeeMe Photo Album](https://images.openai.com/static-rsc-4/zuySbPOZqYAFdzBRz5rwZ0R7clDoghwqH0LBQjBG5u_29d_HKOzAFXh6vIMwgv2ZPLTX6E7sDMzInTBT-Somu6OqfaTOJ9uy7wciFVmRNDPKonL6mpjIMtnCuEAzh4hTayNW8sRuP0Kw0NZpz8uAg-BTWDyDTXXWAlJP4AQSMwA?purpose=inline)

[ibiblio.org](https://www.ibiblio.org/cisco/lounge/cusm.html?utm_source=chatgpt.com)

CU-SeeMe后来被用于教育、远程会议、艺术交流和网络表演。

它的出现使互联网视频从单向的信息展示，逐渐走向双向的实时互动。

### **2.5 RealNetworks与互联网流媒体技术**

[RealPlayerの新バージョン「RealPlayer 7」β版登場](https://images.openai.com/static-rsc-4/y33Q1GYi7-tpKbiJ5SoT-ajBwLQ8ovPE-ffSu3TZaHBTkjRwvTPwAWJeGx5jFH1nhAPbWvOvd2-_tdr9140faaYULcWY3IfN5-tdQSQ570AmCH0keN_yhbe1IxF5n4tofu_SGNw4JROVlKSVBJcjcUr2OsaeeN0S3yfqIng5B1w?purpose=inline)

[internet.watch.impress.co.jp](https://internet.watch.impress.co.jp/www/article/1999/1108/real7.htm?utm_source=chatgpt.com)

1995年，RealNetworks的前身Progressive Networks推出了RealAudio技术。

随后，RealVideo于1997年推出。

这些技术使互联网用户能够在文件尚未完全下载时开始播放音视频内容。

这就是流媒体（Streaming Media）的重要技术基础之一。

1995年，RealNetworks曾通过互联网进行西雅图水手队（Seattle Mariners）的棒球比赛音频直播。

RealNetworks+1

需要区分几个概念：

| 技术或概念 | 主要功能 |
| ----- | ----- |
| Webcam | 摄像机采集并提供远程图像 |
| CU-SeeMe | 实时视频通信 |
| RealAudio | 网络音频流媒体 |
| RealVideo | 网络视频流媒体 |
| Webcasting | 通过互联网进行广播式传播 |
| Live Streaming | 实时传输并播放正在产生的媒体内容 |

这些技术共同推动了网络直播的发展，但它们并不完全相同。

尤其要注意：早期网络摄像头有些只周期性更新静态图像，并不属于连续视频直播。

## **第三节 1996年：JenniCam与个人生活直播**

### **3.1 Jennifer Ringley与JenniCam**

[Jennifer Ringley was the first woman to broadcast her life on the internet. Until she disappeared.](https://images.openai.com/static-rsc-4/cO14N9bU8g9tiVmNPUEQuPDPsjHOQW7bkDBAOIcKx5ciTsr6CMwz4jDLtNbgXib8pecA40Ao1eeHPGmfPiD_rKlYCbbU5uxM4nNyS68RMdqnMjnhEU46PgsT-qKUnj60a1shYiQ5WFmKbJx8KbQQUrXhZknuKBFubqWRdNts3aQ?purpose=inline)

[JenniCam is The World’s First Web Celebrity, But You Don’t Remember Her \| by Cláudia \| Medium](https://images.openai.com/static-rsc-4/djhv_kIK8nOqlhLB8CqyjRDcM14b-enjz2I30_arE9LWcyFynEIbJemFVb70emCEKaBh4BNFWIBSorWghzZ3wbItj4kCHrvjSRaBnyF_l01eMpRQur9EThP1Tl2VJuhKXZfFqCbneqB3hA0aGuACagLeIdmETw1CbWb8_4iZ6h8?purpose=inline)

[PPT \- The Future of Reputation PowerPoint Presentation, free download \- ID:4652146](https://images.openai.com/static-rsc-4/Xly82T-b-j-VkELwn7DKwsf2TBSu2Ak1VFDaOOzijQDoJawcs_ST0yMm1i5pCIJaqNygCkFR2kgzWL728Nas9_GP4gyxqeUj0PbrFRFAvk2KEzs8VikFgUU4a84T8tm8lNLoLePCxgUmpTuVfkV0QlBSqXZuxRPtZ1725I3F9VQ?purpose=inline)

1996年4月，19岁的美国大学生Jennifer Ringley开始了一个名为JenniCam的网络摄像头项目。

她在自己的宿舍安装摄像机，将生活中的画面周期性上传到个人网站。

最初，画面以黑白静态照片为主，大约每三分钟更新一次。

观众可以通过互联网观察她的日常生活。

这一项目后来发展成为早期互联网最著名的个人摄像头网站之一。

WIRED+1

### **3.2 JenniCam拍摄什么？**

[Jennifer Ringley was the first woman to broadcast her life on the internet. Until she disappeared.](https://images.openai.com/static-rsc-4/cO14N9bU8g9tiVmNPUEQuPDPsjHOQW7bkDBAOIcKx5ciTsr6CMwz4jDLtNbgXib8pecA40Ao1eeHPGmfPiD_rKlYCbbU5uxM4nNyS68RMdqnMjnhEU46PgsT-qKUnj60a1shYiQ5WFmKbJx8KbQQUrXhZknuKBFubqWRdNts3aQ?purpose=inline)

[mamamia.com.au](https://www.mamamia.com.au/jennicam/?utm_source=chatgpt.com)

JenniCam并不像传统电视节目那样具有明确的剧本。

它主要记录日常生活：

* 在房间里休息。  
* 使用计算机。  
* 阅读。  
* 与朋友交谈。  
* 吃饭。  
* 看电视。  
* 进行其他日常活动。

最重要的是，摄像机长期保持运行。

这使作品的主要内容不再是某个经过专门安排的事件，而是生活本身的持续发生。

### **3.3 JenniCam为什么具有艺术史意义？**

JenniCam是研究网络影像文化时非常重要的案例。

它涉及四个重要概念。

**第一，生活记录（Lifelogging）。**

生活本身成为持续记录的对象。

**第二，自我展示（Self-presentation）。**

个人主动允许远方观众观看自己的生活。

**第三，持续观看（Continuous Surveillance）。**

观众可以反复访问网站，观察同一个人的生活变化。

**第四，网络表演（Networked Performance）。**

即使没有传统意义上的舞台和剧本，摄像机与观众之间仍然形成了某种表演关系。

学者Barry Smith在2005年的论文《Jennicam, or the telematic theatre of a real life》中，将JenniCam放在远程媒介表演的背景下研究，强调了普通生活如何通过网络摄像头形成一种持续展开的表演。

tandfonline.com

### **3.4 真实生活与表演之间的界限**

JenniCam引出了一个非常重要的问题：

当一个人知道自己正在被观看时，他的行为还是完全自然的吗？

即使创作者没有主动表演，摄像机的存在也可能改变行为。

例如：

* 她可能知道某些观众正在观看。  
* 她可能调整摄像机的位置。  
* 她可能决定哪些空间可以被看到。  
* 她可能决定何时关闭摄像机。  
* 观众可能对画面中的日常行为进行解释。

因此，JenniCam并不是一个完全被动的记录装置。

它涉及创作者、摄像机、网络和观众之间复杂的关系。

### **3.5 私人空间如何变成公共空间？**

[Julia Scher \| Esther Schipper](https://images.openai.com/static-rsc-4/BMzDFGH6bASl_ommm6oAedC-9shMrHI41sLN67NcwDritvCg8cv7uEJwoJvKBedBktPeI1lMNJu4Icvn1Y17DNqBaZD0SREYAtt4N-PKn2GNAeqwnYFhP94uKSimb4GYLQRH4rAU0jcGWIXYmOs2fs7Y2pnsuZgihPJ-7QxkDeA?purpose=inline)

[estherschipper.com](https://www.estherschipper.com/artists/51-julia-scher/?utm_source=chatgpt.com)

JenniCam将宿舍和家庭空间转变成了网络公共观看空间。

在传统生活中，卧室通常属于私人领域。

但当摄像机持续记录并向互联网传输影像时，私人空间开始具有公共展示属性。

这一现象后来影响了：

* 网络直播。  
* 真人秀。  
* 个人视频博客。  
* 网络摄像头文化。  
* 社交媒体中的自我展示。  
* 当代数字监控艺术。

JenniCam于2003年关闭，结束了长达约七年的项目。

WIRED+1

它的历史意义不仅在于它是早期网络摄像头的代表，也在于它提前探索了后来网络直播文化中的核心问题：观看、隐私、身份和自我展示。

## **第四节 1990年代网络表演艺术的形成**

前面介绍的咖啡壶摄像头和JenniCam主要关注远程观看。

但艺术家很快发现，互联网不仅能够传输影像，还能够让不同地点的人共同参与一场表演。

这种艺术实践通常被称为远程表演艺术（Telematic Performance）或网络表演（Networked Performance）。

### **4.1 什么是Telematic Art？**

Telematic Art通常译为远程通信艺术或电信艺术。

它是利用通信技术连接不同地点的人、物体和影像的艺术实践。

其历史并不始于互联网。

20世纪70年代，艺术家已经开始利用卫星、电话、电视和电子网络进行跨地域艺术实验。

[Lost in transaction : une histoire d'« Interfaces » \- Pompidou+ \- Centre Pompidou](https://images.openai.com/static-rsc-4/0YyiLYd964u81ITgj_PESHir5DsxgFC2T55A6saZ-R5ExFtXRZ1MhAyiOJTkrQrA2bgh5OsVtBfLMlAl1iLTquA2QkqZenkEfBM3z-U8PATD80NjT0zWMXB15WprvQ7H9FOj4XWlBt02q9pZ-JZ4sPon1PPVy1fvwrLQqe68Cvk?purpose=inline)

[centrepompidou.fr](https://www.centrepompidou.fr/en/pompidou-plus/magazine/article/lost-in-transaction-une-histoire-d-interfaces?utm_source=chatgpt.com)

Telematic Art的重要特点包括：

* 创作者可以分处不同地点。  
* 影像和声音通过通信网络传输。  
* 观众可以参与远程互动。  
* 不同空间可以共同构成一个作品。  
* 通信技术本身可以成为艺术主题。

互联网出现后，这些实践获得了更加方便的数字网络基础设施。

### **4.2 George Coates：跨地域网络表演**

[Interview with Tom Klinkowstein](https://images.openai.com/static-rsc-4/vkUazTXUqiHkydaH2vYK1Vc4bAxfcDNvAmYHm_mP5QhTCaJ3zxTbCjKWZao71N7AxJvFzo08eo3yAzVp9s9XTygOUg5YPCWbn5gKYeVgjqm0YPKSwAb9cSQjr6lvwwx7yxq3ON7awnvoCDMw6dnAVVowL9B6ireuj2ieuNQrV0g?purpose=inline)

[narrabase.net](https://www.narrabase.net/Tom_Klinkowstein.html?utm_source=chatgpt.com)

美国艺术家和剧场创作者George Coates曾探索计算机网络与现场表演之间的关系。

1994年，他参与的《Nowhere Band》利用CU-SeeMe视频通信软件，将不同地点的音乐表演者连接起来。

其中，部分音乐家位于旧金山湾区，而一位演奏保加利亚风笛的音乐家位于澳大利亚。

他们通过网络共同参与表演，现场观众则在旧金山观看。

companions.digitalhumanities.org+1

这件作品的重要性在于：

传统音乐演出通常要求表演者在同一个舞台上。

而网络表演允许表演者分布在不同国家，通过实时通信共同完成演出。

这使地理距离不再是艺术合作的绝对限制。

### **4.3 Cathy Weiss：远程舞蹈与实时影像**

[The Kitchen and its Double: Broadcasting Institutional Experimentation in "Two Moon July" \> Metode](https://images.openai.com/static-rsc-4/43O3XGpRWtaiIU0uykAJTItLW--EAhpJsQJFYu-gvlG4wkx8Lbv1jwDeYbBschi8CvngmgzkcaJ00Za6IdO0W1c0BDiqszFM58Tkm7bO3ygayXoa8GuNu3Qt2d4iZ1uXBsD3rGS1esrzCu0zodcAvmwOOT2LJRs0GE00bklAvrc?purpose=inline)

[metode.rom.no](https://metode.rom.no/articles/essay/the-kitchen-and-its-double-broadcasting-institutional-experimentation-in-two-moon-july?utm_source=chatgpt.com)

1995年，艺术家Cathy Weiss利用CU-SeeMe进行了一场跨地域即兴舞蹈表演。

参与者分布在不同地点：

* 纽约The Kitchen的现场表演空间。  
* 布拉格的一位视频艺术家。  
* 美国圣莫尼卡的一位DJ。

不同地点的参与者通过实时网络连接，共同参与表演。

companions.digitalhumanities.org+1

这类作品改变了传统舞蹈表演的空间结构。

舞者不必全部出现在同一个舞台。

远方的影像可以成为现场表演的一部分。

声音、身体动作和网络传输共同构成作品。

### **4.4 网络延迟为什么能够成为艺术材料？**

[Play On Earth — Station House Opera](https://images.openai.com/static-rsc-4/GcDoETxN_6Uj_F1lSjsOTixHqvDMggscxFzSOUM-AEIhq000zFd54pzugeeCf5Oq6xpbSz_w16VEqkaBZDPTyPNcUB0Tr2dwBr-fZS1MZcwZ7gAgl-6_oT-JGI7AmgUjLKT5TofQ-gM6DQ0__MmLuhmXbMEptxtR17ankeDMReo?purpose=inline)

[stationhouseopera.com](https://stationhouseopera.com/projects/play-on-earth?utm_source=chatgpt.com)

1990年代的互联网传输速度远不如今天。

视频可能出现：

* 延迟。  
* 卡顿。  
* 图像模糊。  
* 声画不同步。  
* 连接中断。  
* 画面冻结。

对于普通视频通信，这些通常被认为是技术缺陷。

但在艺术创作中，它们也可能成为作品的组成部分。

例如：

一位舞者向远方发送动作，另一位舞者根据延迟到达的画面作出反应。

此时，两个人并不是在完全相同的时间行动。

网络延迟改变了动作的节奏，也改变了两个人之间的关系。

因此，艺术家开始关注一个问题：

**当两个身体通过网络连接时，它们是否能够真正共享同一个时间？**

这个问题后来成为网络表演和远程影像艺术的重要研究方向。

## **第五节 Paul Sermon与《Telematic Dreaming》**

### **5.1 艺术家介绍**

[Paul Sermon](https://images.openai.com/static-rsc-4/h06wjfaO1kV4-asoCgXioE9yaar0xmrJk4UL-gB0ULJV4goycrRfIXqS6cXSSlrjRqu30sGRFmNSlWGmgvE-XRJHaUQLwWytducyXdo5Bj1I7mvv47pfXXhprF8LzyXy35mv2AfBl0RJBthvF6k3OJQ0V34Sy1tsxD6HG-XoG7I?purpose=inline)

[paulsermon.org](https://www.paulsermon.org/sermon/?utm_source=chatgpt.com)

Paul Sermon 是研究远程通信艺术的重要艺术家。

他长期研究互动媒体、远程身体和网络空间。

其作品经常将不同地点的参与者连接起来，使他们通过视频技术产生身体接触和空间互动。

### **5.2 《Telematic Dreaming》（1992）**

[Telematic Dreaming, Paul Sermon, 1992 – Seung hyun Kim 遠距離夢05 (英國) \| Рокки хоррор, Рокки](https://images.openai.com/static-rsc-4/XP4v9ekIQVEELi798SBtCJ1yi-zbrMdjCyUUX4W01IdBot_F5pXPBjvBkQ00BN-mkTRgsz_QvL8nnH3a65zoQK2uKzmCGR8ZOtV3f8EcRyXRx6HidCIHzv91FWE6POnaBatnW84OSeB47H9kTNhOpV-FgUC4fnXrRwzOV9HQxTY?purpose=inline)

[Fabrica \| Brighton \| Contemporary Art](https://images.openai.com/static-rsc-4/NrvL1IdPZ1c_QVBp_QGbtF7tADxqwuTBAfacZlIjtgDCzdbEKwgSml8B4iAiI2EZWrsGSkMHQd3TwWKg-i0uUvTMjUYU0wFaylNTy4WEJ2esNRwrAQX0viotIHG--PJNGGVkuCLMGEMqL61onPLcwSbYCfjuYoa3X6VuNlxxP3s?purpose=inline)

[2001 Paul Sermon – Telematic Dreaming \| El Arte en la Edad del Silicio](https://images.openai.com/static-rsc-4/Xfz8PnsJ_xMPs1yq90IakfBrr-AcHigxr5CYO7jMNLZ0uDCIp3vOc3h5rCvBWprmJ0jjBsEFb0_anHSiA-dXxj45noce3y4C0xKO2jvUXvj_d-I-TuwbD2X1_sBuzcJG29waoKqDhUDU6P5obwHfW6OumWYjwMm-M9C5zvlTK8o?purpose=inline)

5

《Telematic Dreaming》创作于1992年，是早期远程通信艺术最具代表性的作品之一。

作品将两个不同地点的床连接起来。

在一个地点，参与者躺在床上。

摄像机拍摄他们的身体，并将实时影像传输到另一个地点。

另一位参与者可以躺在另一张床上，与投射过来的影像进行互动。

通过摄像机、投影设备和通信系统，两个不同地点的参与者仿佛躺在同一张床上。

### **5.3 作品的技术结构**

[Telematic Dreaming, Paul Sermon, 1992 – Seung hyun Kim 遠距離夢05 (英國) \| Рокки хоррор, Рокки](https://images.openai.com/static-rsc-4/XP4v9ekIQVEELi798SBtCJ1yi-zbrMdjCyUUX4W01IdBot_F5pXPBjvBkQ00BN-mkTRgsz_QvL8nnH3a65zoQK2uKzmCGR8ZOtV3f8EcRyXRx6HidCIHzv91FWE6POnaBatnW84OSeB47H9kTNhOpV-FgUC4fnXrRwzOV9HQxTY?purpose=inline)

[pinterest.com](https://www.pinterest.com/pin/telematic-dreaming-paul-sermon-1992-seung-hyun-kim-05--276408495866864341/?utm_source=chatgpt.com)

可以把作品理解为以下过程：

1. 第一地点的摄像机拍摄参与者。  
2. 影像通过通信网络传输。  
3. 第二地点的投影设备显示第一地点的身体影像。  
4. 第二地点的参与者与投影影像互动。  
5. 第二地点的摄像机将新的影像传回第一地点。  
6. 双方通过屏幕和投影继续互动。

于是，两个地点形成一个相互连接的影像空间。

### **5.4 身体与虚拟空间**

这件作品涉及一个非常深刻的艺术问题：

身体是否必须实际处于同一个空间，才能产生共同的身体经验？

在传统表演艺术中，观众和演员通常共享物理空间。

但在《Telematic Dreaming》中，参与者虽然身处不同地点，却能够通过影像建立一种虚拟的共同空间。

[2001 Paul Sermon – Telematic Dreaming \| El Arte en la Edad del Silicio](https://images.openai.com/static-rsc-4/Xfz8PnsJ_xMPs1yq90IakfBrr-AcHigxr5CYO7jMNLZ0uDCIp3vOc3h5rCvBWprmJ0jjBsEFb0_anHSiA-dXxj45noce3y4C0xKO2jvUXvj_d-I-TuwbD2X1_sBuzcJG29waoKqDhUDU6P5obwHfW6OumWYjwMm-M9C5zvlTK8o?purpose=inline)

[arteedadsilicio.com](https://arteedadsilicio.com/especial-2001/2001-paul-sermon-telematic-dreaming/?utm_source=chatgpt.com)

作品讨论了：

* 身体的远程呈现。  
* 虚拟空间中的亲密关系。  
* 真实身体与影像身体。  
* 观看与触摸。  
* 物理空间与电子空间。  
* 网络技术对人际关系的改变。

这件作品非常重要，因为它说明网络艺术并不只是将已经存在的作品放到网上。

艺术家可以直接利用网络通信创造一种以前无法实现的艺术经验。

### **5.5 与现代视频通话的区别**

今天，我们可以通过Zoom、FaceTime和其他软件与远方的人视频交流。

但《Telematic Dreaming》并不是简单的视频通话。

它将远程影像投射到身体所在的物理空间，并让影像参与现场身体互动。

因此，网络通信在这里不只是传递信息的工具，而是雕塑、表演和空间组织的一部分。

它可以被视为后来远程互动艺术的重要历史先驱。

LABoral

## **第六节 网络摄像头艺术（Webcam Art）**

### **6.1 从工具变成艺术媒介**

[Track/Trace \| ZKM](https://images.openai.com/static-rsc-4/9LvM-nOed4NoP14LzhpSszs6kC2fBGE8-OXgpYAur-QwOwaSsJsi8LQhCNCioIaAigv-fcIUvfEO5V9CGvNQ3Ha6hkvV3s7fG9unvmQ7pW4ybznieuC6u49nB6ZV6yTg_LTnCP1mq0fdva2wpEPo7Igan6nqa_7xkp7uIe6rQEc?purpose=inline)

[zkm.de](https://zkm.de/de/werk/tracktrace?utm_source=chatgpt.com)

早期网络摄像头最初主要用于监控和远程观察。

但艺术家逐渐发现，它可以成为一种独立的艺术媒介。

传统摄影作品通常呈现已经拍摄完成的瞬间。

网络摄像头作品则可以持续呈现一个正在变化的现实场景。

这带来了新的创作方式：

* 长时间拍摄一个固定空间。  
* 将公共场所实时影像传送到远方。  
* 让观众决定观看的时间。  
* 让多个地点的摄像头形成影像网络。  
* 将观众的观看行为纳入作品。

  ### **6.2 摄像头与监控文化**

  [Surveillance Technology Is Wielded by the People in ‘Eyewitness’ \| The Tyee](https://images.openai.com/static-rsc-4/n4lWNtAnPPHib6SygCiUfDX1ZHqX_bbPqoUGVW5QViCMOU5MnWpwPKm0fCCUxhiPtERcInQjNrQrygammbb58xsGBfWIYUO6jF-fYrT-L1iUvgeJQ2buVK4vB_MXV6cewFw6hiLXQa9QX7Hu8Rwl3Np0OSwts1N7_tH4JxMYEHw?purpose=inline)  
  [thetyee.ca](https://thetyee.ca/Culture/2022/02/21/Surveillance-Technology-Wielded-People-Eyewitness/?utm_source=chatgpt.com)

网络摄像头艺术与监控艺术之间存在密切联系。

摄像机既可以记录，也可以监视。

当艺术家将摄像头对准公共空间或私人生活时，观众开始意识到：

观看并不总是中性的行为。

摄像机的位置、拍摄对象、观看权限和图像传播范围都会影响作品的意义。

这使网络摄像头艺术逐渐涉及：

* 隐私。  
* 监控。  
* 身份。  
* 公共空间。  
* 身体展示。  
* 观看权力。

  ### **6.3 观众也成为作品的一部分**

  [The exhibit that turns audience into art \| Design Indaba](https://images.openai.com/static-rsc-4/ueZ-Zba4OQoo-svudkffCW1ubn1ckdp19UHy3E_T9Dgs4jSsf9Im-ucBmbp4MnIT3f4zdm24QQS-OXTQxp85nMBEWiLfM7wnh8TbDGYsqX9VFxFzUebL-d7MRTqeA85pqsy-DsWinlI2MlsCn8k-ZTJnNxHZ9n5ltUZpXI4ts-c?purpose=inline)  
  [designindaba.com](https://www.designindaba.com/articles/creative-work/exhibit-turns-audience-art?utm_source=chatgpt.com)

在传统电影中，观众通常不能改变画面中的事件。

而在某些网络摄像头作品中，观众可以：

* 选择摄像机角度。  
* 控制摄像头移动。  
* 决定观看对象。  
* 与远程参与者交流。  
* 改变作品中的实时状态。

于是，观众不再只是影像的接收者，也可能成为影像系统中的参与者。

这使网络摄像头艺术与互动艺术（Interactive Art）产生联系。

## **第七节 网络直播与公共空间：远程观看城市**

### **7.1 城市摄像头与公共影像**

[25 jaar WWW: van krakerig inbellen naar supersnel streamen](https://images.openai.com/static-rsc-4/abHoee3E-nUGwYi1sqHe1AxC0G-xG6IQJcnR59crhL8YrXdmDg3ngbS1WGeJNxihA_DvfeOcE07NQ6rsHQu-UNYaHCf_4OVK6VIjlgpi325k4JlDiG0s3DaJ8bMpqIsvyk4jAczz5qXIhjxSt5FDf7h5io6Nz_i7R-twZcL60rU?purpose=inline)

[nos.nl](https://nos.nl/artikel/2127737-25-jaar-www-van-krakerig-inbellen-naar-supersnel-streamen?utm_source=chatgpt.com)

1990年代后期，越来越多的网络摄像头开始被安装在公共场所。

例如：

* 城市街道。  
* 大学校园。  
* 旅游景点。  
* 广场。  
* 海滩。  
* 港口。  
* 自然保护区。

这些摄像头使人们能够从远方观察某个地点的实时状况。

例如，一位身处纽约的观众可以通过网络摄像头查看伦敦某个街道的景象。

这种观看方式与传统旅游摄影不同。

照片通常记录过去某个时刻，而网络摄像头提供的是一个持续更新的观察窗口。

### **7.2 远程观看与地理空间**

[Times Square \- a webcam in NYC, United States](https://images.openai.com/static-rsc-4/zyJVYPZMNCO1IYaoWJS5U3V-H76XYNrzrWj88bXZp2rgw_7v8_obTbyc0nIFmeypdMN9yEP63H5875XzcQM5iH6kfreFxeCCBug14dAQ2-Z8_DNJwDdNxyRPyZWdMBHMZ4Wk6-p2Az_gW1MdJbpFAkNAhtUUyYcVwszCNiCmdO0?purpose=inline)

[opentopia.com](https://www.opentopia.com/webcam/18174?utm_source=chatgpt.com)

网络直播使地理空间产生了新的媒介关系。

一个人可以不必真正前往某个地点，就能够观察那里正在发生的事情。

这并不意味着远程观看能够完全代替真实的空间体验。

观众无法直接感受当地的气温、声音、气味和身体环境。

但他们获得了一种新的空间认知方式：

**地理上遥远的地点，可以通过实时影像成为日常观看的一部分。**

### **7.3 城市作为持续表演的场所**

[Portal Between New York And Dublin Closed After A Week Due To "Inappropriate Behavior" \| IFLScience](https://images.openai.com/static-rsc-4/QFMC7CEq8_YtSvdRzOwimxDEOvowkMRfQi83hvDWWFJO4an96LAfxmHwwTtdaPSQgdE_7nUtNAenO8QUotFPSfO4zUEjBaSXuJ1Zt8vJ2u7KRGHhoOejwly5NsP9ueWQxxsn4x3usxQNh0egMJ2lA6X5HWd5Um11dl4wg7p4XTk?purpose=inline)

[iflscience.com](https://www.iflscience.com/portal-between-new-york-and-dublin-closed-after-a-week-due-to-inappropriate-behavior-74201?utm_source=chatgpt.com)

艺术家可以把城市看作一个持续变化的影像系统。

行人、车辆、天气、光线和建筑共同形成不断变化的画面。

在这种创作中，艺术家不一定需要安排演员或设计剧本。

城市自身的日常活动就可以成为作品的内容。

这种实践与早期纪录影像、城市摄影和观念艺术存在联系。

它也使艺术家开始重新思考：

如果一个场景始终处于变化之中，那么作品究竟是画面本身，还是观看这个画面的持续过程？

## **第八节 网络直播与表演艺术的融合**

### **8.1 现场表演的网络传播**

[Interview with Tom Klinkowstein](https://images.openai.com/static-rsc-4/tfeGZy1N0hOvADjyAUUEF4rxyqY6w1NBn6o1o-jGXDFyVQOD20X5ZbNQA-0BSbdrxeCFF0rIor2-Duv0r8UDMHeeoayF6eGgbBj_r-mV1pZj1ML1-j4AC7p7RsrpEfeaseQUWfjZd3_oASdDJR4slJWhYTBxG1aNJ_cBujnTWtA?purpose=inline)

[narrabase.net](https://www.narrabase.net/Tom_Klinkowstein.html?utm_source=chatgpt.com)

互联网直播逐渐改变了传统表演艺术的传播条件。

过去，舞蹈、戏剧、音乐和行为艺术通常要求表演者与观众处于同一个物理空间。

网络通信出现以后，表演可以跨越地域。

例如：

* 一位艺术家在纽约表演。  
* 另一位艺术家在伦敦进行回应。  
* 现场观众通过屏幕观看两地的影像。  
* 远程观众通过网络加入讨论或参与互动。

这样一来，作品不再完全依赖单一舞台。

### **8.2 网络表演的四种形式**

[Referente: Telematic dreaming – BosqueMultimedios](https://images.openai.com/static-rsc-4/QfpbZqMwLOJ9-jGJ1PuNhGUTAMjBb3RmsxUi03UnAYwXujFGzQ3kPzI7xhM63UhMXbQxFuOoZzwKZMJ5-QZaDd7gD3BoJ7oPb892j8qSQfcibxk6KPEXH89psSaZoEB62bprkESm4312keZKMJBX2TKAr2kyFfYKobjXN1s1aY8?purpose=inline)

[The Internet of Bodies—alive, connected and collective: the virtual physical future of our bodies and our senses \| AI & SOCIETY \| Springer Nature Link](https://images.openai.com/static-rsc-4/f_J1t5pDkieMbwWBVv6eAfepGD5QQB4uWXlu1dIAlVGw_YShwJHpsRQmdjmQVud1Fm43_lC4DMl17wI6dCSJVaSx2hGZ2ouVA5KHZ_P4zHISa5fxn62l_mQSF4CNoOH9W8BHfMjtH6NSG66_dLW6k1hzY1rLPG7yia-ker3rjfM?purpose=inline)

[Arab Stages \- Dina Mousawi’s RETURN: a Compelling site of representing Women’s Status of Agency Under Occupation \| The Martin E. Segal Theater Center](https://images.openai.com/static-rsc-4/XDa172lVQl3vZe5hk0LiN69J78w8p6re4p7WJepHMFeIdx6IAOzXyKUxTMNxUUjF6tbmwafNKfpdFuEWFv02wY-PpEPkrD_1U9NuC2oqFSSl_4qhBmkGcg634k5pqlp4h05daVr42Y6EKNMqAZ--oc2lEwlQOAI8-fjAZfEtk3w?purpose=inline)

10

**第一种：远程同步表演（Remote Synchronous Performance）**

不同地点的艺术家通过网络同时表演。

**第二种：远程回应表演（Remote Responsive Performance）**

一地的表演者根据另一地传来的影像或声音作出反应。

**第三种：观众参与型表演（Audience-participatory Performance）**

观众通过网络摄像头、麦克风或其他输入设备参与作品。

**第四种：网络空间表演（Online Performance）**

作品直接发生在互联网环境中，不一定需要传统舞台。

这四种形式并不是严格互斥的分类，一件作品可能同时包含多种形式。

### **8.3 远程表演与传统戏剧的区别**

| 维度 | 传统现场表演 | 网络表演 |
| ----- | ----- | ----- |
| 表演空间 | 通常共享物理空间 | 可以分布在多个地点 |
| 观众位置 | 通常在演出现场 | 可以远程观看 |
| 身体关系 | 直接身体共在 | 通过影像建立关系 |
| 时间结构 | 现场进行 | 可能存在传输延迟 |
| 技术角色 | 舞台和灯光等 | 网络、摄像机和显示设备 |
| 互动方式 | 现场交流 | 远程互动和数字反馈 |

网络表演并不是简单地把戏剧演出拍摄下来，再上传到视频网站。

真正的网络表演往往将通信过程本身纳入作品结构。

## **第九节 网络直播的技术局限与艺术可能性**

### **9.1 早期互联网为什么不能传输高质量视频？**

[5 hábitos adolescentes dos anos 2000 que não faz mais sentido hoje • DOL](https://images.openai.com/static-rsc-4/uWlsZzlDFm8tIoSM9Dx87gWmhZ8CHwr0wfV23XH2rdn56ES7VmDy62q70T_ozWYP9g8vkS96Ch7llLaUhF8tZcRbqwUsWELFtwh99gwGLEZkXp80XSsbBNqjNptzvPicq30423KMErt9WmdOY8yr1kcvJc3Kx7JgP7WofpogwJo?purpose=inline)

[dol.com.br](https://dol.com.br/entretenimento/930367/5-habitos-adolescentes-dos-anos-2000-que-nao-faz-mais-sentido-hoje?utm_source=chatgpt.com)

1990年代的互联网基础设施与今天有很大区别。

当时很多用户使用拨号网络（Dial-up Internet）。

典型的56K调制解调器理论传输速率最高约为56 kbps。

相比今天的宽带网络，这种速度非常有限。

因此，早期互联网视频通常存在：

* 分辨率低。  
* 帧率低。  
* 画面模糊。  
* 声音质量有限。  
* 网络延迟明显。  
* 连接容易中断。

  ### **9.2 压缩技术的重要性**

  [How to Make Videos a Smaller File Size: A Coach's Guide \| Coachful](https://images.openai.com/static-rsc-4/hm7RKdIRngkkfMlFEYmkXxCD0XmjtJ_F13b0895Cf6nXqTJepEVNfpWpUGezqKdh4VO84MDcIzmwI7n8z5oLxvR4vSIwUwAk7t0buVRtZ0hUbmDSnlkvFaiQbRCUM8-iSEbdaGiBboEQkAXDxcBGH3ZXrkLgVpev6tmyh-my2VE?purpose=inline)  
  [coachful.co](https://www.coachful.co/blog/how-to-make-videos-a-smaller-file-size?utm_source=chatgpt.com)

为了通过有限带宽传输视频，系统必须对影像进行压缩。

视频压缩通常利用图像中的空间冗余和连续帧之间的时间冗余减少数据量。

例如：

一段固定摄像机拍摄的画面，如果背景基本不变，编码系统就不必在每一帧都完整传输所有图像信息。

通过这种方式，可以降低网络传输所需的带宽。

但是，压缩也可能带来：

* 细节丢失。  
* 图像块状失真。  
* 色彩变化。  
* 运动拖影。

  ### **9.3 网络延迟（Latency）**

  [深圳国际研究生院王智、计算机系朱文武课题组在智能5G测量与优化研究方面取得进展-清华大学](https://images.openai.com/static-rsc-4/sEgVuQtgzUcWnyTnjvXop0nNKH2pbgYJ7gcQdgdZNfMpSguEoyMPgVy8cyTx9c0s9rOkebmfGpJXuTjG9MvAYbFjjgsICM0v3AhLfEh2WSUVk6xsicBt9KjOVPrbGAtGOcGR-xjk_DFxIvEpx1zAJp2pLH76BhzMvhN-JOpal6g?purpose=inline)  
  [tsinghua.edu.cn](https://www.tsinghua.edu.cn/info/1175/95932.htm?utm_source=chatgpt.com)

网络延迟是实时影像传播中的重要问题。

它指影像或声音从发送端到接收端所需要的时间。

例如：

艺术家在纽约拍手，远在伦敦的参与者可能稍后才看到这一动作。

如果两个人要根据对方的动作进行舞蹈或音乐互动，延迟就可能影响表演节奏。

因此，网络延迟不仅是技术问题，也可能成为艺术问题。

### **9.4 故障与中断是否能够成为艺术？**

早期网络表演经常遇到技术故障。

例如：

* 影像突然冻结。  
* 声音消失。  
* 网络连接断开。  
* 图像出现严重失真。  
* 不同地点的表演无法同步。

对于传统电视直播而言，这些通常是需要尽量避免的问题。

但对于实验艺术而言，技术故障可能暴露通信系统的结构。

它让观众意识到，所谓的实时连接并不是没有中介的直接交流，而是依赖复杂技术基础设施建立起来的关系。

由此，网络的不稳定性本身也可以成为作品的主题。

## **第十节 1990—2010年网络直播艺术发展时间线**

[History Of Camera Revolution \| PPTX](https://images.openai.com/static-rsc-4/rMHSh8CyKM24oawB8HCrCde2btG2ulmuFmLafbSb6xOhpG6ttwvsfURdgZmtEEyRCWwPXPzMqVUzT7QLjVkH3ho1IvyDu96HmKzOWZlaE2qsVQpR5iij4HiaNcpbtAPVyl5zTW3wiKlpkkB4jzTZSdOeJGN7E9yhsqTfKa4esMg?purpose=inline)

[slideshare.net](https://www.slideshare.net/slideshow/history-of-camera-revolution/110680671?utm_source=chatgpt.com)

| 年份 | 事件 | 历史意义 |
| ----- | ----- | ----- |
| 1991 | Trojan Room咖啡壶摄像头开始运行 | 早期网络摄像头实验 |
| 1992 | CU-SeeMe开始发展 | 互联网视频通信 |
| 1993 | 咖啡壶图像接入万维网 | 远程网络观看 |
| 1995 | RealAudio推出 | 网络流媒体发展 |
| 1995 | RealNetworks传输棒球比赛音频 | 早期互联网直播 |
| 1996 | JenniCam开始运行 | 个人生活持续影像 |
| 1997 | RealVideo推出 | 网络视频流媒体发展 |
| 1994—1995 | Nowhere Band等远程表演实践 | 多地点网络表演 |
| 1995 | Cathy Weiss远程舞蹈实践 | 网络实时互动艺术 |
| 1992 | Paul Sermon创作Telematic Dreaming | 远程身体与虚拟空间 |
| 2000年代 | Webcam与视频通信逐渐普及 | 网络实时影像大众化 |
| 2005年以后 | YouTube等平台发展 | 点播视频大众化 |
| 2010年前后 | 网络直播和社交视频服务扩张 | 实时视频传播进入新阶段 |

需要注意：网络直播的历史不是从YouTube开始的。早期摄像头、网络视频通信和远程表演在1990年代已经出现。

## **第十一节 本章艺术史定位：从录像艺术到网络实时影像艺术**

这是本章最重要的理论部分。

我们需要将三个历史阶段区分开来。

**第一阶段：录像艺术（Video Art）**

[Media Preservation Initiative \| Whitney Museum of American Art](https://images.openai.com/static-rsc-4/GiH1rFhz459fKQrxHfDC8Xl0_gyPPyHxyok7vHu8wldHkXHtUEsQOiuDn8aTBNgtOIyca729_gHYL07r-AqaVTGSmJ3pLUixyJUsjQmqhnHOaA-NBjVf9JwpUrBc8sB40Sr0XejAUjPoinUtedHKvs3P3ovbhxKPs2cdxISPgss?purpose=inline)

[whitney.org](https://whitney.org/conservation/mpi?utm_source=chatgpt.com)

1960年代以后

电视、录像机、摄像机和电子显示器成为艺术媒介。艺术家探索身体、时间、信号和影像装置。

**第二阶段：网络艺术与远程通信艺术（Net Art and Telematic Art）**

[Fabrica \| Brighton \| Contemporary Art](https://images.openai.com/static-rsc-4/NrvL1IdPZ1c_QVBp_QGbtF7tADxqwuTBAfacZlIjtgDCzdbEKwgSml8B4iAiI2EZWrsGSkMHQd3TwWKg-i0uUvTMjUYU0wFaylNTy4WEJ2esNRwrAQX0viotIHG--PJNGGVkuCLMGEMqL61onPLcwSbYCfjuYoa3X6VuNlxxP3s?purpose=inline)

[fabrica.org.uk](https://fabrica.org.uk/exhibitions/theres-no-simulation-like-home?utm_source=chatgpt.com)

1990年代

互联网和通信网络使不同地点的参与者能够共同创作，作品开始涉及网络空间、远程身体和实时互动。

**第三阶段：大众网络直播文化（Mass Internet Live Streaming）**

[第3回　Ustream.tvでWebカメラやビデオカメラを使って中継してみよう \| gihyo.jp](https://images.openai.com/static-rsc-4/kMrrMENzPSKSKJVmLo0FXgTUo5qz3NJ0Rf4Cs0C0_pEJKdsUSnB0c779LKfsA42bKDSG1sQHDdcmb2Nb82MvqnI4g44PEAYRXSovoIA_Szxb1rX3os-0XevvsXUVoOFjM17pDLrmY_3Zcki5pZBi5SH37xZ0gN5IjDPC_LU7x8k?purpose=inline)

[gihyo.jp](https://gihyo.jp/lifestyle/serial/01/streaming/0003?utm_source=chatgpt.com)

2000年代至今

实时视频技术逐渐进入大众互联网，直播从艺术实验发展为日常传播、娱乐、新闻和社交活动。

这三个阶段存在历史联系，但并不是完全取代关系。

今天的录像艺术仍然存在，网络艺术也仍然存在，而网络直播则成为更加普遍的传播形式。

### **11.1 影像从记录对象变成实时过程**

传统录像作品通常可以作为一个已经完成的视频文件保存。

实时影像作品则可能依赖持续运行的摄像机、网络连接和参与者。

如果设备关闭，作品可能就不再以原来的形式存在。

因此，实时影像艺术有时更接近一种持续发生的过程，而不是一个固定的物体。

### **11.2 观众从旁观者变成参与者**

传统电影中的观众通常不能改变影片内容。

网络表演则可能允许观众参与。

他们可以通过摄像头、麦克风或其他网络设备改变作品的发展。

这使观众与作品之间的关系发生变化。

### **11.3 空间从物理场所变成网络连接**

传统展览依赖特定建筑和空间。

网络表演则可以同时发生在多个地点。

艺术家可以将不同国家的房间、舞台和公共空间连接起来，形成一个分布式作品。

因此，互联网不仅改变了艺术作品的传播方式，也改变了艺术作品可以存在的空间结构。

## **第十二节 本章核心概念**

| 英文术语 | 中文名称 | 主要含义 |
| ----- | ----- | ----- |
| Live Streaming | 网络直播 | 实时传输和观看正在产生的媒体内容 |
| Webcam | 网络摄像头 | 将现场影像提供给网络用户 |
| Real-time Video | 实时视频 | 接近实际发生时间的影像 |
| Telepresence | 远程临场感 | 通过技术产生远程空间的临场体验 |
| Telematic Art | 远程通信艺术 | 利用通信网络进行艺术创作 |
| Networked Performance | 网络表演 | 通过网络连接的表演实践 |
| Closed-Circuit Television | 闭路电视 | 通过封闭系统传输实时影像 |
| Latency | 延迟 | 信息传输所需的时间 |
| Lifelogging | 生活记录 | 持续记录个人生活 |
| Interactive Art | 互动艺术 | 观众参与并影响作品 |
| Surveillance Art | 监控艺术 | 研究监控、观看与权力关系 |
| Video Installation | 影像装置 | 将影像与空间、设备结合的艺术形式 |

## **主要参考资料**

以下资料包括大学研究机构、艺术机构档案、学术论文和技术史资料。

1\. **剑桥大学冈维尔与凯斯学院：The Caian, the coffee pot and the webcam**

[第一台网络摄像头的历史](https://www.cai.cam.ac.uk/news/caian-coffee-pot-and-webcam-award-winning-combination?utm_source=chatgpt.com)

2\. **British Film Institute：The Trojan Room Coffee Pot Movie**

[Trojan Room咖啡壶影像档案](https://replay.bfi.org.uk/video/4554d8a1-c3e1-58c9-9458-b25402f7d7b9?utm_source=chatgpt.com)

3\. **Barry Smith：Jennicam, or the telematic theatre of a real life（2005）**

[JenniCam与远程媒介表演研究](https://www.tandfonline.com/doi/abs/10.1386/padm.1.2.91/1?utm_source=chatgpt.com)

4\. **Art and the Internet：Connected by Camera**

[网络摄像头与早期网络文化研究](https://attachments.are.na/52076113/fe6cabb8871c391b17cfa47783153aba.pdf?1793294323&utm_source=chatgpt.com)

5\. **A Companion to Digital Literary Studies：Telematic Performance**

[1990年代远程表演艺术研究](https://companions.digitalhumanities.org/DLS/?chapter=content%2F9781405148641_chapter_18.html&utm_source=chatgpt.com)

6\. **LABoral艺术中心：Feedback: From Object to Process and System**

[远程通信艺术与Paul Sermon作品研究](https://laboralcentrodearte.org/en/publications/feedback-from-object-to-process-and-system/?utm_source=chatgpt.com)

7\. **RealNetworks：Pioneering Internet Streaming Technology**

[RealNetworks早期流媒体技术历史](https://realnetworks.com/node/671?utm_source=chatgpt.com)

## **下一章**

**010 网络直播艺术与早期互动影像（Live Streaming Art and Early Interactive Moving Images）**

[Fabrica \| Brighton \| Contemporary Art](https://images.openai.com/static-rsc-4/NrvL1IdPZ1c_QVBp_QGbtF7tADxqwuTBAfacZlIjtgDCzdbEKwgSml8B4iAiI2EZWrsGSkMHQd3TwWKg-i0uUvTMjUYU0wFaylNTy4WEJ2esNRwrAQX0viotIHG--PJNGGVkuCLMGEMqL61onPLcwSbYCfjuYoa3X6VuNlxxP3s?purpose=inline)

[Telepresence 2 \| Net Art Anthology](https://images.openai.com/static-rsc-4/-x1cjWSGym9PApHCMeNBes0HFEb2IGFsZ7oFMPD9CZRIDH0WLvSaMbmOl2jMXtmRvRYUK83vCb1-zKAW5CKTZLjihlequJWxoyGjlWU-EmRxI6LwRDP0cRWoV_Oe_1zGwr2yMGr2VnV8eZ5UfTZaRX-d43iFpzhfXXBgREnX7I0?purpose=inline)

[The Tables Turned \| ZKM](https://images.openai.com/static-rsc-4/PCOShHIt_wT_6IpIyNB7b3eH0qlpDXvpMJ6jIo5b7YvxJeSC9IPQotKfuo5vIvQVBXarQFKAH4HR_Bqxq29Oq9LEUK7caGjsTiCQhbS14h9KhvhYqWjX3hkRAkoEHkknYR8hMQGsoa-OSxyMqGrJBIYLRrfHQUFsXY5YYCCD208?purpose=inline)

12

下一章将在本章基础上进一步研究：

1. 实时影像与互动艺术的结合。  
2. 网络观众如何参与艺术作品。  
3. 摄像头控制与远程操纵。  
4. 网络表演中的身体与身份。  
5. 实时影像装置。  
6. 多地点协作艺术。  
7. 网络延迟与互动机制。  
8. 早期网络艺术如何发展为当代互动影像艺术。

我们还会重点研究一个问题：

**当观众能够通过网络改变一件作品正在发生的过程时，作品的作者究竟是谁？艺术家、参与者，还是整个技术系统？**

这将是理解当代网络影像艺术的重要理论问题。

**本章特别需要记住的三个历史节点：**

* **1993年：** Trojan Room咖啡壶摄像头接入万维网，早期网络远程观看成为现实。  
* **1996年：** JenniCam开始运行，个人日常生活成为持续传播的网络影像。  
* **1992—1995年：** Paul Sermon、George Coates和Cathy Weiss等人的实践，推动了网络远程表演艺术的发展。

这三条历史线索分别代表了网络直播的三种重要可能性：**远程观察、个人生活展示和跨地域艺术协作。**

下一章我们将从这里继续，进一步研究实时影像如何从远程传输发展为观众能够直接参与和改变的互动艺术。

