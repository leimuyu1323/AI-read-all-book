# **02\. 流媒体视频艺术（Streaming Video Art）**

# **006 网络视频平台与流媒体生态的形成**

*The Emergence of Online Video Platforms and Streaming Ecosystems*

[Why YouTube is a monopoly. Think about YouTube for a second. They… \| by Justin \| Medium](https://images.openai.com/static-rsc-4/lZcZ2Q5ViymGdognSZ4wS1OmtJFCieqlg6xu4ZgzauhwHHjyFAzKFibSri7NwXcvNQp-2g5q-30TVjIGBTIP9gATsM38qIoSRzERVA138RKr5NSjMVsxp--sC7PdjPmZ9l3L038_JHfD6StQu3_2PHcdiaT3Pu0Szn1x0N_7xiQ?purpose=inline)

[\#006 JoinVimeo \| Videos & Movies on Vimeo](https://images.openai.com/static-rsc-4/mvkPajHTUHm1IeuyWyQWa4upDqGuFXwu-rOTOMEcjpgBxdoTLIwGDNGX9JwIZMTfYnTjukT0FcQQUnN35pGDNzKD8E2gj3CGKTBSkpY1JEcHNJ8Av5NhqyLIXkEFQZXyBb9Yge8mMcGBUsQ6Mrk-89PVkZTqIy1b7dtb2TzBNgU?purpose=inline)

[Dailymotion in 2006 \- Web Design Museum](https://images.openai.com/static-rsc-4/ZkagWvlCidUE-vDbvAaHHZDE407c7Rve9I5zdYGiXJceR_JbXViVNQgcVV6VKXIZ5pbrSB4uOayPu7m6e-oxU3HQR8N-Zu9lUhZo9HuRvkyLTkAlo-GD5KgTD0UPPPnlWp-L4mJqDXHGDaUrOX33vm771zZLvnQJm5kVnfm_4IA?purpose=inline)

6

## **导言：从视频传播技术到视频平台生态**

在上一章中，我们讨论了宽带互联网、视频压缩和流媒体传输技术的发展。

这些技术解决了一个重要问题：如何通过互联网传输和播放视频。

但技术本身并不能自动形成完整的视频文化。

即使一个人拥有高速互联网和数字摄像机，他仍然需要解决几个问题：

1. 视频应该上传到哪里？  
2. 如何让其他人找到自己的作品？  
3. 如何管理和存储大量视频？  
4. 如何让观众发表评论和分享内容？  
5. 如何建立创作者与观众之间的关系？  
6. 如何通过视频获得收入？  
7. 如何管理版权、删除内容和控制传播？

2000年代，YouTube、Vimeo、Dailymotion等视频网站逐渐发展起来，正是为了处理这些问题。

它们不只是视频播放器，而是逐渐形成了包含创作者、观众、广告商、版权机构、服务器和推荐算法的复杂生态系统。

对于流媒体视频艺术而言，这一时期具有重要意义：艺术家不再只需要考虑作品本身，还需要考虑作品所处的平台、传播机制、用户行为和商业环境。

## **第一节 网络视频平台的出现**

### **1.1 早期互联网视频分享的困难**

在YouTube出现之前，互联网用户已经能够上传和传播视频。

但当时的视频分享存在不少技术障碍。

**第一，服务器成本较高。**

视频文件通常比文字和图片大得多，个人网站很难长期承担大量视频文件的存储和传输费用。

**第二，格式兼容问题。**

不同视频文件可能需要不同的播放器和解码组件。

**第三，上传过程复杂。**

用户需要寻找服务器、配置网站、处理文件格式，有时还需要掌握一定的技术知识。

**第四，视频发现困难。**

即使视频已经上传，其他用户也不一定能够找到它。

**第五，传播缺乏统一机制。**

不同网站之间缺少统一的视频搜索、评论和分享系统。

[Internet](https://images.openai.com/static-rsc-4/ZZ2c83EiHEa7XDd54iNxJkVru-yH0siLz8_emRH1r7cg1vcZqoQo8Eo175U7c-YnGs-bwfcTi9DKQ-6js9RV6f_IHGkNCBhxDZJzRmSLCjQSaJhMMEU62KKyx1MEjsm0iR_kWQ-WxmTHkoLCTCk-sYfauxAqWZ72ySD69xKI34Y?purpose=inline)

[lecompagnon.info](https://lecompagnon.info/internet/?utm_source=chatgpt.com)

因此，早期网络视频虽然已经存在，但还没有形成后来那种由大型平台组织的全球视频分享文化。

### **1.2 Web 2.0与用户参与**

2000年代初期，互联网逐渐出现一种重要的发展趋势：Web 2.0。

Web 2.0并不是一个严格的技术标准，而是对互联网应用形态变化的概括。

早期网站通常由网站管理者发布内容，用户主要负责阅读。

Web 2.0环境则更加重视用户参与：

* 用户可以发布内容。  
* 用户可以发表评论。  
* 用户可以建立个人主页。  
* 用户可以参与社群。  
* 用户可以分享和转发信息。  
* 用户可以参与内容的组织和评价。  
  [Web 1.0 vs Web 2.0 Interaction Diagrams](https://images.openai.com/static-rsc-4/tSgRZG74zdMV5uWFOXd81fA_9ObCLWDifmdOGr1Gs6v2-JpW4CbAINwaPZc0M2ANOZab0H5TowjaJujc__0R1L2Ltsy-5P5PK0p9a8LcO0AE-_vUk4QTyLvCRy9zvoJwRtSERcP7Lr8IS2TR3AqAKHOQx0ChoJf-28Fu_1REI1c?purpose=inline)  
  [ar.pinterest.com](https://ar.pinterest.com/pin/340936634275011298/?utm_source=chatgpt.com)

网络视频平台正是在这种文化环境中发展起来的。

视频不再只是网站提供给用户观看的内容，也成为用户自己生产和分享的内容。

### **1.3 视频平台的基本结构**

一个成熟的视频平台通常包括以下组成部分：

| 组成部分 | 主要功能 |
| ----- | ----- |
| 用户账户 | 管理创作者和观众身份 |
| 视频上传系统 | 接收用户的视频文件 |
| 视频编码系统 | 将视频转换成适合播放的格式 |
| 视频存储系统 | 保存原始文件及不同编码版本 |
| 播放器 | 在网页或应用中播放视频 |
| 搜索系统 | 帮助用户寻找内容 |
| 推荐系统 | 向用户推荐视频 |
| 评论系统 | 建立观众互动 |
| 版权系统 | 处理作品授权和侵权问题 |
| 商业系统 | 广告、订阅和创作者收入 |

[Design YouTube \- System Design Interview](https://images.openai.com/static-rsc-4/xs78rKsMVjoBLBo6xFBEqcRrMQqFOBpuate1Tvr5h7rTR_PQsAO9uaAyDsPmMiuWfZaXfJyty-aAf73Biaq28AlgvDMHPxk5AqkOWFudyWQOaESWuFYi5saNrHnafL2RAtDGZsiUPfSN2liuLPpE4Or0p8tuIMpME45sZkbFAMA?purpose=inline)

[blog.algomaster.io](https://blog.algomaster.io/p/design-youtube-system-design-interview?utm_source=chatgpt.com)

因此，视频网站实际上是一种复杂的数字媒体基础设施。

## **第二节 YouTube：全球视频分享文化的形成**

### **2.1 YouTube的创立**

[Why YouTube is a monopoly. Think about YouTube for a second. They… \| by Justin \| Medium](https://images.openai.com/static-rsc-4/lZcZ2Q5ViymGdognSZ4wS1OmtJFCieqlg6xu4ZgzauhwHHjyFAzKFibSri7NwXcvNQp-2g5q-30TVjIGBTIP9gATsM38qIoSRzERVA138RKr5NSjMVsxp--sC7PdjPmZ9l3L038_JHfD6StQu3_2PHcdiaT3Pu0Szn1x0N_7xiQ?purpose=inline)

[medium.com](https://medium.com/%40hujustin/r-i-p-vidme-why-youtube-is-a-monopoly-f733da4756e4?utm_source=chatgpt.com)

YouTube 于2005年2月14日注册成立。

其早期创始团队包括：

* Chad Hurley  
* Steve Chen  
* Jawed Karim

三人都曾在PayPal工作。

YouTube早期的核心理念非常简单：让用户能够方便地上传和分享视频。

2005年4月23日，Jawed Karim上传了著名的《Me at the zoo》。

[The first ever YouTube video was uploaded 17 years ago in April. Watch it here](https://images.openai.com/static-rsc-4/GJDDSsDIpeZrSpYrWOb6WH-QlfrRdmLHCDeFjumIbL4QVtdXxvaWUeZHqsQsl2fdEE1JMCdO4rkqz9UKvVDaGrCUzTpdC07W-Wwvzj7LFaviuPoD6FvbCGkR42dFBqWetHnGRqKSBUtUlxtuwyoL85gMZA4TvjFYWalA1k9XCSE?purpose=inline)

[moneycontrol.com](https://www.moneycontrol.com/news/trends/the-first-ever-youtube-video-was-uploaded-17-years-ago-in-april-watch-it-here-8413061.html?utm_source=chatgpt.com)

这段约19秒的视频记录了他在动物园大象围栏前的讲话。

它并不是一件艺术作品，但标志着普通用户影像开始通过平台进入全球传播环境。

### **2.2 YouTube早期的核心功能**

YouTube最初提供的主要功能包括：

1. 视频上传。  
2. 视频搜索。  
3. 视频播放。  
4. 用户评论。  
5. 视频评分。  
6. 视频分享。  
7. 网页嵌入。

其中，网页嵌入（Video Embedding）尤其重要。

用户不必把视频文件复制到自己的个人网站，只需要将视频网站提供的嵌入代码放入网页，就能让其他网站直接播放视频。

[How to Embed a Video Into Instructables : 3 Steps \- Instructables](https://images.openai.com/static-rsc-4/8KQw-trJXBd8lydK6amt6XhFoWgkXLy1_naz5ZSlTWvthfKzHd4nouGO2HBNwrH31zOZk_lf6xSim9dlbEWmCyHLwiqvIHOwHYY8Bx-fS8dUw0MibA0BnIEs55zy3JTSaHcTHP3izvVIA6aVxoIEvNtjWPKiFD8wTaAv2rKMWhk?purpose=inline)

[instructables.com](https://www.instructables.com/How-to-embed-a-video-into-Instructables/?utm_source=chatgpt.com)

这使YouTube不只是一个独立的网站，而逐渐成为整个互联网的视频基础设施之一。

### **2.3 Google收购YouTube**

2006年10月，Google宣布以16.5亿美元股票收购YouTube。

这次收购具有重要的产业意义。

Google原本以搜索和互联网广告业务为核心，而YouTube则拥有快速增长的视频内容和用户群体。

收购之后，在线视频逐渐进入大型互联网公司的战略体系。

视频网站开始与搜索、广告、数据分析和用户账户系统更加紧密地结合。

### **2.4 YouTube对大众影像文化的影响**

[Think YouTube is just for content creators? This YouTube video now sits in an art museum (yes, really\!) \| Digital Camera World](https://images.openai.com/static-rsc-4/fiGhSjkxz0kFrlXrKiSSfQT684SQ2Y5dfrxo1Lk-FFCNmGAjJVoDSIMxucJ9y-rmyKH0xMk8yjkdsK5EABIcAvzd34uDSUeYmd_4JSiHM2d077sQZT2WuQhlLdJ4uPWdZFkrHxBA3fVpO4NXaxwXmmMq4jYfSLdyGewoBNTxc1I?purpose=inline)

[Classic YouTube Layout (2008) After Effects & PhotoShop Template 8K Ready](https://images.openai.com/static-rsc-4/cwqXslHAq4G5p43pgl7xldGfF5KPccJGNiCyOJWiZNNavXkA4iHpNXsHi8Cm-0L_bzoftcOBhFkNTk87oElj1FmULX5a5xFeUEsfZQDxBjlfX4nX1HIb0uOMaVZBu0D9zCb0OHf5y-SND2b9GT4-5ZYLwfe2dm8bd8aIUiCo__U?purpose=inline)

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s — Paleofuture](https://images.openai.com/static-rsc-4/-Im0UJptTcrurseKJqpHSYQ5TPXQNQ0Py5JSVAF6tDYIUhPQAqKgHaEN9Ue_Al6bGwCgQ2qn3lFQLWrT9b_ZYNA1tJOxKD0Vq4HK7EhcgfdTR_vtOKzhYu90yVOVkH2rkqwXXHaKdd5Z7b-1arnXHufsrPtI2KJZr_zfp7DgGWs?purpose=inline)

9

YouTube使大量此前难以进入公共传播空间的影像获得了观众。

例如：

* 个人生活录像。  
* 家庭视频。  
* 搞笑视频。  
* 独立动画。  
* 音乐表演。  
* 游戏录像。  
* 教学视频。  
* 实验性影像。

它改变了传统媒体中生产者与消费者之间的关系。

普通人不再只是观看电视和电影，也可以成为视频内容的生产者。

但这种开放并不意味着完全平等。平台仍然掌握视频托管、内容审核、搜索排序和推荐机制。

这一矛盾后来成为平台艺术和互联网批判艺术的重要主题。

## **第三节 Vimeo：独立创作者与艺术视频文化**

### **3.1 Vimeo的诞生**

[\#006 JoinVimeo \| Videos & Movies on Vimeo](https://images.openai.com/static-rsc-4/mvkPajHTUHm1IeuyWyQWa4upDqGuFXwu-rOTOMEcjpgBxdoTLIwGDNGX9JwIZMTfYnTjukT0FcQQUnN35pGDNzKD8E2gj3CGKTBSkpY1JEcHNJ8Av5NhqyLIXkEFQZXyBb9Yge8mMcGBUsQ6Mrk-89PVkZTqIy1b7dtb2TzBNgU?purpose=inline)

[vimeo.com](https://vimeo.com/1223924?utm_source=chatgpt.com)

Vimeo 于2004年开始发展，其网站于2005年正式推出。

与YouTube相比，Vimeo逐渐形成了更加重视原创作品、电影制作、动画、摄影和独立创作者的文化形象。

Vimeo早期的定位与互联网创作者社群有密切联系。

它吸引了不少：

* 独立电影制作者。  
* 实验动画艺术家。  
* 摄影师。  
* 视频艺术家。  
* 设计师。  
* 纪录片创作者。  
* 视觉特效制作人员。

这种创作者结构使Vimeo在网络影像艺术发展史中具有特殊地位。

vimeo.com+1

### **3.2 Vimeo与YouTube的文化差异**

两者都属于在线视频平台，但在早期发展过程中形成了不同的文化形象。

| 维度 | YouTube | Vimeo |
| ----- | ----- | ----- |
| 主要文化形象 | 大众视频分享 | 创作者与原创作品 |
| 内容范围 | 极其广泛 | 早期较重视原创视频 |
| 主要观众 | 大众互联网用户 | 电影及视觉创作者社群 |
| 创作类型 | 娱乐、教育、生活、音乐等 | 短片、动画、纪录片、实验影像等 |
| 平台特点 | 大规模内容传播 | 创作者展示与作品托管 |

需要注意，这只是两家平台早期形成的文化倾向，并不是绝对的内容分类。今天的YouTube也有大量专业电影和艺术视频，而Vimeo也已经发展出面向企业、营销和商业制作的服务。

### **3.3 Vimeo与实验影像**

[Method Studios Reimagines 3D Animation for Painterly Motion Poem \| Animation World Network](https://images.openai.com/static-rsc-4/0zpEwuMFpu_Ejp7YFGm8BCoZhAy3kKb54Ahg7uIdrD_ceSxAQEnqD2wNWJ0GLWKJcCGIkab7U-od9iT4YuxahQ20gTy-i8VIPaW7GbbTwKGGqv7aWxPjPkPDmisShAdMnDh_zPgfiwEz5Av5YS9u8im2UxRsCvpMgEhnzeyJrIQ?purpose=inline)

[awn.com](https://www.awn.com/news/method-studios-reimagines-3d-animation-painterly-motion-poem?utm_source=chatgpt.com)

Vimeo对于网络视频艺术的重要意义，在于它为专业和独立创作者提供了一个相对方便的作品展示环境。

例如，一位实验动画艺术家可以将自己的短片上传到Vimeo，让其他艺术家、策展人和观众观看。

一位独立电影制作者可以将作品用于作品集展示。

一位视频艺术家也可以通过Vimeo分享作品片段、创作记录或展览影像。

这种环境使在线视频平台逐渐与传统艺术机构发生联系。

艺术家可以先在网络上建立作品传播渠道，再通过电影节、画廊、艺术机构和策展项目扩大作品影响力。

### **3.4 网络作品集（Online Portfolio）**

Vimeo还体现了互联网在艺术家职业发展中的一种重要作用：网络作品集。

传统艺术家通常需要制作实体作品集、DVD或录像带，向画廊、制片人和策展人展示作品。

在线视频平台使作品能够通过网络直接访问。

[Films \| Erika Urano](https://images.openai.com/static-rsc-4/63X6FOm9FRWkMP5Xx7mHoIqyVZCJq7v-2Yp_WHWz313r7ko8JHiJLimNrkj2qI0gv3Fbmie2gR4sre3APkM_WvS-2yi3-i79HuP_J1RvbkBMh2piUTmdLqBL-FMQfBtx6tX2qWN6HYnP73eFdLeCmOL-0Tyzbe2veh6WYMbJVNY?purpose=inline)

[erikaurano.com](https://erikaurano.com/films/?utm_source=chatgpt.com)

这改变了艺术家的作品展示方式。

作品不再只是某个展览期间的展示对象，也可以长期存在于网络空间，成为艺术家职业身份的一部分。

## **第四节 Dailymotion：欧洲在线视频平台的发展**

### **4.1 Dailymotion的成立**

[Dailymotion : le devenir média d’une plateforme. Analyse d’une trajectoire sémio-économique (2005-2018)](https://images.openai.com/static-rsc-4/3hr3F0n1usA2JZ4XuGZ_8rpj9A0Mw0M5zARISNRktQJZX-nFo658p2A6lZfbqOaXxXJrT81YKkFkWVcFKjM63o_aHubEGBf33PvHCVo5S2XYO5tSTW14O3kG7Xe2C3jhS7bMZjOXF3RASZlPAuZGN4nvRQpQj6cqHJnjwpnwDo0?purpose=inline)

[journals.openedition.org](https://journals.openedition.org/ticetsociete/3540?lang=en&utm_source=chatgpt.com)

Dailymotion 于2005年在法国成立，是YouTube早期最重要的国际竞争者之一。

它同样提供视频上传、观看和分享服务。

Dailymotion的出现说明，在线视频平台并不是美国互联网产业独有的现象。

欧洲也在这一时期发展出自己的网络视频传播生态。

### **4.2 Dailymotion的早期特点**

早期Dailymotion主要围绕用户上传和视频分享建立服务。

平台上的内容包括：

* 个人视频。  
* 新闻影像。  
* 音乐视频。  
* 电影片段。  
* 动画。  
* 体育影像。  
* 独立创作者作品。  
  [Comment télécharger Dailymotion en streaming? \- Vite une solution Doc \!](https://images.openai.com/static-rsc-4/GYGlS1Tfz9KPyh_izHtyriTPVua4sZP-sPYUy0Ti8SqWEcP0u90wXyKIWTt-X5t1o_mUIe0n4lyR0gOsryEnbqR9zvisRKdT1iSetAHjpcy8uabrLLruJEjmE-ZzLpxN1lxrWzNEz7JZZI6_aJhaJTxy4fcR6pJCsSr6qyBTryc?purpose=inline)  
  [vite-une-solution-doc.blogspot.com](https://vite-une-solution-doc.blogspot.com/2013/02/comment-telecharger-dailymotion-en.html?utm_source=chatgpt.com)

它与YouTube一样，降低了个人发布视频的技术门槛。

不过，Dailymotion后来逐渐调整了商业方向，发展出面向媒体机构、出版商和专业内容提供者的视频服务。

Technology for Real Outcomes+1

### **4.3 为什么Dailymotion值得研究？**

从艺术史角度看，Dailymotion的重要性不仅在于它是一个视频网站。

它代表了在线视频生态的多中心发展。

如果只研究YouTube，我们很容易把网络视频史理解为一家美国公司的发展史。

实际上，欧洲、亚洲和其他地区也形成了不同的视频平台、用户文化和传播机制。

不同平台在语言、内容审核、商业模式和用户群体方面存在差异。

因此，研究流媒体视频艺术，需要将平台放在具体的地域文化和互联网产业背景中理解。

## **第五节 视频平台如何形成商业模式**

### **5.1 从免费分享走向商业化**

早期在线视频平台通常强调免费上传和免费观看。

但视频存储和传播需要持续支付成本：

* 服务器租赁。  
* 数据存储。  
* 视频编码。  
* CDN流量。  
* 带宽。  
* 软件维护。  
* 内容审核。

随着用户数量增加，平台必须寻找可持续的收入来源。

逐渐形成了几种主要商业模式。

### **5.2 广告模式（Advertising-supported Video）**

广告模式是在线视频平台最重要的商业模式之一。

平台通过在视频播放前、播放中或播放后展示广告获得收入。

[Discover how the Internet looked in its early years with Ten Years Ago](https://images.openai.com/static-rsc-4/QxPCb7vCbOvh6DAr-LyOJhztQQsGi82fGnB27wY8bQOkRGNnBUhqFg0DvoneEt_mWwKmy_8Cs1CpGR7cDKtLaOrjwVlPezwipLkjKv4DTPODGrp0wHB0xm-CrCsWmsec0O-n6_jqAgViigmucb1EG8DCJwFrZ_xmFCUTbT-NfqQ?purpose=inline)

[blog.en.uptodown.com](https://blog.en.uptodown.com/ten-years-ago-internet-web/?utm_source=chatgpt.com)

广告模式形成了一个经济循环：

1. 创作者上传视频。  
2. 用户观看视频。  
3. 平台获得流量和用户数据。  
4. 广告商购买广告展示机会。  
5. 平台根据商业规则分配部分收入。

这种模式使平台可以向大量用户免费提供视频服务。

但它也产生了一个重要问题：创作者的收入可能越来越依赖观看量和用户注意力。

### **5.3 YouTube Partner Program**

2007年，YouTube推出合作伙伴计划（YouTube Partner Program）。

它使部分原创视频创作者能够通过视频广告获得收入。

[Timeline: History of YouTube \| Timetoast](https://images.openai.com/static-rsc-4/VUh6EwT8NjIvqyJcABLlbN_vuY0sADyag17Xca69HLKti94HO5cmmuPYKN_shaFmkrn-byXa3i8sLsTyE5gV21QENVAy7y0sTWJVn7SyKRPZdBFQ6J-MzxmKTL1q7c4cdsIsonREma1uVxgmqScEXHHqWp4kuIhQXx1UTbP62x4?purpose=inline)

[timetoast.com](https://www.timetoast.com/timelines/history-of-youtube?utm_source=chatgpt.com)

2007年12月，YouTube宣布扩大该计划，允许美国和加拿大符合条件的创作者申请加入。

YouTube Blog+1

这一变化具有重要意义。

此前，个人制作视频主要是兴趣活动、社交表达或独立创作。

随着商业化机制出现，视频创作开始具有新的职业可能性。

一些创作者逐渐从业余视频制作者转变为职业内容生产者。

但也产生了新的矛盾：

* 创作是否越来越受到广告商影响？  
* 创作者是否需要迎合平台推荐机制？  
* 观看量是否成为评价作品的重要标准？  
* 艺术价值能否通过商业流量衡量？

这些问题后来成为平台文化批判的重要内容。

### **5.4 订阅模式（Subscription）**

订阅模式是另一种重要商业形式。

用户定期支付费用，以获得视频观看服务。

[A Brief History of Netflix Personalization \| by Gibson Biddle \| Medium](https://images.openai.com/static-rsc-4/IXZy_QnM8YYlES2MQkBjtPfChhrvBPZMb8FF-3ZmqU8es_9r-L9TZSfnrlGuycdpSJsihaez_3SC0ha6VDQN9hBQbrWrdA19JLTFnfcjtWInxZXZNO0R9hGQ_28ptqfOMEHUscMesGY1BAuo6Z03eA8wa_sd1ha7y2HWDoPOb3c?purpose=inline)

[gibsonbiddle.medium.com](https://gibsonbiddle.medium.com/a-brief-history-of-netflix-personalization-1f2debf010a1?utm_source=chatgpt.com)

Netflix是这种模式的重要代表。

它将传统DVD租赁业务与互联网视频服务结合起来，逐渐建立起以订阅收入为基础的流媒体业务。

与广告模式相比，订阅模式不必完全依靠广告展示获得收入。

但是，它也要求平台不断增加内容、改善播放体验并维持用户订阅。

### **5.5 交易模式（Transactional Video）**

交易模式也称为TVOD（Transactional Video on Demand）。

用户不是订阅整个服务，而是为单部电影、单集节目或特定视频内容付费。

例如：

* 单部电影租赁。  
* 单部电影购买。  
* 单场演出付费观看。  
* 特定课程付费访问。

这种模式使单个视频作品能够作为独立商品进行销售。

它也为独立电影和专业影像内容提供了不同于广告的商业传播方式。

## **第六节 推荐算法与视频观看行为的改变**

### **6.1 从用户搜索到平台推荐**

早期在线视频网站主要依赖用户主动搜索。

用户输入视频标题、关键词或创作者名称，再从搜索结果中选择内容。

随着视频数量迅速增加，仅仅依靠搜索已经难以满足用户需求。

平台逐渐发展出推荐系统（Recommendation System）。

[Pamiętacie starego YouTube'a? Ten stary layout, 5-gwiazdkowa skala ... (@maciorqa) :: Wykop.pl](https://images.openai.com/static-rsc-4/LBmOGrGZl4gD-3bxyllM034Wlfyx146QQwm8u-M4LRllUFmSKRbhPauy6u_Jy7XM9z3HDz0jhKb7OZhyX9y9VIQWPxuX654b3yFPbKztGcidDQEgk9XHDxj873L6h98WwM2-zxyOGpR4rRcy1nYXhirbpfRR_ojy6ZokLy6xYqA?purpose=inline)

[wykop.pl](https://wykop.pl/wpis/49093797/pamietacie-starego-youtubea-ten-stary-layout-5-gwi?utm_source=chatgpt.com)

推荐系统会根据多种信息决定向用户展示哪些视频，例如：

* 用户观看历史。  
* 搜索记录。  
* 视频标题和标签。  
* 用户订阅关系。  
* 视频点击和观看情况。  
* 其他用户的观看行为。

推荐系统的具体机制会随平台和时期变化，不能简单理解为所有平台都使用同一套算法。

### **6.2 推荐算法如何改变艺术传播？**

在传统美术馆中，观众通常通过策展、展览目录、艺术评论和艺术史知识接触作品。

而在在线视频平台中，观众可能通过搜索、相关推荐和首页推荐发现作品。

这意味着作品能否被观看，开始受到平台内容分发机制的影响。

例如：

一位独立视频艺术家上传了一件实验影像作品。

如果作品被推荐系统识别为具有一定观看吸引力，它可能接触到更多观众。

但如果作品的标题、封面和观看行为不符合平台的分发机制，它也可能很难获得曝光。

因此，艺术家开始面临一个新的问题：

**作品应该按照自身的艺术逻辑创作，还是应该考虑平台的传播逻辑？**

### **6.3 观看时间与注意力经济**

[Are Algorithms Choosing What We Pay Attention To? Recommendation Systems and Digital Engagement \| by Yuangu Xu \| Digital Society \| May, 2026 \| Medium](https://images.openai.com/static-rsc-4/gBFYBB6FFxkKlY7CjhSG_9M6OUKaa6lBG4jj2roWM5DmzeW9UcKzlitIZiUj5KRfsNC8xUDaRnNki9I-GSRXjkThkh_vN-zWdb-j3RE2IWZI-HP7uIVeuwBXPCHaRjl8lu1x8Rq7R5iSonL5qjw5g3nZj36myarz5kp4LaEqhkE?purpose=inline)

[medium.com](https://medium.com/digital-society/are-algorithms-choosing-what-we-pay-attention-to-recommendation-systems-and-digital-engagement-979d669888d5?utm_source=chatgpt.com)

注意力经济（Attention Economy）指在信息极其丰富的环境中，人的注意力成为稀缺资源，并具有商业价值。

对于在线视频平台而言，用户观看时间、点击行为和互动行为能够产生商业价值。

因此，平台不仅需要吸引用户进入网站，还希望用户持续观看内容。

这改变了视频的传播逻辑。

传统电视通常按照节目表安排观看时间。

在线视频平台则可以根据用户行为持续推荐新的内容。

从艺术批判的角度看，这使观看本身成为一种受到商业机制组织的行为。

## **第七节 版权制度与视频平台治理**

### **7.1 视频平台为什么需要版权管理？**

在线视频平台允许用户上传内容，但用户上传的视频可能包含其他人的作品。

例如：

* 电影片段。  
* 电视节目。  
* 商业音乐。  
* 体育赛事录像。  
* 动画作品。  
* 其他艺术家的影像作品。

这就产生了版权问题。

[How To Use Copyrighted Music On YouTube \- TunePocket](https://images.openai.com/static-rsc-4/2fhMKMo4bqeShAX4SVmmVOiU6j8KVc-PYfgk8K_K1XWACPByhGsG_W3WYiJrvXXJZF6Yt2vOKkaD_Wd6EjlPMdV35b5D89UiM3AdQO5LMe61ITXpvMqOYdbj0o2K37xZUusXS5TqU5-VzqcxbBzz63z7dplsiDQj2wtsS2QwP1Q?purpose=inline)

[tunepocket.com](https://www.tunepocket.com/use-copyrighted-music-youtube/?utm_source=chatgpt.com)

平台需要建立版权管理机制，以处理未经授权上传、侵权投诉和内容使用许可等问题。

### **7.2 Content ID**

YouTube后来发展出Content ID系统。

该系统可以通过识别上传视频中的音频和视频信息，与版权持有人提交的参考文件进行比对。

如果系统发现匹配内容，版权持有人可以根据相应政策采取措施，例如：

* 追踪视频观看情况。  
* 对视频进行广告变现。  
* 在部分地区限制播放。  
* 要求移除内容。

Content ID的具体应用受到版权政策、地区法律和权利人设置影响。

### **7.3 版权管理与艺术创作的矛盾**

版权管理具有保护创作者权益的重要作用。

但是，在实验性影像艺术中，艺术家也可能使用已有的电影片段、电视画面、广告、新闻录像和网络视频进行再创作。

这涉及挪用艺术（Appropriation Art）、拼贴艺术（Collage）和采样（Sampling）等艺术实践。

[Gretchen Bender: So Much Deathless \- The Brooklyn Rail](https://images.openai.com/static-rsc-4/X4wFDOyY2fFAytKg9Tip0s6QnGBkmbYkHuQQj1Xf1jND8KFcOqkk9NNHwjyMFhy7kFiNNW3H0YyHldBuerpJGYxw9bLuWj4AZcADkO8yT7HA0LwOuLJcrzwRyKPipZWCXSU6vjTaSO2GquL2gW0AkGGD1M-k0CLD5o_25O8JDSY?purpose=inline)

[brooklynrail.org](https://brooklynrail.org/2019/05/artseen/Gretchen-Bender-So-Much-Deathless/?utm_source=chatgpt.com)

由此产生一个复杂问题：

当艺术家使用已有影像进行批判、重新组合或创造新意义时，这种使用是否构成合理的艺术表达？

美国法律中的合理使用（Fair Use）提供了判断版权使用是否合法的一种法律框架，但它并不是对所有二次创作的自动豁免。

因此，网络视频平台的版权制度不仅是技术管理问题，也直接影响艺术家能够使用哪些影像材料。

### **7.4 内容审核与平台权力**

平台除了管理版权，还需要处理内容审核问题。

例如：

* 暴力内容。  
* 色情内容。  
* 仇恨言论。  
* 虚假信息。  
* 侵犯隐私的内容。  
* 违反社区规范的内容。  
  [Shawnee Mission School District meeting removed from YouTube](https://images.openai.com/static-rsc-4/JdZw_aPZRcTm9ubtZdCJEHarNqjGfdcWbTXrkqI859TWOMu_KiexWyq1uvyb8mkf9naKhJQVFf_xa6-t9lBgYfHeTJGpl4jqNzKL5hsc1MlK8P8eGyjzCreZJZTd5l2R6J0Uk2MriCSt8nKd4WNrKoIuC-tML4eAeJzaQisZkQQ?purpose=inline)  
  [kshb.com](https://www.kshb.com/news/local-news/shawnee-mission-school-district-meeting-removed-from-youtube?utm_source=chatgpt.com)

平台的内容审核制度会影响哪些作品能够公开传播。

这对艺术家尤其重要，因为当代艺术可能涉及身体、政治、宗教、暴力和社会争议等主题。

因此，平台不只是被动的传播工具，也具有决定内容可见性和传播范围的权力。

## **第八节 在线视频平台与网络艺术的关系**

### **8.1 视频平台作为新的展示空间**

传统视频艺术主要依赖美术馆、画廊、艺术节和专业影像机构展示。

在线视频平台则提供了新的展示方式。

[John Akomfrah at Sharjah Biennial 15, Sharjah Art Foundation, Sharjah, UAE](https://images.openai.com/static-rsc-4/dtSQDEckBzy-SNHj11J8hmcaFhZyMkeXKiwbhcoj3uPE8alocUzTAjqjhpSG9Bei4KGerycKaxYUpns2oNDLtnQU1pfj0GJgbBInabaJq4OcVleAUKF7HrFnlGh6-lb2_RWaWPYdrXTyUhLiVHylr8KAsr84F1P6YKcQE5kkAMA?purpose=inline)

[lissongallery.com](https://www.lissongallery.com/news/john-akomfrah-debuts-two-new-film-works-at-sharjah-biennial-15?utm_source=chatgpt.com)

艺术家可以通过网络发布作品，使观众不必前往美术馆就能够观看影像。

这种传播方式扩大了作品的潜在观众范围。

但是，网络平台与美术馆的展示方式并不相同。

美术馆能够通过空间布局、屏幕位置、声音环境和观众动线组织观看经验。

在线视频平台则主要通过个人设备、播放器界面和推荐机制组织观看。

因此，网络展示并不是简单地把美术馆中的视频复制到互联网上，而是形成了不同的观看条件。

### **8.2 网络艺术（Net Art）**

网络艺术（Net Art）是20世纪90年代以来逐渐发展的艺术实践，强调互联网及其技术、网络结构和社会关系在艺术创作中的作用。

[Rhizome \> blog \> Speaking in Net Language: My Boyfriend Came Back from the War](https://images.openai.com/static-rsc-4/8z-v58SXbM4f4XJ7oDfH8HE_i8faByH3ARf8WwdQPkBSSIJUuBbXO6AlnweldL3dc6UdAEYVShHQJFYixTkbaam7ySdGwJ2aSvIgPxl32QKpEtmEWn91GGTiBQIKYXoeYf2-YjhEYH5ZSzDhFQ5tN9jJk41ucfwc5_BluxDfdaQ?purpose=inline)

[rhizome.org](https://rhizome.org/editorial/2016/nov/10/my-boyfriend-came-back-from-the-war/?utm_source=chatgpt.com)

它可能包括：

* 网站艺术。  
* 网络互动作品。  
* 浏览器艺术。  
* 网络影像。  
* 在线社群艺术。  
* 数据艺术。  
* 网络表演。

其中，网络视频只是网络艺术的一种形式。

需要注意：网络艺术并不等同于流媒体视频艺术。

一件网站艺术作品可能完全没有视频，而一件通过YouTube传播的普通短片也不一定属于网络艺术。

关键在于互联网是否成为作品的创作媒介、结构或观念内容。

### **8.3 网络表演与远程参与**

网络视频平台的发展，使不同地点的人能够通过视频进行交流和共同创作。

[Telepresence 2 \| Net Art Anthology](https://images.openai.com/static-rsc-4/-x1cjWSGym9PApHCMeNBes0HFEb2IGFsZ7oFMPD9CZRIDH0WLvSaMbmOl2jMXtmRvRYUK83vCb1-zKAW5CKTZLjihlequJWxoyGjlWU-EmRxI6LwRDP0cRWoV_Oe_1zGwr2yMGr2VnV8eZ5UfTZaRX-d43iFpzhfXXBgREnX7I0?purpose=inline)

[anthology.rhizome.org](https://anthology.rhizome.org/telepresence?utm_source=chatgpt.com)

这为网络表演（Network Performance）提供了新的条件。

例如：

* 两位艺术家在不同国家同时进行表演。  
* 观众通过网络摄像头参与作品。  
* 不同地点的影像实时合成为一个作品。  
* 网络延迟成为作品的时间结构。  
* 观众的操作改变实时影像。

在这些作品中，互联网不再只是作品的传播渠道，而是作品本身的组成部分。

### **8.4 平台艺术（Platform Art）**

平台艺术可以理解为以数字平台、平台规则、用户数据和传播机制为研究对象的艺术实践。

[Interaction Design Master of Arts SUPSI. Hands-On Path to Innovation. \| Master of Arts in Interaction Design, SUPSI \- Switzerland](https://images.openai.com/static-rsc-4/oFLNYgpTRP8nXTqzc2mbay8pT4hloJOei9fxacWsZV1-W867uAswShTmprnvFFgMs0H_IRqf5S8cHcVGcGvas1hKGVbUjojybdOZR0wxsXNA0ydjHNVJIfqH5CqQwliFCVyDBy3i0FvztcRG7Cns0GSzI4wIA-m1DdSxMSDnGIU?purpose=inline)

[maind.supsi.ch](https://maind.supsi.ch/master-interaction-design/en?utm_source=chatgpt.com)

艺术家可能会研究：

* 平台如何控制信息传播。  
* 算法如何组织用户观看。  
* 商业机制如何影响创作。  
* 用户数据如何被收集。  
* 内容审核如何影响艺术表达。  
* 视频平台如何塑造公共文化。

这使平台从一个中性的工具，转变为艺术家可以直接研究和批判的对象。

## **第九节 主要网络视频平台的历史比较**

| 平台 | 创立或起步时间 | 早期文化特点 | 历史意义 |
| ----- | ----- | ----- | ----- |
| YouTube | 2005 | 大众视频分享 | 普通用户影像传播 |
| Vimeo | 2004年起步，2005年上线 | 原创与创作者社群 | 独立影像展示 |
| Dailymotion | 2005 | 国际视频分享 | 欧洲在线视频生态 |
| Netflix | 1997 | DVD租赁，2007年流媒体 | 订阅型视频服务 |

这几家平台并不是同一种类型。

YouTube、Vimeo和Dailymotion主要从在线视频分享与托管发展而来；Netflix则从DVD租赁转向订阅型流媒体服务。

它们共同构成了互联网视频产业的重要组成部分，但其商业模式、内容来源和艺术文化角色并不相同。

## **第十节 网络视频平台的发展时间线**

[YouTube视频营销怎么做？品牌如何实现流量变现？ \- Shopify 中国](https://images.openai.com/static-rsc-4/FUdH7j171-pM946idi6Fc2jgHckXfg4zM5s08ip6Obc3_1tcHNrKVhlMPoKzBuQTp2OHFwY2zKU3-QM88jHii0yT-2pVX76mSnWlbrv-KcmCbCSkEacXG1stA5hsGxSCNvq8In8D9AnNmdhA8vSIQDkCT-yBFGNXgZ7ZlpcwtVE?purpose=inline)

[shopify.com](https://www.shopify.com/zh/blog/sell-on-youtube?utm_source=chatgpt.com)

| 年份 | 事件 | 历史意义 |
| ----- | ----- | ----- |
| 2004 | Vimeo开始发展 | 创作者视频社群形成 |
| 2005年2月 | YouTube注册成立 | 视频分享平台出现 |
| 2005年4月 | 《Me at the zoo》上传 | 普通用户视频传播的标志性事件 |
| 2005年 | Dailymotion成立 | 欧洲在线视频平台发展 |
| 2006年10月 | Google收购YouTube | 大型互联网公司进入视频产业 |
| 2007年1月 | Netflix推出流媒体服务 | 订阅型网络视频发展 |
| 2007年 | YouTube Partner Program启动 | 视频创作者商业化 |
| 2009年 | HLS推出 | 网络视频传输技术进一步发展 |
| 2010年代 | 视频推荐与移动应用普及 | 平台化观看成为主流 |

其中，YouTube合作伙伴计划在2007年先进行试点，随后逐步扩大申请范围。

youtube.googleblog.com+2

## **第十一节 本章的核心问题：谁在控制视频传播？**

网络视频平台的发展产生了一个重要的历史变化。

在传统广播时代，电视台和电影发行机构掌握着相当大的传播权力。

在早期互联网时代，个人网站和独立服务器提供了相对分散的传播渠道。

到了大型在线视频平台时代，视频的上传、存储、搜索、推荐、商业化和审核逐渐集中到少数大型平台。

这种变化可以称为平台化（Platformization）。

平台化并不意味着所有视频都只能通过大型商业网站传播，而是指数字平台逐渐成为组织内容生产、分发和商业活动的重要基础设施。

对于艺术史研究，这带来了五个重要问题：

**1\. 作品的传播权力。**

艺术家可以自行创作作品，但作品能否获得大量观众，可能受到平台推荐机制影响。

**2\. 作品的商业价值。**

播放量、广告收入和订阅关系可能影响创作者的生产方式。

**3\. 作品的可见性。**

平台搜索和推荐机制影响哪些作品更容易被发现。

**4\. 作品的保存。**

当平台关闭、账户被删除或视频被下架时，作品可能失去原有传播环境。

**5\. 作品的自主性。**

艺术家是否能够在不依赖商业平台的情况下建立自己的传播渠道？

这些问题构成了当代网络影像艺术的重要研究方向。

2010年代至今

视频平台逐渐整合推荐算法、商业化、移动应用、版权管理和全球内容分发。

从艺术史角度看，这一时期最重要的变化是：

视频作品不再只是被创作出来、然后被观众观看的对象。它们逐渐进入一个由平台、算法、观众、商业机构和技术基础设施共同构成的生态系统。

艺术家不仅能够使用视频平台传播作品，也能够把平台本身作为创作和批判的对象。

因此，我们需要将网络视频平台的发展与流媒体视频艺术的形成联系起来研究。

