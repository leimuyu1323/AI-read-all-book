# **008 用户生成内容（UGC）的兴起**

**The Rise of User-Generated Content (UGC)**

流媒体视频艺术史 · 网络影像文化与数字艺术的发展

[A Breakdown of YouTube from an Information Architecture Lens \| by Paniz Amirnasiri \| Medium](https://images.openai.com/static-rsc-4/nK6M_3sbRsiuVZsYLaCn8B_-p0Xgajsmhu3fsDUsIpJzO6F1KXISE9zn7F4dyr9AXqSgKXzpf89jiw4sAQ1nPA68KtGLbDjoA0aRB0UHxeywcfjEnW2Udp2x08Mg0LOAXjHI4JTrzuqXjMJ1-iT8Pi5xRN9lc6p-J7sYFeO7I2g?purpose=inline)

[The V\&A adds YouTube's first video to its digital archive \| Wallpaper\*](https://images.openai.com/static-rsc-4/gF2oTb9NfKS1YUhF9mIm32xUf5_GhlZAUEfROjHksZo25US9BB1cRJ_5KT_tFeSirahQfGfVyGgB3NiVzuXrVAzXz6miZN51fcS10XUaywQIx5svc2cRihfZFI-ktxz1Tc71mdosMry-EAfrcfNQT0Ch0kYUUyTcDlhsRJLjaSY?purpose=inline)

[Yahoo Prepares New Flickr Flavor \- Softpedia](https://images.openai.com/static-rsc-4/lvB_huTuc33oLaH8KHwYj8TMUfDSS3EiIYpnf0ZQ8dwHfMZxsK7PCguJIcVYilPMwiUaxAd-l6IS9yLBdMMj3YxsNGs0P590DTm8XMPkmySPS1rns6kxmi1GXEeU8A2hhEODigCvILnp8SYmBDWYzY_SyoCfRy_Ysd-T0WlaDzY?purpose=inline)

9

## **一、用户生成内容的概念与历史意义**

用户生成内容（User-Generated Content，简称 UGC），是指普通互联网用户而非传统媒体机构、专业制作公司或商业出版机构，自主创作、上传、发布和传播的数字内容。

UGC 可以包括：

1. 视频：个人拍摄的视频、生活记录、教学视频、游戏实况、网络评论等。  
2. 图片：摄影作品、数字绘画、网络表情包、图片编辑作品等。  
3. 文字：博客、论坛帖子、网络文章、评论和个人日志。  
4. 音频：播客、翻唱、音乐创作、声音记录等。  
5. 交互内容：用户制作的游戏地图、虚拟世界、数字模型等。

在流媒体视频艺术史中，我们尤其关注其中的视频内容。

UGC 的兴起带来了一项重要变化：**视频创作不再主要由专业影视机构和电视台控制，普通互联网用户也开始成为视频生产者、发布者和传播者。**

这改变了影像生产的社会结构。

在传统电视时代，影像传播通常具有明显的中心化结构：

* 电视台负责制作和采购节目。  
* 专业制作团队负责拍摄和剪辑。  
* 广播机构控制播出时间和频道。  
* 观众主要负责观看。

而在 UGC 时代，生产和传播逐渐形成更加开放的结构：

* 用户可以自行拍摄。  
* 用户可以自行剪辑。  
* 用户可以直接上传。  
* 其他用户可以评论、分享和再创作。

观众与创作者之间的界限因此开始模糊。

## **二、UGC 兴起之前：个人影像生产的技术基础**

UGC 并不是突然出现的。它的形成依赖于20世纪后半叶个人影像技术、计算机技术和互联网基础设施的发展。

### **2.1 家用摄像机的普及**

[Видеокамеры: эволюция стиля и качества :: Ноутбук-Центр](https://images.openai.com/static-rsc-4/Fbrgeox39fJwyRfhSO0P3mUap3mFp3Ff-dDuqVSUryOX8bUNFdzvd_m6UwJ0scOi6DDek4Q4RJZxHDs4ejGKgSNLTNN702I8s8FQwWCo--lPI2NK-NUHjOGSbRpgijy_Us5sQ34I2zuUMrp_zido4MFsGfz-FOpGET7JT75Q0Jk?purpose=inline)

[Home video \| Europeana](https://images.openai.com/static-rsc-4/vZSJ6edvE3s3vcqF2eBbB86YixyG8X6Qhl_9FJ392CuMIplG27MoK8xxJabae3eJAPDi8RHQqUaGVXrGGypngDdmOParz2Kb73KzZv_-FAYyYl5alII0P1m17kBHob4DXEDjotVp31AFkweLvVhY0_61GHSgynPZpuTfO0r0sJM?purpose=inline)

[Sony](https://images.openai.com/static-rsc-4/HtFSw69u-OJ3d9kIx1XQMdbrVt-bcvOen1ZHNWAm3FEvmR_Z3UUM_FHPSi8VvGgHkbCzRjjhMMxavXx53ZuNldfDg8bJVtCrJFW9ZfG7rVC_g4ckzS0DNDDiwQNGyS1yGZvKzBFdj1mGOuDVswxxX3U36zHv8CN1jpwYNqjdLYA?purpose=inline)

9

20世纪70—80年代，家用录像设备逐渐普及。

早期具有代表性的技术包括：

* VHS（Video Home System）：家庭录像带系统。  
* Betamax：索尼推出的家庭录像格式。  
* Camcorder：将摄像机与录像设备结合的便携式摄录一体机。

这些设备使普通家庭能够记录婚礼、生日、旅行和日常生活。

影像生产开始从专业摄影棚扩展到家庭空间。

不过，这个阶段的个人影像仍然存在传播限制：视频通常保存在录像带中，主要通过家庭播放、录像带交换或有限的电视节目传播。

### **2.2 数字摄像与个人计算机**

[Sony Handycam DCR-TRV30 Camcorder for sale online \| eBay](https://images.openai.com/static-rsc-4/x1qRRwswXKrYH6cUkCo6iL251kRGLUf2HUJNLnZXXdXBXeGV2a335tV4ekldvvvWuPanR-S-V9w9-vHJdh4C2idwg75x679UaoMbvXGVVI_MinzEVkOXCQj7MrZ2fYyTT2L0je291sE_gwy6iv1iCJHfB87fxenr2P5GgtWY8lg?purpose=inline)

[iMovie 1.x \- Macintosh Repository](https://images.openai.com/static-rsc-4/_X0OSBYlQAeSP5I4Fl0yCcwbbkG4Vjh8PvkP_WxtoHiid2N46WFVrS9xNzVQzO3IrNTIAAeuQWs43lFOx8Up8yczIgLvuBO6CkP1EdsytqMn1K2IdnceclmGB5evlaWfYfOzOd80IvWwHfJQ4pJbTsrN9DrjhNsS1_brExLUq0k?purpose=inline)

[Adobe Premier from 1999 \| 90s Kids Games \- 90kids.com](https://images.openai.com/static-rsc-4/_-Uv_rtAI1OY0JAPkvaoORdzg7fRw7pOxWhKtfrzxIrfnq6d2DuX4YxE939lIHwKtHd0Tnp70LPjc2c2XG2Tq9JCDcRBmc4NxUEkL7qT7t0tcmOKV2RIrUkQ1wsNDsO158e9Y3Bd-uG4QvYGjxM1L0hiO928XZdJRQh5Sc8-3_E?purpose=inline)

6

20世纪90年代，数字视频技术的发展进一步降低了个人视频制作的难度。

其中有三个重要变化：

**第一，数字摄像设备出现。**

MiniDV 等数字录像格式使影像能够以数字形式记录。

**第二，个人计算机开始具备视频处理能力。**

普通用户逐渐可以在个人电脑上进行视频剪辑、添加字幕、调整画面和制作简单特效。

**第三，视频编辑软件逐渐普及。**

例如：

* Adobe Premiere  
* Apple iMovie  
* Windows Movie Maker

这些软件使视频制作不再完全依赖专业剪辑设备。

但此时仍然存在一个重要问题：制作视频相对容易了，如何让大量普通人方便地把视频传播给全世界？

这需要互联网基础设施的发展。

## **三、早期互联网：个人内容发布文化的形成**

[\[Image \- 552487\] \| GeoCities \| Know Your Meme](https://images.openai.com/static-rsc-4/Mq6ifGU9mMn1qcFCve06V2lkoM3ZWbN1SVZtC3WJ0FgSOio25z99Vl4_VrLkfHovjXHlr0G14cXTTlcAPSccOUa5wNBZO8UdJjhyqQKhGRurcC3AU6VJQW4pbh9sZJwZ0wjUMmv_YRWDgo0Xrd_HqtHbtW6TczqD0B_zYDaf7f4?purpose=inline)

[First Versions: Blogger](https://images.openai.com/static-rsc-4/QdmUc26rwh7F4hNPICjbCIl25jgP_1cW-reuogeOxdDRn3ECCJvxuugRx2uFvU_iWqQG5rqXieiiyK0GiNekbUY63UKPtmISNZzIOFxKcsmltG474wnmxfVvWdPjgzCBVmbZgT2xhcSXBizzSQ1We6RXlaAmxD4r0OG2MtAfwXc?purpose=inline)

[The History of Blogging: From 1997 Until Now (With Pictures)](https://images.openai.com/static-rsc-4/GJiT3vINumInCH3LfM18aRbGj2pIgdA8NRRJ87hORgizDu1dRPWxxFBT4xCWVVmone8OIDpJDuuGxmp1CtFUxZbCmCS0RhPafBuo255msgW24SmbuXt49p9925ALXXGY_YjigAc0Vp-cReFy45RPUzp0fe-NYqpowYdNTmsPhzo?purpose=inline)

9

20世纪90年代，互联网逐渐出现个人主页、博客和网络社区。

这为后来 UGC 的发展提供了文化和技术基础。

### **3.1 个人主页（Personal Homepage）**

早期互联网用户可以通过网站建立个人主页，发布文字、图片和个人信息。

例如：

* GeoCities  
* Angelfire  
* Tripod

这些网站使普通用户第一次能够相对自由地建立属于自己的网络空间。

个人主页具有鲜明的个人表达特征。

用户可以自行设计页面布局、选择背景、添加图片和发布个人文字。

这种文化意味着互联网开始从单纯的信息获取工具，逐渐转变为个人表达和内容生产空间。

### **3.2 博客文化（Blogging Culture）**

1990年代末至2000年代初，博客逐渐流行。

具有代表性的平台包括：

* Blogger（1999）  
* LiveJournal（1999）  
* WordPress（2003）

博客使普通人可以持续发布自己的文章、照片和生活记录。

博客文化的重要意义在于：用户不再只是偶尔制作网页，而是开始持续性地生产和更新内容。

这种持续生产的模式，后来也成为视频创作者文化的重要基础。

## **四、Web 2.0：UGC 发展的关键转折**

[Web 2.0 \| Digital Communication](https://images.openai.com/static-rsc-4/GYh19V4GJ8aujlBRQ0zuDDdhdgR0TDQ5cV9iz1eW-_Igfj5AN9RFwVXIQzmnC8TFddwhF-wpF7FsF-AVwbZXh81nfHZEPRbIoU3JMIEv4wwEWF-luXBekQ9nphU9gMgl6LyMen3SK_UjJdY441ZLWwfG2IZUKwkauxbgfcO4DmA?purpose=inline)

[jordanmagennis.wordpress.com](https://jordanmagennis.wordpress.com/web-2-0/?utm_source=chatgpt.com)

2000年代初期，互联网开始进入通常被称为 Web 2.0 的发展阶段。

Web 2.0 并不是某一种具体的软件或网络协议，而是一种描述互联网应用形态变化的概念。

其核心特点包括：

1. 用户参与内容生产。  
2. 用户之间能够进行互动。  
3. 内容能够被分享和重新传播。  
4. 平台通过用户活动不断积累内容。  
5. 社区和社交关系成为网络服务的重要组成部分。

传统互联网网站通常由网站管理者提供内容，用户主要负责浏览。

Web 2.0 则逐渐形成了用户共同生产内容的模式。

### **4.1 图片分享平台**

[Flickr home page archive: 2004-04-29 \| I'm not 100% sure tha… \| Flickr](https://images.openai.com/static-rsc-4/kfL-INTlhes9qS-EtGC8s_HNyvK_DGmI1TvbJOcnWJd5lf6kvnrN9Obs_LIXTID9tblkKpEtHNLZaawvxGLSSJyAzXWGHEdCEhYiCYuoabBYtfiYEcLWGVgKRm16nsX6EisI47tmNRuXQmU6khE9QZ5V9hXWmqjqgOn7DJDfdnw?purpose=inline)

[A Nostalgic Journey: Evolution of Popular Websites Over Time \- Hongkiat](https://images.openai.com/static-rsc-4/VzKitYUoKcopSWtz_qE0aBt2PukK8_0NOfIaOH2vl9c5UWw-cj3bYiBcaMDKOVWykYuZjnAefkJZFadlM6OD2d00Cwocd39EDf3AwqjETDQcYOflcnnLVYAHOuSRbOm3Pzx6gQSFkBA_LWzVc7Oe-9JBD1ommfVf-0Da3IAf_Hw?purpose=inline)

[Picture Posting tutorial... \- The Supercar Registry](https://images.openai.com/static-rsc-4/2hF9YyFCM2jFZFaznWb9Az8vGVGEXVX7Dw_2p3WOMEb2HcLQS7gStmxz1V6Buw9nbM-8lVK-1s8YlXYTh1O5iUo7TLlBiM1L2pmciBhB-PkMtU-vgj8Qj2pzRbAEeTBCUT7kyQ97epQQWrUIDC1gn6zJfO3p7ZwKdGnILneKl1E?purpose=inline)

6

2004年，Flickr迅速发展。

它使用户能够上传照片、添加标签、建立相册、评论和分享其他人的摄影作品。

图片不再只是个人电脑中的文件，而成为可以在网络社区中传播和讨论的公共内容。

### **4.2 维基百科与协作生产**

[Jon Erlichman (@JonErlichman) on X](https://images.openai.com/static-rsc-4/1l9b_tUDTP163qYJPR41nx7u4hbzxaiWKwJVbIAjQJMUFgjHBvqx1de_H50zjy6ssJ1k8rUMcrs-01oGzLfskpDyiakkyn2G9Tmz7l3SENgVUPFPBpp1NQtLFWt3850fvVNc6R7DGvPR02J6odKkUdV7_ulcsHFeBk49_A9Vx4U?purpose=inline)

[x.com](https://x.com/JonErlichman/status/952885683571568640?utm_source=chatgpt.com)

2001年，Wikipedia创立。

它展示了另一种 UGC 模式：用户不仅生产个人内容，还可以共同参与知识的编辑、整理和维护。

这种协作生产方式对后来开放式网络文化产生了深远影响。

### **4.3 社交网络与内容传播**

2003—2004年，Myspace、Facebook 等社交网络相继出现。

社交网络将用户身份、好友关系和内容传播结合起来。

内容不再只是上传到某个网站，还能够通过用户之间的社交关系不断扩散。

这一变化为视频平台的快速发展创造了条件。

## **五、YouTube 的出现：UGC 视频时代的开端**

[A Breakdown of YouTube from an Information Architecture Lens \| by Paniz Amirnasiri \| Medium](https://images.openai.com/static-rsc-4/nK6M_3sbRsiuVZsYLaCn8B_-p0Xgajsmhu3fsDUsIpJzO6F1KXISE9zn7F4dyr9AXqSgKXzpf89jiw4sAQ1nPA68KtGLbDjoA0aRB0UHxeywcfjEnW2Udp2x08Mg0LOAXjHI4JTrzuqXjMJ1-iT8Pi5xRN9lc6p-J7sYFeO7I2g?purpose=inline)

[Flashback 2005: YouTube Is Born \| Sound & Vision](https://images.openai.com/static-rsc-4/97l5MaK5eGHv1OnmgvKTaSTGdNLLEsiDTQCfeykIMrTd8ZAQ618hjsG4n00wQKfehVOBs8w-tlPzAy8GPkdiZhyNbSZEjMmoTB1RiWjC-S1raqxFnF2WwanJt5xRZkJsK9KTZBSUwRRiqNR-YH6QhnF_V8NQmx7TeL9zFLjLhRM?purpose=inline)

[YouTube cumplió 18 años y estos han sido sus cambios de imagen](https://images.openai.com/static-rsc-4/UildOFTSn3_hnuo4509KDXzlVWOr2pi3sfkORq9mlqxp8nivBXtsSadRxoMtuN1Nwi9FsAJBPbPDf90Bw_y_fB6QiQrqkh9Om3QMRE1zndy8uKiNp8KCFgmPLXJ2LomOMKCXwk8r5nQZmWrooX6qUKxHO47L00Sq2SJx0hJ2L0w?purpose=inline)

重要历史节点：2005年

2005年2月，YouTube成立。

它是 UGC 视频史上最重要的平台之一。

在 YouTube 出现之前，普通用户虽然已经可以制作视频，但上传和传播视频仍然存在许多障碍：

* 视频文件体积较大。  
* 视频格式不统一。  
* 网站需要专门的存储空间。  
* 视频播放需要一定技术知识。  
* 普通用户很难建立稳定的视频传播渠道。

YouTube 将视频上传、托管、编码转换和在线播放整合在一个相对简单的平台中。

这使普通用户能够通过浏览器上传视频，再将视频分享给其他人。

### **5.1 第一支 YouTube 视频**

[Flashback 2005: YouTube Is Born \| Sound & Vision](https://images.openai.com/static-rsc-4/97l5MaK5eGHv1OnmgvKTaSTGdNLLEsiDTQCfeykIMrTd8ZAQ618hjsG4n00wQKfehVOBs8w-tlPzAy8GPkdiZhyNbSZEjMmoTB1RiWjC-S1raqxFnF2WwanJt5xRZkJsK9KTZBSUwRRiqNR-YH6QhnF_V8NQmx7TeL9zFLjLhRM?purpose=inline)

[soundandvision.com](https://www.soundandvision.com/content/flashback-2005-youtube-born-0?utm_source=chatgpt.com)

2005年4月23日，YouTube 联合创始人 Jawed Karim 上传了著名的第一支视频：

**Me at the zoo**

视频内容非常简单：拍摄者站在动物园的大象围栏前，介绍大象的鼻子。

这段视频只有很短的时间，没有复杂的剪辑、剧情和专业制作。

但它具有重要的历史意义。

它展示了一种全新的影像传播方式：普通人可以把自己日常生活中的影像直接发布到互联网，让世界各地的用户观看。

### **5.2 YouTube 对视频生产结构的改变**

YouTube 的重要性不只是提供视频播放器，而是改变了视频生产和传播的组织方式。

| 传统电视模式 | YouTube 模式 |
| ----- | ----- |
| 电视台组织生产 | 用户自主生产 |
| 专业机构审核和播出 | 平台提供发布机制 |
| 固定播出时间 | 随时点播 |
| 频道控制内容 | 用户建立个人频道 |
| 观众主要观看 | 观众也能参与创作 |

这意味着视频生产开始出现明显的去中心化趋势。

不过，这并不代表权力完全消失。视频平台仍然控制内容推荐、审核、商业化和传播规则。

## **六、早期 UGC 视频的主要类型**

2005—2010年，网络视频创作逐渐形成多种类型。

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s](https://images.openai.com/static-rsc-4/08pspF-ANFfll6Yf3iO3W0DP7TMjgdKueRuTLDVQohlJkZ4e3yYBzY-lkdJwYdGihGRBwVR6zgcU8FiL92tM6SJOpFeYThLLOSPFn1y1At4sjiN8e_tzPDQcpoGWaKCxnjgL1Yfyw6rh9THie-Qn3px8FkKiwfSYZNvo1XaWS0w?purpose=inline)

[Balloon \#001: Video Tutorial \| PaperMatrix](https://images.openai.com/static-rsc-4/zCOTndGJ-iarLqU3eVowvBoG-uZwnJXhZAlOX28b0IbBuIUX2l7uJkFW2XGe_79tFrsCxuyR4xMwEs5Y4ydEcsvVpjlTVsctcFDE81o0mdsR1SofiXQjaB3j95qEUCQrrjHSaX-J3g8tGIl9UfgPKK59OB8crd15fqUEkzQiy0Y?purpose=inline)

[How the world changed around Far Lands or Bust \| Bevan Philip](https://images.openai.com/static-rsc-4/a3S3EAVIqLDzbfR1NHKy1fE-pWkLMukhTpzawoN_co58QkDusbt_IBI60o7iCQPEVozUpKKvQYcwFkZMf0_Ia0-OgV20gsomf-vQNVs2_BDax33_oDjlPMx_VpFMOgg0LWYG7WDFHtcKfg2mRyDR8jlDyx_AUABatXgV3j6nzuk?purpose=inline)

12

### **6.1 个人日志视频（Video Blogging / Vlogging）**

创作者通过摄像机或电脑摄像头记录自己的生活、想法和个人经历。

这种形式通常具有以下特点：

* 创作者直接面对摄像机。  
* 视频具有明显的个人视角。  
* 内容不一定需要专业脚本。  
* 生活记录与个人表达相结合。

Vlogging 后来发展为 YouTube 最具代表性的内容形式之一。

### **6.2 教学视频（Tutorial Videos）**

普通用户开始制作软件教程、烹饪教程、维修教程和知识讲解视频。

这使网络视频逐渐成为一种知识传播工具。

### **6.3 游戏视频（Gaming Videos）**

用户开始上传游戏过程、攻略、游戏评论和实况录像。

游戏视频后来发展出规模庞大的创作者生态。

### **6.4 音乐与表演视频**

普通用户开始上传翻唱歌曲、乐器演奏、舞蹈和其他表演作品。

音乐视频不再完全依赖唱片公司和电视音乐频道。

### **6.5 搞笑与恶搞视频**

用户开始制作短小的喜剧视频、模仿视频、恶搞视频和网络段子。

这类内容尤其适合在网络社区中传播。

## **七、UGC 与网络艺术的关系**

这是本章最重要的艺术史问题。

UGC 并不等同于艺术。

绝大多数用户生成内容的主要目的可能是娱乐、社交、记录生活或传播信息，而不是进行艺术创作。

但是，UGC 的兴起确实改变了当代艺术的生产环境。

### **7.1 艺术创作主体的扩大**

传统艺术体系通常存在较为明确的创作身份：

* 职业艺术家。  
* 独立艺术家。  
* 艺术团体。  
* 文化机构。  
* 商业制作公司。

UGC 时代，普通用户也可以利用数字设备创作影像作品。

创作者身份开始变得更加开放。

一个没有接受过专业艺术教育的人，也可以通过网络影像表达个人经验、社会观点和审美观念。

### **7.2 日常生活成为创作材料**

[VVEBCAM \| Net Art Anthology](https://images.openai.com/static-rsc-4/6c5a3L6AR83yVm05hJWOUuLncIyH5L16dpgpI7DQFs_Nguu9VwDMULHAnuP0OrLqM1_rvJBWQlXAI8Dy0WQHVAX2w6C-n92Vp01EWmR9d6w5aEMAHjOb5Iq2KcYySNYfbcWJ2Llmva8jCDPJo0P-FI_qnhokjetoh-IqrR4B8vU?purpose=inline)

[Christopher Baker's new show Hello World\! is a large-scale audio visual installation comprised of... \- purple ART](https://images.openai.com/static-rsc-4/nIcu3Ox5D8hsP1lkqcsUPWiIGwLxrZV0eFPqbe6RsJeeCJdFjcsvNCfltpUo8Ez_9_ud58QyYjXyfT10peqI3EGS10d9fKOcoMSgfyXkRuPl6p6PG_fYRPKmGPBK29k87msxrSaq-PyiSGrVIk5gDfRudBnzLy7Czxm0pBm8X84?purpose=inline)

[Telepresence 2 \| Net Art Anthology](https://images.openai.com/static-rsc-4/-x1cjWSGym9PApHCMeNBes0HFEb2IGFsZ7oFMPD9CZRIDH0WLvSaMbmOl2jMXtmRvRYUK83vCb1-zKAW5CKTZLjihlequJWxoyGjlWU-EmRxI6LwRDP0cRWoV_Oe_1zGwr2yMGr2VnV8eZ5UfTZaRX-d43iFpzhfXXBgREnX7I0?purpose=inline)

10

UGC 文化使日常生活中的大量影像进入公共传播空间。

例如：

* 家庭生活。  
* 城市街道。  
* 个人旅行。  
* 社会事件。  
* 个人情绪。  
* 网络交流。

这些内容可以被艺术家重新组织、编辑和解释。

普通人的生活记录因此也可能成为当代影像艺术的素材。

### **7.3 从作品到参与过程**

传统艺术作品往往强调艺术家的创作行为，以及最终完成的作品。

UGC 文化则使艺术创作越来越重视：

* 用户参与。  
* 社区互动。  
* 集体创作。  
* 内容共享。  
* 作品再加工。

艺术作品有时不再是一个完全固定的对象，而是一个持续发展的过程。

这与参与式艺术（Participatory Art）和关系美学（Relational Aesthetics）等艺术理论存在一定联系。

不过，需要注意：UGC 平台并不自动构成参与式艺术，只有当用户参与被纳入艺术作品的观念和组织结构时，才适合从这些艺术理论角度分析。

## **八、UGC 的进一步发展：从个人发布到网络社群**

[YouTube in 2007 \- Web Design Museum](https://images.openai.com/static-rsc-4/SGVLlL_GuYlXU7cHBXP1lyPWm2aSejtTF_cc2v-vLlUsYhf8Qg2_BgEnRrLUwaavtuJB_rt1HfkToPKU69id3W15s8vSfL_s0mSDtxqKOBKepA0ngx8MZskU9y07UIhKtmH85mH3ZlYL9r42bqwgZaz_4YozPAuDRGDambeTqtQ?purpose=inline)

[Así se construyó YouTube, gracias a un pionero grupo de influencers](https://images.openai.com/static-rsc-4/rYkS49sjyDUi-K3jYgdHuFKnxSX5crfgl05kvzj4WU5Fb78jXvi-XT67dfCEzlN9dHHjZjFh3krSE4FLBa0-SlVnUa-v4fEndLyG6_QGVV5aJaDpLBmTisSiWg6LQcxroZbabXz0lVMRliSgltMFmpdF8joJThopsSKh3UDY8_E?purpose=inline)

[Here's What People Thought of YouTube When It First Launched in the Mid-2000s — Paleofuture](https://images.openai.com/static-rsc-4/wwzNMV-wzYzTzIs6JbINBlcBz2rSU5gg5BN_Ny0JOfcoibCr3v-9xaUNGp3gY2iQ2o6KWoT7LwovQhYSF5jMoFcIN5CwJa5Ndsgax0MIhCj_djTfIyCcJak3yF1S9KvdknZI-uFJ5oWGQJYU3yhZ1cWCi-NBnaQkm0zEiqOY2Jg?purpose=inline)

8

2007年，YouTube 推出了重要的合作伙伴计划（YouTube Partner Program）。

它使符合条件的创作者能够通过视频广告等方式获得收入。

这标志着 UGC 开始逐渐从个人兴趣活动发展为一种商业化内容生产模式。

随后出现了新的创作生态：

1. 个人创作者开始建立长期频道。  
2. 创作者逐渐形成固定观众群体。  
3. 观众通过评论和订阅参与社区。  
4. 创作者开始考虑视频制作的持续性。  
5. 视频制作逐渐成为部分人的职业。

由此，网络创作者（Content Creator）开始成为一种新的社会角色。

这一过程也带来了一个重要变化：UGC 不再只是用户自由表达的文化现象，同时也成为互联网平台商业模式的重要组成部分。

## **九、UGC 时代的技术与社会影响**

### **9.1 影像生产民主化**

摄像设备、剪辑软件和网络平台的普及，使更多人获得影像生产能力。

但这里的民主化并不意味着每个人都拥有完全平等的传播机会。

设备成本、数字技能、平台推荐机制和社会资源仍然会影响创作者的可见度。

### **9.2 传播权力的变化**

传统大众传媒具有较强的中心化特征。

UGC 使大量个人创作者能够直接接触观众，部分绕过传统媒体机构。

但平台逐渐成为新的传播中介。

因此，传播权力并没有彻底消失，而是从传统媒体机构部分转移到了数字平台。

### **9.3 内容数量的爆炸式增长**

UGC 使网络内容生产规模大幅扩大。

这也带来了新的问题：

* 内容质量参差不齐。  
* 虚假信息传播。  
* 版权争议。  
* 隐私泄露。  
* 网络暴力。  
* 平台算法造成的信息茧房。

这些问题后来成为数字媒体研究和互联网治理的重要议题。

## **十、UGC 的历史阶段划分**

为了理解 UGC 的发展，可以将其初步划分为五个阶段。

1. **第一阶段：个人数字内容的萌芽（1980年代—1990年代）**  
   家用摄像机、个人主页和个人数字创作逐渐普及。  
   [Reviviendo el Jaén de ayer: ‘Cuando éramos zagales’ vuelve con libro y exposición](https://images.openai.com/static-rsc-4/qJgighWBp0uCnH2aDIw6xXrf_06FZlHH151O9jTfc90uUp5KYQNnRRp8xi7xQrX1SB9yN2nqwTNecUWtjDW40jQch4_SbpvLon3g_W0zRZrJDbBJC4LHot0bpuMW8dK-U_x6IJVUA3g4qQ-UrCnFcBXd3yadpHW9Nn6qQvkdGf0?purpose=inline)  
   [jaenhoy.es](https://www.jaenhoy.es/ocio/reviviendo-jaen-ayer-zagales-vuelve_3_2002978290.html?utm_source=chatgpt.com)  
2. **第二阶段：网络个人发布文化（1990年代末—2003年）**  
   博客、个人主页、图片分享和网络社区逐渐形成。  
   [Pred tri desetljeća: GeoCities – od Beverly Hillsa do virtualnih gradova \- Događaji @ Bug.hr](https://images.openai.com/static-rsc-4/ZYZhVuqhgud-cqi-CUEGQTZ_sShe05Va24z2oYHviKgBMIL6xbnO4aTepdHxqAynaeexIhYED_VbpjvLU5fIXtPz2UH-xFlbcCDLjP6JtdkT011xV_AfFXaa3hk6iAxxxX8YEAiq_TBXuAzbUIt4T3MQTJ16A30zx2Cu18Jp0lY?purpose=inline)  
   [bug.hr](https://www.bug.hr/dogadjaji/pred-tri-desetljeca-geocities--od-beverly-hillsa-do-virtualnih-gradova-48148?utm_source=chatgpt.com)  
3. **第三阶段：UGC 视频平台兴起（2004—2007年）**  
   YouTube 等平台降低视频发布门槛，个人视频创作迅速发展。  
   [20 años de YouTube: de la red social más cruda al asalto definitivo a la televisión](https://images.openai.com/static-rsc-4/PCWoJtej1AhsY0uxJ2UTE4AOGYCebpac5NvJy0JZb9HWM7UDp9WzKAOv8_Gzp4XoRUaPXxAAXVzILYgGigTSsGAQWgf0frV3L21xRtpCFYmWZD9n3rUl5-WrE0o__STHJotllzffsWSqqFsTDXCHcTwR2trQSJpJe86mz6gxeEE?purpose=inline)  
   [eldiario.es](https://www.eldiario.es/tecnologia/20-anos-youtube-red-social-cruda-asalto-definitivo-television_1_12244873.html?utm_source=chatgpt.com)  
4. **第四阶段：创作者经济形成（2007—2015年）**  
   视频商业化、创作者社区和专业化内容生产逐渐成熟。  
   [Behind the scenes at YouTube's "The Philip DeFranco Show" \- Los Angeles Times](https://images.openai.com/static-rsc-4/MyhgTG-zbHjiTznzSWFxF67sFdmYtiS8zT4EwwG-ytGBSvQxjsLtYy-N9VotA3UrITFOQbxUvakpLHgdtRYo0xHnQ6x4CtWqLRUeLnGesffx0qolaOMcRnH-vpzU_SCJoMb8Uyt0xalB2pmdvLxURHtRAxfIiKeIzKwQixFdPls?purpose=inline)  
   [latimes.com](https://www.latimes.com/entertainment/envelope/cotown/la-fi-philip-defranco-show-youtube-pictures-photogallery.html?utm_source=chatgpt.com)  
5. **第五阶段：移动化与算法化 UGC（2015年至今）**  
   智能手机、短视频平台和推荐算法改变用户创作与观看方式。  
   [TikTok Tips: How to Make a Good TikTok Video — Mixcord](https://images.openai.com/static-rsc-4/3Rf5zWoq9MN41Gd4VFSvXtcr6Dqq5SJOzgEeptLyMdPGeO5vDbGjRk4eeK2Uhs4L4mL0cOM_Y7KPp9hpK8NpE_Mhr-sygQQxBvYozy_hq1XwAr2oswaRRYvdR5Vh5Sip7HDkMgpQJAZo5LoKyaVvWo2qaBTNq9IFyGobFGkO7QM?purpose=inline)  
   [mixcord.co](https://www.mixcord.co/blogs/content-creators/tiktok-tips-and-tricks?utm_source=chatgpt.com)

   ## **十一、UGC 在艺术史中的定位**

我们需要把 UGC 放在一个更大的数字艺术史框架中理解。

它与此前的网络艺术、录像艺术、流媒体视频艺术存在联系，但不能简单地将它们视为同一种艺术形式。

| 概念 | 核心特征 |
| ----- | ----- |
| 录像艺术（Video Art） | 将电子影像作为艺术媒介 |
| 网络艺术（Net Art） | 将互联网及其网络结构作为艺术创作环境 |
| 流媒体视频艺术 | 利用网络视频传输、在线播放和实时传播等机制进行艺术表达 |
| UGC | 普通用户自主生产和发布数字内容 |
| 创作者文化 | 围绕个人创作者形成的内容生产与传播生态 |

UGC 最重要的历史意义，是扩大了数字影像的生产主体，使网络视频逐渐成为一种大众化的表达媒介。

与此同时，它也为后来的网络影像艺术、参与式艺术、数字社群艺术和平台艺术提供了新的社会与技术环境。

