# **010 中国网络直播的兴起与早期实时影像艺术**

**The Rise of Chinese Online Live Streaming and Early Real-Time Video Art**

[底层残酷物语前传——一个视频聊天网站里的中国“边缘人”\_活儿](https://images.openai.com/static-rsc-4/1wfEiLW53nc9gGzXSRULEah0wNKrUoqob_5CiUqDeB-DIOAKAd601R0c6D28stcTfU0spoYbxfEQ_GnmxKP-w12V9j_V8FAFO_Ov_DyM83_tKO7fo92uDn7wirCct_5vmxUhD-vX73taJEWRUpK5aguovqtn14C6bFszLDZNLkk?purpose=inline)

[9158多人视频聊天官方下载-9158多人视频聊天最新版v7.4.2免费下载\_3DM软件](https://images.openai.com/static-rsc-4/sRqbAqaN8KP9SJ6rR8aLDwFeFNeheO6kdP7h0yV1JvzQwvy6y2u_CwhEXj6yTtJ_nB2xztur5bZNskCeKFG1yMQZPuaBLntmaCiD6vjL6YaUtmsE_af6_KXkXB15EK1wgIOU4PdCx2WtaKmNKMkb3huWZW0bFeyX6AKGTITCrGQ?purpose=inline)

[YY盛典八年，直播行业波澜壮阔\_百科TA说](https://images.openai.com/static-rsc-4/lqkIyDD2pRYcdNz9j8rPXTAWSoypAzPo92BfZobhpz6JpzCK5aELwX8c-tP0yOPnM-ySRFhuE0t2rG-qnIyWcAb0_-1-MlK5wLPWJ9_1gEPf6TxMAGUl7gjSfHzzQ-GMWfQUZCGHHVuUWXjG7PpQBvlhcDEekEcCxsxQ2SmYJQI?purpose=inline)

8

本章属于网络影像艺术史（History of Internet Video Art）的中国发展部分，主要研究中国网络直播的技术起源、早期视频聊天室、网络实时表演、秀场直播、观众互动机制，以及直播如何逐渐成为一种独立的网络影像文化。

本章不讨论电影直播、电视节目转播或传统影视作品的网络播放，也不把今天成熟的短视频平台简单地倒推到早期网络直播时代。

本章需要区分两个相互联系但并不完全相同的概念：

* **网络直播（Online Live Streaming）**：通过互联网实时传输影像、声音和现场活动，使远程观众能够同步观看。  
* **实时影像艺术（Real-time Video Art）**：利用实时摄像、影像处理、网络传输和观众互动等技术进行艺术表达的创作形式。

网络直播首先是一种技术与传播方式，而实时影像艺术则是一种艺术实践。两者在中国互联网发展过程中逐渐发生联系。

## **010.001 网络直播的技术起源与早期发展（1990—2003年）**

### **一、实时影像传播的技术基础**

网络直播的出现依赖于几个技术领域的共同发展：

1. 数字摄像技术（Digital Video Capture）。  
2. 音视频压缩技术（Audio and Video Compression）。  
3. 网络数据传输技术（Network Transmission）。  
4. 实时流媒体技术（Real-time Streaming Media）。  
5. 视频播放器与浏览器技术（Video Player and Browser Technology）。

在互联网发展初期，网络视频主要通过文件下载传播。用户需要等待视频文件下载完成，才能完整观看。

而实时视频传输则尝试解决另一个问题：让摄像机拍摄的画面能够在产生之后，尽可能迅速地传递给远程观众。

其基本过程如下：

**摄像机（Camera）**

实时拍摄人物或现场活动

**编码器（Encoder）**

压缩视频与音频数据

**网络传输（Network Transmission）**

将实时数据发送到服务器或接收端

**播放器（Player）**

接收、缓冲并播放影像

**远程观众（Audience）**

同步观看现场影像

与普通视频文件相比，直播还必须处理网络延迟（Latency）、数据丢失、缓冲和实时同步等问题。

### **二、网络摄像头的普及**

20世纪90年代末至21世纪初，网络摄像头（Webcam）逐渐进入个人电脑和互联网用户的日常生活。

网络摄像头通常安装在电脑显示器上，可以通过网络向其他用户传输实时画面。

这一设备使普通人开始能够在互联网上展示自己的实时影像。

早期网络摄像头的使用方式包括：

* 个人网络摄像头展示；  
* 远程视频交流；  
* 网络聊天室；  
* 远程教学和会议；  
* 远程现场观察。  
  [Connectix Quickcam Drivers: Lessons From a Retro Installation Failure](https://images.openai.com/static-rsc-4/O-ZvBK-IviX3Cq8V4bwhh0YdLw0lI272Q1a31Prtapppxhf4RUjqRee_AJDMB5pq6u3IwVqnMyq0CBOUdzpYNDkO52wD21T_DCVeB9euZCMrDncH9Uwdw5Z3TeYkCmW9Z6vK8mpLIXxGsQG0ACYWTJRjIIQZQsf9u6AXy8OFkCg?purpose=inline)  
  [CU-SeeMe](https://images.openai.com/static-rsc-4/7NOCYOO4QekwUmWt1-MOPp7WWV7LwGmSIk624LiuJnENXUwBpGFlbg4kGrbDfZiIXxvTgdmx3dfdFKXtdmSjqs1fXvwY8CIIFOJO6ZjLcgX1ASXS-fo2RH3RA8ORJVlMfKVffM2sEtnkTh2ZDGN7_dTg46E7M2pF0hBw2ZLyESY?purpose=inline)  
  [The CEARCH CU-SeeMe Photo Album](https://images.openai.com/static-rsc-4/zuySbPOZqYAFdzBRz5rwZ0R7clDoghwqH0LBQjBG5u_29d_HKOzAFXh6vIMwgv2ZPLTX6E7sDMzInTBT-Somu6OqfaTOJ9uy7wciFVmRNDPKonL6mpjIMtnCuEAzh4hTayNW8sRuP0Kw0NZpz8uAg-BTWDyDTXXWAlJP4AQSMwA?purpose=inline)  
  8

其中，CU-SeeMe等早期视频通信系统展示了互联网实时影像交流的可能性。

需要注意，早期视频通信与后来面向公众的网络直播并不完全相同：前者主要解决人与人之间的视频交流，后者则逐渐形成了一个主播面对大量观众的传播结构。

### **三、从视频通信到公共直播**

网络实时影像逐渐出现了三种不同的发展方向：

| 方向 | 主要特征 |
| ----- | ----- |
| 视频通信 | 两人或多人实时交流 |
| 网络摄像头展示 | 将个人或现场画面持续公开 |
| 网络直播 | 主播向大量观众实时传播内容 |

这三种模式为中国网络直播的发展提供了技术基础。

## **010.002 中国早期网络视频聊天室的出现（2003—2006年）**

[9158多人视频聊天官方下载-9158多人视频聊天最新版v7.4.2免费下载\_3DM软件](https://images.openai.com/static-rsc-4/sRqbAqaN8KP9SJ6rR8aLDwFeFNeheO6kdP7h0yV1JvzQwvy6y2u_CwhEXj6yTtJ_nB2xztur5bZNskCeKFG1yMQZPuaBLntmaCiD6vjL6YaUtmsE_af6_KXkXB15EK1wgIOU4PdCx2WtaKmNKMkb3huWZW0bFeyX6AKGTITCrGQ?purpose=inline)

[底层残酷物语前传——一个视频聊天网站里的中国“边缘人”\_活儿](https://images.openai.com/static-rsc-4/1wfEiLW53nc9gGzXSRULEah0wNKrUoqob_5CiUqDeB-DIOAKAd601R0c6D28stcTfU0spoYbxfEQ_GnmxKP-w12V9j_V8FAFO_Ov_DyM83_tKO7fo92uDn7wirCct_5vmxUhD-vX73taJEWRUpK5aguovqtn14C6bFszLDZNLkk?purpose=inline)

[20年前大火的“网络聊天室”，现在怎么样了？\_用户\_功能\_进行](https://images.openai.com/static-rsc-4/oVOgfQvXqtCOF0-71F4cO4qoC4dz56K6HLmJWdi0xlCGH8udTY1XoU-5lwilS96qmTd92vU8QUTKMqGJzc846coJ8xxoHIvAwbsWHgpHBNl1q9Eu4MlTIEluudgCzEYY7Q5YQAvrbNldyQ9c0BkA_8nIYnKOt9y0YuytdtRuODM?purpose=inline)

5

中国网络直播并不是首先从今天意义上的直播平台发展起来的，而是与早期网络聊天室（Online Chat Rooms）和视频社交服务密切相关。

在2000年代初期，网络聊天室已经是中国互联网的重要社交形式。用户可以通过文字、语音和图片进行交流。随着摄像头和网络视频技术的发展，聊天室逐渐加入实时视频功能。

### **一、从文字聊天室到视频聊天室**

早期网络聊天室主要采用文字交流。

用户进入某个聊天室后，可以看到其他在线用户，并通过文字消息进行对话。

后来，部分聊天室开始支持：

* 摄像头实时画面；  
* 多人语音交流；  
* 视频窗口；  
* 房间管理员；  
* 用户身份和等级；  
* 在线互动。

这使聊天室从文字社交空间逐渐变成一种实时影像社交空间。

与传统视频网站相比，视频聊天室有一个重要区别：用户不只是观看已经制作好的视频，而是能够看到其他参与者正在发生的实时活动。

### **二、9158与早期秀场直播**

**9158**

2005年前后出现，是中国早期视频聊天室与秀场直播发展中的重要平台。

9158最初以视频社交和陌生人互动为重要特色。

其早期服务让用户可以进入不同的视频房间，与其他人进行实时交流。

随着平台发展，视频聊天室逐渐形成了更加明确的表演结构：

* 房间中出现固定的表演者；  
* 观众进入房间观看；  
* 表演者进行唱歌、聊天和才艺展示；  
* 观众通过文字和其他互动方式表达反馈；  
* 平台组织房间、用户和互动功能。

这意味着网络视频开始从单纯的社交交流，逐渐转向具有明确表演者和观众关系的传播形式。

### **三、网络房间的空间结构**

早期视频聊天室有一个值得注意的特点：它将现实生活中的表演空间转化为互联网中的虚拟房间。

传统舞台通常需要实体场地、灯光、音响和观众席。

而网络视频房间可以通过网页或客户端建立。

[9158多人视频聊天官方下载-9158多人视频聊天最新版v7.4.2免费下载\_3DM软件](https://images.openai.com/static-rsc-4/sRqbAqaN8KP9SJ6rR8aLDwFeFNeheO6kdP7h0yV1JvzQwvy6y2u_CwhEXj6yTtJ_nB2xztur5bZNskCeKFG1yMQZPuaBLntmaCiD6vjL6YaUtmsE_af6_KXkXB15EK1wgIOU4PdCx2WtaKmNKMkb3huWZW0bFeyX6AKGTITCrGQ?purpose=inline)

[m.3dmgame.com](https://m.3dmgame.com/soft/216863.html?utm_source=chatgpt.com)

一个典型的视频房间可以包括：

| 空间组成 | 功能 |
| ----- | ----- |
| 主播视频窗口 | 展示表演者的实时影像 |
| 观众区域 | 显示进入房间的用户 |
| 聊天区域 | 观众发送文字消息 |
| 管理区域 | 管理员维持房间秩序 |
| 礼物区域 | 支持虚拟礼物与互动 |

这种结构逐渐形成了网络直播最重要的空间关系：主播、观众和平台共同构成一个实时传播环境。

### **四、视频聊天室的文化意义**

视频聊天室使个人影像具有了社交属性。

传统个人录像通常需要先拍摄、剪辑，再向其他人展示。

而视频聊天室中的影像可以在产生的同时被其他人观看。

这产生了三种重要变化：

1. **实时性**：观看者可以看到正在发生的活动。  
2. **公共性**：原本发生在个人空间中的活动能够向陌生人展示。  
3. **互动性**：观众可以通过即时消息参与现场交流。

这三个特点构成了后来中国网络直播文化的重要基础。

## **010.003 秀场直播的形成与发展（2005—2012年）**

[六间房【www\.6.cn】\_九州网址](https://images.openai.com/static-rsc-4/ueJDK2bX2VnEbZvG7kc_GvTobpUwBPXyGLbDp8JLYUk_0jo-xhZL6K26mTXl4HHe41Jrg5Nbgn9E3bxABF4ETCqgKWzJOItO-UPU9-nVT54Ub2Ai31vnZmLSSklWNXoIdpRdkWR7HjStCulyg-NKHyQZohaiQ6aGIHwW-btIvgM?purpose=inline)

[YY盛典八年，直播行业波澜壮阔\_百科TA说](https://images.openai.com/static-rsc-4/lqkIyDD2pRYcdNz9j8rPXTAWSoypAzPo92BfZobhpz6JpzCK5aELwX8c-tP0yOPnM-ySRFhuE0t2rG-qnIyWcAb0_-1-MlK5wLPWJ9_1gEPf6TxMAGUl7gjSfHzzQ-GMWfQUZCGHHVuUWXjG7PpQBvlhcDEekEcCxsxQ2SmYJQI?purpose=inline)

[无忧。。图片 \- 主播个人照片 \- 六间房直播](https://images.openai.com/static-rsc-4/QatLzWD2XrThEl6nKcLRzK68ugMiZB5EXPLN_cVBEiY1wp4_ZOrgZrMYuU5GZBq6o6qxgfLXh3LH0_tLQWYk-B71DhCa0jiALuOzswq7MgGi4zRzXCtfJ6-1z0PQM-qGUnSWKnFKSh-M086z6VkyThV1dpGWaxaa98hS30GpYjE?purpose=inline)

10

秀场直播（Showroom Live Streaming）是中国早期网络直播最重要的商业模式之一。

它的核心不是传播新闻或现场直播事件，而是让个人通过互联网进行持续表演，吸引观众观看和互动。

### **一、秀场直播的基本结构**

秀场直播将传统表演中的舞台、演员和观众关系搬到了互联网。

其典型结构为：

* 主播（Streamer）：负责表演和与观众交流。  
* 观众（Audience）：观看直播并参与互动。  
* 房间（Room）：提供虚拟表演空间。  
* 平台（Platform）：提供技术、流量和管理服务。  
* 公会（Agency）：后来逐渐出现，帮助主播组织和运营。

常见的表演内容包括唱歌、跳舞、聊天、乐器演奏、脱口秀和个人才艺展示。

### **二、9158：秀场直播模式的早期探索**

9158在2005年前后进入市场，其早期视频社交模式逐渐发展为秀场直播。

它的重要探索是将视频聊天室与虚拟礼物结合起来。

观众可以通过购买虚拟物品向主播表达支持。平台再按照一定规则分配相关收益。

这使网络直播不再只是免费的视频交流，而逐渐形成可持续经营的商业模式。

### **三、六间房：从视频网站到秀场直播**

[六间房-快懂百科](https://images.openai.com/static-rsc-4/jlGL1VQW133LI2djfmn5Er7MB6OG_UiFCmum8vzBkp87V7YHtiLI6KW4rTOhyKx5ccixd-PiLzN80Zai83-wMoj0MaciobUGp0a9BcOuawmnWitDVax5NSAzld8ogsY4lvHPXrZz3bB6rtH9iwRX90cDUdx6-50Al1NUQ5rPFQ8?purpose=inline)

**六间房（6.cn）**

早期以视频网站和用户视频分享为主要业务，后来转向互联网演艺与视频直播。

六间房的历史尤其值得研究，因为它展示了视频网站向直播平台转型的过程。

早期视频网站需要承担较高的视频存储和带宽成本，同时面临激烈的用户流量竞争。

秀场直播则通过实时互动和虚拟礼物形成了不同的商业模式。

2008—2009年前后，六间房逐渐转向秀场直播业务。

这一变化体现了中国视频网站产业的一条重要发展路径：平台不再只提供已经制作完成的视频，而是开始组织实时的网络表演活动。

People's Paper+2

### **四、YY：语音社区向视频直播发展**

[YY直播LOGO更新，小浣熊大变样-吉祥物设计—视觉设计—品牌形象—品牌设计—IP设计-设计资讯-意邦资讯-无锡意邦品牌设计公司](https://images.openai.com/static-rsc-4/dT2ik2zdmzP3_TQWuE66DOdUUNw_kgs2MIiTQ8Jp5fpVShvOYeHNgJhu5S2eREsE582nF-9S-6w9-iH4xHkmRmR5szwT7qgw-wJaF95suKR6wgcQEPNW2aIJFXK5ykW2w09sFcUiZ7V6ipvb0ViTgd9Slc1qimCmbRBHhtDLi90?purpose=inline)

**YY**

早期以网络语音通信和多人语音社区为重要业务，后来逐渐发展视频娱乐和直播服务。

YY的发展路径与9158和六间房有所不同。

它最初的重要使用场景是多人语音交流，尤其是网络游戏中的团队沟通。

用户可以加入不同的语音频道，与其他人实时交流。

随后，平台逐渐增加娱乐表演、视频互动等功能。

YY的发展说明，网络直播并不一定要从视频分享网站开始，也可以从即时通信和语音社交平台发展而来。

### **五、虚拟礼物与网络表演经济**

[客服中心查看答案](https://images.openai.com/static-rsc-4/8CT77tiKhpkcr8_jT2mHs6GjlsjK5iz-JwgMaBl73RIBT2h10qjLz8vMeHjSowbXeLX2-T63A7aaHWJh578Yb6a3NsV-IFdSEr-JO8MJ3swX4vl3e7VEwY3DdiVZIWEYQ8eyfvwZ2-P_kF3BUBNYjRZa1jcsOx8pGGZPetYzbPs?purpose=inline)

[kf.yy.com](https://kf.yy.com/search/qa/80789.html?utm_source=chatgpt.com)

虚拟礼物（Virtual Gifts）是秀场直播商业模式中的重要创新。

其基本运行方式如下：

1. 观众购买平台虚拟货币。  
2. 观众使用虚拟货币购买礼物。  
3. 观众将礼物发送给主播。  
4. 平台记录礼物价值并进行收益分配。  
5. 主播、平台及相关运营组织按照规则获得收入。

这种模式改变了传统视频观看的经济关系。

在普通视频网站中，观众通常是广告的接收者；而在秀场直播中，观众也可以直接成为表演者收入的贡献者。

同时，礼物也具有社交意义。它能够表达赞赏、支持、身份和参与感。

### **六、主播职业化**

随着秀场直播发展，部分主播开始将网络表演作为职业。

平台逐渐形成签约、培训、内容运营和公会管理等制度。

这使个人网络表演逐渐从业余娱乐活动转变为一种具有商业组织结构的职业活动。

但也要注意，早期秀场直播的创作自由与商业要求之间存在张力：主播需要保持个人风格，同时也受到平台流量、观众偏好和收入模式的影响。

## **010.004 网络实时表演与早期实时影像艺术**

这一节是本章与网络影像艺术史关系最密切的部分。

必须强调：网络直播与网络艺术并不是同一回事。一个直播间可以只是商业娱乐空间，也可以成为艺术家探索实时影像、远程空间、观看关系和身体表现的媒介。

### **一、从录像艺术到实时影像艺术**

在中国，录像艺术（Video Art）在20世纪90年代已经发展起来。

早期录像艺术家主要利用摄像机记录行为、身体、社会环境和日常生活，再通过录像带、电视监视器或投影装置展示作品。

进入21世纪以后，数字影像、网络传输和交互技术为艺术家提供了新的创作条件。

影像不再只能作为一个已经完成的作品被观看，也可以在作品实施的过程中持续产生。

两种形式可以这样区分：

| 录像艺术 | 实时影像艺术 |
| ----- | ----- |
| 通常先拍摄再展示 | 可以边拍摄边展示 |
| 影像通常已经完成 | 影像在现场持续生成 |
| 观众主要观看作品 | 观众可能参与过程 |
| 空间通常固定 | 可以连接不同地点 |
| 时间可以被剪辑 | 实时性本身可能成为作品内容 |

实时影像艺术可以使用摄像机、网络视频、实时投影、远程交互和数字影像处理等多种媒介。

### **二、2003年《远程写生》：网络实时艺术的重要案例**

[清华的艺术课，在线这样上-中国教育和科研计算机网CERNET](https://images.openai.com/static-rsc-4/wzUHlBmBLPLtmIqODvx_26U_XtyPKv_uluey0PTwI3eBHeW64h8IWTAW96e4OT_c76_Ehoko7K0GSBebJ8PI8U061C5nJJvi_xrsDNe00w-vuIEN_9x50vAAUQjDUaF1Ea9O5ygxL77YTy4itkJGcXVMccclEUG34KpUolsNlyg?purpose=inline)

[edu.cn](https://www.edu.cn/xxh/focus/202006/t20200601_1730463.shtml?utm_source=chatgpt.com)

\*\*《远程写生》（2003）\*\*是理解中国早期网络实时互动艺术的一个重要案例。

艺术家李颂华曾在访谈中介绍这件网络作品。

作品的基本形式是：

* 一位画家在广东美术馆；  
* 另一位画家在北京的TOM网站总部；  
* 两人利用网络视频观察对方现场中的模特；  
* 两位画家分别进行写生；  
* 网民可以在线实时观看作品实施的过程。

这件作品最重要的地方在于，它改变了传统写生中的空间关系。

传统写生通常要求画家与模特处于同一物理空间。

而在《远程写生》中，画家、模特和观看者分处不同地点，网络视频成为连接他们的媒介。

它还提出了一个有趣的问题：

**当画家并不直接面对现实中的模特，而是通过网络影像观察对方时，他究竟是在描绘真实的人，还是在描绘经过数字媒介转换的影像？**

这件作品体现了网络艺术的几个重要特点：

1. 远程协作（Remote Collaboration）。  
2. 实时互动（Real-time Interaction）。  
3. 网络空间（Networked Space）。  
4. 数字中介（Digital Mediation）。  
5. 观众对创作过程的实时观看。

它不是今天商业意义上的直播节目，而是一种将网络实时传输作为作品组成部分的艺术实践。

artda.cn

### **三、远程表演与身体的重新组织**

网络实时影像艺术还改变了身体在艺术作品中的位置。

在传统行为艺术中，艺术家的身体通常直接出现在现场。

在网络实时表演中，身体可以被摄像机捕捉，再通过网络传送到另一个空间。

这产生了几个重要问题：

* 身体是否必须在观众面前真实出现？  
* 摄像机拍摄的身体是否能够代替真实身体？  
* 网络延迟会不会改变表演的时间结构？  
* 不同地点的参与者能否共同构成一个表演空间？  
* 远程观众是否也属于作品的一部分？

这些问题逐渐成为网络艺术和新媒体艺术的重要研究方向。

### **四、网络实时影像的艺术形式**

早期网络实时影像艺术可以从以下几个方向理解：

**1\. 远程协作艺术（Telematic Art）**

不同地点的艺术家利用网络共同完成作品。

**2\. 网络行为艺术（Networked Performance Art）**

艺术家的身体行为通过网络实时传播，观众能够远程观看。

**3\. 实时影像装置（Real-time Video Installation）**

摄像机捕捉现场画面，并通过投影、显示器或实时处理系统呈现。

**4\. 互动影像艺术（Interactive Video Art）**

观众的行为能够改变影像内容、播放方式或作品运行过程。

**5\. 网络参与式艺术（Participatory Net Art）**

观众不只是观看者，还可以通过网络提交内容、参与表演或影响作品的发展。

这些形式与网络直播共享实时传输和互动技术，但其艺术目标、作品结构和评价方式并不相同。

## **010.005 从秀场直播到游戏直播（2010—2015年）**

[YY盛典八年，直播行业波澜壮阔\_百科TA说](https://images.openai.com/static-rsc-4/lqkIyDD2pRYcdNz9j8rPXTAWSoypAzPo92BfZobhpz6JpzCK5aELwX8c-tP0yOPnM-ySRFhuE0t2rG-qnIyWcAb0_-1-MlK5wLPWJ9_1gEPf6TxMAGUl7gjSfHzzQ-GMWfQUZCGHHVuUWXjG7PpQBvlhcDEekEcCxsxQ2SmYJQI?purpose=inline)

[斗鱼TV的前世今生，直播行业发展成全民直播！\_新浪新闻](https://images.openai.com/static-rsc-4/ukbdgzU0aBAeJglH44_jjkMlyrHdVDUU0dxRWCGGLr0RZH9ZoGzBuNGyPfIYReLLPTjQgrASMVe-lfOz_M2onQISGbbpUlJYqM5BvwIVvF1Jmen9rxFklx22lNZuxx7AE9fzkwU8yr0049h3hSTIcUMlhO6IwqHycQGbNOgAzcI?purpose=inline)

[帮助中心-年轻人喜爱的互动直播平台，直播帮助，直播教程，虎牙直播](https://images.openai.com/static-rsc-4/ctL40YBWKetiLjt_HtcgRQL69V03nv5TyHTYSrdM4t3IRTUnTp859BiafBtCtpl1H0208z_7RB32x_4Y_Abkc9FbuPbmrqjMhQWWPAD5KvG_iJpN9h3_NoJuxn9EDN76CtNXJcsIn432PiPKXh_FyDG988e_6G6N0h69RpVjc7Y?purpose=inline)

10

2010年以后，中国网络直播开始出现新的内容方向。

早期秀场直播主要以个人表演为中心，而游戏直播则将电子游戏的运行过程变成一种可以观看、评论和参与的网络影像活动。

这是中国网络直播从个人表演向多类型实时内容发展的重要阶段。

### **一、YY视频娱乐的发展**

YY在发展语音社区的基础上，逐渐增加视频娱乐和互动表演功能。

2010—2012年前后，YY的娱乐直播逐渐成熟。

网络主播开始形成较为固定的表演形式，例如：

* 歌唱表演；  
* 舞蹈表演；  
* 音乐互动；  
* 娱乐聊天；  
* 多人连麦；  
* 网络才艺比赛。

2012年以后，YY的直播业务进一步发展，秀场直播的商业模式逐渐成熟。

### **二、游戏直播的出现**

[再扒《魔兽争霸3》黄金赛infi兽王升鹰事件 细节分析始末\_解说](https://images.openai.com/static-rsc-4/lL6rutH9fT5WgGmRn6F2gtkRTvwTigVj35t5xG6r4wrlnCpzSA8cJuzqFoi1a2UI0xJVH9exIshQxSCmOGEktvZKg33ai3DWUS08IJwY1VbDBdb0Jnz75lDOsBh1aAqu-cjZkuOSVqrbdt30x8y4WTTYjuhSxLkmXgal6t1CKPE?purpose=inline)

[sohu.com](https://www.sohu.com/a/279822785_100209402?utm_source=chatgpt.com)

游戏直播（Game Streaming）与秀场直播存在明显区别。

秀场直播通常以主播本人为主要视觉对象，而游戏直播通常以游戏画面为主要视觉对象。

主播可能同时出现在屏幕的一角，通过语音、摄像头和文字与观众交流。

游戏直播的主要内容包括：

* 实时游戏过程；  
* 竞技比赛；  
* 游戏攻略；  
* 玩家解说；  
* 游戏教学；  
* 多人合作与对抗。

游戏直播的出现，使电子游戏本身成为网络观看和表演的对象。

### **三、斗鱼与游戏直播的发展**

**斗鱼（Douyu）**

2014年前后进入市场，逐渐成为中国游戏直播领域的重要平台。

斗鱼的发展与电子竞技和网络游戏文化密切相关。

游戏直播使观众可以同步观看其他玩家的操作，了解游戏策略，并通过弹幕和聊天功能参与讨论。

这种观看方式产生了一种新的文化现象：观众不一定亲自参与游戏，也可以通过观看其他人的游戏过程获得娱乐体验。

### **四、虎牙直播的形成**

[虎牙直播app下载\_虎牙直播13.2.23官方最新版下载\_虎牙直播安卓手机版下载\_华军软件园](https://images.openai.com/static-rsc-4/7nLMEAUwTpICqO1Z58hZX-bRQV7YyT97IY3CD6xoywJfOVPuHP9GjUXeeluLd9HDZXLX8-LqEiv97GfjvozO569hn58elQWKla2jZMiDNBNUNT9Lf9eyQYmvooHpJBeH3A8MX5Hqw8EW8GQ_-NvQlktFQWiWJQ54CZy5N-EQLtc?purpose=inline)

**虎牙直播（Huya）**

其业务源于YY游戏直播，2014—2015年前后逐渐独立发展。

虎牙直播将游戏直播作为重要的发展方向。

随着《英雄联盟》《魔兽争霸》等游戏赛事和电竞文化的发展，网络直播逐渐成为电子游戏观赏文化的重要组成部分。

### **五、游戏直播带来的影像形式变化**

游戏直播不仅是游戏产业的一部分，也改变了网络影像的视觉结构。

传统秀场直播：

**主播身体与面部**

**观众观看主播表演**

游戏直播：

**游戏画面**

主要视觉对象

**主播影像与声音**

辅助视觉与解说

**观众同步观看、评论和互动**

这使网络直播从以人的身体为中心的表演影像，逐渐扩展到以虚拟世界、游戏画面和数字环境为中心的实时影像。

## **010.006 网络直播的视觉语言与互动机制**

网络直播逐渐发展出一套区别于传统电视和普通视频网站的视觉语言。

### **一、实时性（Liveness）**

实时性是网络直播最重要的特征之一。

观众观看的不是已经完成的作品，而是正在发生的事件。

这种实时性能够产生特殊的观看体验：

* 观众不知道下一秒会发生什么；  
* 主播需要对现场情况即时作出反应；  
* 表演可能出现失误和意外；  
* 观众可以同步参与事件。

从艺术角度看，偶然性（Contingency）和不可完全控制性可以成为作品的一部分。

### **二、身体展示（Body Presentation）**

秀场直播将主播的身体和面部变成主要视觉内容。

摄像头不仅记录表演，也决定了观众能够看到什么。

主播可以通过以下方式组织画面：

* 调整摄像头位置；  
* 选择背景；  
* 控制照明；  
* 改变拍摄角度；  
* 使用化妆和服装；  
* 通过动作与表情进行表演。

因此，直播中的身体并不是未经处理的现实身体，而是经过镜头、环境和表演方式组织的视觉形象。

### **三、弹幕与实时评论（Live Comments）**

['The People's Republic Of Desire': Truths And Half-Truths About China's Live Streaming](https://images.openai.com/static-rsc-4/udTZ6WLEmTo1dM4VN6v_69AyzhblDvFLkZV4j7kkpQbIFFFAXSJLdUqrCziuTE18aLYaoaZTPHa1bKodIj2RxxWZ1X-AwWr5RVj8LwrkP5hvZFhi9uAepTjgnO-BmahWXEYhMoarK6KQTD4FgxA7CCC6gUIuTiHrpNXdTprKhQk?purpose=inline)

[forbes.com](https://www.forbes.com/sites/laurenhallanan/2018/12/12/the-peoples-republic-of-desire-truths-and-half-truths-about-chinas-live-streaming/?utm_source=chatgpt.com)

弹幕和实时聊天是网络直播中非常重要的互动形式。

它们使观众的文字表达能够与直播影像同时出现。

这种方式改变了传统观看关系：

在传统电视中，观众通常无法直接影响正在播出的节目。

而在网络直播中，观众能够即时发送评论，主播也可能根据评论改变表演内容。

这使观看行为本身成为直播事件的一部分。

### **四、虚拟礼物与数字化表达**

虚拟礼物不仅具有经济功能，也具有视觉传播功能。

例如，礼物可以在直播界面中以动画形式出现，并伴随声音、文字或特殊效果。

于是，原本抽象的经济交易被转化成一种可见的数字表演。

这可以从三个层面理解：

1. 经济层面：观众通过礼物支持主播。  
2. 社交层面：礼物表达观众与主播之间的关系。  
3. 视觉层面：礼物动画成为直播画面的一部分。

   ### **五、直播中的时间与空间**

直播重新组织了观众与表演者之间的空间关系。

主播可能坐在自己的房间中，观众则分布在不同城市，双方通过网络形成临时的共同空间。

这种空间既不完全属于现实中的主播房间，也不完全属于观众所在的物理环境。

它是一种由影像、声音、网络和互动共同构成的媒介空间。

从新媒体艺术角度看，这与远程艺术（Telematic Art）中的空间连接问题存在重要联系。

## **010.007 中国早期网络直播的社会文化影响（2005—2016年）**

### **一、普通人获得公开表演的机会**

传统舞台表演通常需要通过专业机构、演出场所或商业渠道才能接触大量观众。

网络直播降低了公开表演的门槛。

普通人可以在家中通过摄像头展示自己的才艺和日常生活。

这使表演逐渐成为大众互联网文化的一部分。

### **二、主播身份的形成**

网络主播（Online Streamer）逐渐成为一种新的职业身份。

主播不再只是偶尔上传视频的个人用户，而是可能持续进行内容生产、维护观众关系和参与商业运营的网络表演者。

由此产生了新的劳动形式：

* 实时表演；  
* 观众关系维护；  
* 内容策划；  
* 个人形象经营；  
* 网络社群管理。

  ### **三、网络社群的形成**

早期直播房间不仅是观看视频的地方，也逐渐形成稳定的用户社群。

部分观众会长期关注同一位主播，彼此之间也会形成交流和关系。

主播与观众之间逐渐出现一种持续性的互动关系。

与普通视频网站的评论区相比，直播社群具有更强的实时性。

### **四、网络直播与大众文化**

2016年前后，中国移动互联网和智能手机进一步普及，网络直播进入快速扩张阶段。

映客、花椒等移动直播应用出现，直播从以PC端为主的环境逐渐转向移动端。

2016年通常被媒体和行业研究称为中国网络直播的爆发期或直播元年，但它并不是中国网络直播的真正起点。早在2005年左右，视频聊天室和秀场直播已经开始发展。

People's Daily+2

[全民娱乐直播：映客、花椒直播竞品分析 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/lvt8aN4yg7JoAkNtQo8VHr94CdyM6piFPu034SYS0dOaCtfaovJYlcRxCG9xyhk1dfZZddEoG3lN56vo7o10Lm4Ehp4Ybe4ly2kHiE_4Fr0yYXgnbSi69QgPKe9Pr5IdSzeGOpqFoTvQgLBaTF8MPsuiYDOgH0TsgHzrwi3D07c?purpose=inline)

[全民娱乐直播：映客、花椒直播竞品分析 \| 人人都是产品经理](https://images.openai.com/static-rsc-4/VngoaXE-vWSJphp4xcT_DM8u3bJ4bFVnnAobHv-wDBrM86IL3ry5uJmIHWl2gJAdix9KYX4MB2ih-gQU3tEfICjphH2rlaKKNlNf9MZSoet8GkuQYgr3KZ8STJfS9vsG69pFpayeIZsTJOwXafTmR3UW7XhlUC4ZXgswRdGXlvo?purpose=inline)

[When being watched is your work – life inside a Chinese live-streaming company \| Aeon Videos](https://images.openai.com/static-rsc-4/-2AOF0yiyGyHtFjMVRt-04g9ph9m5sOHIAtl5msTGv8GcxCkX0297xuj4wKvca7iCjBCDo3Qo-vDOY-ZWlBr-vA1uFID_JKzdl3JOvkZXFQtGAjRPvK-clySVzc5lYuTo_80mCDac9l3KckVemAnovP9eUnmem7z0n8LTF1ImJE?purpose=inline)

10

移动设备使主播不再必须坐在电脑前进行直播。

人们可以通过手机展示旅行、聚会、户外活动、个人生活和现场事件。

这使直播的内容范围从固定房间中的表演，逐渐扩展到日常生活和社会现场。

## **010.008 中国早期网络直播发展年表**

下面将网络直播产业史与网络实时艺术史放在同一时间轴中，便于理解两条历史线索之间的关系。

| 时间 | 重要事件 | 历史意义 |
| ----- | ----- | ----- |
| 1990年代 | 网络视频通信技术发展 | 实时影像传输成为可能 |
| 1990年代末 | 网络摄像头逐渐普及 | 个人实时影像展示出现 |
| 2000年 | 中国网络影像艺术展在吉林举行 | 网络与影像艺术的结合受到关注 |
| 2003年 | 李颂华《远程写生》 | 网络实时协作艺术的重要案例 |
| 2005年 | 9158出现 | 早期视频聊天室和秀场模式发展 |
| 2006年 | 六间房等视频平台发展 | 视频分享与直播业务逐渐交汇 |
| 2008年前后 | YY语音社区发展 | 多人语音互动平台逐渐成熟 |
| 2008—2009年 | 六间房转型秀场直播 | 视频网站向实时表演平台转型 |
| 2010—2012年 | YY视频娱乐发展 | PC端秀场直播逐渐成熟 |
| 2013年 | 游戏直播开始发展 | 实时影像内容进一步多样化 |
| 2014—2015年 | 斗鱼、虎牙等游戏直播平台发展 | 游戏观看成为独立直播类型 |
| 2015—2016年 | 移动直播平台兴起 | 手机成为新的直播终端 |
| 2016年 | 网络直播行业快速扩张 | 全民直播和移动直播进入快速发展期 |

其中，2000年的网络影像艺术展与2003年的《远程写生》属于网络艺术和新媒体艺术发展线索，不应直接视为商业直播平台的诞生事件。

artda.cn+3

## **010.009 本章的历史定位：从网络表演到实时影像文化**

中国网络直播的发展可以从三个相互联系的层面理解。

**第一层：技术层面。**

网络摄像头、数字视频编码、流媒体和宽带网络使实时影像传输逐渐成为普通互联网用户可以使用的技术。

**第二层：社会文化层面。**

视频聊天室、9158、六间房和YY等平台，使个人表演逐渐成为一种新的网络社交与娱乐形式。

**第三层：艺术层面。**

网络实时传输、远程协作、数字身体和观众互动为艺术家提供了新的创作条件。《远程写生》等作品体现了网络媒介对传统艺术空间、创作过程和观看关系的重新组织。

### **中国网络直播与网络影像艺术的关系**

**数字影像与网络技术**

摄像机、视频编码、网络传输、实时播放

**网络直播产业**

视频聊天室

秀场直播

游戏直播

移动直播

**网络实时艺术**

远程协作艺术

网络行为艺术

实时影像装置

互动影像艺术

**中国网络实时影像文化的形成**

本章最重要的结论是：网络直播并非只是视频网站增加了一种播放功能，而是改变了影像的时间结构、空间结构、观看关系和创作主体。

影像可以在产生的同时被观看，观看者可以参与正在发生的表演，远距离的个人也可以通过网络构成临时的共同空间。

这使实时影像成为一种独立的数字文化现象，也为后来网络表演艺术、互动媒体艺术和移动直播文化的发展提供了基础。

## **本章重点研究对象与术语**

| 分类 | 研究对象 |
| ----- | ----- |
| 早期技术 | Webcam、Streaming Media、Real-time Video |
| 早期平台 | 9158、六间房、YY |
| 游戏直播 | 斗鱼、虎牙 |
| 移动直播 | 映客、花椒 |
| 艺术案例 | 李颂华《远程写生》（2003） |
| 艺术形式 | Telematic Art、Networked Performance、Interactive Video Art |
| 核心理论 | 实时性、身体展示、远程空间、观众参与 |

## **参考资料与延伸阅读**

1. [未来媒体艺术：关于网络艺术与实时互动的访谈](https://www.artda.cn/xinmeitidangan-c-2626.html?utm_source=chatgpt.com)——包含李颂华《远程写生》的作品介绍。  
2. [中国新媒体艺术展览大事记（2000—2020）](https://www.artda.cn/20222023nian-c-12027.html?utm_source=chatgpt.com)——中国新媒体艺术的重要历史事件。  
3. [我国互联网直播业发展综述](https://media.people.com.cn/n1/2017/0320/c411694-29156478.html?utm_source=chatgpt.com)——人民网，2017年。  
4. [易观分析：直播跻身移动互联网风口](https://www.analysys.cn/article/detail/1000010?utm_source=chatgpt.com)——中国直播商业模式的发展。  
5. [网络直播的日常展演与场景魅惑](https://www.cssn.cn/xwcbx/__deleted_2022.12.31_13.46.18__xwcbx_xkqy/202208/t20220802_5440114.shtml?utm_source=chatgpt.com)——网络直播的视觉文化与社会学研究。

**下一章建议：**

**011 中国移动短视频的兴起与网络影像文化的转型（The Rise of Chinese Mobile Short Video and the Transformation of Online Visual Culture）**

重点研究：

* 011.001 智能手机与移动影像生产  
* 011.002 GIF、微视频与早期移动视频文化  
* 011.003 秒拍与小咖秀  
* 011.004 美拍与女性化影像表达  
* 011.005 快手与草根影像文化  
* 011.006 抖音与算法驱动的影像传播  
* 011.007 B站与青年视频创作文化  
* 011.008 短视频与网络艺术的关系  
* 011.009 中国移动影像文化的形成

这样，009研究视频网站，010研究实时直播，011研究移动短视频，三章分别讨论三种不同的网络影像传播形态，不把它们混在一起。

