# **02\. 流媒体视频艺术（Streaming Video Art）**

# **005 宽带互联网与视频传播革命**

*Broadband Internet and the Video Distribution Revolution*

[30 anos da internet no Brasil: entre revolução e desafios](https://images.openai.com/static-rsc-4/q0bCz3-ZahpZmuJhi18BAgxUK35yjVCnYM3tqiCV15TWDVCiJnz5RlEQZipVqOw0WA8_HWrWB_BTkrO_uhW4u7nlv9AAcdroOXIZqzXE_vdagSlwW8laBb-8ctt6dYLKe_ENcOmKCboCOx44crh3bU9_5LTc7i-CB2o8iispqmw?purpose=inline)

[ブロードバンド百景](https://images.openai.com/static-rsc-4/72AYS8tgQAzHZ-EFtT2nDHUsHysML8aTxEQ3CfbmRsi8A2M77H0iU7UAapa9hDo1opCLr0xX39NU9rc4kc91CGKgxTILPzd0CUH6SWXmwRfdsCRrD_IE8Od2mb-xJWL9LC56fRUmS7ZQJqGe6NWWIxzqHWu93OnzPTGplfIZMCM?purpose=inline)

[El primer video publicado en YouTube se convierte en pieza de museo en Londres \| La Nación](https://images.openai.com/static-rsc-4/NGZzr5I_6EPH1lW04YhpMegxw3K_AG2LeTVwytdZwPWDenA7VuqNSZroEC0Ivpir1aSJR3z4eM7c3XnPm8CNudJEVYcmSA1J7UvpZ37ExsbyEOneWh5NylYR1Avr8cJDY2FlDFT2ZRWY-PkcX5sH0YtOOoGJbbYaWr8--G0tI-I?purpose=inline)

8

## **导言：互联网如何从信息网络变成影像传播媒介**

20世纪末至21世纪初，互联网发生了一次深刻的媒介变革：它逐渐从以文字、电子邮件和静态图片为主的信息网络，转变为能够持续传播声音、动画和动态影像的多媒体环境。

这场变化并不是由某一项技术单独造成的，而是多种技术共同发展的结果：

1. 宽带互联网提高了数据传输能力。  
2. 视频压缩技术降低了影像的数据量。  
3. 流媒体技术改变了视频接收和播放的方式。  
4. 在线视频平台降低了视频发布和传播的门槛。  
5. 内容分发网络使视频能够面向全球大量用户传播。  
6. 数字摄像设备和个人计算机使普通用户也能够参与影像生产。

这些变化不仅影响了电影、电视和大众娱乐，也深刻改变了当代艺术。

对于流媒体视频艺术而言，宽带互联网提供了一个此前并不存在的创作环境：艺术家可以利用网络传输实时影像，让不同地点的观众共同观看作品，甚至让远程参与者直接影响作品的发展。

因此，我们研究宽带互联网，不只是研究计算机通信技术，而是在研究一种新的影像文化如何形成。

## **第一节 拨号互联网时代：视频传播的技术限制**

### **1.1 拨号上网的基本原理**

在20世纪90年代，普通家庭主要通过拨号上网（Dial-up Internet）接入互联网。

用户需要使用调制解调器（Modem），通过传统电话线路连接互联网服务提供商（ISP）。

调制解调器负责在计算机的数字数据与电话线路能够传输的信号之间进行转换。

[US ROBOTICS SPORTSTER OPERATING INSTRUCTIONS MANUAL Pdf Download \| ManualsLib](https://images.openai.com/static-rsc-4/DGXQDaS4uobHSIpdh2KEeVIPFJB8CdxnOsXW0foEupBdmW0PqGnaPckvtJ-4eRUxDWILpW2XSqa61u00iAGISsY9gWsKoPshFAObWnTKNwplfAyX-S8KHuY977ZFL6z5alS1niTIHF_8W2luduRqJ6-OZ6a15p75absIYYfQwM0?purpose=inline)

[Elementos necesarios para la conexión de internet :: Redes de computadoras e Internet](https://images.openai.com/static-rsc-4/wdmBAkF26jeUzyVzvFkBKYqoJWoztLoEovgN3VEX-5L2XGyz6vhXM16Lv6l8Mxf3N-TOKyV25-xsmWQH5vojO2EjrQpSxUtuqfmQPdZ0fC5YQ2xS2XY7f8KR5KnpuxMRd229sAlaALOns_dXy3FqCGA0duEy9oXzGH3qzXlmqPU?purpose=inline)

[Fotogalerie: Vzpomínky uživatelů Technet.cz na internetová léta 90\.](https://images.openai.com/static-rsc-4/FxTysCGDrOlq_-39q4CqhIkI78IbJWNvV-znAh34MV1ADrxY4MeonHby_IvVW2M6KP7e8YlWCwYNX0OmtRWukF4G6ZEEnysio9Ng5Ol4nLPyFFO0MrJNS2KtMdOxemVZ31RHn1fqrorU1Pzy1Mo2H3hjlN1GpBi5esAbdj68aa8?purpose=inline)

7

拨号上网具有几个明显特征：

* 需要通过电话线路建立网络连接。  
* 连接过程通常伴随拨号声音。  
* 网络速度受到电话线路和调制解调器性能限制。  
* 传统拨号连接通常无法同时正常使用同一电话线路通话。  
* 下载大型文件需要很长时间。

当时常见的调制解调器速度包括14.4 kbps、28.8 kbps、33.6 kbps和56 kbps。

这里的kbps是每秒传输的千比特数（kilobits per second）。

### **1.2 为什么拨号时代很难观看视频？**

视频由连续排列的图像帧组成。

假设一个视频每秒播放30帧，每一帧都是一张独立的图像。如果每张图像都未经压缩，视频产生的数据量会非常庞大。

在56 kbps的拨号网络中，即使只是下载一个100 MB的视频文件，理论上也需要约4小时。

这意味着：

* 用户很难快速下载完整视频。  
* 在线播放容易出现长时间缓冲。  
* 视频通常需要降低分辨率。  
* 画面帧率和声音质量受到限制。  
* 长视频的传播成本较高。

因此，早期互联网主要以文字网页、电子邮件、静态图片和小型动画为主。

不过，视频并不是完全无法在拨号时代传播。RealVideo等早期技术已经尝试以极低码率传输动态影像，只是观看体验与后来宽带时代存在很大差距。

### **1.3 早期网络的视觉文化**

[Internet](https://images.openai.com/static-rsc-4/ZZ2c83EiHEa7XDd54iNxJkVru-yH0siLz8_emRH1r7cg1vcZqoQo8Eo175U7c-YnGs-bwfcTi9DKQ-6js9RV6f_IHGkNCBhxDZJzRmSLCjQSaJhMMEU62KKyx1MEjsm0iR_kWQ-WxmTHkoLCTCk-sYfauxAqWZ72ySD69xKI34Y?purpose=inline)

[窓の杜 \- ストリーム再生機能を大幅に強化した「QuickTime 4」Preview Release](https://images.openai.com/static-rsc-4/mcOlX6d1kuv-eb-DXOKGGovc44GwuAkVUWK7719Ue0g6dGre8_CDAa51n3V5Ev1YOc-azlCxtcVvzAuUc34dZch6t1F0W4UKFJ_VJBMoYOJwUiH1zFzEl8LXklpJM2uI6hSXK8grvs3AZEs5pa_gxqFJkzgu9J9XlcatZ35_Ttc?purpose=inline)

[Geocities Is Back (But a Lot Better) \| by Clancy Dennis \| Jan, 2026 \| Medium](https://images.openai.com/static-rsc-4/xqgc1GvI3uuXiOb1_JVE4f1unYMvkU3110n5-iWqdQ9S4-IeWQ8a8SXuFW0nsK5jv7p-iA1w6EQE_AkcyFYxxzCAswdelhI_hiBcXLc6bSNarpanoEGVCXsivAmD4uaUdIGSU6Kge6vLjtIwM59snhC5Qk7satZ_cWJ_W56j77Q?purpose=inline)

11

早期网络视频具有一种特殊的视觉风格：

* 小尺寸画面。  
* 低分辨率。  
* 较低帧率。  
* 强烈的压缩痕迹。  
* 画面和声音偶尔不同步。  
* 播放过程中出现缓冲。

今天看来，这些现象似乎只是技术缺陷，但它们实际上构成了早期网络影像文化的历史特征。

后来，一些数字艺术家开始主动利用低分辨率、压缩失真和网络延迟进行创作，使原本的技术限制转化为视觉语言。

## **第二节 宽带互联网的兴起**

### **2.1 什么是宽带互联网？**

宽带互联网（Broadband Internet）不是某一种单独的通信技术，而是对具有较高数据传输能力的互联网接入方式的统称。

20世纪90年代末至21世纪初，宽带逐渐进入家庭、学校和商业机构。

与传统拨号方式相比，宽带能够提供更高的传输速度和更稳定的连接，使用户可以更方便地访问大型数字内容。

宽带发展的主要技术包括DSL、有线电视宽带和光纤。

### **2.2 DSL：数字用户线路**

DSL（Digital Subscriber Line，数字用户线路）利用传统电话铜线传输数字数据。

其中最常见的一种形式是ADSL（Asymmetric Digital Subscriber Line，非对称数字用户线路）。

ADSL通常将较多带宽分配给下载，将较少带宽分配给上传。

这种设计适合当时的家庭互联网使用习惯，因为用户通常需要下载网页、软件、图片和视频，而不是频繁上传大型文件。

[ブロードバンド百景](https://images.openai.com/static-rsc-4/72AYS8tgQAzHZ-EFtT2nDHUsHysML8aTxEQ3CfbmRsi8A2M77H0iU7UAapa9hDo1opCLr0xX39NU9rc4kc91CGKgxTILPzd0CUH6SWXmwRfdsCRrD_IE8Od2mb-xJWL9LC56fRUmS7ZQJqGe6NWWIxzqHWu93OnzPTGplfIZMCM?purpose=inline)

[bb.watch.impress.co.jp](https://bb.watch.impress.co.jp/column/hyakkei/2002/06/12/?utm_source=chatgpt.com)

### **2.3 Cable Internet：有线电视宽带**

有线电视宽带利用原本用于电视信号传输的同轴电缆提供互联网服务。

[Motorola SB5100 DOCSIS 2.0 Cable Modem](https://images.openai.com/static-rsc-4/zyqodi8YbK1L8bqJQ2kmip508iMfvuF4H6QFtf-NEn9rxQeFRAHgupQiwAqxM_Y4HBaVQQjLR_Z-ooptZ-AFJkpfeUSiYhyanvyHXEDsACJpnTotwJe-jA4DXMo-2OQG3SbJSzfyiHHNmDkR1IifqPkZ-YqU8LVSICVcPzVqaJE?purpose=inline)

[hardwarejet.com](https://www.hardwarejet.com/motorola-sb5100.html?srsltid=AfmBOornlPLD5IG2zwFTHKpx3mITlzmDlEhto3SXif62X37YUqdDjgFU&utm_source=chatgpt.com)

这种技术在北美家庭互联网发展史中具有重要地位。

它使有线电视运营商能够利用已有网络基础设施提供互联网接入服务。

### **2.4 Fiber-optic Internet：光纤互联网**

光纤通信使用光信号传输数据。

与传统铜线相比，光纤具有较高的传输容量和较低的信号损耗，能够支持大规模数据传输。

[Claro compra Desktop e acelera consolidação na fibra óptica](https://images.openai.com/static-rsc-4/UpN5EyKKb3HuejPAtAdPDi1tS2J0nXUSQnpFsAnigNuXi__UTqbycmq2-BtpixCAJU_ISsHQdP3_zdVpDtQXMrrEToKKRJm6hLPzA_tSajrVbrs8mnO_el9qcc7blT0_Ca5QsMhOjZt84QTpwktBwnU5z6aNMut-2vxNbeqHDLY?purpose=inline)

[investnews.com.br](https://investnews.com.br/negocios/claro-paga-r-4-bilhoes-pela-desktop-e-acelera-consolidacao-da-fibra-optica-no-interior/?utm_source=chatgpt.com)

随着光纤通信网络逐渐发展，互联网开始具备支持高清视频、复杂在线服务和大规模实时影像传播的技术基础。

### **2.5 宽带如何改变视频文化？**

宽带普及以后，互联网用户能够更加方便地：

1. 在线观看视频。  
2. 下载较大的视频文件。  
3. 上传个人拍摄的影像。  
4. 观看网络直播。  
5. 参加视频会议。  
6. 通过网络分享和传播影像作品。

最重要的变化是：视频逐渐从一种相对特殊的网络内容，转变为普通用户日常使用的媒体形式。

这为后来YouTube、Vimeo和各种流媒体平台的发展奠定了基础。

## **第三节 数字视频压缩技术的发展**

### **3.1 为什么视频需要压缩？**

宽带提高了网络传输能力，但视频文件仍然非常庞大。

一段数字视频由连续图像帧构成。画面分辨率越高、帧率越高、色彩信息越丰富，通常需要处理的数据量就越大。

因此，网络视频必须使用视频压缩技术（Video Compression）。

视频压缩的基本目标是：尽可能减少需要存储和传输的数据，同时保留足够的视觉信息，使视频能够被有效播放。

### **3.2 空间冗余与时间冗余**

视频压缩主要利用影像中重复或相似的信息。

**空间冗余（Spatial Redundancy）**

指同一帧画面内部存在大量相似信息。

例如，一面白色墙壁上的相邻像素往往具有相近的颜色和亮度，因此没有必要把每一个像素都作为完全独立的信息处理。

**时间冗余（Temporal Redundancy）**

指连续视频帧之间存在相似性。

例如，一个人在房间里讲话时，背景可能在连续几十帧中几乎没有变化。编码器可以利用参考画面描述后续画面的变化，而不是每一帧都完整记录。

[PPT \- High-definition video recording in defence and aerospace applications Andrew Haylett PowerPoint Presentation \- ID:2396420](https://images.openai.com/static-rsc-4/adDd-KwMzNx0Ds-7ceAOUv6P0w40NT47cots2vdUQSf-EHLadHKnusNZxHCEID2lCCrBp94ZFcFa_cRHOt-4U2lX8HsJP7Ir9PGtUsnMsfJb4VRDBXGSiyDhX-dxdUKL9IEmnCC-7xoAiup_k0S0Bfj3sLqbI4057Y6CG2eTW4Q?purpose=inline)

[slideserve.com](https://www.slideserve.com/sondra/high-definition-video-recording-in-defence-and-aerospace-applications-andrew-haylett?utm_source=chatgpt.com)

### **3.3 MPEG标准的发展**

MPEG（Moving Picture Experts Group）是推动数字音视频编码标准化的重要工作组名称，也常用于指称其制定的相关标准。

主要发展包括：

| 标准 | 时间 | 主要用途 |
| ----- | ----- | ----- |
| MPEG-1 | 1993年 | VCD及早期数字视频 |
| MPEG-2 | 1995年 | DVD、数字电视 |
| MPEG-4 | 1998年起 | 数字多媒体与网络视频 |
| H.264/AVC | 2003年 | 高清视频及互联网传播 |

### **3.4 H.264：互联网高清视频的重要基础**

2003年，H.264/AVC标准正式发布。

它由ITU-T和ISO/IEC相关专家共同制定，是互联网视频发展史上非常重要的编码标准。

[High Efficiency Video Coding H.264/MPEG-4 AVC Diagram Video Coding Format Ffdshow PNG](https://images.openai.com/static-rsc-4/cdrZw5QkJCKIABHtTcuyT4eW1eecK0II49Wx9UJdWLROm4tvEM7iDNl2Azyv3TY0I1DuCP1IkPLNAZexFq3yQTttp3eQeWcd6itT92C1A0rxd5kJc0rsT4pdLGGDmc2ykgH5GWXUN5n5Z_NV0oRlWgYsyJcgJ2jJS2_hsqVnnuA?purpose=inline)

[favpng.com](https://favpng.com/png_view/cloud-security-high-efficiency-video-coding-h-264-mpeg-4-avc-diagram-video-coding-format-ffdshow-png/gDAuBY1Z?utm_source=chatgpt.com)

H.264通过改进预测、变换、量化和熵编码等技术，提高了视频压缩效率。

这使得相对有限的网络带宽能够传输质量更高的数字视频。

H.264后来广泛应用于：

* 网络视频平台。  
* 数字电视。  
* 视频会议。  
* 高清摄像设备。  
* 手机视频。  
* 网络直播。

  ### **3.5 压缩失真与数字故障美学**

视频压缩并不是完全无损的。

当编码器试图进一步减少数据量时，可能造成画面细节丢失、边缘模糊、色彩变化和块状失真。

[Video Compression Artifacts Explained: Causes, Fixes & AI Solutions \| Zawa (formerly X-Design )](https://images.openai.com/static-rsc-4/Qv09M8ZlQfA77K5HCEL1y9Q7dN4_jcyrJu9JaSYoBTnRE7uYjbgdqKat7gJxFVt2Ostrn5VOBjztx3iLpnk0dRIeGtsXmmJ7uFXCPYiZIqFvEW69uzb0lwR6ZyLCdEgJaDJu6Q-17g2t5FpVL8jkPWiH3I7ve0MHn7mJlOxNqrQ?purpose=inline)

[Fast-MFQE: A Fast Approach for Multi-Frame Quality Enhancement on Compressed Video \| MDPI](https://images.openai.com/static-rsc-4/qW1VyWYjzH2AzL6LjJpGIrLf3zL8bR_qnFPrWWrZE-VwgaWvdiVZb29YR8xYLFEaVkBA6RKFiDs0zw_fD6DaUFLNuhJUwZhtbd4SLe253FTke62DUTGFsnYAW2gu0l83ebrNIBRQzWWfsGnyZSfjdFVO0U1XfLnuYnxDv9ru33I?purpose=inline)

[Unique Design Abstract Digital Pixel Noise Glitch Error Video Damage](https://images.openai.com/static-rsc-4/FXJssEsCn5lRnG6r3Yil7BAcwo8ISmCWm8LZ9429B_1qvUrugEeIbPsbe-Rf57P5oFxSlxolAy9LcZOBauZf19LZZkqhMnmTpTbubh5gjZfUwcVqcGLrSPU5EUHC8B4UHQaj3vp8gSj5Mtj4awU1KZqyKNP-Y42JzkttkwGj_69KQgUEPGQ_pXNE9JaWKP6Q?purpose=inline)

9

这些视觉异常后来成为数字故障艺术（Glitch Art）的重要材料。

例如，Datamoshing是一种利用视频压缩帧之间的预测关系制造视觉异常的技术。

艺术家可以通过修改视频数据，使原本应该消失的上一帧画面继续残留，并与下一帧融合。

这种现象使数字视频的编码机制本身成为艺术创作的对象。

这里出现了一个重要的艺术史转变：

传统影像艺术家主要处理摄影机、录像机和屏幕；数字影像艺术家则可以进一步处理文件、编码、压缩和数据结构。

## **第四节 从视频文件下载到流媒体播放**

### **4.1 早期网络视频的下载模式**

在流媒体普及之前，用户通常需要先下载视频文件，再使用本地播放器观看。

常见的视频技术包括：

* AVI  
* QuickTime  
* MPEG  
* RealVideo  
  [窓の杜 \- ストリーム再生機能を大幅に強化した「QuickTime 4」Preview Release](https://images.openai.com/static-rsc-4/mcOlX6d1kuv-eb-DXOKGGovc44GwuAkVUWK7719Ue0g6dGre8_CDAa51n3V5Ev1YOc-azlCxtcVvzAuUc34dZch6t1F0W4UKFJ_VJBMoYOJwUiH1zFzEl8LXklpJM2uI6hSXK8grvs3AZEs5pa_gxqFJkzgu9J9XlcatZ35_Ttc?purpose=inline)  
  [Windows Media Player 7 .1 \- Télécharger pour PC Gratuit](https://images.openai.com/static-rsc-4/HJT-U9hvc7o-Ztwq8X--3Ter5AARq6OP6aYJ1sldb2FNldC06-ElMxVWQDKedWYoYersGcHEZTRY83w2GykMaFC4oal8mO6j4lflU2Oi9gbb_NMAkEmUyjCWBkLrUA7r2FbO6F_pTZjttflRDb8ZLh56v5F5Tkr6K796AK65y9E?purpose=inline)  
  [QuickTime Videos display no picture (audio works) \- E-Maculation](https://images.openai.com/static-rsc-4/EsC3xRomsVXYwtYT0Ca-hnUkevALTAZtT6qQhR9CF6VyKu2pkuD-w8wQppu4G6Qk8Oh6r5W-VxBcfMvAuR0pzwipzAcuvY1Yms6owlXBl5GKVh-0K2AKCWn8JFUIPdVng9VMpmGGbhX7icHUHx8LG8aG4bzcIMgopBzKnC_KSGo?purpose=inline)  
  6

这种模式将获取文件和观看影像分成两个相对独立的阶段。

用户需要先找到视频文件，等待下载，然后打开播放器。

当视频文件较大时，这个过程可能非常漫长。

### **4.2 RealNetworks与早期流媒体**

[RealPlayerの新バージョン「RealPlayer 7」β版登場](https://images.openai.com/static-rsc-4/y33Q1GYi7-tpKbiJ5SoT-ajBwLQ8ovPE-ffSu3TZaHBTkjRwvTPwAWJeGx5jFH1nhAPbWvOvd2-_tdr9140faaYULcWY3IfN5-tdQSQ570AmCH0keN_yhbe1IxF5n4tofu_SGNw4JROVlKSVBJcjcUr2OsaeeN0S3yfqIng5B1w?purpose=inline)

[internet.watch.impress.co.jp](https://internet.watch.impress.co.jp/www/article/1999/1108/real7.htm?utm_source=chatgpt.com)

1995年前后，Progressive Networks推出RealAudio，推动了早期互联网音频流媒体的发展。

随后，公司发展出RealVideo技术，并逐渐形成RealPlayer播放器体系。

RealNetworks 是早期互联网流媒体产业的重要参与者。

RealPlayer使用户能够在接收数据的过程中开始播放音视频，而不必等到整个文件全部下载完成。

这就是流媒体（Streaming Media）的重要特征。

不过，早期流媒体仍然受到带宽限制。画面往往较小，帧率较低，网络不稳定时还会出现缓冲和播放中断。

### **4.3 渐进式下载与真正的流媒体**

需要区分两种技术：

**渐进式下载（Progressive Download）**

视频文件从服务器逐渐下载到用户设备。播放器可以在下载到足够数据之后开始播放，但文件仍然按照下载过程逐渐传输。

**流媒体传输（Streaming）**

媒体数据按照播放需求持续传输，播放器通过缓冲和媒体传输机制维持连续播放。

两者可能产生相似的观看体验，但底层机制并不完全相同。

对于流媒体视频艺术史，这一区别非常重要。

如果艺术作品只是将传统视频文件上传到网站，那么互联网可能只是它的发行渠道。

如果作品依赖实时传输、网络延迟、远程连接或观众互动，那么网络就可能成为作品本身的构成条件。

## **第五节 视频点播与直播：影像时间结构的变化**

### **5.1 视频点播（Video on Demand）**

视频点播（VOD）是指用户能够自行选择视频内容，并在自己决定的时间观看。

传统电视按照固定节目表播放内容，而视频点播将部分时间控制权交给观众。

[A Brief History of Netflix Personalization \| by Gibson Biddle \| Medium](https://images.openai.com/static-rsc-4/IXZy_QnM8YYlES2MQkBjtPfChhrvBPZMb8FF-3ZmqU8es_9r-L9TZSfnrlGuycdpSJsihaez_3SC0ha6VDQN9hBQbrWrdA19JLTFnfcjtWInxZXZNO0R9hGQ_28ptqfOMEHUscMesGY1BAuo6Z03eA8wa_sd1ha7y2HWDoPOb3c?purpose=inline)

[中華電信 MOD 家庭豪華套餐 HD 頻道及新功能齊測 \- Mobile01](https://images.openai.com/static-rsc-4/aniNbcLVDZ_U816yX2SuwUK2VAG0FzOWUgGeq7hwymKj4if0tJ46v_19lrnM1fS3eZt5Jqh2NguZsqzA3LjmksRX2BCZwDNFpcjochsl5f0kWDtxaH1Vb-a-Sx2XAi7BqwY01NrzeBn2af_xDWepw2rdS6_kQDH9YSxuSL4ZdMk?purpose=inline)

[Netflix: la renta de películas y series en línea inicia en México el lunes](https://images.openai.com/static-rsc-4/3ruaouBxk7CqzT13LG5QOKX4u9msURZIf6i1aanA-QaJOT_gvc8Wpn4LhcnTVatbV8BUFikkntw_7Vu77R2hGIovra6j85ipkcLyOlYeCzKesMFUPA9h7QoN_8ZNA7VtaxYonjT0z5YCyIjXSUQTwcjVyDEl5gRnJHz17sSV9nk?purpose=inline)

8

用户可以自主决定：

* 观看什么作品。  
* 什么时候开始。  
* 什么时候暂停。  
* 是否继续观看。  
* 是否重复播放。

视频点播的发展依赖数字视频编码、存储系统、视频服务器、网络带宽和播放器等技术。

它改变了影像作品与时间之间的关系。

作品不再必须与某个固定的广播时刻绑定，而可以在较长时间内等待观众主动访问。

### **5.2 网络直播（Live Streaming）**

网络直播是将正在发生的影像和声音通过互联网传送给远程观众。

与点播相比，直播更加重视事件发生与观看之间的时间关系。

[25 jaar WWW: van krakerig inbellen naar supersnel streamen](https://images.openai.com/static-rsc-4/abHoee3E-nUGwYi1sqHe1AxC0G-xG6IQJcnR59crhL8YrXdmDg3ngbS1WGeJNxihA_DvfeOcE07NQ6rsHQu-UNYaHCf_4OVK6VIjlgpi325k4JlDiG0s3DaJ8bMpqIsvyk4jAczz5qXIhjxSt5FDf7h5io6Nz_i7R-twZcL60rU?purpose=inline)

[Complete Guide to IRL Streaming \| UnlimitedIRL](https://images.openai.com/static-rsc-4/AuULQ7AgiI6RqLUhoh3Z8RehQoA0Zve5UE9PbJrFoX0CR1pb-qnohw6GGl_jo7cwerCXJgdi051omQ27D_Egc5azjzvydmsMLlkYK_h5xxF2AIw5MENLfr8VJfQ3O87DmTK9AEOGYIAIGZkwCNMOuuk1T2ZkhCQCscBX-k7Fy9Y?purpose=inline)

[RYTHEM生配信で解散を発表！Zepp Tokyoでラストライブ \- 音楽ナタリー](https://images.openai.com/static-rsc-4/rmfiOjQBsaPrWux1rjUizvZQrkGPpt1N1p6UwxBSU_6NhFfKcm4u9LwP8kru9jSXJ06UnAAJdmFFhI7Mu80z3yEDqS1jIr-kSuUkTvTbZaqrfNc-Xj6RdV8vl5gCFV97xlKlwM9uF6nDdCIFn7hup79xDIEhAdhN5sT--QqE6ro?purpose=inline)

10

网络直播具有几个重要特征：

1. 实时性。  
2. 时间上的不确定性。  
3. 远程观看。  
4. 潜在的实时互动。  
5. 观众之间可能存在网络延迟。

需要注意，网络直播中的实时性并不意味着绝对同步。摄像、编码、传输、缓冲和解码都会产生延迟。

对于艺术创作而言，这些延迟甚至可以成为作品的一部分。

### **5.3 点播艺术与直播艺术的区别**

| 比较维度 | 视频点播艺术 | 直播艺术 |
| ----- | ----- | ----- |
| 时间结构 | 相对固定 | 持续变化 |
| 观看时间 | 观众自主选择 | 与事件时间相关 |
| 内容状态 | 通常提前完成 | 可以正在生成 |
| 观众参与 | 评论、选择、互动 | 实时参与、反馈 |
| 重要艺术问题 | 剪辑、循环、观看顺序 | 在场、延迟、偶然性 |

两者共同构成了现代网络影像艺术的重要基础。

## **第六节 Netflix与家庭视频消费的变化**

### **6.1 Netflix的早期历史**

[Wayback Machine Project \- Home](https://images.openai.com/static-rsc-4/HvcNgFpRPvIaU_6x3AQxEeIBhZKg1WGzMHQbAnGWd-N6fEXp7pQBYFzNghXpz3HQSYiPGSIgP92LFmxFwelW9EYkwzaQsV5Rr7VT22uTCdU5QB8-jCsWADwH6qt8QxLDrtYYO-dgqa11W96zliB_ghJHjHuIdMp34nD2J243ZQ0?purpose=inline)

**Netflix**

1997年成立，最初主要经营DVD邮寄租赁业务。

1998年，Netflix开始提供DVD邮寄租赁服务。

2007年，Netflix推出互联网流媒体观看服务，逐渐从实体媒介租赁转向在线视频服务。

[Wayback Machine Project \- Home](https://images.openai.com/static-rsc-4/HvcNgFpRPvIaU_6x3AQxEeIBhZKg1WGzMHQbAnGWd-N6fEXp7pQBYFzNghXpz3HQSYiPGSIgP92LFmxFwelW9EYkwzaQsV5Rr7VT22uTCdU5QB8-jCsWADwH6qt8QxLDrtYYO-dgqa11W96zliB_ghJHjHuIdMp34nD2J243ZQ0?purpose=inline)

[A Brief History of Netflix Personalization \| by Gibson Biddle \| Medium](https://images.openai.com/static-rsc-4/IXZy_QnM8YYlES2MQkBjtPfChhrvBPZMb8FF-3ZmqU8es_9r-L9TZSfnrlGuycdpSJsihaez_3SC0ha6VDQN9hBQbrWrdA19JLTFnfcjtWInxZXZNO0R9hGQ_28ptqfOMEHUscMesGY1BAuo6Z03eA8wa_sd1ha7y2HWDoPOb3c?purpose=inline)

这体现了家庭视频消费方式的一次重要转变。

过去，观众需要购买或租赁录像带、DVD，才能在家中观看电影。

互联网流媒体则使视频逐渐成为可以随时访问的网络服务。

需要注意，Netflix主要属于商业视频传播史，而不是流媒体视频艺术史。它的重要性在于改变了大众观看视频的习惯，为网络影像艺术的传播创造了更成熟的社会环境。

## **第七节 YouTube与用户生成视频文化**

### **7.1 YouTube的诞生**

[YouTube classic logo vector PNG \| YouTube red play-bar emblem \- freepng](https://images.openai.com/static-rsc-4/bZFHDj79nsOQJBk9Uq5wA_Nys7ymZElHxdte9Npj4s-M5VYAcyMxlGAXaf69MvgpVFXRqvZSzJGC2gUDxZjPXFsU04og2XXjB-YuvIWoSUXJE2m2qx4h8SO74F7cNL7W407rhCQ7MtefJmny7c1T9ZQIPPuZ1V53xgrc4brjrj4?purpose=inline)

**YouTube**

2005年成立，是互联网视频分享史上最重要的平台之一。

YouTube的创立改变了普通用户发布视频的方式。

在此前的互联网环境中，个人发布视频通常需要自行寻找服务器、建立网站、处理视频格式和网络带宽问题。

YouTube将视频上传、托管、播放、搜索和分享整合到一个平台中。

[A Breakdown of YouTube from an Information Architecture Lens \| by Paniz Amirnasiri \| Medium](https://images.openai.com/static-rsc-4/nK6M_3sbRsiuVZsYLaCn8B_-p0Xgajsmhu3fsDUsIpJzO6F1KXISE9zn7F4dyr9AXqSgKXzpf89jiw4sAQ1nPA68KtGLbDjoA0aRB0UHxeywcfjEnW2Udp2x08Mg0LOAXjHI4JTrzuqXjMJ1-iT8Pi5xRN9lc6p-J7sYFeO7I2g?purpose=inline)

[Think YouTube is just for content creators? This YouTube video now sits in an art museum (yes, really\!) \| Digital Camera World](https://images.openai.com/static-rsc-4/fiGhSjkxz0kFrlXrKiSSfQT684SQ2Y5dfrxo1Lk-FFCNmGAjJVoDSIMxucJ9y-rmyKH0xMk8yjkdsK5EABIcAvzd34uDSUeYmd_4JSiHM2d077sQZT2WuQhlLdJ4uPWdZFkrHxBA3fVpO4NXaxwXmmMq4jYfSLdyGewoBNTxc1I?purpose=inline)

[YouTube faz 16 anos: relembre o início e as mudanças na plataforma de vídeos](https://images.openai.com/static-rsc-4/ZlHLFvcv5yZdVknCQD--hGdpNaZjZ7GRyBIiHxwv7h_lbjAyQZPt9BGGSIXxeyDRXIuTbf3Yee1BBetJfqMNsJ26OVaOwyQ1-rgF6vV7Od3OqQsa6-rJzq8nLf7o7GC44aPMBxZDNbupaC-wdIDucYnkpHp910OcELzzxLE1exk?purpose=inline)

6

早期YouTube的重要功能包括：

* 用户上传视频。  
* 视频标题和标签。  
* 搜索视频。  
* 评论和评分。  
* 分享视频网址。  
* 将视频嵌入其他网站。

这使视频逐渐成为互联网社交和文化交流的重要媒介。

### **7.2 《Me at the zoo》：普通人影像的全球传播**

[Me at the zoo, a 20 años del primer video subido a YouTube](https://images.openai.com/static-rsc-4/GXsDLVzVR6t3CBoaICelabjiX_kDsRa_HMa1jBnCEF-4BsOP8BMlTEAbqlbMjkBSBYSf4Mq2in59LLRKBBBZG7jcN-jN7clktJ_wXxc6hz2Jc6wG3nNhg_MmF7QuI0_w9JzjECeuf1Zi7NyTva2T5ZnRbl1QhUQJzOGWd4qLCbA?purpose=inline)

[ambito.com](https://www.ambito.com/tecnologia/me-at-the-zoo-20-anos-del-primer-video-subido-youtube-n6137689?utm_source=chatgpt.com)

《Me at the zoo》，Jawed Karim，2005年4月23日。

2005年4月23日，YouTube联合创始人Jawed Karim上传了《Me at the zoo》。

这段约19秒的视频记录了他在圣迭戈动物园的大象围栏前讲话。

它并不是一件专门创作的视频艺术作品，但具有重要的网络文化意义。

它展示了一种新的影像生产模式：

普通人可以直接通过互联网向全球观众展示自己的日常生活。

过去，普通人的生活影像通常只在家庭录像带或私人社交圈中传播。

而在线视频平台使这些影像能够进入公共传播空间。

### **7.3 用户生成内容（UGC）**

UGC（User-Generated Content）是指由普通用户制作和发布的数字内容。

网络视频领域中的UGC包括：

* 个人生活记录。  
* 视频博客。  
* 游戏实况。  
* 教学视频。  
* 网络评论。  
* 实验影像。  
* 个人动画。  
* 独立短片。  
  [Think YouTube is just for content creators? This YouTube video now sits in an art museum (yes, really\!) \| Digital Camera World](https://images.openai.com/static-rsc-4/fiGhSjkxz0kFrlXrKiSSfQT684SQ2Y5dfrxo1Lk-FFCNmGAjJVoDSIMxucJ9y-rmyKH0xMk8yjkdsK5EABIcAvzd34uDSUeYmd_4JSiHM2d077sQZT2WuQhlLdJ4uPWdZFkrHxBA3fVpO4NXaxwXmmMq4jYfSLdyGewoBNTxc1I?purpose=inline)  
  [Telex: Videós randioldalnak indult, aztán felforgatta az egész szórakoztatóipart](https://images.openai.com/static-rsc-4/nXE9oML-b-J-_I_jluxahl54FCqOTwZbbZV3uoFK7qjN5YTpXCx38QG-aOsMPIHpMSFLMWcPUUb407g0GSCYxTVBC2OTpRGTaS9eqNI8zxfknOj6o30Wh_sNuxt9QMt-jJTl-3qLQwc_k5gd7VpyBDyCBOmaHGCHPmXtw-gJVeA?purpose=inline)  
  ["창업의 시작은 아주 작은 아이디어로" 유튜브 창업자의 사업개발 스토리](https://images.openai.com/static-rsc-4/rfMBwLDc_WgxCVDYya8Qb40Qv1hWBDQJxB9n-B1hn2a_YEFZXkrhy284wixcS3pl1eC2_YJEvNvlPT2LOjQNcyn4fL9gDmCGFsK8Ns3Fe1seoHuOaUyxOM_TjNMeyZue-XH3CAGYniVVjSKqtiEs3JdjXHwO8V3p0dFyEc2RgXc?purpose=inline)  
  9

这种生产模式改变了传统媒体中生产者与消费者之间的关系。

在传统电视产业中，节目通常由专业机构生产，再由电视台向观众传播。

而在线视频平台使普通用户也可以成为影像生产者。

这并没有消除专业制作机构的作用，却使影像生产者的范围大幅扩大。

### **7.4 Vlog与个人影像表达**

Vlog是Video Blog的缩写，即视频博客。

早期Vlog通常使用个人摄像机、数码相机或电脑摄像头拍摄，创作者直接面对镜头讲话，记录生活、观点和个人经历。

[lonelygirl15: The Pleasures and Perils of Participation – Flow](https://images.openai.com/static-rsc-4/oj8p8bEzqKeUpmcTn0zIo6AQ-wmDaFWd77VFrUZ_P0NFfqJQlGF4VXY4aX5cEbqNTuugnqV8k4e8ywiQxb__rYgTZBX3yFoIu1AOx2FkAGaKCVuabZhEaha8T2joPKYFX1Fho46FobaKxeTGqkYdMxvNf8eZYcbeF5uLFk1n1cQ?purpose=inline)

[Jovens, vídeos e fama no YouTube \- RTP Ensina](https://images.openai.com/static-rsc-4/8DzhXte7_r4tWQzbV5FULnas548gYbzbbJajvVKfsUOffYJA4rjhMElTEUUU4icEdp6kTJ6gIdj1SaJsRsNDkksjiNBxcq4ypeZIQ9Lp-8DQ1RrmwAUIyIeuM4cj71dQi44A8C60JL2VETd9aTRTIcBkPJh3ZVquIejJtm0pQ14?purpose=inline)

[Pin by Sunshine Blocking Sunshine on Boyz with Chase \| Cute camera, Vintage camera, Camcorder](https://images.openai.com/static-rsc-4/ujWqJuQspwv4oHRvzlF9m00WzMtsbDaVzy85xmVkTVpmB5hdlma_6t_0iIk1CqziiBkbzpt3V3UMvRB61Mm3G-X2WbLVFYbduxMm0aCGKRLYvsjGN7FkuTZggThix9xs9B_TA7xnP_b0fU7oksrI_07sgy-mgxv_uSYBB3lvto4?purpose=inline)

11

Vlog具有几个重要特征：

第一，内容具有较强的个人化特征。

第二，制作成本相对较低。

第三，创作者可以自行决定发布频率。

第四，观众可以通过评论和交流参与内容传播。

Vlog的发展对网络影像艺术产生了重要影响。艺术家开始重新研究个人身份、身体展示、日常生活和镜头凝视等问题。

不过，普通Vlog并不自动属于视频艺术。判断一件作品是否属于视频艺术，还需要考察其创作目的、形式组织和观念结构。

## **第八节 Flash Video与网页视频时代**

### **8.1 Flash从动画工具发展为视频播放器**

Flash最初主要用于制作矢量动画、网页游戏和交互式多媒体内容。

随着网络视频需求增长，Flash逐渐加入视频播放能力。

2000年代，Flash Video（FLV）成为早期网络视频传播的重要技术。

[Macromedia Flash MX in 2002 \- Web Design Museum](https://images.openai.com/static-rsc-4/43gllI7F2FLh2qTYThXFhonCbmkduaMlxlyDEjbX2X65qQudN6BjmznNvSF80uT5PoTMM27uZkaLfLLQQDXqjAs4QnZKrLkfFWpHdUHtgAvXBpxKvsM1J6y5LmFIyPQ9BgQYZy0_ZomLxjERWLgGhfLzVQQxLU3qAAhYviopiDg?purpose=inline)

[Insert multimedia \- QuizFaber](https://images.openai.com/static-rsc-4/e7YMBrY438PTz4Eujfstp9CwaVoMWkx2VPYCNNqGUoXU4xByy6BWFfMmPjULViNmSTW2grCiRpsal-HkSfTa4I8VebsfP7-dMadIgeXUSRpc-eaT7Ea57MsHSPMN5xop72e4dBgj8qZpAIahW_w_AGDG2SX04o0nz-VY4ixWzfM?purpose=inline)

[FlowPlayer Flash \- Download \- Softpedia](https://images.openai.com/static-rsc-4/XyTGZj6Kd_l1MS7_vengYP61OcU81reStjlCn-3PIobFYuV6x_utzozvlH8qjEfXzzuIoxFY6fQ__HmuQ5Eu56lIU-Oz3k5N-4oCN8DlKWd3_1fyhrRe3FEXEyXLfrFRot0AhLYFHPnnCVAokEnnWEQg89SvBGOoNMjjDpWwNWE?purpose=inline)

7

Flash Video的优势包括：

* 能够直接嵌入网页。  
* 可以与网页动画结合。  
* 可以与互动按钮和其他界面元素结合。  
* 能够通过Flash Player提供相对统一的播放体验。

  ### **8.2 Flash Video与YouTube**

  [YouTube to block artists from paid music service: report](https://images.openai.com/static-rsc-4/FbCCGdv_q-qzsKaGbxL9RLiUJlJFtX23q8Auz0MtdeQ9CT7ZRT6wgtduScgViUtA9QNnwCYQGrhKZQLVfw0sNo7jWX0-lZUek6BHrjpT9YpiFjgnDGqSAC_tbfL-u2i9qcZMZf8xrhgbEUqw2AXqKv34WWYYVNtYm16B-szU1TU?purpose=inline)  
  [livemint.com](https://www.livemint.com/Consumer/BvWnHdtf849ZPqWc2PShfK/YouTube-to-block-artists-from-paid-music-service-report.html?utm_source=chatgpt.com)

YouTube早期使用Flash播放器，使用户能够直接在浏览器中观看视频。

这种设计减少了用户安装不同播放器和处理视频格式的麻烦。

不过，必须区分Flash动画和Flash Video：

| Flash动画 | Flash Video |
| ----- | ----- |
| 主要使用矢量图形 | 主要播放数字视频 |
| 通过时间轴生成动画 | 通过视频编码生成影像 |
| 支持ActionScript互动 | 支持网页视频播放 |
| 常见于网络动画和游戏 | 常见于早期视频网站 |

两者可以结合，但并不是同一种创作形式。

### **8.3 Flash的衰落**

Flash依赖浏览器插件，存在安全、性能、兼容性和移动设备支持等问题。

随着智能手机普及、HTML5原生视频能力发展，以及浏览器厂商逐渐停止支持Flash，Flash最终退出主流网页环境。

Adobe于2020年12月31日正式停止Flash Player支持，并于2021年1月12日起阻止Flash内容运行。

[Recovering Google Workspace: A Detective Story \- TidBITS](https://images.openai.com/static-rsc-4/YXUgcYIhOW_V4eLaZMl2q9V0TDnsZ1w7lCP9xUtx_d7HwK8TB557ZoXFlbDO-KA4OTw6v1NKmtK8HJHlFSB4I1eQwj8X4GaV9nkJBnf8Clgya-hcOHoa6pZVvvce5TZLRorA3kRjhu2PmOmEges95fsYyzhbNIBJWa0seguCkPY?purpose=inline)

[tidbits.com](https://tidbits.com/2022/10/03/recovering-google-workspace-a-detective-story/?utm_source=chatgpt.com)

Flash的退出对于网络艺术保存尤其重要。

许多早期网络艺术作品不仅包含视频文件，还依赖Flash播放器、脚本、浏览器行为和交互环境。

即使作品的部分图像和声音能够被保存，如果原来的运行环境消失，作品的交互方式和时间结构仍然可能无法完整重现。

## **第九节 内容分发网络与全球视频传播**

### **9.1 什么是CDN？**

CDN（Content Delivery Network，内容分发网络）是现代在线视频服务的重要基础设施。

假设一个视频网站只有一台位于美国的服务器，世界各地的用户都需要从这台服务器获取视频。

当用户数量增加时，服务器可能出现拥堵，远距离传输也可能增加延迟。

CDN通过在不同地理位置部署缓存服务器，使用户能够从相对接近自己的节点获取视频。

[What Is a CDN and How Does It Work?](https://images.openai.com/static-rsc-4/Fd0M_V8DDnZ2a6Z7GIBPuw7TbL-XSsnXXVXRs9Fx1kngf2TqxUv6vgIQd9G2043zO5rf-98KSSo1n6z1WT4KYvHON8vK-mRuuBc-DfyJM436AL6sUss6GAa9J-ikO2jW3nv4OEJgvIZ0KNANMEp8wkhZwulPoCvKRK-qhnnc8uQ?purpose=inline)

[chemicloud.com](https://chemicloud.com/glossary/term/what-is-a-cdn/?utm_source=chatgpt.com)

例如：

* 纽约用户可能从美国东海岸的节点获取视频。  
* 伦敦用户可能从欧洲的节点获取视频。  
* 东京用户可能从亚洲的节点获取视频。

这样能够减少原始服务器的负担，提高视频传输效率。

### **9.2 CDN对网络艺术的意义**

CDN看起来只是商业互联网的后台基础设施，但它实际上改变了网络艺术能够实现的规模。

在早期互联网环境中，一件实时影像作品可能只能支持少量观众同时观看。

随着内容分发技术的发展，艺术作品能够面对更加广泛的观众。

这使大型在线影像展览、跨国网络直播和多人参与的互动作品更容易实现。

但是，CDN也意味着艺术作品越来越依赖商业基础设施。

如果服务器关闭、域名失效或者平台停止服务，作品可能无法继续运行。

因此，网络艺术的保存不仅涉及视频文件，还涉及服务器、网络协议、域名和软件环境。

## **第十节 自适应码率与现代流媒体**

### **10.1 什么是自适应码率？**

自适应码率流媒体（Adaptive Bitrate Streaming，ABR）是一种根据网络状况调整视频质量的传输技术。

同一段视频可以提前编码成多个不同分辨率和码率的版本。

播放器在播放过程中，根据网络带宽、缓冲区状态和设备能力选择合适的视频片段。

[Designing a Scalable Video Streaming Platform — YouTube/Netflix Level Architecture \| by Gyanaa Vaibhav \| Medium](https://images.openai.com/static-rsc-4/v4JUJiWv4L22_Z3faE3Y4_wsjUygbxDrx7cclB8aVgs2B1Q55A3tXQiMFjovmd6EX2w8Yx79xqLiudkiAqSkLjAjRu4D4nmrFOMu1_77Eh4AhFWbnMvY9U-jbgmM6uRxKHNYLDzb1HMJId9YXbt9_cXgS9gtse5hY4AIHXUQO_M?purpose=inline)

[medium.com](https://medium.com/%40gynanrudr0/designing-a-scalable-video-streaming-platform-youtube-netflix-level-architecture-503cd149641f?utm_source=chatgpt.com)

例如：

* 网络较好时播放1080p。  
* 网络一般时切换到720p或480p。  
* 网络较差时降低到360p。

这样可以减少视频播放过程中的卡顿。

### **10.2 HLS：HTTP Live Streaming**

HLS是Apple于2009年推出的基于HTTP的流媒体技术。

它将媒体内容组织成连续的视频片段，并通过播放列表描述可供播放器获取的媒体资源。

[Edition \#4 \- Understanding HLS: A Practical Guide for Swift Developers](https://images.openai.com/static-rsc-4/GjOi1hGAYc_rynOF7JS5M65IPAbXO6yzxqWRQaoh1Cy4FVnv6sS6qEutfeJTbWXeW1XZKCD5ehCxCV2z2-CJj_3hqG0gL40DrIAVk-0aqGjBY0CYc-hKOIm25Twe5_Emr1tj2DuvALwqesA6KrCmqfOxUMoUySX6kxxQURGlsSc?purpose=inline)

[linkedin.com](https://www.linkedin.com/pulse/edition-4-understanding-hls-practical-guide-swift-bruno-s69bf?utm_source=chatgpt.com)

HLS的重要特征包括：

1. 视频可以被分割成多个小片段。  
2. 播放列表负责描述媒体资源。  
3. 播放器可以根据网络情况选择不同码率。  
4. 能够利用常见HTTP基础设施传输媒体内容。

   ### **10.3 MPEG-DASH**

MPEG-DASH（Dynamic Adaptive Streaming over HTTP）是另一种重要的自适应流媒体标准。

它与HLS具有相似的目标：通过HTTP协议传输分段视频，并允许播放器根据网络状况选择不同质量的内容。

两者都是现代在线视频服务的重要技术基础。

### **10.4 画质与艺术家的控制权**

自适应码率技术带来了一个值得艺术史研究的问题：

当同一件作品在不同网络条件下以不同画质呈现时，作品的视觉形式究竟由谁决定？

在传统电影制作中，艺术家通常可以对最终放映版本的画面进行比较明确的控制。

而在网络流媒体环境中，实际呈现还受到编码版本、带宽、设备屏幕、播放器算法和网络状态的共同影响。

这意味着网络影像作品的最终观看体验可能由艺术创作与技术系统共同塑造。

对于某些网络艺术作品而言，这种不确定性甚至可以成为作品主题的一部分。

## **第十一节 宽带革命对艺术创作的影响**

### **11.1 展示空间从物理场所扩展到网络环境**

传统视频艺术经常依赖美术馆、画廊、艺术节、电影院或特定的影像装置空间。

观众需要到达特定地点，才能观看作品。

宽带互联网使艺术家能够通过个人网站、网络平台和在线展览发布影像作品。

[JODI, Joan Heemskerk, Dirk Paesmans. My%Desktop. 2002 \| MoMA](https://images.openai.com/static-rsc-4/X6i3hHjBMbxU8rpwxNkaEUdOs3Ja0MtBSCJeO8NA2nlL7Kb9jQVe3_rkyHVXl4pQjX6kT_eFzbnr6DTeqVSd3FbeIjyTL5yaZOGt2ZLVh9ZY7DvRuujCygurYSNkJtRAdEe89E0iFn1JNJ0LXfp3vwn18yfJPoneCuXZjIKdmbs?purpose=inline)

[arebyte Digital Art Centre — Olia Lialina](https://images.openai.com/static-rsc-4/F2WMXWzLE26FQ906LIDtv6ZmAlreK8VjCvC3Q0CvZNVeRx7qNmXfaJc8JcaxGUyMnGpz_nWgCz5X4IERxcYjtPYRARG2Ju_0DjbHcqpnVSsFL6OBUH0H1W4DlI3QAwENkICaLJxqxTcAGf02BwR9nuxvXrpjRd5eh72P37Co9EA?purpose=inline)

[Exhibitions \- New Museum Digital Archive](https://images.openai.com/static-rsc-4/RvzF3z3ArJ2GaKYSuEFkSDCJrPSFkWEmd_FECghZ7BtgNEzTI3tINMk8XLEcj7JXUOnkhvuWdhfeLEtyHpzZ2jr3lV19c2GmUGwtZU-qk8r_IqVMWb4LxafJOlt8kPGJCmoZX9JVrjyg1MeMLHiJvZbdD2sorxVeVQi8NSPimrI?purpose=inline)

12

这使视频艺术获得了新的展示空间。

但是，网络观看不能完全替代现场装置。屏幕尺寸、声音环境、空间布局、观众身体的位置以及观众之间的关系，仍然会影响作品的意义。

### **11.2 艺术家的身份发生变化**

在线视频平台使影像创作者的身份更加多样化。

一个人可以同时是：

* 视频艺术家；  
* 动画创作者；  
* 网络表演者；  
* 影像博主；  
* 数字艺术家；  
* 网络社群组织者。

这打破了传统艺术制度中相对明确的职业分类。

### **11.3 数字影像的可复制性**

数字视频可以被复制、下载、重新编码和再次上传。

一件视频艺术作品可能同时存在于艺术家官方网站、美术馆数字档案、在线视频平台和私人收藏中。

这些副本可能具有不同的分辨率、压缩质量、时长、画面比例和字幕信息。

因此，数字作品的原作身份不能总是通过某一个视频文件简单确定。

研究者需要进一步考察艺术家认可的版本、作品的展示要求、文件来源、元数据，以及作品是否依赖特定软件或网络环境。

### **11.4 注意力经济与平台批判**

在线视频平台不仅提供存储和播放服务，也逐渐发展出广告、订阅、推荐、排名和数据分析机制。

用户的观看时间、点击、搜索和互动行为成为平台运营的重要数据。

这产生了一个新的批判性研究主题：注意力经济（Attention Economy）。

[TikTok's Algorithm-Driven Content Feed Model](https://images.openai.com/static-rsc-4/_7B6TrqxmyuxRs-aGZQ-0VANx3BoK01vSUgomlR1uPfhfSb4A0oODWfy5izjd15ntv5zxcnTwTxTy3BWcr4z4Eoy6NV1tosL3V6LkDENGxOPNoOFW6RM1JFguHJjmqU9Y4BWSuZ1hXDo48wJ0X6bU_8RrYJxXVJXFGi4201_IUY?purpose=inline)

[markhub24.com](https://www.markhub24.com/post/tiktok-s-algorithm-driven-content-feed-model?utm_source=chatgpt.com)

艺术家可以利用网络视频讨论：

* 用户注意力如何被争夺。  
* 推荐算法如何影响观看。  
* 商业平台如何控制内容传播。  
* 视频创作者如何受到流量机制影响。  
* 观众如何成为数据生产者。

这些问题后来成为平台艺术（Platform Art）和后互联网艺术（Post-Internet Art）的重要研究方向。

## **第十二节 宽带互联网与视频传播革命的历史时间线**

[Happy 25 years of the internet, Australia \| SBS News](https://images.openai.com/static-rsc-4/sxLLH0tYOfv_VPTV2eKCAfnJO7KCDp66KsWEWsdEF5VZ2I_BRJ56FbH8Tze_H70dmHeRV9YXr_uWms6urR_n0faznj7bqOYUNk7J5h85xCFJubzEvgMsCRECudLAHUYDoVrTpAkZIKEMG7BcEK-8jSDAvLw_jH7G49zAz4Oui44?purpose=inline)

[Internet](https://images.openai.com/static-rsc-4/ZZ2c83EiHEa7XDd54iNxJkVru-yH0siLz8_emRH1r7cg1vcZqoQo8Eo175U7c-YnGs-bwfcTi9DKQ-6js9RV6f_IHGkNCBhxDZJzRmSLCjQSaJhMMEU62KKyx1MEjsm0iR_kWQ-WxmTHkoLCTCk-sYfauxAqWZ72ySD69xKI34Y?purpose=inline)

[YouTube faz 20 anos: 6 curiosidades e o que esperar nos próximos anos](https://images.openai.com/static-rsc-4/Yze5xN5vT7_ryApFWhXoy9NI3qjo7TeNIVcA-6ehKC3ZUhmKk9_KFB80wLxglqQs1y5DV8YUEbslufNJhTkkcRay8XI7kc7sW3a8qv3bXOMLHWCB--6E0fow3g30Kz7Hww61WGkjvirAo1fFzug3mF2cZ4Mp_ZAn1v8b1mXDUfA?purpose=inline)

6

| 时间 | 重要事件 | 历史意义 |
| ----- | ----- | ----- |
| 1990年代 | 拨号互联网普及 | 早期网络影像传播 |
| 1995年前后 | RealAudio发展 | 早期网络音频流媒体 |
| 1990年代后期 | RealVideo发展 | 网络视频流媒体出现 |
| 1990年代末至2000年代 | DSL与Cable宽带普及 | 家庭视频传输能力提高 |
| 2003年 | H.264/AVC标准发布 | 视频压缩效率提高 |
| 2005年 | YouTube成立 | 用户视频分享平台兴起 |
| 2006年 | Google收购YouTube | 视频分享进入大型平台体系 |
| 2007年 | Netflix推出流媒体服务 | 网络点播服务发展 |
| 2009年 | Apple推出HLS | HTTP流媒体技术发展 |
| 2010年代 | 智能手机与移动宽带普及 | 视频传播进入移动互联网时代 |

这些年份表示重要的历史节点，并不意味着相应技术在某一年突然出现。许多技术经历了长期研发、标准化、商业部署和用户普及。

## **第十三节 本章的艺术史定位**

宽带互联网带来的革命，不只是视频传输速度提高，而是影像文化生产结构的改变。

这一变化可以从五个方面理解。

**第一，技术条件发生改变。**

宽带接入、视频压缩和内容分发网络，使大规模网络视频传播成为现实。

**第二，创作条件发生改变。**

数字摄像设备和在线视频平台降低了影像生产与发布门槛，普通用户和独立艺术家获得了新的传播工具。

**第三，展示条件发生改变。**

视频作品能够脱离传统广播机构和固定展览空间，直接面向网络观众。

**第四，观看关系发生改变。**

点播、直播、评论、转发和互动改变了观众接触影像的时间方式与参与方式。

**第五，艺术观念发生改变。**

网络连接、平台规则、压缩失真、算法推荐、数据传播和作品保存，逐渐成为艺术创作与批判的对象。

### **必须区分的四个层次**

| 层次 | 定义 | 代表性例子 |
| ----- | ----- | ----- |
| 通信基础设施 | 解决数据如何传输 | DSL、光纤、宽带 |
| 视频传播平台 | 解决视频如何发布和寻找 | YouTube、Vimeo |
| 流媒体技术 | 解决视频如何连续传输和播放 | RealVideo、HLS |
| 流媒体视频艺术 | 将网络传输和实时影像转化为艺术表达 | 网络直播艺术、实时网络影像 |

这四个层次相互关联，但不能混为一谈。

YouTube是在线视频平台，HLS是一种流媒体技术，宽带是通信基础设施；只有当艺术家将这些条件转化为作品的形式、观念或展示结构时，才进入流媒体视频艺术的讨论范围。

**本章的核心结论：宽带互联网并没有自动创造流媒体视频艺术，却为它提供了新的技术条件、传播空间和文化环境。**

网络影像从少数机构控制的专业传播形式，逐渐发展为由平台、艺术家、普通用户和观众共同参与的复杂生态。

理解这场传播革命，是理解后续网络视频艺术、平台艺术和当代流媒体艺术的必要基础。

## **主要参考资料**

以下是本章涉及的技术史和平台史资料：

1\. **ITU-T — H.264 Advanced Video Coding**

[H.264标准及相关技术文件](https://www.itu.int/rec/T-REC-H.264/?utm_source=chatgpt.com)

2\. **Apple Developer — HTTP Live Streaming**

[HLS官方技术文档](https://developer.apple.com/streaming/?utm_source=chatgpt.com)

3\. **YouTube Official Blog**

[YouTube官方历史与平台发展资料](https://blog.youtube/?utm_source=chatgpt.com)

4\. **Internet Society**

[互联网发展与基础设施研究资料](https://www.internetsociety.org/?utm_source=chatgpt.com)

5\. **RealNetworks**

[RealNetworks公司及技术历史资料](https://www.realnetworks.com/?utm_source=chatgpt.com)

