\# \*\*02. 流媒体视频艺术\*\*

\#\# \*\*专题：Flash动画与早期网络创作（Flash Animation and Early Web Creativity）\*\*

\#\#\# \*\*第一节 Flash技术的诞生与发展\*\*

\#\#\#\# \*\*1.1 Flash是什么？\*\*

Flash是20世纪90年代末至21世纪初最重要的网络多媒体技术之一。它曾经广泛用于网页动画、互动艺术、网络游戏、音乐作品和实验性数字影像。

Flash的特殊之处在于，它并不只是一个视频播放软件，而是一套集动画制作、矢量图形、声音处理、程序交互和网络内容发布于一体的多媒体创作环境。

在Flash流行之前，网页主要由文字、静态图片和简单的超链接构成。虽然GIF动画已经能够展示动态画面，但它在动画复杂程度、交互能力和程序控制方面存在明显限制。

Flash改变了这一状况。

艺术家和普通网络用户可以利用它制作具有连续运动、声音、互动按钮和复杂视觉效果的网页作品。

\#\#\#\# \*\*1.2 Flash的历史起源\*\*

Flash的历史可以追溯到1993年。

美国FutureWave Software公司开发了一款名为SmartSketch的绘图软件，最初主要用于数字绘图。

随后，开发团队开始探索将矢量绘图技术应用于动画制作。

\[FutureSplash Animator in 1996 \- Web Design Museum\](https\://images.openai.com/static-rsc-4/6GpO2GQxO5TBbAGnv59w9fDDtk04aOdwj07e3pstOd1yNnYSWAZFwpRLnzFBvopApUYHLsnZA0AGyMTBxUDDee9GINYj9NmPaxxqA8zoBQhIBg280HNfYdjqdDExoKzUytukuYEwGMfdD7WhUF8AfLBOEfvCtQdG0m\_WuCDLlKU?purpose=inline)

\[A Brief History of Flash \| Flash Reference Guide \| Peachpit\](https\://images.openai.com/static-rsc-4/mxznQd4kxIArRbYR4d2qVROhDgHTcZpHjwvN\_VCoDe6ZMEjpgyediLMBNKAoBNKmQqVMAOHZubV42SjvaC2D-6kKfASa9ipBaWGV9GYvJuoCvw3LMnguhXF2axZKaI-rYNJOppI-8Qvgk0qOpvcJkcZlr9CNL24dAVrZRkMFV3c?purpose=inline)

\[Untitled \- Web Design Museum\](https\://images.openai.com/static-rsc-4/5\_GkIk7167gkv46a5EI50RSkQindg2GKKLtTVSbnxrCz3xJMTq\_53RyoZ6usuDzD6LdAfAvvDerXSkr9drUvUW-gPwgedfhFrSvi7r\_kEi3Y4K507LZaVd8zKOWG1GY3jy1XNBUSKzPJvyt5FrsHAEqji9sk5OpUvxtFjkwm\_TE?purpose=inline)

6

重要发展节点：

\| 时间    \| 事件                            \|

\| \----- \| \----------------------------- \|

\| 1993年 \| FutureWave开发SmartSketch       \|

\| 1995年 \| 开始开发FutureSplash Animator     \|

\| 1996年 \| FutureSplash Animator发布       \|

\| 1996年 \| Macromedia收购FutureWave相关技术与团队 \|

\| 1997年 \| Flash 2发布                     \|

\| 1998年 \| Flash 3发布                     \|

\| 1999年 \| Flash 4发布                     \|

\| 2000年 \| Flash 5发布                     \|

\| 2002年 \| Flash MX发布                    \|

\| 2005年 \| Adobe收购Macromedia             \|

\| 2007年 \| Flash CS3发布                   \|

\| 2010年 \| Flash逐渐受到移动互联网平台的限制           \|

\| 2020年 \| Adobe正式停止Flash Player支持       \|

Flash的成功，很大程度上来自它解决了早期互联网的一个重要问题：如何在有限的网络带宽下展示复杂的动态视觉内容。

\#\#\# \*\*第二节 Flash动画的核心技术\*\*

\#\#\#\# \*\*2.1 矢量图形（Vector Graphics）\*\*

Flash最重要的技术基础之一是矢量图形。

传统位图图像（Raster Graphics）由大量像素构成。图片放大时，如果没有足够的像素，就容易出现锯齿和模糊。

矢量图形则通过数学参数描述点、线、曲线和形状。

例如，一个圆形可以通过圆心坐标和半径来描述，而不必逐一记录组成圆形的所有像素。

\[Imagining a 13-inch iPad Pro \| iMore\](https\://images.openai.com/static-rsc-4/6vquZmEhWxwIJNOKgE1fnTat8ZD1GizWId9jmGRPJ8pXBn3APZZGl8iYMDzxQd-awzZCBMtnGLxpFOiejYV-2EUfMtGhO81n8N6uzx\_jsYfg1jyBuEkOnRueljumHVg08igrAepweCUyrKyYgRNlGftaf96VpDOO\_uqM0mRS4Bc?purpose=inline)

\*\*位图图形\*\*

放大后可以看到像素结构。

\[Circle bezier path with vector handles\](https\://images.openai.com/static-rsc-4/OoWwnOZkndHQi5Lce77YXkOsucsA2mHgtCb5i-Ntdjig24yW8soV3AePFCGHDb7bCw4N5i0GSioCQn4ez1pqafB\_7ACaT\_HLXxf8lLWH1UHbzjNuBzvuoR0yZDb8Jr9yOxX\_QyfApy\_T30DRXC-PwqMRS8C-2iC4f28R5V9uTyDTWetYKbdLUAMCNeX5Rutw?purpose=inline)

\*\*矢量图形\*\*

通过数学路径描述形状，可以按比例缩放。

矢量技术具有几个重要优势：

\- 文件通常较小，适合早期低带宽互联网。

\- 可以自由调整大小。

\- 形状、颜色和运动可以通过程序控制。

\- 能够支持复杂的交互式动画。

这使Flash特别适合制作网页人物、卡通动画、动态文字和交互式视觉作品。

\#\#\#\# \*\*2.2 时间轴动画（Timeline Animation）\*\*

Flash使用时间轴组织动画。

时间轴由帧（Frame）、关键帧（Keyframe）和图层（Layer）等组成。

艺术家可以在不同时间点设置对象的位置、大小、旋转角度和其他属性，再由软件生成中间运动过程。

\[The Timeline \| Special Edition Using Macromedia Studio MX 2004\](https\://images.openai.com/static-rsc-4/0Wr\_lwZp3b5iuxyISg7goi7KREJzH73sYtWfA91RtZOcwsctMFbP1GlgPeuhXpJeArjQ4oetru9Ay0kjb6tkpscDWyGcp15XyjrR-HyORxLMfrOVr9jPU44vS9G8mmrqqfWHJKZ5CSl85TmgqeQxcqQ7py5\_o4H4j8-FfoURHY4?purpose=inline)

\[flylib.com\](https\://flylib.com/books/en/1.324.1.147/1/?utm\_source=chatgpt.com)

例如，假设要制作一个从左向右移动的圆形：

1\. 在第一帧绘制圆形。

2\. 在第30帧设置另一个位置。

3\. 使用补间动画（Tweening）生成中间运动。

4\. 播放时间轴，形成连续移动效果。

Flash中的补间动画包括运动补间和形状补间等不同形式。

这种制作方式降低了动画创作的技术门槛，使没有传统逐帧动画经验的用户也能够制作动态作品。

\#\#\#\# \*\*2.3 ActionScript与互动艺术\*\*

Flash的另一项重要技术是ActionScript。

ActionScript是一种面向Flash运行环境的脚本语言。

它允许创作者为动画增加程序控制和互动功能。

例如：

\- 点击按钮切换画面。

\- 根据用户操作改变人物动作。

\- 根据鼠标位置改变视觉效果。

\- 根据输入内容生成不同图形。

\- 控制声音播放和动画循环。

Flash 5时期，ActionScript的编程能力得到进一步发展；Flash MX及后续版本又扩展了其多媒体和网络应用能力。

这使Flash从单纯的动画制作软件逐渐发展为互动作品创作平台。

\#\#\# \*\*第三节 早期网络动画的代表平台\*\*

\#\#\#\# \*\*3.1 Newgrounds\*\*

\[11 forgotten websites that used to rule the internet, from AOL to MySpace\](https\://images.openai.com/static-rsc-4/Qdbz8Z5HLsNh8nP0T7llCavMhi3QYce0YW9tQxJdSkhajthkrj2Df9DyyGfHRLepgIc-5VJN8vB6D6QS0YH-s7lQgyn\_Pi0eTaFDzUaCQA0IUqAOHVvLENlsQWBYFkFj5zSqMTufOZoT0lnaU4fr8OuCx-N27gJV22FX77Sa7OY?purpose=inline)

\[digitalspy.com\](https\://www\.digitalspy.com/tech/a797267/11-forgotten-websites-that-used-to-rule-the-internet-from-aol-to-myspace/?utm\_source=chatgpt.com)

Newgrounds 是早期网络动画文化最重要的平台之一。

它由Tom Fulp于1995年创立，后来逐渐发展成为用户原创动画、游戏和数字艺术的重要聚集地。

Newgrounds的特别之处在于，它并不是传统动画公司运营的作品发行网站，而是一个由创作者和观众共同构成的网络社区。

用户可以上传自己的Flash动画，其他用户则可以观看、评分、评论和分享。

这种机制形成了一种新的创作生态：

创作者制作动画，平台提供展示空间，观众提供反馈，而作品则通过网络传播不断获得新的观众。

这与传统动画产业中由制片公司、电视台和发行商控制作品传播的模式存在明显差异。

\#\#\#\# \*\*3.2 Newgrounds的文化特征\*\*

Newgrounds上的早期作品经常具有以下特点：

\- 个人化的绘画风格。

\- 简单但富有表现力的角色设计。

\- 荒诞、讽刺和黑色幽默。

\- 大量电子游戏与流行文化引用。

\- 较短的播放时间。

\- 观众评分与评论参与。

这些作品并不一定追求传统动画工业中的精细制作。

相反，它们经常强调创意、幽默和表达自由。

Newgrounds因此成为研究早期网络亚文化的重要场所。

\#\#\# \*\*第四节 早期Flash动画代表作品\*\*

\#\#\#\# \*\*4.1 《The Decline of Video Gaming》\*\*

\[Flash Changed How We Communicate. I first encountered Flash in a rather… \| by Tom Green \| Medium\](https\://images.openai.com/static-rsc-4/SGiLfgn7xicoTjkJ0Wg5S-WJBlKHVidncxgthdJR1iNkvaF5I9y7eBiLL8J26iv0hCx7i-pjdQATjz8-TuTRQPc\_VuyQPBU8rSDAzhWIWU9DUURlu-evfJmuNqnyzzlz04Td78BJJHxqUXXfI8\_PIIMxluEu9nVjasVUhZwc8Kc?purpose=inline)

\[tomgreen17.medium.com\](https\://tomgreen17.medium.com/flash-changed-how-we-communicate-56e18a9cdecf?utm\_source=chatgpt.com)

《The Decline of Video Gaming》是早期网络游戏文化和Flash动画的重要代表作品之一。

它通过讽刺性的角色表演和夸张叙事，批评电子游戏产业中的一些发展趋势。

这类作品体现了Flash动画的一个重要特点：创作者可以不依赖大型动画制作公司，直接针对网络社群的共同兴趣进行创作。

\#\#\#\# \*\*4.2 《Homestar Runner》\*\*

\[All 206 Strong Bad Emails from Homestar Runner, ranked\](https\://images.openai.com/static-rsc-4/mNnni89hfZ16qSzUtfM8n275BsthpKikI5WPnE9XevRcRLrqBp0QDjQNDaWpOnVIaXwFB4ws4rYGtlq06Fr6PNou5UydJtm6W02m-7l9tQLT8IBFuJliyTUWw3\_djU3-igDHFbM4ZkGTJXKTdt\_fwYUNAw9uJQIjKryuMkh72So?purpose=inline)

\[Homestar Runner \| Homestar Runner \| Know Your Meme\](https\://images.openai.com/static-rsc-4/sS34X6usRBYS3JQmpnZkUalL\_KnoSQSVBedzIG8X3ZOlmhYKWU4FluLwHk-5Oy9gU-U44ZmX9jLnrsQrPo6VzIfHd3KOAgGQhFPB8fEzTR2MCyKHfLyIx5D3VrotIieWeFA0gkPW0KggfSsAVlQeZJevVY-uofU-0m9xARq-Gfo?purpose=inline)

\['A Brief History of Homestar Runner', A Look Back at the Classic Flash-Animated Internet Series 'Homestar Runner'\](https\://images.openai.com/static-rsc-4/PXqK9lw\_t3PYOPM4ExNa1AxxtbruIB3obLWlWGS3tpEq4Cl-cFJoJPQiQYzyqMh\_kAAWMc4OCvNeUch-iSeiXd-wwJYvQaRmKchlFohHcxmLjhBYhXohTgvCgJS0Id\_R2Qp8i3ggwIHQmALLEAEnHBfu48Q8F216Nbu0GCh0dnQ?purpose=inline)

10

Homestar Runner 是由Mike Chapman和Matt Chapman创作的网络动画系列。

它于2000年正式进入公众视野，使用Flash动画技术制作。

其中最著名的部分之一是Strong Bad Emails，即Strong Bad回复观众邮件的系列。

这一设计特别有意思：观众可以通过邮件参与内容生产，而创作者则将部分观众输入转化为动画剧情。

因此，它不仅是一部网络动画，也体现了早期网络文化中的参与式创作。

\#\#\#\# \*\*4.3 《Salad Fingers》\*\*

\[Salad Fingers creator never meant for the seriously creepy character to be scary\](https\://images.openai.com/static-rsc-4/301kL7n-t5CZLQwbHTEfuCxhtMg\_HHM7fAza5D5SXAu1jZSMX948kNfJuuu9AEm1wgajmlZFGrapZJ46fBX7EQUXRK12ni1EOGC5182ItihJ2EnAzGO7ZbYVRUMZr89TPp0OmRKs0JIyEIsY\_ayQjEYRyuxwZBnUUWWO7tNBKak?purpose=inline)

\[Salad Fingers (2004) \| MUBI\](https\://images.openai.com/static-rsc-4/GJ0Gzbro43iIEqQCel2QwLJ0TD4wB77VAJoXyZnMsY7pyYaWDFCFnyEHkvVEYzDUOu\_vWG1qiW\_C-aGpQys4ZvYgLmLYDTnTZNzisipLev-4g-aquvhxOaO12TP0obNSMKKFjErorg1WCXz2Sn7RZ\_TVVgJGZ-Bf7OLVcjGwNfc?purpose=inline)

\[Watch Dedos de ensalada • Temporada 1 Full Episodes Free Online \- Plex\](https\://images.openai.com/static-rsc-4/JR0WH09HzMVsHLamv9IE2ek4SGMabc4L6MX88sdInIrZwxRum8FAc18Q2W3-kkUl7binIG6AYqknUSJOru\_f3y3zuIQT-IBWrM\_ujCiazbVGzpjH8\_ijoaGaiWH0mVAReqIz2wDnigElcOODPVxnK5i7R2JXwbXKPULQJ65zDZg?purpose=inline)

10

Salad Fingers 是英国动画创作者David Firth于2004年开始制作的超现实主义网络动画系列。

作品以一个绿色、瘦长的人形角色为中心，构建了一个荒诞、阴郁且具有心理恐怖色彩的世界。

它具有几个鲜明特征：

第一，人物造型高度简化，缺乏传统动画中的写实比例。

第二，画面经常采用低饱和度色彩和不稳定的视觉构图。

第三，声音设计与重复动作形成特殊的心理氛围。

第四，作品不依赖传统叙事逻辑，而通过奇异的场景、对话和人物行为制造不安感。

《Salad Fingers》说明，早期网络动画不只是幽默短片，也能够成为具有独立美学和作者风格的实验性影像创作。

\#\#\#\# \*\*4.4 《Animator vs. Animation》\*\*

\[Animator vs. Animation \| Videos & Movies on Vimeo\](https\://images.openai.com/static-rsc-4/ko\_16xHAgUdaibYE8h2xhCGsfNT6KAjL-u2nMGS3B6Zwe7xMI5v4VDQcKEzXWgOekpldJH12OVQIq50hownAjji5q3G09gTyhtaG0gXXiDwaWsNxtSPfPYDkLi6-3E3n8kYOPe2\_thXeUimHZ9YdmDx6btsbMlg7-b59K3f8UNg?purpose=inline)

\[vimeo.com\](https\://vimeo.com/17016768?utm\_source=chatgpt.com)

《Animator vs. Animation》由Alan Becker创作，第一部作品于2006年发布。

它的基本创意是：动画中的火柴人角色意识到自己处于计算机绘图环境中，并开始反抗操纵自己的动画创作者。

作品将计算机桌面、鼠标指针、绘图软件界面和动画人物结合起来。

其艺术价值在于，它打破了动画世界与创作工具之间的界限。

传统动画通常把制作软件隐藏在作品背后，而《Animator vs. Animation》直接将软件界面变成故事发生的空间。

这种形式可以称为元媒介表达（Metamedial Expression）：作品不仅使用媒介，还把媒介自身作为表现对象。

\#\#\# \*\*第五节 Flash与早期网络互动艺术\*\*

\#\#\#\# \*\*5.1 从观看到操作\*\*

传统动画通常要求观众按照创作者预设的时间顺序观看。

Flash则允许艺术家将按钮、鼠标和键盘操作纳入作品。

观众可以选择不同场景，触发人物动作，改变声音，甚至决定作品的发展方向。

这种变化使动画从单纯的动态视觉对象转变为可操作的数字环境。

\#\#\#\# \*\*5.2 互动叙事（Interactive Narrative）\*\*

Flash可以支持多分支叙事。

例如，创作者可以设计一个故事，让观众在关键节点选择不同选项。

不同选择会触发不同的动画场景，最终产生不同的故事结局。

这种创作方式模糊了动画、电子游戏和数字艺术之间的边界。

\[Sixstation in 2002 \- Web Design Museum\](https\://images.openai.com/static-rsc-4/yi9OP-OZn\_2pmlTosK9hS4fwvLTHHPjv9ou\_BHp4bkbIGYGbBleb0ARH1WGBZBrIvYRKUoWhMr5OwY9Y\_RRqQ\_BsOcyIBvLxFSyCiYUaJGQ6BmwtDjgxYp1iX7nyylj-4hFnFm\_gktyKseOaFXOIwH4kocH7iDymQ6CiG5r-awg?purpose=inline)

\[Superlooper in 2001 \- Web Design Museum\](https\://images.openai.com/static-rsc-4/hRPne5Uy4HCa0Mbp-pTOEtQvn5wLeTW0OJsFzenlygIOm4zG-oE88yTne6bCSawnY8Aub09YJsPLAl2PCD0h-1NlcaxyCGZbSE\_rs8rm9pDNgla4kD5UO-6cdmhlZIijwK-kJsJuInUn0KssyuuBWcDP8Ep\_ckKagdpOsMUC6pk?purpose=inline)

\[MONO\\\*crafts in 1999 \- Web Design Museum\](https\://images.openai.com/static-rsc-4/KPIOYm0q41wKhdN-SAOub5zD7ttTJI\_xKr3qawrNHfVhjYS5mglEsVI2iw9D6g8y8GAkH3MNrAF07UE4JuqsQp5bzCfAPpuUbcYzrPcpIU793smcvLD\_bytB8FSBHQQPJwVzR6LO3PjgN88b2i8adC7Rr0wpEKNBSQzskftn2rQ?purpose=inline)

15

与传统电影相比，互动叙事的时间结构并不是完全固定的。

观众的选择可能影响作品实际呈现的顺序和内容。

这使作者与观众之间的关系发生变化。

\#\#\#\# \*\*5.3 Flash游戏与艺术\*\*

Flash游戏也是早期网络创作的重要组成部分。

由于Flash支持动画、声音和用户输入，创作者能够在网页中制作简单的互动游戏。

部分作品具有明显的艺术实验性质，例如利用游戏机制讨论社会问题、身份认同、暴力、消费文化和权力关系。

因此，Flash游戏与互动艺术之间存在大量交叉。

但并不是所有Flash游戏都是艺术作品。研究时仍然需要考察作品的创作目的、形式结构和文化意义。

\#\#\# \*\*第六节 Flash视觉美学的形成\*\*

Flash逐渐形成了具有辨识度的网络视觉风格。

\#\#\#\# \*\*6.1 简化人物造型\*\*

早期Flash动画常常使用简单的几何形状、线条和夸张比例。

这种设计既降低了制作成本，也使人物更容易被观众识别。

\#\#\#\# \*\*6.2 循环动画\*\*

许多Flash动画使用循环动作。

人物走路、跳舞、挥手或做出其他动作，可以不断重复播放。

这种循环结构与GIF动画有一定联系，但Flash允许更复杂的时间控制和交互。

\#\#\#\# \*\*6.3 数字拼贴\*\*

创作者经常将摄影、绘画、文字、声音和动画组合在同一作品中。

这种拼贴方式体现了数字媒介的开放性。

\#\#\#\# \*\*6.4 荒诞与反传统叙事\*\*

Flash动画不必遵循电视动画或商业电影的叙事规范。

许多创作者会故意使用夸张、重复、无意义对话、突然转场和黑色幽默。

这种自由度使早期网络动画成为互联网亚文化的重要表达形式。

\#\#\# \*\*第七节 Flash的衰落与历史终结\*\*

\#\#\#\# \*\*7.1 移动互联网的兴起\*\*

2007年，苹果公司推出iPhone，移动互联网开始快速发展。

Flash在桌面浏览器中拥有广泛的应用，但它在移动设备上面临功耗、性能和兼容性等问题。

苹果公司在2010年公开阐述了不支持iPhone运行Flash的决定。

这对Flash的移动互联网发展产生了重要影响。

\#\#\#\# \*\*7.2 HTML5的发展\*\*

HTML5逐渐支持原生音视频播放、Canvas绘图和其他互动功能。

这意味着网页不再需要依赖Flash插件，就能够实现越来越复杂的动态视觉内容。

同时，浏览器开始加强对插件安全性、性能和兼容性的管理。

\#\#\#\# \*\*7.3 Flash Player的终止\*\*

Adobe于2020年12月31日正式停止Flash Player支持，并于2021年1月12日起阻止Flash内容运行。

\[How to save data journalism: A guide to… \| DataJournalism.com\](https\://images.openai.com/static-rsc-4/xp1h-Z0o2Fw5XiATvhEZhelypoDmp9qhkAl4MuZe5ZDHs5Zb1wc74ZHgbzmbYA3rHHdaa5oRdazW0PoWDD4FNUv-rgtj9iGIwmTEAlSmoLwLpaiwqvclm1ziH3FyYHdQmP6eiKcMwReG62x24Kn1K\_3U7mUYlmTq7L4ps81CjmU?purpose=inline)

\[datajournalism.com\](https\://datajournalism.com/read/longreads/how-to-save-data-journalism?utm\_source=chatgpt.com)

Flash虽然退出了主流网络环境，但它留下的作品并没有因此失去艺术史价值。

Newgrounds、Ruffle等项目以及数字艺术保存机构，仍然在尝试保存和恢复早期网络动画。

\#\#\# \*\*第八节 Flash在艺术史中的地位\*\*

Flash的历史意义不仅是提供了一种动画制作软件。

它实际上改变了数字影像的创作生态。

首先，它降低了动态影像创作的技术门槛，使个人创作者能够独立制作并传播动画。

其次，它将动画、游戏、交互设计和网页艺术结合起来，形成跨媒介创作环境。

再次，它推动了网络创作者社群的发展，使观众反馈和用户参与成为网络创作的重要组成部分。

最后，它形成了具有鲜明时代特征的网络视觉美学，成为早期互联网文化的重要组成部分。

从艺术史角度看，Flash最重要的贡献是：\*\*它使普通计算机用户能够直接在互联网环境中创造动态视觉作品，并让动画从传统影视工业中进一步独立出来。\*\*

但Flash动画并不等于流媒体视频艺术。它属于早期网络动画和互动多媒体艺术的重要技术体系，是流媒体视频艺术发展所处的广泛网络视觉文化背景之一。

\*\*下一专题：早期网络视频艺术与Flash时代的视觉实验。\*\*

我们可以进一步研究早期网络动画如何影响后来的数字艺术、视频装置、互动影像和网络亚文化。