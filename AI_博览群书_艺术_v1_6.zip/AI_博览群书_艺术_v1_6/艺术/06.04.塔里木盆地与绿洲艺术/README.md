# 06.04.塔里木盆地与绿洲艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/180fY_zSLYCrUs1DweNVpXX8iPYq992f6)

## 教材课文

- [001 克孜尔石窟：菱格里的故事与中心柱后的路](001_%E5%85%8B%E5%AD%9C%E5%B0%94%E7%9F%B3%E7%AA%9F%EF%BC%9A%E8%8F%B1%E6%A0%BC%E9%87%8C%E7%9A%84%E6%95%85%E4%BA%8B%E4%B8%8E%E4%B8%AD%E5%BF%83%E6%9F%B1%E5%90%8E%E7%9A%84%E8%B7%AF.md)
- [002 尼雅双楔形木牍：读信之前先看它怎样封合](002_%E5%B0%BC%E9%9B%85%E5%8F%8C%E6%A5%94%E5%BD%A2%E6%9C%A8%E7%89%8D%EF%BC%9A%E8%AF%BB%E4%BF%A1%E4%B9%8B%E5%89%8D%E5%85%88%E7%9C%8B%E5%AE%83%E6%80%8E%E6%A0%B7%E5%B0%81%E5%90%88.md)
