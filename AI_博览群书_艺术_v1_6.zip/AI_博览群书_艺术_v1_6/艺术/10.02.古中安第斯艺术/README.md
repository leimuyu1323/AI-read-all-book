# 10.02.古中安第斯艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1oQPdnb9NZrrZ_C55erbFgOpqJmkrahlC)

## 教材课文

- [001 莫切肖像陶壶，面孔怎样变成容器](001_%E8%8E%AB%E5%88%87%E8%82%96%E5%83%8F%E9%99%B6%E5%A3%B6%EF%BC%8C%E9%9D%A2%E5%AD%94%E6%80%8E%E6%A0%B7%E5%8F%98%E6%88%90%E5%AE%B9%E5%99%A8.md)
- [002 纳斯卡与帕尔帕地画：移开石子怎样画出一条长线](002_%E7%BA%B3%E6%96%AF%E5%8D%A1%E4%B8%8E%E5%B8%95%E5%B0%94%E5%B8%95%E5%9C%B0%E7%94%BB%EF%BC%9A%E7%A7%BB%E5%BC%80%E7%9F%B3%E5%AD%90%E6%80%8E%E6%A0%B7%E7%94%BB%E5%87%BA%E4%B8%80%E6%9D%A1%E9%95%BF%E7%BA%BF.md)
