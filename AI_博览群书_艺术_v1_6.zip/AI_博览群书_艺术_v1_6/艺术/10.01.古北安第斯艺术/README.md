# 10.01.古北安第斯艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1BZBcc4Ql69ouwec3zP8iws5DsGAa5uQd)

## 教材课文

- [001 穆伊斯卡金筏：一场仪式怎样铸成掌中群像](001_%E7%A9%86%E4%BC%8A%E6%96%AF%E5%8D%A1%E9%87%91%E7%AD%8F%EF%BC%9A%E4%B8%80%E5%9C%BA%E4%BB%AA%E5%BC%8F%E6%80%8E%E6%A0%B7%E9%93%B8%E6%88%90%E6%8E%8C%E4%B8%AD%E7%BE%A4%E5%83%8F.md)
- [002 金巴亚石灰罐：从窄颈与空腔理解金工](002_%E9%87%91%E5%B7%B4%E4%BA%9A%E7%9F%B3%E7%81%B0%E7%BD%90%EF%BC%9A%E4%BB%8E%E7%AA%84%E9%A2%88%E4%B8%8E%E7%A9%BA%E8%85%94%E7%90%86%E8%A7%A3%E9%87%91%E5%B7%A5.md)

## 网盘子目录

- [90.原有媒介与专题资料](90.%E5%8E%9F%E6%9C%89%E5%AA%92%E4%BB%8B%E4%B8%8E%E4%B8%93%E9%A2%98%E8%B5%84%E6%96%99/README.md)
