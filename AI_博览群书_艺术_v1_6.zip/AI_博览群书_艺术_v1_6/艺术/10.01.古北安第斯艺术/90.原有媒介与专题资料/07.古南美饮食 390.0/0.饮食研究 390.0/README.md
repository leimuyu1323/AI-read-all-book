# 0.饮食研究 390.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1TrIQ0u4SZLRKG12RAIyz88TTghYRYxNm)

上一级：[07.古南美饮食 390.0](../README.md)

## 网盘原资料

- [Chap01.生态环境 20.0](https://docs.google.com/document/d/1NYZPJ9m29qGCpTJL2aZorVHld5hME0lU4CWoNqVFhes/edit?usp=drivesdk)
- [Chap02.玉米 20.0](https://docs.google.com/document/d/1l-CmYizrDpcDEwvDPA2S2HK1BfnG-kiDlBZP1AQP24c/edit?usp=drivesdk)
- [Chap03.土豆 20.0](https://docs.google.com/document/d/1La01eYJE2xujlW60KetO9h0HyDvmhhnMzdvmEnp18BY/edit?usp=drivesdk)
- [Chap04.藜麦 20.0](https://docs.google.com/document/d/1HJvQsIAWBCS63K4nPJ574_W8ZWPtoBlgRfVQF7fo1CE/edit?usp=drivesdk)
- [Chap05.木薯 20.0](https://docs.google.com/document/d/1xQP827BmKmLDTaS7F4RN-KiInou6vHLCkgLnNHY7nZU/edit?usp=drivesdk)
- [Chap06.羊驼 20.0](https://docs.google.com/document/d/1uEMlzLZMOziNjD9utOAvz7Y9VwmP-paY4r2RaS5wOZs/edit?usp=drivesdk)
- [Chap07.豚鼠 20.0](https://docs.google.com/document/d/1_qDVzx3G2QHYclxqfNSjarMH0sUKuIBWxhTZ7ACzD2I/edit?usp=drivesdk)
- [Chap08.秘鲁寒流 20.0](https://docs.google.com/document/d/1Kof7gLcBPsoNAfw6k7tx_AJ2EZwT_pmMt2zo7OUB_7M/edit?usp=drivesdk)
- [Chap09.奇恰酒 20.0](https://docs.google.com/document/d/1ldkz_qvDlUhb-DEtwPCGd5JNv2KCQHO_QSYja3-PjeA/edit?usp=drivesdk)
- [Chap10.可可 20.0](https://docs.google.com/document/d/1nDVE-1PATz3BLTLMFc4TOksxB_dkYB4F46W9YCs1DaY/edit?usp=drivesdk)
- [Chap11.辣椒 20.0](https://docs.google.com/document/d/1XCzcDLIFRSDKhGyLUI8sKc8HkVuaFms7hz3bX0v0vns/edit?usp=drivesdk)
- [Chap12.宇宙法则 20.0](https://docs.google.com/document/d/1UF8uJZnswkDuFVph3BTLkMvs9n4toscEtgH400I-ZiM/edit?usp=drivesdk)
- [Chap13.饮宴政治 20.0](https://docs.google.com/document/d/1EIGzwRUWm8ovUOpa2cGEv8_wH8AT7megShN-v_7Oavg/edit?usp=drivesdk)
- [Chap14.饮食器具 20.0](https://docs.google.com/document/d/1wm4Cq-p4QFpP_1e8KCPaDMon3oCIfUa4s0fDWnkRcC4/edit?usp=drivesdk)
- [Chap15.巴查曼卡 20.0](https://docs.google.com/document/d/1hldTTCFczfFTk14j-nJBcpcZwXqUZn9kHZca4JFovfA/edit?usp=drivesdk)
- [Chap16.卡拉尔查文 10.0](https://docs.google.com/document/d/11Ydk_Glt6efmOiiJgDKkMEElsmt7pfbMHwqnShmcvQ4/edit?usp=drivesdk)
- [Chap17.莫切奇穆 20.0](https://docs.google.com/document/d/1jsjOv6JoB7QIwFXFQIbu2zUDRvC3hC0GSjVfWNPoGKQ/edit?usp=drivesdk)
- [Chap18.蒂亚瓦纳科瓦里 20.0](https://docs.google.com/document/d/1-oFo7exd-kPWQ8Rj0GYOwi-pjrTdY2VAFXP9iCr3rMg/edit?usp=drivesdk)
- [Chap19.印加 20.0](https://docs.google.com/document/d/1mREsHd_jy6xv_u-JtZlTKU12FYy-3BVcBIL6BgEOqTk/edit?usp=drivesdk)
- [Chap20.哥伦布大交换 20.0](https://docs.google.com/document/d/1zM5JRDdaaQgRLPHDb4DI3L1Qv5CYwF1KXoumaVIJ2MI/edit?usp=drivesdk)
