# 90.原有媒介与专题资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1MTxbiSpehn7pRqYNP3T3-GsKxRS7IbJe)

上一级：[10.01.古北安第斯艺术](../README.md)

## 网盘子目录

- [07.古南美饮食 390.0](07.%E5%8F%A4%E5%8D%97%E7%BE%8E%E9%A5%AE%E9%A3%9F%20390.0/README.md)
