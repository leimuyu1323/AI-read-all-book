# 02.两周钱币 150.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1qlX0aRknkftBdYrQ2VIJtZjP9NigLOBA)

上一级：[古代钱币资料](../README.md)

## 网盘子目录

- [01.货币研究 80.0](01.%E8%B4%A7%E5%B8%81%E7%A0%94%E7%A9%B6%2080.0/README.md)

## 网盘原资料

- [Chap02.02.尖足布钱币 1.0.docx](https://docs.google.com/document/d/1Q1bJ3q80O4GzGcCWnwxYI2vMlXQdFZgI/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap02.03.圆足布钱币 2.0.docx](https://docs.google.com/document/d/15MGkWoauQYkBVuY4895UEx7tscgeX6cG/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap02.04.三孔布 10.0](https://docs.google.com/document/d/1As99g-GRAMCXL9YwoLS1pVaD_rfMP7NpmP2Xa8LiBkM/edit?usp=drivesdk)
- [Chap02.05.圜钱钱币 1.0.docx](https://docs.google.com/document/d/1D2Ai7DwZsIgxWcXlXT8o3tpY_izLwpk_/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap02.07.钱板钱币 1.0.docx](https://docs.google.com/document/d/1j6RaK4cnprreKtlOPu-4IGcf53D7yIHA/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap02.贝币 10.0](https://docs.google.com/document/d/1XRxlAv7XQxvRTpCtilKM5MhyJlKz-zMgibDRYER9P0w/edit?usp=drivesdk)
- [Chap06.01. 郢爯金板 20.0](https://docs.google.com/document/d/1lSkCKPkKOqKMQUQq4uPSa9VkLPQUfJ3dpq0r96awqtw/edit?usp=drivesdk)
- [言阳新刀 10.0](https://docs.google.com/document/d/1MqSO7Co2nzN17A3M8brheq0AQK-c1-fRXW0BjRiJ8Z0/edit?usp=drivesdk)
