# 01.货币研究 80.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1LBnqLgVq1Qke7Vhlv0RGYiW5zXYgap0C)

上一级：[02.两周钱币 150.0](../README.md)

## 网盘原资料

- [Chap01.历史基础 20.0](https://docs.google.com/document/d/1xfRqXxm9th6DfEBiuO0RAX2g9DMQf25RbltW3lPtGqA/edit?usp=drivesdk)
- [Chap02.两周贝币 30.0](https://docs.google.com/document/d/15nISCXpKyKQGpFqi1JS0b0clgamtQc3rD6BIQpqoNA4/edit?usp=drivesdk)
- [Chap03.仿制贝币 30.0](https://docs.google.com/document/d/118h57WkoDTcKSIp3LJU-5CQhZtVT0stHaMzDhLimioI/edit?usp=drivesdk)
