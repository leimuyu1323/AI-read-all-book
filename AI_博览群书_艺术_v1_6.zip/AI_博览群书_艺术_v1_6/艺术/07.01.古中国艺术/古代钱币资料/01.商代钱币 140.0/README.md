# 01.商代钱币 140.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1yarmjViG-m6MD2iWOS0_JF5c4lf0drHE)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap01.商代钱币 30.0](https://docs.google.com/document/d/1iKh73JilElE9clIK7tcJp_djK0BvPr-_7vXl2gcZnBc/edit?usp=drivesdk)
- [Chap03.骨贝币 20.0](https://docs.google.com/document/d/1ltEK2aEUMFAJmk38GpPAJWPrREwcaQntfeQkwkLsa_c/edit?usp=drivesdk)
- [Chap04.砗磲贝币 40.0](https://docs.google.com/document/d/1WR7F3MKtNFBXu1Ev1zuC9owRl_6ccsjJrYC7yraO2Js/edit?usp=drivesdk)
- [Chap05.铜贝币 10.0](https://docs.google.com/document/d/1uUU8aMI4yoiqCHD57K_oiw62u9N2129anRqb2N-HRbs/edit?usp=drivesdk)
- [Chap06.金贝币 10.0](https://docs.google.com/document/d/1rFCsbgHNsnNUNkc0WO2qLXkaxVgzUyu_qixdXpkocgY/edit?usp=drivesdk)
- [Chap07.水晶贝币 30.0](https://docs.google.com/document/d/1G7thfhv_yarzJkT4VNK-mT_omMqyjOC_hNzRF1Qj_Hs/edit?usp=drivesdk)
