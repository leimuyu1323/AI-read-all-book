# 11.宋朝钱币 70.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1zlHZ1P5JJhkCDSzvdiTh7yRYS4VEnmXE)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap.西夏天下太平 10.0](https://docs.google.com/document/d/1AtTFONWdiNfpN0xwe-UgwS8pdOgTqI3B9qapRq0w3ZE/edit?usp=drivesdk)
- [Chap01.01.靖康钱币 10.0](https://docs.google.com/document/d/1gXrH41V13gbBFMpkVLWIA1p1viNAMky4hQ20JGUa-Ts/edit?usp=drivesdk)
- [Chap01.02.临安钱币 30.0](https://docs.google.com/document/d/1Wuy0IAwci3hS6tZzy04NMqROml0x9EQvnvGr4Vu-zrM/edit?usp=drivesdk)
- [Chap01.03.太平钱币 10.0](https://docs.google.com/document/d/1UT0njphucn6_cXBu_1eWYCuBfdxmllvZUaYxJkcnw-A/edit?usp=drivesdk)
- [Chap01.06.崇庆钱币](https://docs.google.com/document/d/1_YyZF_n94Hfkrou2t_yTzyWmmWUBixunNzwL8hWFJkg/edit?usp=drivesdk)
- [Chap02.01.泰和钱币 10.0](https://docs.google.com/document/d/1QDy4vcVaIP4DOv3DAwQwvNmSEKp_XbGRXdhNEqDS1U4/edit?usp=drivesdk)
- [Chap03.01.福圣钱币 10.0](https://docs.google.com/document/d/19zAIl1OiT-p6iCR7Yx73birnJ8wFukDVBJR1_M6MFcI/edit?usp=drivesdk)
- [Chap05.01.宋朝银锭 10.0](https://docs.google.com/document/d/1YNsRpctSgf4gZXEyTGl_3R28xGqozbEkibVa8HiIy1I/edit?usp=drivesdk)
