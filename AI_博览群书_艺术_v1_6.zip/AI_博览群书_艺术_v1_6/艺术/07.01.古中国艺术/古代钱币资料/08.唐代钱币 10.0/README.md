# 08.唐代钱币 10.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1uIBEnk7LfG5uaTQ4iaP0jj9Qe7Axr2YX)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap01.01.开元钱币 10.0](https://docs.google.com/document/d/1y7GbTADIZxCT2dI2JOkTu-LOnxkKwuFY0oQY-h9Sdqo/edit?usp=drivesdk)
