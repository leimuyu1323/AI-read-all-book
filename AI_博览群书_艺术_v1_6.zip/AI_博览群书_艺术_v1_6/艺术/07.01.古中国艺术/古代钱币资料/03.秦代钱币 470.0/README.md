# 03.秦代钱币 470.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1r-ZQCwW3r91Hxt0Z7aYsNuAzYZzsY2UN)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap01.秦代钱币 30.0](https://docs.google.com/document/d/18sjv05_-1iTp-Fl0Lf4Nl1yvSlnqN2rZa9vzLksmZ1w/edit?usp=drivesdk)
- [Chap02.战国半两 90.0](https://docs.google.com/document/d/1pm7chDvQVmzd4ayAlepFUx7xZJeg_FfnFzxsiuXCS10/edit?usp=drivesdk)
- [Chap02.秦半两 160.0](https://docs.google.com/document/d/1Aeg6U-DGiTfC7kYpKXSj31zQ7GVxoFpP/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap03.日入千半两 10.0](https://docs.google.com/document/d/1tsKGLBh8SY0ph2GeZhUgkUYDZvEP1-CbCKO1VUEaXXQ/edit?usp=drivesdk)
- [Chap03.银半两 10.0](https://docs.google.com/document/d/1AP7r0KnDIjPT23WB_Te5LzwPwi4lyTj7G2WrcVYYYkk/edit?usp=drivesdk)
- [Chap04.半两镇库 20.0](https://docs.google.com/document/d/1GDC3xZTwSziL_kTPgTZ3vSYART11k5WL9TmAAP16QNs/edit?usp=drivesdk)
- [Chap05.秦半两钱模 10.0](https://docs.google.com/document/d/1Mt-FvHB-J9qWtth4PLNhay6YwbykyJfvIMzj5e9E0m8/edit?usp=drivesdk)
- [Chap06.01.文信钱 20.0](https://docs.google.com/document/d/1LIVhV3gjEjP5FN0HxYDUzkSE0-gfnI8wUQhlooWwVP4/edit?usp=drivesdk)
- [Chap06.02.文信钱模 10.0](https://docs.google.com/document/d/1zgWY-1xkdyx9fR20KgJ6aZ_IuIiI83VpsRc9qRIh_U0/edit?usp=drivesdk)
- [Chap07.金饼 10.0](https://docs.google.com/document/d/1qR6E6JJALDnxx7f2u0iJ1Uzrg9qBJ2dm1AiSUxl-O94/edit?usp=drivesdk)
- [Chap08.兵符 20.0](https://docs.google.com/document/d/1tfFMe1oyKcXXPA_fh4v4P_oLbsMi-qI1/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap09.秦权钱 10.0](https://docs.google.com/document/d/1Eqd7gsNBEexLlpjE4lFBwB6IWBYrGFdfI82ZBkNzhrY/edit?usp=drivesdk)
- [Chap10.秦权 90.0](https://docs.google.com/document/d/1zR6vFubFArMQPC8bZn5aqrSWw8VfZ040/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
