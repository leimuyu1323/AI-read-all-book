# 06.南北朝钱币 50.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1GAgsuR0GQtYbwJCy3Y4x45lMBJqeTVg_)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap04.01.成汉钱 1.0.docx](https://docs.google.com/document/d/1aKR2eBLAJCoQ70rFf67AkZPUT2Gt1uR9/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap05.01.北周钱币 10.0](https://docs.google.com/document/d/1pLHfiC11KlRFczOZdfWgmwTh_ic-lLYk0czwNWFjbD0/edit?usp=drivesdk)
- [Chap05.01.北齐钱币 10.0](https://docs.google.com/document/d/1xtDLDiKTHP5Kt5CT2vGRJQhvv20VosME6R-zvrqLAYc/edit?usp=drivesdk)
- [Chap06.01.南梁钱币 10.0](https://docs.google.com/document/d/1Jx9WJnDP8V_cFUtMcasGRmvK2HaPEdkLjYrce25TE6s/edit?usp=drivesdk)
- [Chap07.01.北魏钱币 10.0](https://docs.google.com/document/d/1-_BMA43O848LTc64WzANrLi0gvpj2-qED72zLcMTE0M/edit?usp=drivesdk)
