# 12.元朝钱币 10.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Yx0SEjefaRLLlcIjYOCyt3rcEggP6BEz)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap01.01.至正钱币 10.0](https://docs.google.com/document/d/1jWIA5JneYNH1NFWGFhptSuKAb7iX5IGUS31SzGm1nv0/edit?usp=drivesdk)
- [Chap02.01.中统宝钞 10.0](https://docs.google.com/document/d/1x-9QJFSbMkpOIecLtcOEfEP_GSV6pgA3mVwwsJ-1u4M/edit?usp=drivesdk)
