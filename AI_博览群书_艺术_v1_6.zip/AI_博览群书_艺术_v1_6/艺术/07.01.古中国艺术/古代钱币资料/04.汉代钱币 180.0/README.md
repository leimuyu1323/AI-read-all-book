# 04.汉代钱币 180.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/17gOKIY0RYP_p-lyBaSl2iNFWNx4yrXCl)

上一级：[古代钱币资料](../README.md)

## 网盘原资料

- [Chap03.01.汉钱币 120.0.docx](https://docs.google.com/document/d/1Jt5Hk6ozjkR1Yw-iacGCbv8fNJmnsIPh/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap03.02.新钱币 3.0.docx](https://docs.google.com/document/d/1Xt6npj7iMMGXYPkXOVLq2gifTE1N8Xci/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap03.03.汉金钱币 2.0.docx](https://docs.google.com/document/d/1cUA6XdY5MZsiNaEM7G9g2VyfWclMg54W/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap03.汉半两母钱 10.0](https://docs.google.com/document/d/1bg6DcBhr_uuU3EkUEoe7VY9vZQCRyU5JMStA6ahjEtw/edit?usp=drivesdk)
- [Chap04.01.金五铢 10.0](https://docs.google.com/document/d/1oraedD1jCTeTwYqaHRCOwjLhd9RugNC1KA-C9RPIUW0/edit?usp=drivesdk)
