# 06.古东亚服饰 150.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/13VN59aL0-jMoKic-jJhekO6TQMmak1y8)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘原资料

- [Chap04.5.壮族服饰 1.0.docx](https://docs.google.com/document/d/1Q8rgiGXt6PDubZtCz4g1E-eaAghMU0r5/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap05.1.日本服饰 27.0.docx](https://docs.google.com/document/d/1f3aISzQt26zdrWpxVUvoYSRX1E2wTHr2/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Document.docx](https://docs.google.com/document/d/17Twsqu4D1fzvMOUei0COe0FVnqSvw9sf/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
