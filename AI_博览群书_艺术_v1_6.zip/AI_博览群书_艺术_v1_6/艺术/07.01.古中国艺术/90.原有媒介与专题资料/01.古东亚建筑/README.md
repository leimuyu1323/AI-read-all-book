# 01.古东亚建筑

[打开网盘中的本目录](https://drive.google.com/drive/folders/1xABlBprEOV43Z5ZGaGXlAvdnLyFYyjAo)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘原资料

- [永安寺](https://docs.google.com/document/d/16CKdHgsOzp9lWi7XVHrccqcAvZO17_a2TD2h8jAnXv4/edit?usp=drivesdk)
