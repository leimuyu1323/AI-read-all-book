# 01.中国钱币 1240.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1JvqjmniNuY885eoc09aGKRM65330vV3W)

上一级：[05.东亚钱币 1240.0](../README.md)
