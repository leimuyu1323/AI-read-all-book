# 05.古东亚雕塑

[打开网盘中的本目录](https://drive.google.com/drive/folders/1_wrTQ52MiCc8ngEVwWLiFv_LkSq5f-e2)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘原资料

- [Chap04.01.健陀罗佛像 53.0.docx](https://docs.google.com/document/d/1FHgcZsgGOQ0InwmDumENM1DohZfJN65E/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap05.1.贵霜佛像 3.0.docx](https://docs.google.com/document/d/1A9doi58xDCH40VyOUCi_nzRv5fSFr-d1/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
