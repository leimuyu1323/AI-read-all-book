# 02.日本饮食 3770.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/13s8tQ-zrh8Ysg8l6y4Lgu3W792WNXVcC)

上一级：[06.古东亚饮食 9020.0](../README.md)

## 网盘子目录

- [05.古日本饮食 20.0](05.%E5%8F%A4%E6%97%A5%E6%9C%AC%E9%A5%AE%E9%A3%9F%2020.0/README.md)

## 网盘原资料

- [Chap01.虎屋菓子 3750.0](https://docs.google.com/document/d/1HU_ofit67m3PLDQFNRqeaqvjCb98vLXv/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap02.虎屋抹茶 30.0](https://docs.google.com/document/d/1CJM8mkOeluoimSi_9q7TFseXCgGDOfkOigsGUlX7mEQ/edit?usp=drivesdk)
