# 05.古日本饮食 20.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/18j9fMsIQOM2WTdXeYbbL2WtuOw8JjqSZ)

上一级：[02.日本饮食 3770.0](../README.md)

## 网盘原资料

- [Chap01.日本茶道 20.0](https://docs.google.com/document/d/156YXW-6Z11PaVPheeWLYtAP45ScCdFMHl5368RFL4eg/edit?usp=drivesdk)
