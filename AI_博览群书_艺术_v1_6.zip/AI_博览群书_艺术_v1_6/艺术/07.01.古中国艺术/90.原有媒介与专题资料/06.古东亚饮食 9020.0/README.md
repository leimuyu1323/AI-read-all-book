# 06.古东亚饮食 9020.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/18RKTVO6qvGcbxdngaRMVsQcL_9ZIUMYq)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘子目录

- [01.中国饮食 5250.0](01.%E4%B8%AD%E5%9B%BD%E9%A5%AE%E9%A3%9F%205250.0/README.md)
- [02.日本饮食 3770.0](02.%E6%97%A5%E6%9C%AC%E9%A5%AE%E9%A3%9F%203770.0/README.md)
