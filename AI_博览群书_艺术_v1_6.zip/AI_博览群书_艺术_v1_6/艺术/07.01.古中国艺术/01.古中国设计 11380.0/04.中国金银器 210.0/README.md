# 04.中国金银器 210.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1fPLLVi1-NQbdn-xH1j-l-15s9SxhNKI_)

上一级：[01.古中国设计 11380.0](../README.md)

## 网盘原资料

- [Document1.docx](https://docs.google.com/document/d/1_48Rp_jjioYwK3kYMEP_Mp_pBu65tihm/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Document2.docx](https://docs.google.com/document/d/1Zzu9gfL1tWGF5kH6Sk1XKqxQk1GPc0xj/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
