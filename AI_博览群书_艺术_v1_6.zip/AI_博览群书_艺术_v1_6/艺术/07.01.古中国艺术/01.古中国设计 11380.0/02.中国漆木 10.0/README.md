# 02.中国漆木 10.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/14SD_lnDd58_73OrmkMP-aa7y5qe61WAl)

上一级：[01.古中国设计 11380.0](../README.md)

## 网盘原资料

- [元漆器 10.0](https://docs.google.com/document/d/1TaF4tTS1JFqvm8tp_TCHxhRsKyoR1X32U8spDSGLhpA/edit?usp=drivesdk)
