# 05.中国青铜 1160.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1KOhegYEpIvbvshjUygitKD4698cRAC4b)

上一级：[01.古中国设计 11380.0](../README.md)

## 网盘原资料

- [Chap7.1.夏青铜 32.0.docx](https://docs.google.com/document/d/1WUfOEa1z4X-tyLQDTyXCWFZIKctCmA0f/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.2.中商青铜 1.0.docx](https://docs.google.com/document/d/1ytf5kZw0vhgIPMPKRf1VNpNNLjMDpTaj/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.4.晚商青铜 19.0.docx](https://docs.google.com/document/d/1UGIb1oDQ76S_VfR4N9ylmE3Igf3e7GIE/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.5.三星堆青铜 3.0.docx](https://docs.google.com/document/d/1hlDr3LsCwn278HkkGGDfmk41ne0vgKpY/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.6.西周青铜器 12.0.docx](https://docs.google.com/document/d/1avjXcNqo9RzhzQjpkNaKDcVnWddzYD_p/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.7.春秋青铜 19.0.docx](https://docs.google.com/document/d/1ObzaF_0YPoEEIcIAsOOM1tOeKLkuTNIP/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap7.8.汉青铜器 9.0.docx](https://docs.google.com/document/d/1EGYRnhNmR3f2n8RAkm_q8snjP70iVG1A/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
