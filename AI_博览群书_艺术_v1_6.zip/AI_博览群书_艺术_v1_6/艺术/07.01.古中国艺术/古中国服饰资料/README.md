# 古中国服饰资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1AOq7Bc6jw4sasQL_zurEPcDNE0IEiNUX)

上一级：[07.01.古中国艺术](../README.md)

## 网盘原资料

- [Chap04.1.辽服饰 2.0.docx](https://docs.google.com/document/d/1lM8Uw5stDix691ya35GuAH4elejzsXhN/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
