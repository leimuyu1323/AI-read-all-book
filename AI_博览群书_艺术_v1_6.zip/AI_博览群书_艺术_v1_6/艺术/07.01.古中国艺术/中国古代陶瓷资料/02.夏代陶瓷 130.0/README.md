# 02.夏代陶瓷 130.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1pi1AScLRHA1sM2OWAD6zGn3sPmCnRCW6)

上一级：[中国古代陶瓷资料](../README.md)

## 网盘原资料

- [Chap05.1.夏陶器 130.0.docx](https://docs.google.com/document/d/1tdb-K_7ChSDVmWyuRPx4-tYDMJs5atiT/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
