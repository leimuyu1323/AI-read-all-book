# 11.元代陶瓷 790.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Z6eauV2x1oiVO6JbvVsl2g-hEP7HKmfQ)

上一级：[中国古代陶瓷资料](../README.md)

## 网盘原资料

- [Chap12.05.堆彩瓷 30.0](https://docs.google.com/document/d/1Kc3sD0q1mn2eIgudYIu0tLUhXJ99MH6EcGosmE-TyUo/edit?usp=drivesdk)
- [Chap12.1.元钧瓷 50.0.docx](https://docs.google.com/document/d/1wYBpc-6djcBxQFzYI7VdMk__ASw2pMro/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap12.2.元釉里红瓷 40.0.docx](https://docs.google.com/document/d/1zJSBM-VE0fzMEiKRdt6JPeFaKY0loSlL/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap12.3.元青花瓷 640.0.docx](https://docs.google.com/document/d/1o6fjd0YA0O7groHtqf03adK4rxHLAFG7/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap12.4.元蓝瓷 30.0.docx](https://docs.google.com/document/d/1gwPBh9AhUuwKqhGdgSXCCq7IhoEqHj5O/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
