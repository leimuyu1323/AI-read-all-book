# 04.西周陶瓷 250.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1-okW7dD1lxzwtcg8CVBZLnM-sd2OkbB3)

上一级：[中国古代陶瓷资料](../README.md)

## 网盘原资料

- [Chap06.1.周陶器 110.0.docx](https://docs.google.com/document/d/1YaRi7e-ZhNYSj33jkJlk1cKUMQP0asH8/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap06.2.周原始瓷 140.0.docx](https://docs.google.com/document/d/1WZNaTEX58qxHc6p2ZLJuRaAxoZlZ-c1U/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
