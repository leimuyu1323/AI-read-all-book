# 07.01.古中国艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1WUWI5wf8QDhbq5xmoubcamjgJc67ux1s)

## 教材课文

- [001 中国古代艺术的开端：彩陶与玉器](001_%E4%B8%AD%E5%9B%BD%E5%8F%A4%E4%BB%A3%E8%89%BA%E6%9C%AF%E7%9A%84%E5%BC%80%E7%AB%AF%EF%BC%9A%E5%BD%A9%E9%99%B6%E4%B8%8E%E7%8E%89%E5%99%A8.md)
- [002 商代青铜艺术：礼器、铸造与纹饰](002_%E5%95%86%E4%BB%A3%E9%9D%92%E9%93%9C%E8%89%BA%E6%9C%AF%EF%BC%9A%E7%A4%BC%E5%99%A8%E3%80%81%E9%93%B8%E9%80%A0%E4%B8%8E%E7%BA%B9%E9%A5%B0.md)
- [003 西周青铜艺术：礼器组合与铭文](003_%E8%A5%BF%E5%91%A8%E9%9D%92%E9%93%9C%E8%89%BA%E6%9C%AF%EF%BC%9A%E7%A4%BC%E5%99%A8%E7%BB%84%E5%90%88%E4%B8%8E%E9%93%AD%E6%96%87.md)
- [004 东周青铜艺术：地域竞争与表面装饰](004_%E4%B8%9C%E5%91%A8%E9%9D%92%E9%93%9C%E8%89%BA%E6%9C%AF%EF%BC%9A%E5%9C%B0%E5%9F%9F%E7%AB%9E%E4%BA%89%E4%B8%8E%E8%A1%A8%E9%9D%A2%E8%A3%85%E9%A5%B0.md)
- [005 秦汉艺术：帝国墓葬、陶俑与建筑模型](005_%E7%A7%A6%E6%B1%89%E8%89%BA%E6%9C%AF%EF%BC%9A%E5%B8%9D%E5%9B%BD%E5%A2%93%E8%91%AC%E3%80%81%E9%99%B6%E4%BF%91%E4%B8%8E%E5%BB%BA%E7%AD%91%E6%A8%A1%E5%9E%8B.md)
- [006 魏晋南北朝艺术：佛教造像与视觉转型](006_%E9%AD%8F%E6%99%8B%E5%8D%97%E5%8C%97%E6%9C%9D%E8%89%BA%E6%9C%AF%EF%BC%9A%E4%BD%9B%E6%95%99%E9%80%A0%E5%83%8F%E4%B8%8E%E8%A7%86%E8%A7%89%E8%BD%AC%E5%9E%8B.md)
- [007 隋唐佛教艺术：造像、材料与礼拜空间](007_%E9%9A%8B%E5%94%90%E4%BD%9B%E6%95%99%E8%89%BA%E6%9C%AF%EF%BC%9A%E9%80%A0%E5%83%8F%E3%80%81%E6%9D%90%E6%96%99%E4%B8%8E%E7%A4%BC%E6%8B%9C%E7%A9%BA%E9%97%B4.md)
- [008 唐代墓葬艺术：三彩骆驼、舞俑与跨地区交流](008_%E5%94%90%E4%BB%A3%E5%A2%93%E8%91%AC%E8%89%BA%E6%9C%AF%EF%BC%9A%E4%B8%89%E5%BD%A9%E9%AA%86%E9%A9%BC%E3%80%81%E8%88%9E%E4%BF%91%E4%B8%8E%E8%B7%A8%E5%9C%B0%E5%8C%BA%E4%BA%A4%E6%B5%81.md)
- [009 唐代书画：宫廷绘画与古典书法的传承](009_%E5%94%90%E4%BB%A3%E4%B9%A6%E7%94%BB%EF%BC%9A%E5%AE%AB%E5%BB%B7%E7%BB%98%E7%94%BB%E4%B8%8E%E5%8F%A4%E5%85%B8%E4%B9%A6%E6%B3%95%E7%9A%84%E4%BC%A0%E6%89%BF.md)
- [010 五代至北宋山水画：立轴、手卷与空间经验](010_%E4%BA%94%E4%BB%A3%E8%87%B3%E5%8C%97%E5%AE%8B%E5%B1%B1%E6%B0%B4%E7%94%BB%EF%BC%9A%E7%AB%8B%E8%BD%B4%E3%80%81%E6%89%8B%E5%8D%B7%E4%B8%8E%E7%A9%BA%E9%97%B4%E7%BB%8F%E9%AA%8C.md)
- [011 南宋绘画：花鸟细察与人物叙事](011_%E5%8D%97%E5%AE%8B%E7%BB%98%E7%94%BB%EF%BC%9A%E8%8A%B1%E9%B8%9F%E7%BB%86%E5%AF%9F%E4%B8%8E%E4%BA%BA%E7%89%A9%E5%8F%99%E4%BA%8B.md)
- [012 宋代陶瓷：建窑茶盏与南宋官窑](012_%E5%AE%8B%E4%BB%A3%E9%99%B6%E7%93%B7%EF%BC%9A%E5%BB%BA%E7%AA%91%E8%8C%B6%E7%9B%8F%E4%B8%8E%E5%8D%97%E5%AE%8B%E5%AE%98%E7%AA%91.md)
- [013 元代至明初文人画：赵孟頫与倪瓒](013_%E5%85%83%E4%BB%A3%E8%87%B3%E6%98%8E%E5%88%9D%E6%96%87%E4%BA%BA%E7%94%BB%EF%BC%9A%E8%B5%B5%E5%AD%9F%E9%A0%AB%E4%B8%8E%E5%80%AA%E7%93%92.md)
- [014 元代青花瓷：景德镇、钴蓝与器形变化](014_%E5%85%83%E4%BB%A3%E9%9D%92%E8%8A%B1%E7%93%B7%EF%BC%9A%E6%99%AF%E5%BE%B7%E9%95%87%E3%80%81%E9%92%B4%E8%93%9D%E4%B8%8E%E5%99%A8%E5%BD%A2%E5%8F%98%E5%8C%96.md)
- [015 明初宫廷瓷器：宣德青花与制度化生产](015_%E6%98%8E%E5%88%9D%E5%AE%AB%E5%BB%B7%E7%93%B7%E5%99%A8%EF%BC%9A%E5%AE%A3%E5%BE%B7%E9%9D%92%E8%8A%B1%E4%B8%8E%E5%88%B6%E5%BA%A6%E5%8C%96%E7%94%9F%E4%BA%A7.md)
- [016 明初绘画：宫廷山水与花鸟传统](016_%E6%98%8E%E5%88%9D%E7%BB%98%E7%94%BB%EF%BC%9A%E5%AE%AB%E5%BB%B7%E5%B1%B1%E6%B0%B4%E4%B8%8E%E8%8A%B1%E9%B8%9F%E4%BC%A0%E7%BB%9F.md)

## 网盘子目录

- [01.古中国设计 11380.0](01.%E5%8F%A4%E4%B8%AD%E5%9B%BD%E8%AE%BE%E8%AE%A1%2011380.0/README.md)
- [01.古中国雕塑](01.%E5%8F%A4%E4%B8%AD%E5%9B%BD%E9%9B%95%E5%A1%91/README.md)
- [03.古中国视觉 16140.0](03.%E5%8F%A4%E4%B8%AD%E5%9B%BD%E8%A7%86%E8%A7%89%2016140.0/README.md)
- [90.原有媒介与专题资料](90.%E5%8E%9F%E6%9C%89%E5%AA%92%E4%BB%8B%E4%B8%8E%E4%B8%93%E9%A2%98%E8%B5%84%E6%96%99/README.md)
- [中国古代玉器资料](%E4%B8%AD%E5%9B%BD%E5%8F%A4%E4%BB%A3%E7%8E%89%E5%99%A8%E8%B5%84%E6%96%99/README.md)
- [中国古代金银器资料](%E4%B8%AD%E5%9B%BD%E5%8F%A4%E4%BB%A3%E9%87%91%E9%93%B6%E5%99%A8%E8%B5%84%E6%96%99/README.md)
- [中国古代陶瓷资料](%E4%B8%AD%E5%9B%BD%E5%8F%A4%E4%BB%A3%E9%99%B6%E7%93%B7%E8%B5%84%E6%96%99/README.md)
- [古中国服饰资料](%E5%8F%A4%E4%B8%AD%E5%9B%BD%E6%9C%8D%E9%A5%B0%E8%B5%84%E6%96%99/README.md)
- [古中国饮食资料](%E5%8F%A4%E4%B8%AD%E5%9B%BD%E9%A5%AE%E9%A3%9F%E8%B5%84%E6%96%99/README.md)
- [古代家具资料](%E5%8F%A4%E4%BB%A3%E5%AE%B6%E5%85%B7%E8%B5%84%E6%96%99/README.md)
- [古代钱币资料](%E5%8F%A4%E4%BB%A3%E9%92%B1%E5%B8%81%E8%B5%84%E6%96%99/README.md)
- [唐代建筑](%E5%94%90%E4%BB%A3%E5%BB%BA%E7%AD%91/README.md)

## 网盘原资料

- [001 中国古代艺术的开端：彩陶与玉器](https://docs.google.com/document/d/1TcgIrwO2weKMTka5VOMNZZqSur_aPHEJw97wPdi1bK8/edit?usp=drivesdk)
- [002 商代青铜艺术：礼器、铸造与纹饰](https://docs.google.com/document/d/1oUavrCOCx0YCDMwEDrRZs2PPMX1yDvXx4yAi4n7rQ8w/edit?usp=drivesdk)
- [003 西周青铜艺术：礼器组合与铭文](https://docs.google.com/document/d/1aqgWo0TwFu4p7gflCrv0nREGlylLjeVZ2KQKj4ajZOI/edit?usp=drivesdk)
- [004 东周青铜艺术：地域竞争与表面装饰](https://docs.google.com/document/d/1wV4lLtR3eEaSRxwMZLpfn-wNsd6MZLhQU5gqhpACCiM/edit?usp=drivesdk)
- [005 秦汉艺术：帝国墓葬、陶俑与建筑模型](https://docs.google.com/document/d/1ma4x7tMLAGlxg_8AsWskMpHNDBZbndEu9e14c7CAGQc/edit?usp=drivesdk)
- [006 魏晋南北朝艺术：佛教造像与视觉转型](https://docs.google.com/document/d/1rKz_6qksMpblpxd8_NNjwKI0-IuA89e8tnbkCYQqSPM/edit?usp=drivesdk)
- [007 隋唐佛教艺术：造像、材料与礼拜空间](https://docs.google.com/document/d/14BX_V4JCZLgrJ_2AtW602JYZ5O06uziLz4PCB_9N9H4/edit?usp=drivesdk)
- [008 唐代墓葬艺术：三彩骆驼、舞俑与跨地区交流](https://docs.google.com/document/d/1Sa85q0IfoO_473pz84rhNXpjlxuY95w_LSRCkRb97Ak/edit?usp=drivesdk)
- [009 唐代书画：宫廷绘画与古典书法的传承](https://docs.google.com/document/d/1VLVThAdswbFCWOtCM9hpuDsjJWuybw536X4zV4RNKKU/edit?usp=drivesdk)
- [010 五代至北宋山水画：立轴、手卷与空间经验](https://docs.google.com/document/d/1ohUHvTWBbayrp1z1je_hjCPIWNasXxQass5qaLA_QgM/edit?usp=drivesdk)
- [011 南宋绘画：花鸟细察与人物叙事](https://docs.google.com/document/d/130CbkSQ4b8yAdqG1IKf7zquip41OmICXmXWaPfCN5n8/edit?usp=drivesdk)
- [012 宋代陶瓷：建窑茶盏与南宋官窑](https://docs.google.com/document/d/1VJQ5KhxeEzrqAicIUA5wV5IC-hdirUPT5hfVTJo4gsI/edit?usp=drivesdk)
- [013 元代至明初文人画：赵孟頫与倪瓒](https://docs.google.com/document/d/1P7vS5r10PCjGD9gMPlkufRr5-oKJLdh0YYN2EoyygKc/edit?usp=drivesdk)
- [014 元代青花瓷：景德镇、钴蓝与器形变化](https://docs.google.com/document/d/14z5y28PlQESeDhdMKBNIYFMELwlFj-573niBDGTxqHY/edit?usp=drivesdk)
- [015 明初宫廷瓷器：宣德青花与制度化生产](https://docs.google.com/document/d/18JYhWSY2zZ25NYY6WiA_crJTw_DsBP04EPDqXmIg4cU/edit?usp=drivesdk)
- [016 明初绘画：宫廷山水与花鸟传统](https://docs.google.com/document/d/1a8UzKfu5BChDnq0yC7CipzIxLc303ZpWJv5xtxeUBU0/edit?usp=drivesdk)
