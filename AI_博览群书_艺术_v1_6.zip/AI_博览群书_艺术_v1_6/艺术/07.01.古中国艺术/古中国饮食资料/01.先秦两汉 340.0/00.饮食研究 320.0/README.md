# 00.饮食研究 320.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1BgvCsvmkMEif1n4ZKYCrxCxEzRTYKPWu)

上一级：[01.先秦两汉 340.0](../README.md)

## 网盘原资料

- [Chap01.先秦食材 30.0](https://docs.google.com/document/d/1U7QbgPIzfnnfwdYu8ik6KmHppvPrbhiACLzFp61SEug/edit?usp=drivesdk)
- [Chap02.先秦礼制 40.0](https://docs.google.com/document/d/1pKK_7xpY7Lt-dFvm-bTSIorXEoIfU7CuPF4hByhtY04/edit?usp=drivesdk)
- [Chap03.礼崩乐坏 40.0](https://docs.google.com/document/d/12-X2o3JAcJA94rhnqYQZ9rflwugy2iNc3aOiyRxPHs8/edit?usp=drivesdk)
- [Chap04.两汉食材 30.0](https://docs.google.com/document/d/10YRpmGslVBKm8BYivvGqNMt9m29kWVYBbPmLsWkdB7o/edit?usp=drivesdk)
- [Chap05.丝绸之路 30.0](https://docs.google.com/document/d/1P9mh8ryVwsPfQmPuh61q8gcZ9r1VLT_CXvdIQ-oU-O8/edit?usp=drivesdk)
- [Chap06.阶级差异 30.0](https://docs.google.com/document/d/1It5y6A_UeQoCw0WNWADuWBLDgpDqZxAKzegNQ-v21VM/edit?usp=drivesdk)
- [Chap07.饮食实证 30.0](https://docs.google.com/document/d/1McmyBXApMwAX3233NIUo1tkMvoxgIq-RwKXMK9RgL4E/edit?usp=drivesdk)
- [Chap08.炊具演变 30.0](https://docs.google.com/document/d/1Qwk6xnz6BWQUJizpJDYmJIgtVscaeelUvZa-ivFtblI/edit?usp=drivesdk)
- [Chap09.地理环境 30.0](https://docs.google.com/document/d/17pw67S7g9DphAr60B5gCTxm-MyaHx02GOTrRkPFiMNg/edit?usp=drivesdk)
- [Chap10.时令节气 30.0](https://docs.google.com/document/d/1vTH_6Rsr2HLgPQnN-5gbgXZCSDv9dB7SMGZl7gpbyUk/edit?usp=drivesdk)
