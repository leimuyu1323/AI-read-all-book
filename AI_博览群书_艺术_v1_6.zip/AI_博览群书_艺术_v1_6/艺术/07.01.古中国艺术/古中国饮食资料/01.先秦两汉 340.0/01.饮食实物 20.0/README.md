# 01.饮食实物 20.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/11pexNJJ3CGNlSCGiH-2MVTwkCTV-NGp4)

上一级：[01.先秦两汉 340.0](../README.md)

## 网盘原资料

- [Chap01.01.阳干咸鱼 10.0](https://docs.google.com/document/d/1giVlUkN_LNHxV-XvyJ0sR3JCRloocynGZI4I2xypG48/edit?usp=drivesdk)
- [Chap02.马王堆藕汤 10.0](https://docs.google.com/document/d/1hiFRG3dBDtMPlTt3a22rfBFjgktPgnH2KY71XRFns00/edit?usp=drivesdk)
