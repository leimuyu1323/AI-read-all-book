# 00.饮食研究 350.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1tTemhfGb7VXi6cgJDIw2StPXk6BcjGk7)

上一级：[02.魏晋隋唐 460.0](../README.md)

## 网盘原资料

- [Chap01.魏晋食材 30.0](https://docs.google.com/document/d/180Vuu0ldZoPrQ_3x7VnSLNVllrFj8V-g8hTL-2dpftQ/edit?usp=drivesdk)
- [Chap02.隋唐食材 30.0](https://docs.google.com/document/d/14Crgs8kPsn0RISLWd7M3rsa-G811hhNJr9heViAwzC0/edit?usp=drivesdk)
- [Chap03.宴饮礼仪 30.0](https://docs.google.com/document/d/1XJvjbDIgA0TfL5lxe6YZt62HwpWh20HH440LJN2_CVA/edit?usp=drivesdk)
- [Chap04.烧尾宴 30.0](https://docs.google.com/document/d/1WOzPkfA97nSuUvL84us9zy4PXAxcijHZUe1fVfl-w-E/edit?usp=drivesdk)
- [Chap05.烹饪演变 30.0](https://docs.google.com/document/d/17mYtGGD-2ZO15TF3dpOVU29KJOqjUBrNLY3kiCHc2bM/edit?usp=drivesdk)
- [Chap06.节气食俗 30.0](https://docs.google.com/document/d/1qhN_4f8nzrjKa-uq5nnl_L0Zx4ViVPktUltgpSEy9Zk/edit?usp=drivesdk)
- [Chap07.食疗理论 30.0](https://docs.google.com/document/d/1uEa_HnlIkg0g9Omlyt5G5VLZ79WBO41cETzpes0eUpo/edit?usp=drivesdk)
- [Chap08.丝绸之路 30.0](https://docs.google.com/document/d/1pyoV5_QFkyo5K9PvBmtVs7fOudZzunPZyXRjNjuqwLE/edit?usp=drivesdk)
- [Chap09.切脍 30.0](https://docs.google.com/document/d/1XYxbTJHTdbR7YuPjv74yGF8KJ0hJ_m49grKQ0OCLMwU/edit?usp=drivesdk)
- [Chap10.酒文化 30.0](https://docs.google.com/document/d/1MQeO27HCYDq5Dg3B1Eyc5yExA6-vAjroaLCg6IWsTZA/edit?usp=drivesdk)
- [Chap11.寄生虫问题 30.0](https://docs.google.com/document/d/1Mg7dXU6a93cXVpy458ZPsi0biYTRa2cMRlM_qd1Sgk4/edit?usp=drivesdk)
- [Chap12.宫廷饮食 30.0](https://docs.google.com/document/d/1D0b3OkvXbWy_EYj5zyz1n4dUripHN2r97zI0hPUS7Kw/edit?usp=drivesdk)
- [Chap12.海外影响 20.0](https://docs.google.com/document/d/15DMJWQoL7fmMdD-h-QB46_wf7V0XUoW4ly1nkTScpGw/edit?usp=drivesdk)
