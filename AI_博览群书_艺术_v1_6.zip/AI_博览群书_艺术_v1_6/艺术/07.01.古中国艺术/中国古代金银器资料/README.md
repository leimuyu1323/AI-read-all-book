# 中国古代金银器资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1DjT8GkxSSmln0gCifC--RoVSxXkHN4Fu)

上一级：[07.01.古中国艺术](../README.md)

## 网盘原资料

- [Chap7.9.唐金银器 11.0.docx](https://docs.google.com/document/d/1RCMPj5GynCr26mkSks0gOGTyNlPDHgW9/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
