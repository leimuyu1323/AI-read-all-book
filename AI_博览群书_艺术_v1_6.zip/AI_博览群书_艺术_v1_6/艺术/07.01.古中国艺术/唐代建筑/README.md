# 唐代建筑

[打开网盘中的本目录](https://drive.google.com/drive/folders/1xLrytLCxxqSX15rBckXraA4-NWkhy1js)

上一级：[07.01.古中国艺术](../README.md)

## 教材课文

- [001 洛阳应天门：从考古基址读到宫城正门](001_%E6%B4%9B%E9%98%B3%E5%BA%94%E5%A4%A9%E9%97%A8%EF%BC%9A%E4%BB%8E%E8%80%83%E5%8F%A4%E5%9F%BA%E5%9D%80%E8%AF%BB%E5%88%B0%E5%AE%AB%E5%9F%8E%E6%AD%A3%E9%97%A8.md)

## 网盘原资料

- [Chap01.洛阳应天门 1000.0](https://docs.google.com/document/d/1lp_IWs_9oVuoxdgyHVFcylglt3yuJOS-BLvMIVySkf8/edit?usp=drivesdk)
- [Chap01.长安丹凤门 1000.0](https://docs.google.com/document/d/1TtyXqLmqzyzwET5HheVjXtnP5DmcfL-AxlXBrd2Oyog/edit?usp=drivesdk)
- [正平方琉璃瓦](https://docs.google.com/document/d/1B7SWSbh7fVOIPq3WK1OrdPTim5zgjB2KB5xGRjJVnCY/edit?usp=drivesdk)
- [洛阳明堂](https://docs.google.com/document/d/19zXDySjgHHMs17Ti1QXbTl6qFNMQF7BMYBx6FTio51s/edit?usp=drivesdk)
