# 古代家具资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/19yxLdppU0T33hiUAvAEVaQeHhPWwCPCx)

上一级：[07.01.古中国艺术](../README.md)

## 网盘原资料

- [Chap1.唐家具 2.0.docx](https://docs.google.com/document/d/1qN1tKb0xZmWit8hiPNyobDBKNH8fQDNA/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
