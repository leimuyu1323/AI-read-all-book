# 秦代雕塑

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Sb0MX_ZiblfiZHBzjOqMtWP_ktoI1K2-)

上一级：[01.古中国雕塑](../README.md)

## 网盘原资料

- [Chap01.1.秦雕塑 40.0.docx](https://docs.google.com/document/d/1LatAn1W5qwlKV42GBIwvo_4ycq_s666L/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
