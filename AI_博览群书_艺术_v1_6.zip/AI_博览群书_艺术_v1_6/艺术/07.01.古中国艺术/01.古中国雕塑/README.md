# 01.古中国雕塑

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Ip-8NiBVSrI1fKLUzFFRQKepNYnGsy0d)

上一级：[07.01.古中国艺术](../README.md)

## 网盘子目录

- [唐代雕塑 680.0](%E5%94%90%E4%BB%A3%E9%9B%95%E5%A1%91%20680.0/README.md)
- [秦代雕塑](%E7%A7%A6%E4%BB%A3%E9%9B%95%E5%A1%91/README.md)

## 网盘原资料

- [Chap02.01.汉雕塑 6.0.docx](https://docs.google.com/document/d/1vkhlWP_kjHG1CXJUPVy0ooUqFkQit72i/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap03.01.唐墓葬雕塑 46.0.docx](https://docs.google.com/document/d/1-zJeAawN_1p_m34Sf3cb9mmSTyPf0MFp/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap06.1.魏晋雕塑 8.0.docx](https://docs.google.com/document/d/1vUld1sfeyOt5sL8wUIG2KP3tkFbWJaYx/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap06.2.魏晋佛像 64.0.docx](https://docs.google.com/document/d/1h5-DV0u3Ui_oO3YVHCryAzIxqyBwR0Ks/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
