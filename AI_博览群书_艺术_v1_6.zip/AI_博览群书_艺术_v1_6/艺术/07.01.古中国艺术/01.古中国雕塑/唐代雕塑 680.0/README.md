# 唐代雕塑 680.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/17QCRsMEArx4CihGRDEcY7mIuZbFHDm_8)

上一级：[01.古中国雕塑](../README.md)

## 网盘原资料

- [Chap.龙门1280窟 620.0.docx](https://docs.google.com/document/d/1tZ2eizlqT1kTPYem5yFP4D5fFJxlo6Fv/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
