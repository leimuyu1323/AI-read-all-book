# 中国古代玉器资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1CP5lMFLAB0h51D01qph9aOUbAcHSUqDq)

上一级：[07.01.古中国艺术](../README.md)

## 网盘原资料

- [Chap7.3.晚商玉器 3.0.docx](https://docs.google.com/document/d/1OqXAWvuQtVho8RVLs_veVK3nh2l_rq0p/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
