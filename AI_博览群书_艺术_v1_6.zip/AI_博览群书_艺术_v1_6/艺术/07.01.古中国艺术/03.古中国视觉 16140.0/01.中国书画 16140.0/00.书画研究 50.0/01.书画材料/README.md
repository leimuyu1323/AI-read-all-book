# 01.书画材料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1qCvDn1bedanhEH9LJc4FUdEFa7gd0aq5)

上一级：[00.书画研究 50.0](../README.md)

## 网盘原资料

- [Chap01.书画材料 50.0](https://docs.google.com/document/d/1eNTDrA1v6gt0Wlaadi0iiT_bjoMV8kfmEjNv6NLEoUw/edit?usp=drivesdk)
