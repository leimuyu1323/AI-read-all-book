# 08.隋代书画

[打开网盘中的本目录](https://drive.google.com/drive/folders/1OaQJXpcog1JyFOtYSpbfkqfj_2mInnvb)

上一级：[书画艺术](../README.md)

## 网盘原资料

- [Chap.吴通墓志铭 60.0](https://docs.google.com/document/d/1ZhEnM8FI24r6ql6Vu1D_-w2gzDGuRhzXi9unbOnMm0c/edit?usp=drivesdk)
- [Chap.展子虔游春图 60.0](https://docs.google.com/document/d/1pwYZ6kuVfc-nfuFhUWuWabDw0VcgOHXG/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap.智永千字文](https://docs.google.com/document/d/1kiBF6X_YpJck1QOMXCMLNpywHPWYxiKKBbNSPwvSojM/edit?usp=drivesdk)
- [Chap.郭休墓志铭 120.0](https://docs.google.com/document/d/1aE3UBhObjJ5R8giO8YUApfbC0Wgb6K3fXhwCuCpU9fw/edit?usp=drivesdk)
