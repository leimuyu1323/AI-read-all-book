# 03.秦代书画 1480.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1boEYkvradEndH6zZCgc3I4YMxH7szXU3)

上一级：[01.中国书画 16140.0](../README.md)

## 网盘原资料

- [Chap.丞相诏铭 10.0](https://drive.google.com/file/d/1-Dj8KXdo8Tx_whuwEGwa76Ae3DEZg2W3/view?usp=drivesdk)
- [Chap.廿六年诏铭 10.0](https://drive.google.com/file/d/1OBviG-zvCmHJNarrvbY0MFvGFWZwahNd/view?usp=drivesdk)
- [Chap.李斯会稽碑碑林本 240.0](https://drive.google.com/file/d/1Phe4a-mIA8l3lFcwnq-zSwvVy-DXuhTw/view?usp=drivesdk)
- [Chap.李斯峄山碑碑林本 370.0](https://drive.google.com/file/d/1BlTuSz-O0JyneDQF921QF1PDkJWzASgn/view?usp=drivesdk)
- [Chap.李斯泰山碑安国本 130.0](https://drive.google.com/file/d/1ZJke34faVWvO6__Yqhqdr8p2k65S-cIB/view?usp=drivesdk)
- [Chap.李斯琅琊台碑碑林本 50.0](https://drive.google.com/file/d/1Otmk0fF8vLSo9GDAMFjN1geu5jfvLaoa/view?usp=drivesdk)
- [Chap.李斯田畴碑大观本 10.0](https://docs.google.com/document/d/1ParBkpwlUQjBtMUaIfM788m6GqscCOKg/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap.李斯田畴碑淳化本 20.0](https://docs.google.com/document/d/18Ox8ICeUp8FZxBS6Xxd_3XRYKUfkPmKK/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap.李斯田畴碑绛本 40.0](https://drive.google.com/file/d/1oZXpCgzBanQz36bMNLu8UPBPauJ8yBPE/view?usp=drivesdk)
- [Chap.李斯金石铭绛本 40.0](https://drive.google.com/file/d/1bJdkIU5dmdw6jZ27fc4Bad8i1v2nTyJq/view?usp=drivesdk)
- [Chap.石鼓铭中权本 500.0](https://drive.google.com/file/d/1Y9eZ9P_BDDN_Y3QCtl0i_f8wmd4CYcSG/view?usp=drivesdk)
- [Chap.诅楚铭绛本 60.0](https://drive.google.com/file/d/1f4G2ZP-Aph3dcpGyVGKwUlXsESRw1TYl/view?usp=drivesdk)
