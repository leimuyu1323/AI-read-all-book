# 05.02.古印度艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1xQ7M6tPinnc5yzvD4kLJRRDBp6RQ6IZ_)

## 教材课文

- [001 秣菟罗坐佛，台座上的四年是哪一年](001_%E7%A7%A3%E8%8F%9F%E7%BD%97%E5%9D%90%E4%BD%9B%EF%BC%8C%E5%8F%B0%E5%BA%A7%E4%B8%8A%E7%9A%84%E5%9B%9B%E5%B9%B4%E6%98%AF%E5%93%AA%E4%B8%80%E5%B9%B4.md)
- [002 犍陀罗立佛，衣纹之下为何还有一尊佛](002_%E7%8A%8D%E9%99%80%E7%BD%97%E7%AB%8B%E4%BD%9B%EF%BC%8C%E8%A1%A3%E7%BA%B9%E4%B9%8B%E4%B8%8B%E4%B8%BA%E4%BD%95%E8%BF%98%E6%9C%89%E4%B8%80%E5%B0%8A%E4%BD%9B.md)
- [003 桑奇大塔，为什么要绕着建筑读图](003_%E6%A1%91%E5%A5%87%E5%A4%A7%E5%A1%94%EF%BC%8C%E4%B8%BA%E4%BB%80%E4%B9%88%E8%A6%81%E7%BB%95%E7%9D%80%E5%BB%BA%E7%AD%91%E8%AF%BB%E5%9B%BE.md)
- [004 阿旃陀第一窟：走进壁画中的菩萨身旁](004_%E9%98%BF%E6%97%83%E9%99%80%E7%AC%AC%E4%B8%80%E7%AA%9F%EF%BC%9A%E8%B5%B0%E8%BF%9B%E5%A3%81%E7%94%BB%E4%B8%AD%E7%9A%84%E8%8F%A9%E8%90%A8%E8%BA%AB%E6%97%81.md)

## 网盘原资料

- [001 秣菟罗坐佛，台座上的四年是哪一年](https://docs.google.com/document/d/19iv2gCOCpgpC7h1fl6lxDF08GFqHII_vubIeRD8FlPk/edit?usp=drivesdk)
- [002 犍陀罗立佛，衣纹之下为何还有一尊佛](https://docs.google.com/document/d/1Q_O87zTVOjsQJrEuFHXXWPk2lG5AcCj0u0csypuzEZI/edit?usp=drivesdk)
