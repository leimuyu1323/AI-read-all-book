# 01.泰国用具 20.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/12-CBrYIiUm1SZwuqCMSLB6BOXb_VyvDK)

上一级：[07.古东南亚用具 20.0](../README.md)

## 网盘原资料

- [Chap17.泰国陶器 20.0.docx](https://docs.google.com/document/d/1o6gWuZL-TZo-DSjjBbLIHUoSVUk6j0vs/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
