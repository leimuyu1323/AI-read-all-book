# 08.01.古大陆东南亚艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Tqtd02k8_daFp895MEOZajyBiXsHjciC)

## 教材课文

- [001 吴哥窟搅乳海浮雕：一条蛇怎样组织整面长廊](001_%E5%90%B4%E5%93%A5%E7%AA%9F%E6%90%85%E4%B9%B3%E6%B5%B7%E6%B5%AE%E9%9B%95%EF%BC%9A%E4%B8%80%E6%9D%A1%E8%9B%87%E6%80%8E%E6%A0%B7%E7%BB%84%E7%BB%87%E6%95%B4%E9%9D%A2%E9%95%BF%E5%BB%8A.md)
- [002 蒲甘阿难陀寺：四方佛与环廊怎样安排观看](002_%E8%92%B2%E7%94%98%E9%98%BF%E9%9A%BE%E9%99%80%E5%AF%BA%EF%BC%9A%E5%9B%9B%E6%96%B9%E4%BD%9B%E4%B8%8E%E7%8E%AF%E5%BB%8A%E6%80%8E%E6%A0%B7%E5%AE%89%E6%8E%92%E8%A7%82%E7%9C%8B.md)

## 网盘子目录

- [07.古东南亚用具 20.0](07.%E5%8F%A4%E4%B8%9C%E5%8D%97%E4%BA%9A%E7%94%A8%E5%85%B7%2020.0/README.md)
