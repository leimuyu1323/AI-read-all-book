# 90.原有媒介与专题资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1nHsTyyEc-7EgsO_8LgOCRjt3rpA86MQZ)

上一级：[05.01.印度河文明艺术](../README.md)

## 网盘子目录

- [05.古南亚服饰 40.0](05.%E5%8F%A4%E5%8D%97%E4%BA%9A%E6%9C%8D%E9%A5%B0%2040.0/README.md)
- [05.古南亚用具](05.%E5%8F%A4%E5%8D%97%E4%BA%9A%E7%94%A8%E5%85%B7/README.md)
- [05.古南亚饮食 160.0](05.%E5%8F%A4%E5%8D%97%E4%BA%9A%E9%A5%AE%E9%A3%9F%20160.0/README.md)
