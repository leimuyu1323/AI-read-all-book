# 05.古南亚服饰 40.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1ObhQwSp3IPA40_KeQpQLSMfh8o5D-bNH)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘原资料

- [Chap04.4.西藏服饰 1.0.docx](https://docs.google.com/document/d/1tT7V292ZRgJHHILzczZqz_uH-G6Sgmzh/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
- [Chap5.1.莫卧儿首饰 4.0.docx](https://docs.google.com/document/d/1_VMJnHSA0NKzq9quv4QSfwI1lPm0_JAg/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
