# 00.饮食研究 160.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1omEyRuHHqCEvw8lq33EUF5vztJUTzSe9)

上一级：[05.古南亚饮食 160.0](../README.md)

## 网盘原资料

- [Chap01.哈拉帕饮食 20.0](https://docs.google.com/document/d/1dXa_vbjPgGhkrkDNUXSrJBq7Nr8SR7u5JRZ7Ro_DvHU/edit?usp=drivesdk)
- [Chap02.轴心时代饮食 20.0](https://docs.google.com/document/d/1ieMTZWchbA6pCVhwAw0U3pWlG9IOtUvKOsqRPkpg7QI/edit?usp=drivesdk)
- [Chap03.阿育吠陀饮食 20.0](https://docs.google.com/document/d/1cH4w9I4I7blETdoqoaFDLsVUMEIjlFvWepV3A68UdN0/edit?usp=drivesdk)
- [Chap04.中世纪饮食 20.0](https://docs.google.com/document/d/1v5wuQ6kSTQy4BZa2M8lLTJkw-l6XmbpvFvZKl6Js3-E/edit?usp=drivesdk)
- [Chap05.莫卧儿饮食 20.0](https://docs.google.com/document/d/1jlWncyY_zqFbwVI7yqL-hBJYTPlLubOFdqnOMbis6Yo/edit?usp=drivesdk)
- [Chap06.物种交换 20.0](https://docs.google.com/document/d/1g6tM-ev7iBMS2bOtgfT8_mKi9Z2ZqvKolvo7Sae70WI/edit?usp=drivesdk)
- [Chap07.英国殖民 20.0](https://docs.google.com/document/d/1LAsPFYfP8C3hxkljo8pNP58ss2Omkcm25lM9inP8wkw/edit?usp=drivesdk)
- [Chap08.全球影响 20.0](https://docs.google.com/document/d/1TaM50uvy3oGPS_KPbe3y7LvfAAoFkzlCVlYYXH4QXvs/edit?usp=drivesdk)
