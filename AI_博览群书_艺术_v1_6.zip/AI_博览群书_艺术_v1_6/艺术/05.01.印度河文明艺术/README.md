# 05.01.印度河文明艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1IKA0C2-2C-w_6ZjZhd4NgInlFNBoMSQu)

## 教材课文

- [001 印度河印章，文字未读通时怎样看图](001_%E5%8D%B0%E5%BA%A6%E6%B2%B3%E5%8D%B0%E7%AB%A0%EF%BC%8C%E6%96%87%E5%AD%97%E6%9C%AA%E8%AF%BB%E9%80%9A%E6%97%B6%E6%80%8E%E6%A0%B7%E7%9C%8B%E5%9B%BE.md)
- [002 摩亨佐达罗的大浴池：水位以下的建筑](002_%E6%91%A9%E4%BA%A8%E4%BD%90%E8%BE%BE%E7%BD%97%E7%9A%84%E5%A4%A7%E6%B5%B4%E6%B1%A0%EF%BC%9A%E6%B0%B4%E4%BD%8D%E4%BB%A5%E4%B8%8B%E7%9A%84%E5%BB%BA%E7%AD%91.md)

## 网盘子目录

- [90.原有媒介与专题资料](90.%E5%8E%9F%E6%9C%89%E5%AA%92%E4%BB%8B%E4%B8%8E%E4%B8%93%E9%A2%98%E8%B5%84%E6%96%99/README.md)
