# 06.05.丝绸之路艺术交流

[打开网盘中的本目录](https://drive.google.com/drive/folders/1j4v_SHJyY85xTayplUNr4Sbemz80JkQg)

## 教材课文

- [001 敦煌以西的粟特古信札：谁能让一封信抵达](001_%E6%95%A6%E7%85%8C%E4%BB%A5%E8%A5%BF%E7%9A%84%E7%B2%9F%E7%89%B9%E5%8F%A4%E4%BF%A1%E6%9C%AD%EF%BC%9A%E8%B0%81%E8%83%BD%E8%AE%A9%E4%B8%80%E5%B0%81%E4%BF%A1%E6%8A%B5%E8%BE%BE.md)
- [002 莫高窟第17窟：一间侧室如何保存多种文字和图像](002_%E8%8E%AB%E9%AB%98%E7%AA%9F%E7%AC%AC17%E7%AA%9F%EF%BC%9A%E4%B8%80%E9%97%B4%E4%BE%A7%E5%AE%A4%E5%A6%82%E4%BD%95%E4%BF%9D%E5%AD%98%E5%A4%9A%E7%A7%8D%E6%96%87%E5%AD%97%E5%92%8C%E5%9B%BE%E5%83%8F.md)
