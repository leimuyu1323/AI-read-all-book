# 05.03.古斯里兰卡艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1kNujHwN0We601aXXFpt_10stxhzcxJC2)

## 教材课文

- [001 锡吉里耶：从水园、岩壁到狮爪之间](001_%E9%94%A1%E5%90%89%E9%87%8C%E8%80%B6%EF%BC%9A%E4%BB%8E%E6%B0%B4%E5%9B%AD%E3%80%81%E5%B2%A9%E5%A3%81%E5%88%B0%E7%8B%AE%E7%88%AA%E4%B9%8B%E9%97%B4.md)
- [002 阿努拉德普勒：佛塔、菩提树与持续使用的圣城](002_%E9%98%BF%E5%8A%AA%E6%8B%89%E5%BE%B7%E6%99%AE%E5%8B%92%EF%BC%9A%E4%BD%9B%E5%A1%94%E3%80%81%E8%8F%A9%E6%8F%90%E6%A0%91%E4%B8%8E%E6%8C%81%E7%BB%AD%E4%BD%BF%E7%94%A8%E7%9A%84%E5%9C%A3%E5%9F%8E.md)
