# 06.01.草原艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1pTvYUXlJXqWyWk3NCa-mIIZY-FF0qsyy)

## 教材课文

- [001 巴泽雷克绒毯：冰封墓里保存下来的马队](001_%E5%B7%B4%E6%B3%BD%E9%9B%B7%E5%85%8B%E7%BB%92%E6%AF%AF%EF%BC%9A%E5%86%B0%E5%B0%81%E5%A2%93%E9%87%8C%E4%BF%9D%E5%AD%98%E4%B8%8B%E6%9D%A5%E7%9A%84%E9%A9%AC%E9%98%9F.md)
- [002 伊塞克金衣人：由墓中的金片复原一套衣装](002_%E4%BC%8A%E5%A1%9E%E5%85%8B%E9%87%91%E8%A1%A3%E4%BA%BA%EF%BC%9A%E7%94%B1%E5%A2%93%E4%B8%AD%E7%9A%84%E9%87%91%E7%89%87%E5%A4%8D%E5%8E%9F%E4%B8%80%E5%A5%97%E8%A1%A3%E8%A3%85.md)
