# 11.03.古密克罗尼西亚艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1D9KT80lPeDcRUk4fCze6Mgsugd1gOYdH)

## 教材课文

- [001 马绍尔群岛的航海图，海浪可以怎样表示](001_%E9%A9%AC%E7%BB%8D%E5%B0%94%E7%BE%A4%E5%B2%9B%E7%9A%84%E8%88%AA%E6%B5%B7%E5%9B%BE%EF%BC%8C%E6%B5%B7%E6%B5%AA%E5%8F%AF%E4%BB%A5%E6%80%8E%E6%A0%B7%E8%A1%A8%E7%A4%BA.md)
- [002 南马都尔：水道怎样把人工小岛连成一座仪式中心](002_%E5%8D%97%E9%A9%AC%E9%83%BD%E5%B0%94%EF%BC%9A%E6%B0%B4%E9%81%93%E6%80%8E%E6%A0%B7%E6%8A%8A%E4%BA%BA%E5%B7%A5%E5%B0%8F%E5%B2%9B%E8%BF%9E%E6%88%90%E4%B8%80%E5%BA%A7%E4%BB%AA%E5%BC%8F%E4%B8%AD%E5%BF%83.md)
