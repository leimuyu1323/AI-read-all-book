# 11.04.古波利尼西亚艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1t__vFE8WDh8_Par8Q85rzBWO3Mz8zAsE)

## 教材课文

- [001 毛利会堂，构件怎样让祖先在场](001_%E6%AF%9B%E5%88%A9%E4%BC%9A%E5%A0%82%EF%BC%8C%E6%9E%84%E4%BB%B6%E6%80%8E%E6%A0%B7%E8%AE%A9%E7%A5%96%E5%85%88%E5%9C%A8%E5%9C%BA.md)
- [002 拉帕努伊摩艾：从采石场到面向聚落的平台](002_%E6%8B%89%E5%B8%95%E5%8A%AA%E4%BC%8A%E6%91%A9%E8%89%BE%EF%BC%9A%E4%BB%8E%E9%87%87%E7%9F%B3%E5%9C%BA%E5%88%B0%E9%9D%A2%E5%90%91%E8%81%9A%E8%90%BD%E7%9A%84%E5%B9%B3%E5%8F%B0.md)
