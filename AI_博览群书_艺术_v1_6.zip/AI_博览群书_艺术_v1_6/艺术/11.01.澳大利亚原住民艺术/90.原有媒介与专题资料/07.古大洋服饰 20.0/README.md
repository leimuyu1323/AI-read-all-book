# 07.古大洋服饰 20.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1GlBkTECRQvrYOwwco7iWvVfKvYfvMSXU)

上一级：[90.原有媒介与专题资料](../README.md)

## 网盘原资料

- [Chap06.1.大洋服饰 2.0.docx](https://docs.google.com/document/d/1GyHNC27BAcVm8RMZj1dyG_wxdNk5xJ_T/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
