# 90.原有媒介与专题资料

[打开网盘中的本目录](https://drive.google.com/drive/folders/1Lsb4AQWwvFGfJiLZGCviCzB59YxcNMlh)

上一级：[11.01.澳大利亚原住民艺术](../README.md)

## 网盘子目录

- [07.古大洋服饰 20.0](07.%E5%8F%A4%E5%A4%A7%E6%B4%8B%E6%9C%8D%E9%A5%B0%2020.0/README.md)
