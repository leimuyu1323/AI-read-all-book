# 08.03.古东南亚艺术交流

[打开网盘中的本目录](https://drive.google.com/drive/folders/1wRAv5ZV-rgdFn8LujoTpFz-Ktg2YSsr4)

## 教材课文

- [001 从越南东山铜鼓读海陆交流](001_%E4%BB%8E%E8%B6%8A%E5%8D%97%E4%B8%9C%E5%B1%B1%E9%93%9C%E9%BC%93%E8%AF%BB%E6%B5%B7%E9%99%86%E4%BA%A4%E6%B5%81.md)
- [002 勿里洞沉船：一只长沙窑碗怎样给航程定年](002_%E5%8B%BF%E9%87%8C%E6%B4%9E%E6%B2%89%E8%88%B9%EF%BC%9A%E4%B8%80%E5%8F%AA%E9%95%BF%E6%B2%99%E7%AA%91%E7%A2%97%E6%80%8E%E6%A0%B7%E7%BB%99%E8%88%AA%E7%A8%8B%E5%AE%9A%E5%B9%B4.md)
