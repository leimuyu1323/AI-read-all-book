# 02.古日本设计 20.0

[打开网盘中的本目录](https://drive.google.com/drive/folders/1lzbSNgmSv4uEx05U5sHMGYqWXjswKdmD)

上一级：[07.03.古日本艺术](../README.md)

## 网盘原资料

- [Chap16.日本瓷器 2.0.docx](https://docs.google.com/document/d/1NkURphcY49qZLXg_qaLntgnnABRQLtKQ/edit?usp=drivesdk&ouid=115278800559113148372&rtpof=true&sd=true)
