# 08.02.古海岛东南亚艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1v057a8D0y79gOKur98ff8Eu4J6a4SRdf)

## 教材课文

- [001 婆罗浮屠，一座山丘怎样变成可行走的叙事](001_%E5%A9%86%E7%BD%97%E6%B5%AE%E5%B1%A0%EF%BC%8C%E4%B8%80%E5%BA%A7%E5%B1%B1%E4%B8%98%E6%80%8E%E6%A0%B7%E5%8F%98%E6%88%90%E5%8F%AF%E8%A1%8C%E8%B5%B0%E7%9A%84%E5%8F%99%E4%BA%8B.md)
- [002 普兰巴南：把《罗摩衍那》读成一圈石雕](002_%E6%99%AE%E5%85%B0%E5%B7%B4%E5%8D%97%EF%BC%9A%E6%8A%8A%E3%80%8A%E7%BD%97%E6%91%A9%E8%A1%8D%E9%82%A3%E3%80%8B%E8%AF%BB%E6%88%90%E4%B8%80%E5%9C%88%E7%9F%B3%E9%9B%95.md)
