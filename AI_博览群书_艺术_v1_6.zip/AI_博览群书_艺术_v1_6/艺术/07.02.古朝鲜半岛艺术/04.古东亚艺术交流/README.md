# 04.古东亚艺术交流

[打开网盘中的本目录](https://drive.google.com/drive/folders/1_Y7sKG3aHB7Qk_7IFE-xqaMsEHjpK16s)

上一级：[07.02.古朝鲜半岛艺术](../README.md)

## 教材课文

- [001 从礼器到手卷，东亚艺术怎样改变观看的时间](001_%E4%BB%8E%E7%A4%BC%E5%99%A8%E5%88%B0%E6%89%8B%E5%8D%B7%EF%BC%8C%E4%B8%9C%E4%BA%9A%E8%89%BA%E6%9C%AF%E6%80%8E%E6%A0%B7%E6%94%B9%E5%8F%98%E8%A7%82%E7%9C%8B%E7%9A%84%E6%97%B6%E9%97%B4.md)
- [002 两尊半跏思惟像：从朝鲜半岛到京都广隆寺](002_%E4%B8%A4%E5%B0%8A%E5%8D%8A%E8%B7%8F%E6%80%9D%E6%83%9F%E5%83%8F%EF%BC%9A%E4%BB%8E%E6%9C%9D%E9%B2%9C%E5%8D%8A%E5%B2%9B%E5%88%B0%E4%BA%AC%E9%83%BD%E5%B9%BF%E9%9A%86%E5%AF%BA.md)
