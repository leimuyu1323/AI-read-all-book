# 09.02.古中美洲艺术

[打开网盘中的本目录](https://drive.google.com/drive/folders/1hbRNwtsOU11xyWRU7aLwjXQunOr-5Fg5)

## 教材课文

- [001 亚斯奇兰门楣，雕刻为什么放在头顶上](001_%E4%BA%9A%E6%96%AF%E5%A5%87%E5%85%B0%E9%97%A8%E6%A5%A3%EF%BC%8C%E9%9B%95%E5%88%BB%E4%B8%BA%E4%BB%80%E4%B9%88%E6%94%BE%E5%9C%A8%E5%A4%B4%E9%A1%B6%E4%B8%8A.md)
- [002 奥尔梅克巨石头像：一块玄武岩怎样成为一张脸](002_%E5%A5%A5%E5%B0%94%E6%A2%85%E5%85%8B%E5%B7%A8%E7%9F%B3%E5%A4%B4%E5%83%8F%EF%BC%9A%E4%B8%80%E5%9D%97%E7%8E%84%E6%AD%A6%E5%B2%A9%E6%80%8E%E6%A0%B7%E6%88%90%E4%B8%BA%E4%B8%80%E5%BC%A0%E8%84%B8.md)
