# 教材许可

《博览群书艺术》中贡献者有权授权的原创教材文字，沿用《博览群书语言》的知识共享署名—相同方式共享 4.0 国际许可。转载时请标明项目名称、作者或贡献者、章节及来源。改编时请说明改动，并按协议以相同许可分享。

[许可说明](https://creativecommons.org/licenses/by-sa/4.0/deed.zh-hans) · [许可法律文本](https://creativecommons.org/licenses/by-sa/4.0/legalcode)

每幅图的来源及权利说明见该图图注和图版索引。馆藏图像、商标、被引作品及外部网站内容分别适用各自的权利状态。
