# 07.03. 古日本列岛

稻作与金属技术经过迁徙和交流进入列岛，传播速度有地区差异。近畿宫廷文书留下官制，东北村落遗存、北海道阿伊努人与琉球王国另有历史。阅读日本篇时，先比较政令企及的区域，再判断“全国”具体指什么。

- [001 日本 · 稻田、庄园与城下町](001.日本.md)

跨区对读　[韩国](../07.02.古朝鲜半岛/002.韩国.md) · [中国](../07.01.古中国与东亚大陆/001.中国.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Mozu-Furuichi Kofun Group: Mounded Tombs of Ancient Japan - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/1593/)

[全卷目录](../../README.md)
