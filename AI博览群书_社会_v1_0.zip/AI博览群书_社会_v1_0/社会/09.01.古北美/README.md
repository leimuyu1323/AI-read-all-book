# 09.01. 古北美

北极海岸、西北海岸、密西西比河流域、东北林地和西南干旱区在资源上很不相同。一端有为海兽移动的猎人，另一端有靠玉米、河运和公共仪式供养的土台城市。一个地区是否留下石碑，同它能否形成复杂协作没有必然关系。

- [001 加拿大 · 从鲑鱼河、草原野牛到毛皮商路](001.加拿大.md)
- [002 美国 · 从卡霍基亚的土台到土地与公民权](002.美国.md)

跨区对读　[墨西哥](../09.02.墨西哥与中美洲/001.墨西哥.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [L’Anse aux Meadows National Historic Site - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/4)

[全卷目录](../../README.md)
