# 02.02. 古努比亚与白尼罗河流域

把地图沿河向南展开，瀑布是交通障碍，也是控制换船与陆上转运的节点。凯尔迈、纳帕塔和麦罗埃相继获得影响，各自联系的矿产、牧地和河段不完全相同。再向南，季节性沼泽使迁牧、捕鱼和牛群交换具有不同于河谷王城的节奏。

- [001 苏丹 · 从凯尔迈到麦罗埃，尼罗河两岸的王权](001.苏丹.md)
- [002 南苏丹 · 洪泛平原上的迁牧与国家边界](002.南苏丹.md)

跨区对读　[埃及](../02.01.尼罗河下游与古埃及/001.埃及.md) · [埃塞俄比亚](../02.05.东非、非洲之角与西印度洋/001.埃塞俄比亚.md)

#### 参考文献与资料

- [UNESCO，《非洲通史》各卷](https://www.unesco.org/en/general-history-africa)
- [MFA Boston Re-Examines Nubia's Story in Exhibition Exploring Power, Representation and Cultural Bias | Museum of Fine Arts Boston](https://www.mfa.org/press-release/nubia)

[全卷目录](../../README.md)
