# 08.02. 海岛东南亚与马来半岛

季风使出航与返航有季节规律，商人可能在港口停留数月。港口因此需要译者、仓储、信贷与多社群居住区。群岛内陆的稻谷、林产和金属生产同港口互补，海路兴旺并不意味着每座岛屿都由海港王权治理。

- [001 马来西亚 · 从布秧谷到马六甲海峡](001.马来西亚.md)
- [002 新加坡 · 十四世纪海港与全球转运站](002.新加坡.md)
- [003 文莱 · 水上聚落、河口王权与油田](003.文莱.md)
- [004 印度尼西亚 · 群岛港口、稻作王国与香料产地](004.印度尼西亚.md)
- [005 东帝汶 · 檀香、山地家屋与帝汶分界](005.东帝汶.md)
- [006 菲律宾 · 港邦、金器与马尼拉帆船](006.菲律宾.md)

跨区对读　[澳大利亚](../11.01.澳大利亚原住民社会/001.澳大利亚.md) · [印度](../05.02.恒河诸国、孟加拉与喜马拉雅/001.印度.md)

#### 参考文献与资料

- [Cambridge，《东南亚史》](https://www.cambridge.org/core/books/cambridge-history-of-southeast-asia/917298863AB03D1105768B453E3A4183)
- [Tapak Arkeologi Sungai Batu & Jeniang, Kedah (Abad Pertama Masihi 2,000 Tahun)](https://www.heritage.gov.my/en/component/content/article/arkeologi-penyelidikan-arkeologi-di-malaysia-tapak-arkeologi-sungai-batu-jeniang-kedah-abad-pertama-masihi-2-000-tahun.html?Itemid=982&catid=17)

[全卷目录](../../README.md)
