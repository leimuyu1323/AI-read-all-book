# 11.04. 古波利尼西亚与远洋社会

远洋定居依赖整套可持续生活能力：能返航的船、可带走的作物、辨认涌浪的知识，以及新聚落的婚姻联系。汤加的贡礼网络、萨摩亚村庄头衔和毛利人的亲属土地关系都是这种世界的一部分，彼此又有鲜明差异。

- [001 新西兰 · 波利尼西亚航海与两种条约文本](001.新西兰.md)
- [002 萨摩亚 · 村庄土地、头衔与分岛历史](002.萨摩亚.md)
- [003 汤加 · 航海联盟与保留王权的现代国家](003.汤加.md)
- [004 图瓦卢 · 环礁园地、独木舟与分离建国](004.图瓦卢.md)

跨区对读　[斐济](../11.02.古美拉尼西亚与岛链迁徙/004.斐济.md) · [基里巴斯](../11.03.古密克罗尼西亚与环礁社会/001.基里巴斯.md) · [智利](../10.03.南安第斯、潘帕斯与南锥体/001.智利.md)

#### 参考文献与资料

- [Māori arrival and settlement | Te Ara Encyclopedia of New Zealand](https://teara.govt.nz/en/history/page-1)
- [The Pacific atoll-island cultural landscape of Tuvalu - UNESCO World Heritage Centre](https://whc.unesco.org/en/tentativelists/6707/)

[全卷目录](../../README.md)
