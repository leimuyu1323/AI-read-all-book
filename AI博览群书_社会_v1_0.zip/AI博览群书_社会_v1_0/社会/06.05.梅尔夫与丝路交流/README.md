# 06.05. 梅尔夫与丝路交流

商路上货物常在数个城市间转手，抵达终点的人和最初生产者未必会面。梅尔夫等绿洲还必须靠当地粮食和水才能维持过路客。丝路交流的另一面，是灌溉渠道的维修，以及贸易路线转移后留在原处的农民和工匠。

- [001 土库曼斯坦 · 梅尔夫绿洲与卡拉库姆牧地](001.土库曼斯坦.md)

跨区对读　[伊朗](../04.04.伊朗高原与帝国交通/001.伊朗.md) · [阿富汗](../06.02.巴克特里亚与高原通道/001.阿富汗.md) · [乌兹别克斯坦](../06.03.粟特城市与河中地区/001.乌兹别克斯坦.md) · [中国](../07.01.古中国与东亚大陆/001.中国.md)

#### 参考文献与资料

- [UNESCO，《中亚文明史》](https://www.unesco.org/archives/multimedia/document-1595)
- [State Historical and Cultural Park “Ancient Merv” - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/886)

[全卷目录](../../README.md)
