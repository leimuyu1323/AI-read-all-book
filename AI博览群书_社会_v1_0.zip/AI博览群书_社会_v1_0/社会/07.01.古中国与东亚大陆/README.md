# 07.01. 古中国与东亚大陆

中原、长江流域、东北、草原与西北绿洲有不同农业和政治传统。汉字文书、官印及考古建筑能追踪国家到达何处，旧村落的饮食、迁居和婚姻则常跨越朝代。蒙古高原单列国别篇，与草原编对读。

- [001 中国 · 从粮仓、封邑到县与户](001.中国.md)
- [002 蒙古国 · 草原联盟怎样组织人、畜和驿站](002.蒙古国.md)

跨区对读　[朝鲜](../07.02.古朝鲜半岛/001.朝鲜.md) · [越南](../08.01.大陆东南亚的河流与王国/005.越南.md) · [哈萨克斯坦](../06.01.草原牧道与天山山口/001.哈萨克斯坦.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Timeline of Chinese History, Art, and Culture - Smithsonian's National Museum of Asian Art](https://asia-archive.si.edu/learn/for-educators/teaching-china-with-the-smithsonian/interactives/timelines/timeline-of-chinese-history-art-and-culture/)

[全卷目录](../../README.md)
