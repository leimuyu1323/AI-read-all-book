# 06.02. 巴克特里亚与高原通道

巴克特里亚位于兴都库什以北、阿姆河流域一带，横跨多个现代国家。绿洲的粮食可以供养城镇和驿旅，山口却会因冬雪中断；能向商人提供补给和保护的寺院、领主与城市，因而同时具有宗教和经济意义。

- [001 阿富汗 · 巴克特里亚、山口和灌溉城镇](001.阿富汗.md)

跨区对读　[塔吉克斯坦](../06.03.粟特城市与河中地区/002.塔吉克斯坦.md) · [土库曼斯坦](../06.05.梅尔夫与丝路交流/001.土库曼斯坦.md) · [巴基斯坦](../05.01.印度河城市与西北通道/001.巴基斯坦.md)

#### 参考文献与资料

- [UNESCO，《中亚文明史》](https://www.unesco.org/archives/multimedia/document-1595)
- [Cultural Landscape and Archaeological Remains of the Bamiyan Valley - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/208)

[全卷目录](../../README.md)
