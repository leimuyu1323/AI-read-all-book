# 11.03. 古密克罗尼西亚与环礁社会

环礁和火山高岛在土地、淡水和食物上差别很大。南马都尔需要集中大量建筑劳力，马绍尔航海依靠涌浪知识，瑙鲁则有磷矿台地。跨海交往能把各岛相联，但不必假定它们共享一个政体或相同定居时间。

- [001 基里巴斯 · 会堂、斑兰与跨赤道国家](001.基里巴斯.md)
- [002 密克罗尼西亚联邦 · 南马都尔石城与四州差异](002.密克罗尼西亚联邦.md)
- [003 马绍尔群岛 · 涌浪航海、环礁土地与核试验迁徙](003.马绍尔群岛.md)
- [004 帕劳 · 石村、女性财产权与跨岛石币](004.帕劳.md)
- [005 瑙鲁 · 一圈沿海土地与中央磷矿](005.瑙鲁.md)

跨区对读　[图瓦卢](../11.04.古波利尼西亚与远洋社会/004.图瓦卢.md) · [巴布亚新几内亚](../11.02.古美拉尼西亚与岛链迁徙/001.巴布亚新几内亚.md)

#### 参考文献与资料

- [Outside the Net: Kiribati and the Knowledge Economy](https://academic.oup.com/jcmc/article/7/2/JCMC726/4584254)
- [Milkfish culture program of the Republic of Nauru :: The University of the South Pacific Library](https://fjdigitallib.usp.ac.fj/greenstone3/pimris/collection/pimris/document/HASH87e3e6aea8e04673636c6f%3Bjsessionid%3D8BA53F613A0464399955424D719FBF83?ed=1)

[全卷目录](../../README.md)
