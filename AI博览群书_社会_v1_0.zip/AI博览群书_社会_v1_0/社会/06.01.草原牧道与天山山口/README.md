# 06.01. 草原牧道与天山山口

季节牧道连接不同海拔的草场，城镇和边墙可能与牧人交换粮食，也可能切断某段迁徙路线。把马骨、墓冢、驿站和后来强制定居的档案放进同一空间，可分辨草原生产本身与帝国征集牲畜之间的区别。

- [001 哈萨克斯坦 · 牧群的季节路线与草原国家](001.哈萨克斯坦.md)
- [002 吉尔吉斯斯坦 · 天山牧道与楚河谷城市](002.吉尔吉斯斯坦.md)

跨区对读　[蒙古国](../07.01.古中国与东亚大陆/002.蒙古国.md) · [俄罗斯](../03.06.东欧、北欧与北大西洋/011.俄罗斯.md)

#### 参考文献与资料

- [UNESCO，《中亚文明史》](https://www.unesco.org/archives/multimedia/document-1595)
- [Rethinking the evidence for early horse domestication at Botai](https://www.nature.com/articles/s41598-021-86832-9)

[全卷目录](../../README.md)
