# 05.04. 南亚跨海交通与马尔代夫

一串珊瑚岛几乎不能生产足够谷物，却能靠椰绳、鱼干和贝币接入跨洋分工。印度洋社会史因此既要问哪支舰队控制海峡，也要问船在哪里补给、家庭如何储水、缺粮时谁有船通向孟加拉或南印度。

- [001 马尔代夫 · 珊瑚环礁上的佛塔、贝币与苏丹](001.马尔代夫.md)

跨区对读　[斯里兰卡](../05.03.斯里兰卡的水库与王国/001.斯里兰卡.md) · [阿曼](../04.05.阿拉伯半岛、红海与海湾/003.阿曼.md) · [孟加拉国](../05.02.恒河诸国、孟加拉与喜马拉雅/002.孟加拉国.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Coral Stone Mosques of Maldives - UNESCO World Heritage Centre](https://whc.unesco.org/en/tentativelists/5812/)

[全卷目录](../../README.md)
