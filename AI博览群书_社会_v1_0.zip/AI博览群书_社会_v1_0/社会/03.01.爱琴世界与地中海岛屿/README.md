# 03.01. 爱琴世界与地中海岛屿

青铜时代的宫殿和海岛神庙都需要集体劳动，能否证实王室和书吏却要看不同遗址的证据。迈锡尼线形文字B是行政档案，马耳他巨石神庙年代更早，没有可比的同时代文书。地中海既是通行的海路，也使岛民保持不同社会组织。

- [001 希腊 · 从宫殿账簿到城邦公民](001.希腊.md)
- [002 马耳他 · 石庙、港湾与帝国补给](002.马耳他.md)

跨区对读　[塞浦路斯](../04.02.安纳托利亚、高加索与东地中海岛屿/002.塞浦路斯.md) · [土耳其](../04.02.安纳托利亚、高加索与东地中海岛屿/001.土耳其.md) · [意大利](../03.02.罗马意大利、山城与教廷/001.意大利.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Linear B page tablet - Heraklion Archaeological Museum](https://heraklionmuseum.gr/en/exhibit/linear-b-page-tablet/)

[全卷目录](../../README.md)
