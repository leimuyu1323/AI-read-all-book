# 04.04. 伊朗高原与帝国交通

高原城市的水源往往需要长距离引水，绿洲之间的补给也需要组织。阿契美尼德统治者既能在浮雕上呈现天下秩序，也必须靠地方书吏记录配给。行政留下的多语材料提醒我们，把后来民族语言直接投射到帝国全境并不可靠。

- [001 伊朗 · 高原上的道路、灌溉与帝国](001.伊朗.md)

跨区对读　[伊拉克](../04.01.美索不达米亚河谷/001.伊拉克.md) · [阿富汗](../06.02.巴克特里亚与高原通道/001.阿富汗.md) · [亚美尼亚](../04.02.安纳托利亚、高加索与东地中海岛屿/003.亚美尼亚.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Iran : a country study](https://tile.loc.gov/storage-services/master/frd/frdcstdy/ir/irancountrystudy00curt_0/irancountrystudy00curt_0.pdf)

[全卷目录](../../README.md)
