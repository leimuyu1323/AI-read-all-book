# 03.03. 伊比利亚、西欧与低地城市

伊比利亚的宗教与政治边界多次移动，低地城市则靠羊毛、港口和水利向领主索取特权。欧洲地图到近代才逐渐接近今天；一座法国或比利时边境小城的中世纪贸易伙伴，可能主要在今天另一个国家。

- [001 法国 · 从高卢庄园到全国性税制](001.法国.md)
- [002 摩纳哥 · 一座海岬上的城堡政治](002.摩纳哥.md)
- [003 安道尔 · 山谷牧场与共治领地](003.安道尔.md)
- [004 西班牙 · 半岛上的多重法律与王权](004.西班牙.md)
- [005 葡萄牙 · 从边疆伯国到海洋税关](005.葡萄牙.md)
- [006 比利时 · 布匹城市与工业煤区](006.比利时.md)
- [007 荷兰 · 堤坝、行省与贸易共和国](007.荷兰.md)
- [008 卢森堡 · 阿尔泽特河谷的一座要塞](008.卢森堡.md)

跨区对读　[摩洛哥](../02.03.北非地中海岸与撒哈拉腹地/004.摩洛哥.md) · [意大利](../03.02.罗马意大利、山城与教廷/001.意大利.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Debasements, Royal Revenues, and Inflation in France During the Hundred Years' War, 1415–1422](https://www.cambridge.org/core/journals/journal-of-economic-history/article/abs/debasements-royal-revenues-and-inflation-in-france-during-the-hundred-years-war-14151422/637A267364FBC3B2D8E1472073CBD701)

[全卷目录](../../README.md)
