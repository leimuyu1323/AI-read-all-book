# 05.02. 恒河诸国、孟加拉与喜马拉雅

恒河平原的稻作城市、孟加拉冲积三角洲、山地寺院与高原牧地形成多种财政基础。沿河而下，税源可能从定居农户转为航道与港口；沿山而上，盐、毛织物和山口保护又变得重要。今日国界多半晚于这些交换关系。

- [001 印度 · 从恒河城市到跨地区的国家与市场](001.印度.md)
- [002 孟加拉国 · 三角洲会移动，村庄和城市也会移动](002.孟加拉国.md)
- [003 尼泊尔 · 加德满都谷地与跨喜马拉雅商路](003.尼泊尔.md)
- [004 不丹 · 山口、寺院与宗堡](004.不丹.md)

跨区对读　[巴基斯坦](../05.01.印度河城市与西北通道/001.巴基斯坦.md) · [斯里兰卡](../05.03.斯里兰卡的水库与王国/001.斯里兰卡.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Serial nomination for Ashokan Edict sites along the Mauryan Routes - UNESCO World Heritage Centre](https://whc.unesco.org/en/tentativelists/6803/)

[全卷目录](../../README.md)
