# 10.01. 北安第斯与加勒比南岸

盐矿、黄金、海贝和高地农作物分布在不同海拔，区域交换早于印加和西班牙征服。波哥大高原、奥里诺科河网与厄瓜多尔太平洋岸虽列同编，其社会权力可能建立在制盐、河航和沿海手工业等不同基础上。

- [001 哥伦比亚 · 高原盐市、河谷金工与咖啡山地](001.哥伦比亚.md)
- [002 委内瑞拉 · 奥里诺科河网与加勒比海岸](002.委内瑞拉.md)
- [003 厄瓜多尔 · 瓦尔迪维亚陶器与赤道高地](003.厄瓜多尔.md)

跨区对读　[巴拿马](../09.02.墨西哥与中美洲/008.巴拿马.md) · [秘鲁](../10.02.中安第斯与的的喀喀湖/001.秘鲁.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [San Agustín Archaeological Park - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/744)

[全卷目录](../../README.md)
