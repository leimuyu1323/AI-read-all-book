# 10.03. 南安第斯、潘帕斯与南锥体

安第斯山脉绝非一条从古至今封闭的国界，山口可把智利南部与潘帕斯贸易相接。地图上后来称作“荒地”的地方常是原住民牧猎和交换的生活空间。国家军队、铁路和牧场铁丝网如何转变用地，须与考古和口述史并读。

- [001 智利 · 沙漠绿洲、马普切边地与铜矿](001.智利.md)
- [002 阿根廷 · 从安第斯道路到潘帕斯牧场](002.阿根廷.md)

跨区对读　[玻利维亚](../10.02.中安第斯与的的喀喀湖/002.玻利维亚.md) · [乌拉圭](../10.04.亚马孙、拉普拉塔低地与圭亚那/002.乌拉圭.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Settlement and Artificial Mummification of the Chinchorro Culture in the Arica and Parinacota Region - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/1634)

[全卷目录](../../README.md)
