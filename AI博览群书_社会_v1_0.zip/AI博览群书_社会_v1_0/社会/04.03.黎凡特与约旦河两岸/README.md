# 04.03. 黎凡特与约旦河两岸

沿海有比布鲁斯等木材和货物转运港，内陆城市依靠泉水、绿洲及商队，耶路撒冷则在不同时期成为多种宗教的朝圣地。古城与人口经历多次改称、迁徙与政治重组。并读以色列、巴勒斯坦和邻国章节，才能看到同一事件怎样形成不同家庭记忆。

- [001 叙利亚 · 商队城市与乡村腹地](001.叙利亚.md)
- [002 黎巴嫩 · 比布鲁斯、推罗与山地村社](002.黎巴嫩.md)
- [003 以色列 · 南黎凡特的古代王国与现代建国](003.以色列.md)
- [004 巴勒斯坦 · 从杰里科的水源到现代流离失所](004.巴勒斯坦.md)
- [005 约旦 · 佩特拉的水渠与商队](005.约旦.md)

跨区对读　[埃及](../02.01.尼罗河下游与古埃及/001.埃及.md) · [伊拉克](../04.01.美索不达米亚河谷/001.伊拉克.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Ebla in the Third Millennium B.C. - The Metropolitan Museum of Art](https://www.metmuseum.org/de/essays/ebla-in-the-third-millennium-b-c)

[全卷目录](../../README.md)
