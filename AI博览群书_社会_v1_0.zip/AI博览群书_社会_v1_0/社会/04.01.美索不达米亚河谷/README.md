# 04.01. 美索不达米亚河谷

上游旱作区与下游需灌溉的冲积平原有不同风险。水能养活城市，也会冲毁沟渠或带来盐碱化。泥板留存尤其丰富，使我们能比较宫廷宣称的征收、商人的私人债务与普通劳动者领取的口粮。

- [001 伊拉克 · 灌渠、泥板与巴格达的城市腹地](001.伊拉克.md)

跨区对读　[叙利亚](../04.03.黎凡特与约旦河两岸/001.叙利亚.md) · [伊朗](../04.04.伊朗高原与帝国交通/001.伊朗.md) · [土耳其](../04.02.安纳托利亚、高加索与东地中海岛屿/001.土耳其.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [The Origins of Writing - The Metropolitan Museum of Art](https://www.metmuseum.org/de/essays/the-origins-of-writing)

[全卷目录](../../README.md)
