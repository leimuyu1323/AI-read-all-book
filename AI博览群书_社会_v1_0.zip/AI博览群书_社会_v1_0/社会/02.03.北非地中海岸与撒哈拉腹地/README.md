# 02.03. 北非地中海岸与撒哈拉腹地

地中海的船能沿海岸快速转运，城市也需要山地木材、腹地橄榄油和谷物。商队把绿洲连接到萨赫勒，沙漠里的水井和向导与海上的港口一样关键。迦太基、努米底亚、伊斯兰城市和近代殖民辖区各有范围，同一地区不同时期的中心会由海边移向内陆。

- [001 利比亚 · 海岸城市和沙漠绿洲的两套网络](001.利比亚.md)
- [002 突尼斯 · 迦太基的港口与伊弗里基亚的腹地](002.突尼斯.md)
- [003 阿尔及利亚 · 努米底亚、山地社会与殖民土地](003.阿尔及利亚.md)
- [004 摩洛哥 · 穿过阿特拉斯山的黄金和王朝](004.摩洛哥.md)

跨区对读　[毛里塔尼亚](../02.04.西非森林、萨赫勒与大西洋岛屿/001.毛里塔尼亚.md) · [西班牙](../03.03.伊比利亚、西欧与低地城市/004.西班牙.md)

#### 参考文献与资料

- [UNESCO，《非洲通史》各卷](https://www.unesco.org/en/general-history-africa)
- [The Garamantes of Fezzan: Excavations on Zinchecra 1965–7](https://www.cambridge.org/core/journals/antiquaries-journal/article/abs/garamantes-of-fezzan-excavations-on-zinchecra-19657/333B25FF671330EBCF809EFBBDC23260)

[全卷目录](../../README.md)
