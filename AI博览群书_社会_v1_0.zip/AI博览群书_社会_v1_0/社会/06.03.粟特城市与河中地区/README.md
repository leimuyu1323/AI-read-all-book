# 06.03. 粟特城市与河中地区

粟特商人的活动范围远大于其故乡城市。片治肯特壁画记录宴饮与神话，商人书信则记录欠款、家庭消息和路途风险。两种材料合读，可以从王朝之外看见远距离贸易需要怎样的信任、语言与亲属支持。

- [001 乌兹别克斯坦 · 粟特城市怎样维系丝路](001.乌兹别克斯坦.md)
- [002 塔吉克斯坦 · 片治肯特壁画与山地商人](002.塔吉克斯坦.md)

跨区对读　[中国](../07.01.古中国与东亚大陆/001.中国.md) · [吉尔吉斯斯坦](../06.01.草原牧道与天山山口/002.吉尔吉斯斯坦.md)

#### 参考文献与资料

- [UNESCO，《中亚文明史》](https://www.unesco.org/archives/multimedia/document-1595)
- [Afrasiab mural paintings | The Sogdians](https://sogdians.si.edu/afrasiab-mural-paintings/)

[全卷目录](../../README.md)
