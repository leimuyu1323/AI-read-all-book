# 05.03. 斯里兰卡的水库与王国

干旱带的塘坝把季节降雨储存到耕作期，王室与僧院的土地又使水利维修成为政治问题。港市与南印度贸易刺激王都，也让岛屿卷入外来战争。在读征服年表时，应保留哪个湖区、港口和地方家族实际受到影响这一层次。

- [001 斯里兰卡 · 蓄水池、寺院与海港竞争](001.斯里兰卡.md)

跨区对读　[印度](../05.02.恒河诸国、孟加拉与喜马拉雅/001.印度.md) · [马尔代夫](../05.04.南亚跨海交通与马尔代夫/001.马尔代夫.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Sacred City of Anuradhapura - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/200/)

[全卷目录](../../README.md)
