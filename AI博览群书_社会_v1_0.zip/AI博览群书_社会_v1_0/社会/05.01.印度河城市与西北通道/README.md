# 05.01. 印度河城市与西北通道

沿河城址的标准化砝码和排水设施展示协调生产的能力，政治制度却因文字未释读而难以确认。青铜时代城市体系消退后，同一区域并未从历史上消失：西北山口、犍陀罗佛寺和后世运河灌区各自利用了不同的地理条件。

- [001 巴基斯坦 · 从摩亨佐达罗的水井到印度河灌区](001.巴基斯坦.md)

跨区对读　[印度](../05.02.恒河诸国、孟加拉与喜马拉雅/001.印度.md) · [阿富汗](../06.02.巴克特里亚与高原通道/001.阿富汗.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Archaeological Ruins at Moenjodaro - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/138/)

[全卷目录](../../README.md)
