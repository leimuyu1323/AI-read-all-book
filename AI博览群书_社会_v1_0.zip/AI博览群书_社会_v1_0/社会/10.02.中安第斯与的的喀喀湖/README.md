# 10.02. 中安第斯与的的喀喀湖

从沿海渔场进入高原湖区，海拔迅速升高。不同作物和畜产需要交换，也能通过家族在多种生态区维持据点而取得。莫切、蒂瓦纳库、瓦里和印加不是一条单线上的四个朝代，多地政权曾长期并存。

- [001 秘鲁 · 没有统一文字档案的安第斯国家](001.秘鲁.md)
- [002 玻利维亚 · 的的喀喀湖高原与波托西矿山](002.玻利维亚.md)

跨区对读　[厄瓜多尔](../10.01.北安第斯与加勒比南岸/003.厄瓜多尔.md) · [智利](../10.03.南安第斯、潘帕斯与南锥体/001.智利.md) · [阿根廷](../10.03.南安第斯、潘帕斯与南锥体/002.阿根廷.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Sacred City of Caral-Supe - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/1269)

[全卷目录](../../README.md)
