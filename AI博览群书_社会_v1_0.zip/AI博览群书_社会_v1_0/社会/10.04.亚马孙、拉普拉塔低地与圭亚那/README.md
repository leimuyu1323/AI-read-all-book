# 10.04. 亚马孙、拉普拉塔低地与圭亚那

亚马孙黑土、沿海土丘与抬高耕地见证低地居民改造环境，并非所有热带森林都是无人影响的原始景观。殖民庄园需要堤坝与排水沟，马龙人社群又以河网与森林组织自治。不同人留下的劳动痕迹有时叠在同一地面上。

- [001 巴拉圭 · 瓜拉尼村庄与河流共和国](001.巴拉圭.md)
- [002 乌拉圭 · 草原土丘与两大帝国之间的港口](002.乌拉圭.md)
- [003 巴西 · 亚马孙人造土与大西洋种植园](003.巴西.md)
- [004 圭亚那 · 河流腹地、排水堤与糖园](004.圭亚那.md)
- [005 苏里南 · 沿岸土丘与马龙人河流社会](005.苏里南.md)

跨区对读　[委内瑞拉](../10.01.北安第斯与加勒比南岸/002.委内瑞拉.md) · [阿根廷](../10.03.南安第斯、潘帕斯与南锥体/002.阿根廷.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Jesuit Missions of La Santísima Trinidad de Paraná and Jesús de Tavarangue - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/648)

[全卷目录](../../README.md)
