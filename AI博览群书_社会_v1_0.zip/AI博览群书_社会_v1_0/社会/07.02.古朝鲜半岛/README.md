# 07.02. 古朝鲜半岛

高句丽的政治中心曾跨鸭绿江移动，百济、新罗与伽倻的海上联系跨过今日国界。高丽与朝鲜王朝的历史是南北共有的；两篇分别侧重北方城市和南部遗存，至二十世纪才以分区占领、战争、工业和制度分途叙述。

- [001 朝鲜 · 从平壤一带的古城到北方工业区](001.朝鲜.md)
- [002 韩国 · 从三国聚落到出口工业社会](002.韩国.md)

跨区对读　[中国](../07.01.古中国与东亚大陆/001.中国.md) · [日本](../07.03.古日本列岛/001.日本.md)

#### 参考文献与资料

- [OpenStax，《世界史》第一卷地图与分期](https://openstax.org/books/world-history-volume-1/pages/b-world-history-volume-1-to-1500-maps-and-timelines)
- [Complex of Koguryo Tombs - UNESCO World Heritage Centre](https://whc.unesco.org/en/list/1091/)

[全卷目录](../../README.md)
