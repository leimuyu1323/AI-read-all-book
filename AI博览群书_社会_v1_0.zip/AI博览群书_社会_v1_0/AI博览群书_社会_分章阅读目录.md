# AI 博览群书 · 社会卷｜分章阅读目录

[打开连读全文](https://chatgpt.com/library?file_id=libfile_d266a502fe7081918fca93255d0be4bb&account_id=personal)

全卷 16 编、50 个分部、219 篇正文。点击篇名可打开单独的 Markdown 文件。195 篇国别史各自包含早期社会、地区政权与交流、史料个案、近现代转折、历史坐标及参考文献。

## 编目

- [00. 社会学框架](#part-00)
- [01. 史前与分期](#part-01)
- [02. 非洲](#part-02)
- [03. 欧洲](#part-03)
- [04. 西亚](#part-04)
- [05. 南亚](#part-05)
- [06. 中亚](#part-06)
- [07. 东亚](#part-07)
- [08. 东南亚](#part-08)
- [09. 北美、中美洲与加勒比](#part-09)
- [10. 南美](#part-10)
- [11. 大洋洲](#part-11)
- [12. 大航海与早期全球联系](#part-12)
- [13. 近世国家、殖民统治与革命](#part-13)
- [14. 工业化、民族国家与帝国扩张](#part-14)
- [15. 世界大战、去殖民化与当代社会](#part-15)

<a id="part-00"></a>

## 00 编


### 00.00 · 社会学框架

[打开分部导读](https://chatgpt.com/library?file_id=libfile_17de647e10f48191a5eb351247502ac9&account_id=personal)

- [001 从一个粮仓认识社会结构](https://chatgpt.com/library?file_id=libfile_1157a38df16c8191971af4e88e337a17&account_id=personal)
- [002 三种理论如何解释同一场罢工](https://chatgpt.com/library?file_id=libfile_edacdc02e9a48191ad6d289f4d7ac137&account_id=personal)
- [003 亲属、家庭与社会再生产](https://chatgpt.com/library?file_id=libfile_3345ecdb58308191a7105ace675c73d2&account_id=personal)
- [004 土地、阶级与身份如何重叠](https://chatgpt.com/library?file_id=libfile_5f086481d6d481919d707d9a4a3bf71a&account_id=personal)
- [005 国家、宗教与合法性](https://chatgpt.com/library?file_id=libfile_c88e36fc39348191b2c123b91299fcfa&account_id=personal)
- [006 怎样使历史判断可以检验](https://chatgpt.com/library?file_id=libfile_1263f0bfbf608191909354c0bb967dd7&account_id=personal)

<a id="part-01"></a>

## 01 编


### 01.00 · 史前社会与世界历史的分期

[打开分部导读](https://chatgpt.com/library?file_id=libfile_4245a85b717c8191b8bf1a980d89dbc1&account_id=personal)

- [001 从营地、食物残留到季节性聚集](https://chatgpt.com/library?file_id=libfile_15d7a8c47a508191b6240a5ed81c7d12&account_id=personal)
- [002 农业、城市与文字怎样走出不同路径](https://chatgpt.com/library?file_id=libfile_8150f5b51378819193e441fda7092418&account_id=personal)
- [003 一张地图上的三种时间](https://chatgpt.com/library?file_id=libfile_7580b36d0f908191ab7224cc16fcbc81&account_id=personal)

<a id="part-02"></a>

## 02 编


### 02.01 · 尼罗河下游与古埃及

[打开分部导读](https://chatgpt.com/library?file_id=libfile_c9384fe5078c8191904ebe9767ab1df6&account_id=personal)

- [001 埃及 · 一船粮食怎样维系上下埃及](https://chatgpt.com/library?file_id=libfile_0fb2fb279648819181b4352062f07f41&account_id=personal)

### 02.02 · 古努比亚与白尼罗河流域

[打开分部导读](https://chatgpt.com/library?file_id=libfile_212bb5a07948819181652bbc046b62af&account_id=personal)

- [001 苏丹 · 从凯尔迈到麦罗埃，尼罗河两岸的王权](https://chatgpt.com/library?file_id=libfile_d4e1cb0946448191838904f147ff1c7f&account_id=personal)
- [002 南苏丹 · 洪泛平原上的迁牧与国家边界](https://chatgpt.com/library?file_id=libfile_86958ba3fb0481919120becaa3091dda&account_id=personal)

### 02.03 · 北非地中海岸与撒哈拉腹地

[打开分部导读](https://chatgpt.com/library?file_id=libfile_dfcca6184b088191af0c0237b997f86e&account_id=personal)

- [001 利比亚 · 海岸城市和沙漠绿洲的两套网络](https://chatgpt.com/library?file_id=libfile_afd70209107c8191b9e5c3ee6a5a762c&account_id=personal)
- [002 突尼斯 · 迦太基的港口与伊弗里基亚的腹地](https://chatgpt.com/library?file_id=libfile_1565a5533bb88191be1c02803fa469fb&account_id=personal)
- [003 阿尔及利亚 · 努米底亚、山地社会与殖民土地](https://chatgpt.com/library?file_id=libfile_3bf49cb42fe88191bc8dfe5ba6348587&account_id=personal)
- [004 摩洛哥 · 穿过阿特拉斯山的黄金和王朝](https://chatgpt.com/library?file_id=libfile_d2a3719fc2188191aa3804043a58f12d&account_id=personal)

### 02.04 · 西非森林、萨赫勒与大西洋岛屿

[打开分部导读](https://chatgpt.com/library?file_id=libfile_0847e2ed01d0819191049fb698cd71e7&account_id=personal)

- [001 毛里塔尼亚 · 商队、盐与沙漠南缘的村庄](https://chatgpt.com/library?file_id=libfile_a9e3a10314ec81918120a35174d795e1&account_id=personal)
- [002 马里 · 杰内的市场与曼萨的黄金](https://chatgpt.com/library?file_id=libfile_3deb5a9fde148191a7ab84f773f47ced&account_id=personal)
- [003 塞内加尔 · 从塔克鲁尔河谷到达喀尔](https://chatgpt.com/library?file_id=libfile_18c21d02d06081919f7fb88b73eeecc5&account_id=personal)
- [004 冈比亚 · 一条河怎样成为一个国家的骨架](https://chatgpt.com/library?file_id=libfile_2719e22ac1f881918ec026a260281d7a&account_id=personal)
- [005 几内亚比绍 · 稻田、岛屿和卡布政权](https://chatgpt.com/library?file_id=libfile_ab903db24a288191848fbde4c69b00a3&account_id=personal)
- [006 几内亚 · 高原、水源与跨区域贸易](https://chatgpt.com/library?file_id=libfile_05ab92217120819184b058996536f84a&account_id=personal)
- [007 塞拉利昂 · 海岸腹地与自由城的两段历史](https://chatgpt.com/library?file_id=libfile_0945b8de4a748191b9a7eea1b56813d9&account_id=personal)
- [008 利比里亚 · 胡椒海岸与定居殖民共和国](https://chatgpt.com/library?file_id=libfile_9274332a4354819185fb4c24f8855c27&account_id=personal)
- [009 科特迪瓦 · 黄金、曼德商路与可可前沿](https://chatgpt.com/library?file_id=libfile_e3187daedeec8191bc180ef6a9451631&account_id=personal)
- [010 加纳 · 沿海城堡背后的黄金社会](https://chatgpt.com/library?file_id=libfile_4214a1634ca48191b735eb18fe67b3f6&account_id=personal)
- [011 多哥 · 海岸商镇、多种王权与一条殖民边界](https://chatgpt.com/library?file_id=libfile_685d65858350819180e2d8659cca659d&account_id=personal)
- [012 贝宁 · 阿波美、港口与王宫的财政](https://chatgpt.com/library?file_id=libfile_651c9d0e9b6081918f374e7391a1ee9d&account_id=personal)
- [013 布基纳法索 · 莫西王国与村庄的土地权](https://chatgpt.com/library?file_id=libfile_23a5b01deac0819192bd05f3f73d2bd5&account_id=personal)
- [014 尼日尔 · 阿加德兹驼队与尼日尔河弯](https://chatgpt.com/library?file_id=libfile_5a650a2bae108191ad7c58072cb549a1&account_id=personal)
- [015 尼日利亚 · 多座城市怎样形成不同国家](https://chatgpt.com/library?file_id=libfile_e73ffc2f16e08191aed918cd0cbfb512&account_id=personal)
- [016 佛得角 · 无人常住的群岛怎样卷入大西洋史](https://chatgpt.com/library?file_id=libfile_4a1439dc1ad08191ac7811f33c64c216&account_id=personal)

### 02.05 · 东非、非洲之角与西印度洋

[打开分部导读](https://chatgpt.com/library?file_id=libfile_daee88b90fac8191b9bb36f2ef970497&account_id=personal)

- [001 埃塞俄比亚 · 阿克苏姆高原与红海航线](https://chatgpt.com/library?file_id=libfile_26027512b6e48191b6525ddae84d797c&account_id=personal)
- [002 厄立特里亚 · 阿杜利斯港与高原到海的通道](https://chatgpt.com/library?file_id=libfile_56e1acbdcecc81919da9242019e2d6ce&account_id=personal)
- [003 吉布提 · 海峡渡口怎样变成铁路终点](https://chatgpt.com/library?file_id=libfile_aecbfa7bdac081919bf1da7a66087151&account_id=personal)
- [004 索马里 · 季风、牧群与摩加迪沙](https://chatgpt.com/library?file_id=libfile_24e2d000905481918b0db899a0d4d0a7&account_id=personal)
- [005 肯尼亚 · 从裂谷牧人到斯瓦希里港市](https://chatgpt.com/library?file_id=libfile_aae749bcf95c8191a2fc7665b1d44b54&account_id=personal)
- [006 乌干达 · 大湖区的牛群、香蕉园和宫廷](https://chatgpt.com/library?file_id=libfile_eaa82e6426888191b2e7841762cfa5e3&account_id=personal)
- [007 坦桑尼亚 · 基尔瓦、内陆商路和两个建国主体](https://chatgpt.com/library?file_id=libfile_0fb4e6439c58819189e228c108ac0d63&account_id=personal)
- [008 卢旺达 · 王权、牛群与身份的历史变化](https://chatgpt.com/library?file_id=libfile_c2bbe6581f2c819184529c565417173a&account_id=personal)
- [009 布隆迪 · 王廷之外的山地家庭](https://chatgpt.com/library?file_id=libfile_bbceae87e084819184413a31cef479f5&account_id=personal)
- [010 塞舌尔 · 从季风航路到安置移民的岛屿](https://chatgpt.com/library?file_id=libfile_238a4af00bd0819180be039e77c17fc0&account_id=personal)
- [011 科摩罗 · 海峡诸岛与斯瓦希里贸易](https://chatgpt.com/library?file_id=libfile_96a9c6782b0c81919785905ea9bff2c9&account_id=personal)
- [012 马达加斯加 · 稻田、牛群与跨洋定居](https://chatgpt.com/library?file_id=libfile_f2c2f7474b408191a860a79dc63619c7&account_id=personal)
- [013 毛里求斯 · 甘蔗、契约与岛屿社会的形成](https://chatgpt.com/library?file_id=libfile_c53e7de13dbc819187340f05170e7909&account_id=personal)

### 02.06 · 中部非洲的湖盆、河网与森林王国

[打开分部导读](https://chatgpt.com/library?file_id=libfile_be78b623dbd48191a33e2e0299a06e6d&account_id=personal)

- [001 喀麦隆 · 从草原酋邦到双语国家](https://chatgpt.com/library?file_id=libfile_3be3326073948191a73092762bc42e23&account_id=personal)
- [002 乍得 · 随湖岸移动的加涅姆与博尔努](https://chatgpt.com/library?file_id=libfile_5edaa3cae22c819188cb85bd813bb41a&account_id=personal)
- [003 中非共和国 · 乌班吉河流域与林地社会](https://chatgpt.com/library?file_id=libfile_d41c52fcc9b481918864078714f05656&account_id=personal)
- [004 赤道几内亚 · 比奥科岛与大陆森林](https://chatgpt.com/library?file_id=libfile_10e391f0b1dc8191a94a861d92c4aadc&account_id=personal)
- [005 加蓬 · 奥果韦河与森林中的交换](https://chatgpt.com/library?file_id=libfile_4808a0a026f88191a966c78c33409e08&account_id=personal)
- [006 刚果共和国 · 洛安戈海岸与刚果河北岸](https://chatgpt.com/library?file_id=libfile_f115141a20b88191aca57dba2d20db89&account_id=personal)
- [007 刚果民主共和国 · 从卢巴、隆达到矿区国家](https://chatgpt.com/library?file_id=libfile_7e3e65484f088191b0d6d98b67a66601&account_id=personal)
- [008 圣多美和普林西比 · 从森林岛到蔗糖种植园](https://chatgpt.com/library?file_id=libfile_6c9e4113f898819184a1c25d916694cf&account_id=personal)
- [009 安哥拉 · 刚果、恩东戈与大西洋腹地](https://chatgpt.com/library?file_id=libfile_9fc47ab6078c819183d50a6e02fbd519&account_id=personal)

### 02.07 · 南部非洲高原、草场与港路

[打开分部导读](https://chatgpt.com/library?file_id=libfile_7343c007c7ac81919156f15e4e9091f2&account_id=personal)

- [001 莫桑比克 · 索法拉、黄金与赞比西河流域](https://chatgpt.com/library?file_id=libfile_18b10182fdc4819180fecdba864432e9&account_id=personal)
- [002 马拉维 · 湖岸渔业和马拉维诸政权](https://chatgpt.com/library?file_id=libfile_c1e216a2c1e48191b9a68bec2e982cb5&account_id=personal)
- [003 赞比亚 · 铜带形成以前的矿业与商路](https://chatgpt.com/library?file_id=libfile_601f5e54563881919d310dcf6244f976&account_id=personal)
- [004 津巴布韦 · 大津巴布韦石墙内外的劳动](https://chatgpt.com/library?file_id=libfile_50ccc39a0df081919552805938798c4e&account_id=personal)
- [005 博茨瓦纳 · 牛群、水井与卡拉哈里交换](https://chatgpt.com/library?file_id=libfile_d7ffa633957881918150b67598a7d4b9&account_id=personal)
- [006 纳米比亚 · 沙漠牧道、铜矿和定居者土地](https://chatgpt.com/library?file_id=libfile_82c966fa9cd0819185e27ec688a123b7&account_id=personal)
- [007 南非 · 从马蓬古布韦到矿工宿舍](https://chatgpt.com/library?file_id=libfile_d38104348b348191a1a605ba800a0f9d&account_id=personal)
- [008 莱索托 · 山地避难怎样变成政治共同体](https://chatgpt.com/library?file_id=libfile_cff2255ae27c8191b7d2021bc3f6b576&account_id=personal)
- [009 埃斯瓦蒂尼 · 王室、年龄团与高原牧地](https://chatgpt.com/library?file_id=libfile_eb908752c6b48191bf5fa10c9b180e46&account_id=personal)

<a id="part-03"></a>

## 03 编


### 03.01 · 爱琴世界与地中海岛屿

[打开分部导读](https://chatgpt.com/library?file_id=libfile_2224d0d2fbf881918b8947197ea8c325&account_id=personal)

- [001 希腊 · 从宫殿账簿到城邦公民](https://chatgpt.com/library?file_id=libfile_c571fb6c68008191b9379b1effb1c85c&account_id=personal)
- [002 马耳他 · 石庙、港湾与帝国补给](https://chatgpt.com/library?file_id=libfile_58517f36d22c8191ba88468b9f38ed2f&account_id=personal)

### 03.02 · 罗马意大利、山城与教廷

[打开分部导读](https://chatgpt.com/library?file_id=libfile_837d135582888191b9156edef4e385cf&account_id=personal)

- [001 意大利 · 罗马怎样把征服转为公民资格](https://chatgpt.com/library?file_id=libfile_aa8e396bf0f081919635c5cae8742bbb&account_id=personal)
- [002 教廷与梵蒂冈城 · 从墓地、朝圣到领土条约](https://chatgpt.com/library?file_id=libfile_4b206934186c8191acc82c56a2b6f8da&account_id=personal)
- [003 圣马力诺 · 山城自治如何延续](https://chatgpt.com/library?file_id=libfile_645a3611d8188191bcde8bc3a5b39031&account_id=personal)

### 03.03 · 伊比利亚、西欧与低地城市

[打开分部导读](https://chatgpt.com/library?file_id=libfile_db515fc8a7cc8191973f2131d7bfda9e&account_id=personal)

- [001 法国 · 从高卢庄园到全国性税制](https://chatgpt.com/library?file_id=libfile_d0c119e7f3488191a295d6901f4c47f0&account_id=personal)
- [002 摩纳哥 · 一座海岬上的城堡政治](https://chatgpt.com/library?file_id=libfile_8d75dccd6f0c8191ac1323fc1cb4299e&account_id=personal)
- [003 安道尔 · 山谷牧场与共治领地](https://chatgpt.com/library?file_id=libfile_6ecbcb403e94819196f58751e5904f73&account_id=personal)
- [004 西班牙 · 半岛上的多重法律与王权](https://chatgpt.com/library?file_id=libfile_b1b251da88f4819195c14453cc2e9913&account_id=personal)
- [005 葡萄牙 · 从边疆伯国到海洋税关](https://chatgpt.com/library?file_id=libfile_34ccc9ce46ec8191863e21ef199c0483&account_id=personal)
- [006 比利时 · 布匹城市与工业煤区](https://chatgpt.com/library?file_id=libfile_a6e2fbd4f86c8191a548b0069eeb8089&account_id=personal)
- [007 荷兰 · 堤坝、行省与贸易共和国](https://chatgpt.com/library?file_id=libfile_d932604773748191a423b92c2462e7c9&account_id=personal)
- [008 卢森堡 · 阿尔泽特河谷的一座要塞](https://chatgpt.com/library?file_id=libfile_c69b6c28490c8191b9665e1a10568b98&account_id=personal)

### 03.04 · 拜占庭遗产与巴尔干

[打开分部导读](https://chatgpt.com/library?file_id=libfile_1fab7498a6908191bac748f1a5a696ff&account_id=personal)

- [001 斯洛文尼亚 · 阿尔卑斯东麓与亚得里亚港口](https://chatgpt.com/library?file_id=libfile_a3b6509aa85c81919c3ae85219ef10c5&account_id=personal)
- [002 克罗地亚 · 达尔马提亚海岸与内陆王国](https://chatgpt.com/library?file_id=libfile_8ce0571cd78881918ccd273c9c839c6f&account_id=personal)
- [003 波斯尼亚和黑塞哥维那 · 山谷贸易与多宗教城市](https://chatgpt.com/library?file_id=libfile_8807e4615bb08191bb1a56f9ff395d87&account_id=personal)
- [004 黑山 · 高地村社与亚得里亚海湾](https://chatgpt.com/library?file_id=libfile_07bd7d54f358819186394b7c7f489043&account_id=personal)
- [005 塞尔维亚 · 河流通道、修道院与边境自治](https://chatgpt.com/library?file_id=libfile_b56f8114edc881918ed67c385d032e63&account_id=personal)
- [006 阿尔巴尼亚 · 从伊利里亚地区到亚得里亚港城](https://chatgpt.com/library?file_id=libfile_156d9ce5e1348191bbc64618244708e6&account_id=personal)
- [007 北马其顿 · 河谷通道与奥赫里德书写传统](https://chatgpt.com/library?file_id=libfile_00b8bfcba86481918db525578bc4b9dc&account_id=personal)
- [008 保加利亚 · 从色雷斯墓葬到两次保加利亚帝国](https://chatgpt.com/library?file_id=libfile_ae60fdc9faf0819186eac8e9ec0d35c5&account_id=personal)
- [009 罗马尼亚 · 从达契亚到多瑙河两公国](https://chatgpt.com/library?file_id=libfile_62740181fec08191b23bd66f8f203173&account_id=personal)
- [010 摩尔多瓦 · 德涅斯特河与普鲁特河之间](https://chatgpt.com/library?file_id=libfile_77a797e7adcc8191ba76cd3c6fcfc4d6&account_id=personal)

### 03.05 · 西欧诸王国、中欧领邦与阿尔卑斯

[打开分部导读](https://chatgpt.com/library?file_id=libfile_afd23e32c1d48191bc2641191ecb1c05&account_id=personal)

- [001 英国 · 岛上的几套王国如何联合](https://chatgpt.com/library?file_id=libfile_4d63faae5b1081919d30da1ed217db4a&account_id=personal)
- [002 爱尔兰 · 墓冢、修道院与土地问题](https://chatgpt.com/library?file_id=libfile_bd42310a6a24819199c8169fc57f68f3&account_id=personal)
- [003 德国 · 帝国诸侯、城市自治与统一](https://chatgpt.com/library?file_id=libfile_debfb10383e0819195c1ceba3767a9e8&account_id=personal)
- [004 瑞士 · 阿尔卑斯通道与州的联盟](https://chatgpt.com/library?file_id=libfile_11afaecac2a081919bfa0694e9304dce&account_id=personal)
- [005 列支敦士登 · 莱茵河谷的领地与主权](https://chatgpt.com/library?file_id=libfile_e88af70e44a88191a379ddbaf2ef6e82&account_id=personal)
- [006 奥地利 · 多瑙边疆与哈布斯堡的复合君主国](https://chatgpt.com/library?file_id=libfile_d18d7c26be448191aad2220ed1d2fc2e&account_id=personal)
- [007 捷克 · 波希米亚王冠与城市工匠](https://chatgpt.com/library?file_id=libfile_5e77220bbb3c8191b0d2e41d52f78587&account_id=personal)
- [008 斯洛伐克 · 从大摩拉维亚到矿业城镇](https://chatgpt.com/library?file_id=libfile_5c2ff6e5b1508191ac48e83d528b401a&account_id=personal)
- [009 波兰 · 皮雅斯特王朝到贵族议会](https://chatgpt.com/library?file_id=libfile_40049cd807a48191aadbd94206f33cde&account_id=personal)
- [010 匈牙利 · 草原骑手如何定居为王国](https://chatgpt.com/library?file_id=libfile_dc00d3539ed48191955003efdc8b5632&account_id=personal)

### 03.06 · 东欧、北欧与北大西洋

[打开分部导读](https://chatgpt.com/library?file_id=libfile_b9859643f2a88191be62e689bb93baf7&account_id=personal)

- [001 乌克兰 · 黑海草原、罗斯城市与哥萨克边疆](https://chatgpt.com/library?file_id=libfile_af7bdaaf379881919757ef594c955662&account_id=personal)
- [002 白俄罗斯 · 波洛茨克河港与多语边地](https://chatgpt.com/library?file_id=libfile_cd538acc0c508191a46146fec273909b&account_id=personal)
- [003 立陶宛 · 异教大公国怎样治理多种信仰](https://chatgpt.com/library?file_id=libfile_aeb67b65e4188191816951e4655c7680&account_id=personal)
- [004 拉脱维亚 · 道加瓦河、里加与庄园](https://chatgpt.com/library?file_id=libfile_9eff42ea89e4819189db5ec723fe6b74&account_id=personal)
- [005 爱沙尼亚 · 堡寨、汉萨商人和农民语言](https://chatgpt.com/library?file_id=libfile_6c7f193db54481919f233faf4f409f00&account_id=personal)
- [006 芬兰 · 湖区农民、萨米人和两种帝国](https://chatgpt.com/library?file_id=libfile_64bba66db0e48191b680dff3cc5e7030&account_id=personal)
- [007 瑞典 · 波罗的海商路、矿山与王国](https://chatgpt.com/library?file_id=libfile_1a75bb5968e481919a5ef8797d4c240f&account_id=personal)
- [008 挪威 · 峡湾农庄与跨海王权](https://chatgpt.com/library?file_id=libfile_5010c109c810819187942b53ff978207&account_id=personal)
- [009 丹麦 · 海峡收费与岛屿王国](https://chatgpt.com/library?file_id=libfile_57a41fb264f481919331a400b4f3deaa&account_id=personal)
- [010 冰岛 · 没有本土谷仓的北大西洋议会](https://chatgpt.com/library?file_id=libfile_78baa37b301881918a3316f5351e4869&account_id=personal)
- [011 俄罗斯 · 河路、贡赋与欧亚帝国扩张](https://chatgpt.com/library?file_id=libfile_f0072a0fc9b88191a5e1931165546ebd&account_id=personal)

<a id="part-04"></a>

## 04 编


### 04.01 · 美索不达米亚河谷

[打开分部导读](https://chatgpt.com/library?file_id=libfile_05e5b5e54ee88191ad29d36d4c88ae6b&account_id=personal)

- [001 伊拉克 · 灌渠、泥板与巴格达的城市腹地](https://chatgpt.com/library?file_id=libfile_34982209634c81919a7cbc1513eb9882&account_id=personal)

### 04.02 · 安纳托利亚、高加索与东地中海岛屿

[打开分部导读](https://chatgpt.com/library?file_id=libfile_9a13075fa8f4819185c45221b5cceec5&account_id=personal)

- [001 土耳其 · 从安纳托利亚诸国到帝国首都](https://chatgpt.com/library?file_id=libfile_794261af539c8191804626037bb28024&account_id=personal)
- [002 塞浦路斯 · 铜、海港与分裂的岛屿](https://chatgpt.com/library?file_id=libfile_cbe33f7ca4648191bfe853f06416c323&account_id=personal)
- [003 亚美尼亚 · 山地教会与跨境社群](https://chatgpt.com/library?file_id=libfile_b0a60a08a4fc81918ddf0731211bc24e&account_id=personal)
- [004 阿塞拜疆 · 高加索商道与巴库油城](https://chatgpt.com/library?file_id=libfile_723bb5029d5c8191afb1717d776c16cd&account_id=personal)
- [005 格鲁吉亚 · 黑海平原与高加索山口](https://chatgpt.com/library?file_id=libfile_89bb83808f90819181f4fcf68a4a8c0d&account_id=personal)

### 04.03 · 黎凡特与约旦河两岸

[打开分部导读](https://chatgpt.com/library?file_id=libfile_9b02137a58988191aa10725f3ac5190a&account_id=personal)

- [001 叙利亚 · 商队城市与乡村腹地](https://chatgpt.com/library?file_id=libfile_5b30ff7e2d7c8191a8a78fe1cd3b37f1&account_id=personal)
- [002 黎巴嫩 · 比布鲁斯、推罗与山地村社](https://chatgpt.com/library?file_id=libfile_c8eb36f7d50081918f248ca7126a412c&account_id=personal)
- [003 以色列 · 南黎凡特的古代王国与现代建国](https://chatgpt.com/library?file_id=libfile_8870554c50c08191bb8ecac2cdefb814&account_id=personal)
- [004 巴勒斯坦 · 从杰里科的水源到现代流离失所](https://chatgpt.com/library?file_id=libfile_0dc2ea586bd48191b9f6c3d520747beb&account_id=personal)
- [005 约旦 · 佩特拉的水渠与商队](https://chatgpt.com/library?file_id=libfile_0552505e510c8191987ebb5369a48753&account_id=personal)

### 04.04 · 伊朗高原与帝国交通

[打开分部导读](https://chatgpt.com/library?file_id=libfile_f4a076efcde88191b09178068171ea3b&account_id=personal)

- [001 伊朗 · 高原上的道路、灌溉与帝国](https://chatgpt.com/library?file_id=libfile_04ed031dd0a48191b8a6aecef3633592&account_id=personal)

### 04.05 · 阿拉伯半岛、红海与海湾

[打开分部导读](https://chatgpt.com/library?file_id=libfile_75af0598a5c88191b40458f68f4ef74a&account_id=personal)

- [001 沙特阿拉伯 · 绿洲商道、圣城与内陆王权](https://chatgpt.com/library?file_id=libfile_3bb69b00bebc8191a83ebc323552d481&account_id=personal)
- [002 也门 · 马里卜水坝与高原商贸](https://chatgpt.com/library?file_id=libfile_6ed1fc29a4548191bdbd2eae92bca2c4&account_id=personal)
- [003 阿曼 · 铜、乳香与跨洋苏丹国](https://chatgpt.com/library?file_id=libfile_5553efb958d48191a4999a0100fb5bcd&account_id=personal)
- [004 阿拉伯联合酋长国 · 绿洲墓群、采珠船与联邦](https://chatgpt.com/library?file_id=libfile_ff5b9e5bca7081919b08f78ecfe5a532&account_id=personal)
- [005 卡塔尔 · 半岛水源、珠业和气田](https://chatgpt.com/library?file_id=libfile_84e48d55a740819185113803e8a97899&account_id=personal)
- [006 巴林 · 迪尔蒙墓丘与珍珠海岸](https://chatgpt.com/library?file_id=libfile_8c7d4aea68b48191b032c40202c14479&account_id=personal)
- [007 科威特 · 法伊拉卡岛、帆船与港市](https://chatgpt.com/library?file_id=libfile_ac64beb394088191969b800393c27aa5&account_id=personal)

<a id="part-05"></a>

## 05 编


### 05.01 · 印度河城市与西北通道

[打开分部导读](https://chatgpt.com/library?file_id=libfile_c15a60ca25488191b77c69edcea78bde&account_id=personal)

- [001 巴基斯坦 · 从摩亨佐达罗的水井到印度河灌区](https://chatgpt.com/library?file_id=libfile_fac570f3e6648191b386507acbb73015&account_id=personal)

### 05.02 · 恒河诸国、孟加拉与喜马拉雅

[打开分部导读](https://chatgpt.com/library?file_id=libfile_628567ad323c8191a5bf1b5543970261&account_id=personal)

- [001 印度 · 从恒河城市到跨地区的国家与市场](https://chatgpt.com/library?file_id=libfile_4427223b63988191b67d88825c4803ac&account_id=personal)
- [002 孟加拉国 · 三角洲会移动，村庄和城市也会移动](https://chatgpt.com/library?file_id=libfile_05f1b577e6508191981753a88affd770&account_id=personal)
- [003 尼泊尔 · 加德满都谷地与跨喜马拉雅商路](https://chatgpt.com/library?file_id=libfile_683429f757108191b0526ade38d117dc&account_id=personal)
- [004 不丹 · 山口、寺院与宗堡](https://chatgpt.com/library?file_id=libfile_cd154003681081918fda2908b17d6ae5&account_id=personal)

### 05.03 · 斯里兰卡的水库与王国

[打开分部导读](https://chatgpt.com/library?file_id=libfile_7558bbaaaf348191a2a97658755798d4&account_id=personal)

- [001 斯里兰卡 · 蓄水池、寺院与海港竞争](https://chatgpt.com/library?file_id=libfile_8bd81b0b2ae881919cc929ef82598a4e&account_id=personal)

### 05.04 · 南亚跨海交通与马尔代夫

[打开分部导读](https://chatgpt.com/library?file_id=libfile_c7e310887e588191a15e262e9b2ad2fe&account_id=personal)

- [001 马尔代夫 · 珊瑚环礁上的佛塔、贝币与苏丹](https://chatgpt.com/library?file_id=libfile_16f6735de0508191a44343191a8d5a57&account_id=personal)

<a id="part-06"></a>

## 06 编


### 06.01 · 草原牧道与天山山口

[打开分部导读](https://chatgpt.com/library?file_id=libfile_91f2bda723048191bc7bec0da4f78c8e&account_id=personal)

- [001 哈萨克斯坦 · 牧群的季节路线与草原国家](https://chatgpt.com/library?file_id=libfile_67ccc183c89c81918b5538d3fd085665&account_id=personal)
- [002 吉尔吉斯斯坦 · 天山牧道与楚河谷城市](https://chatgpt.com/library?file_id=libfile_fe7bf7a91a3481918909839dab78e15c&account_id=personal)

### 06.02 · 巴克特里亚与高原通道

[打开分部导读](https://chatgpt.com/library?file_id=libfile_6802ca9c0420819182d6b520cdaa4f47&account_id=personal)

- [001 阿富汗 · 巴克特里亚、山口和灌溉城镇](https://chatgpt.com/library?file_id=libfile_e59b83d339d88191a4842d256aa2f1ab&account_id=personal)

### 06.03 · 粟特城市与河中地区

[打开分部导读](https://chatgpt.com/library?file_id=libfile_6b44f6c944488191aab9911048f75939&account_id=personal)

- [001 乌兹别克斯坦 · 粟特城市怎样维系丝路](https://chatgpt.com/library?file_id=libfile_bdebeebb7f288191afea402c28766b6f&account_id=personal)
- [002 塔吉克斯坦 · 片治肯特壁画与山地商人](https://chatgpt.com/library?file_id=libfile_f12476ea7ec881919e5bb6a79f29298d&account_id=personal)

### 06.04 · 塔里木盆地与绿洲社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_f0d4ba6710a88191942d8ba11c399b45&account_id=personal)

- [001 于阗与龟兹：绿洲怎样养活一条商路](https://chatgpt.com/library?file_id=libfile_db6e32da6360819189318c86cfc185ad&account_id=personal)

### 06.05 · 梅尔夫与丝路交流

[打开分部导读](https://chatgpt.com/library?file_id=libfile_418311cec4188191804934558fcecf6b&account_id=personal)

- [001 土库曼斯坦 · 梅尔夫绿洲与卡拉库姆牧地](https://chatgpt.com/library?file_id=libfile_09cf6619d53c8191909d6f9e2e0d1a39&account_id=personal)

<a id="part-07"></a>

## 07 编


### 07.01 · 古中国与东亚大陆

[打开分部导读](https://chatgpt.com/library?file_id=libfile_009deaac20848191ba07ece7c9c20cd6&account_id=personal)

- [001 中国 · 从粮仓、封邑到县与户](https://chatgpt.com/library?file_id=libfile_dc2756473f5c81919d5d214a8ed0212d&account_id=personal)
- [002 蒙古国 · 草原联盟怎样组织人、畜和驿站](https://chatgpt.com/library?file_id=libfile_ee79d7dd24788191b1aab0b0e4fe65ce&account_id=personal)

### 07.02 · 古朝鲜半岛

[打开分部导读](https://chatgpt.com/library?file_id=libfile_d021739e306c81919d8678bb9939b755&account_id=personal)

- [001 朝鲜 · 从平壤一带的古城到北方工业区](https://chatgpt.com/library?file_id=libfile_d0d8c539eeb48191a5adf6c76a0a0a0d&account_id=personal)
- [002 韩国 · 从三国聚落到出口工业社会](https://chatgpt.com/library?file_id=libfile_4a0a3497a7588191ad7a512ee074e413&account_id=personal)

### 07.03 · 古日本列岛

[打开分部导读](https://chatgpt.com/library?file_id=libfile_7d997c0a13e48191bf7ed5189e7f9a7e&account_id=personal)

- [001 日本 · 稻田、庄园与城下町](https://chatgpt.com/library?file_id=libfile_4bbe1b987878819189014f22a24178a1&account_id=personal)

<a id="part-08"></a>

## 08 编


### 08.01 · 大陆东南亚的河流与王国

[打开分部导读](https://chatgpt.com/library?file_id=libfile_36c3a43594788191b299e24196e0da66&account_id=personal)

- [001 缅甸 · 骠人城墙与蒲甘灌区](https://chatgpt.com/library?file_id=libfile_a7024b19eda88191b237e0f0b8d45c52&account_id=personal)
- [002 泰国 · 湄南河的稻田与多中心王权](https://chatgpt.com/library?file_id=libfile_282de4e3ffac81919c71bc374c873093&account_id=personal)
- [003 老挝 · 石缸、湄公河与澜沧诸城](https://chatgpt.com/library?file_id=libfile_f30feca2cc748191bbed980453e2b64b&account_id=personal)
- [004 柬埔寨 · 吴哥怎样维持一座低密度城市](https://chatgpt.com/library?file_id=libfile_7f592091bfdc8191a2371a25aac36fca&account_id=personal)
- [005 越南 · 红河村社、占城港口与湄公河三角洲](https://chatgpt.com/library?file_id=libfile_fc6902e074d08191ae15b42124e1d946&account_id=personal)

### 08.02 · 海岛东南亚与马来半岛

[打开分部导读](https://chatgpt.com/library?file_id=libfile_49518a0337e881918219b7d0607448fb&account_id=personal)

- [001 马来西亚 · 从布秧谷到马六甲海峡](https://chatgpt.com/library?file_id=libfile_99c1c3284c808191acf0817893da43b9&account_id=personal)
- [002 新加坡 · 十四世纪海港与全球转运站](https://chatgpt.com/library?file_id=libfile_dfc8b2174c80819199e34160e79f50e7&account_id=personal)
- [003 文莱 · 水上聚落、河口王权与油田](https://chatgpt.com/library?file_id=libfile_71a4c6a882b4819199724d2482375271&account_id=personal)
- [004 印度尼西亚 · 群岛港口、稻作王国与香料产地](https://chatgpt.com/library?file_id=libfile_3eeb2af7f9b88191b6b2463cd36b143b&account_id=personal)
- [005 东帝汶 · 檀香、山地家屋与帝汶分界](https://chatgpt.com/library?file_id=libfile_99c731693dbc8191ae1907ee015cc760&account_id=personal)
- [006 菲律宾 · 港邦、金器与马尼拉帆船](https://chatgpt.com/library?file_id=libfile_148bb4c54fa4819185d98b416a2107de&account_id=personal)

### 08.03 · 大陆与海岛的交流

[打开分部导读](https://chatgpt.com/library?file_id=libfile_67169b7f63b081918031c078ebb170c0&account_id=personal)

- [001 一艘商船要经过哪些社会](https://chatgpt.com/library?file_id=libfile_78d7c6958dd4819199eb27bedd6d4d73&account_id=personal)

<a id="part-09"></a>

## 09 编


### 09.01 · 古北美

[打开分部导读](https://chatgpt.com/library?file_id=libfile_93a9ae7036708191b248fdc0e2f4a3ff&account_id=personal)

- [001 加拿大 · 从鲑鱼河、草原野牛到毛皮商路](https://chatgpt.com/library?file_id=libfile_2bdf771d9b848191a38aea37e34b37d3&account_id=personal)
- [002 美国 · 从卡霍基亚的土台到土地与公民权](https://chatgpt.com/library?file_id=libfile_588e4cd93a5c819191ff3755ad2899a2&account_id=personal)

### 09.02 · 墨西哥与中美洲

[打开分部导读](https://chatgpt.com/library?file_id=libfile_1e0370dffa788191b6ee9ec9e84138e4&account_id=personal)

- [001 墨西哥 · 湖上城邦、贡纳册与墨西哥革命](https://chatgpt.com/library?file_id=libfile_1768a20af6b481918f0cd7f5d44fe365&account_id=personal)
- [002 伯利兹 · 玛雅城市与海岸伐木营地](https://chatgpt.com/library?file_id=libfile_9c5dea2c1b488191959e5b452ee45884&account_id=personal)
- [003 危地马拉 · 从蒂卡尔到高地玛雅共同体](https://chatgpt.com/library?file_id=libfile_cb78c2cfa4648191aa778fd0b9af75bd&account_id=personal)
- [004 萨尔瓦多 · 火山灰封存的农户与咖啡庄园](https://chatgpt.com/library?file_id=libfile_d69a223bcbf88191a521c7d092524a7b&account_id=personal)
- [005 洪都拉斯 · 科潘碑文与加勒比海岸](https://chatgpt.com/library?file_id=libfile_7f7daf0bc0f481919a20420745688c5a&account_id=personal)
- [006 尼加拉瓜 · 湖区农民与加勒比沿岸的另一条历史](https://chatgpt.com/library?file_id=libfile_18c453c8aa8881919a07d9e8c84b89a9&account_id=personal)
- [007 哥斯达黎加 · 瓜亚博水道与迪基斯石球](https://chatgpt.com/library?file_id=libfile_5f4af91be1e48191a881f63e42310aa4&account_id=personal)
- [008 巴拿马 · 地峡转运远早于运河](https://chatgpt.com/library?file_id=libfile_41b202e1c6ec819192ab063e88246537&account_id=personal)

### 09.03 · 加勒比海与岛际社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_91c85e4220fc8191a4d5bb06789450e9&account_id=personal)

- [001 古巴 · 原住民村落、哈瓦那船队与蔗糖](https://chatgpt.com/library?file_id=libfile_305bde984fd481919b8f5bc2a9b409ed&account_id=personal)
- [002 牙买加 · 从木薯村庄到马龙人山地](https://chatgpt.com/library?file_id=libfile_bcf3eb5cfd9481919712f001c7e595f8&account_id=personal)
- [003 海地 · 伊斯帕尼奥拉西部与奴隶革命](https://chatgpt.com/library?file_id=libfile_e850a7ddf0ac8191adb4345e8cf7cdd0&account_id=personal)
- [004 多米尼加共和国 · 从泰诺首领领地到圣多明各](https://chatgpt.com/library?file_id=libfile_df27b70531008191a21a4f0a5b51b325&account_id=personal)
- [005 巴哈马 · 卢卡扬人的岛链与拿骚港](https://chatgpt.com/library?file_id=libfile_b29ea8289134819191940cba1a2f84c6&account_id=personal)
- [006 安提瓜和巴布达 · 甘蔗岛与共有土地的姊妹岛](https://chatgpt.com/library?file_id=libfile_acfe83e0346081918f6bfce4473573b0&account_id=personal)
- [007 多米尼克 · 山林怎样给卡利纳戈人留下政治空间](https://chatgpt.com/library?file_id=libfile_1778fbcc1b2081919efe3fa5d0882230&account_id=personal)
- [008 圣基茨和尼维斯 · 早期英法殖民与两岛联邦](https://chatgpt.com/library?file_id=libfile_de54d1d3cb408191b7822d1afdbc3fbb&account_id=personal)
- [009 格林纳达 · 香料岛之前的木舟航路](https://chatgpt.com/library?file_id=libfile_db7fde18729081919fb6bdf9190b3ee0&account_id=personal)
- [010 圣卢西亚 · 火山岛的木舟航线与种植园](https://chatgpt.com/library?file_id=libfile_188c957a5dd081919dfdfc6c14fe80db&account_id=personal)
- [011 圣文森特和格林纳丁斯 · 加里富纳人的形成与遣离](https://chatgpt.com/library?file_id=libfile_95ab8d9538588191ab2843872d153210&account_id=personal)
- [012 巴巴多斯 · 从岛际村落到英国糖业殖民地](https://chatgpt.com/library?file_id=libfile_9886ef72edfc81918c776e81a53fc809&account_id=personal)
- [013 特立尼达和多巴哥 · 靠近南美洲的双岛国家](https://chatgpt.com/library?file_id=libfile_e3e9a31dd82481918c26e15b1e278272&account_id=personal)

<a id="part-10"></a>

## 10 编


### 10.01 · 北安第斯与加勒比南岸

[打开分部导读](https://chatgpt.com/library?file_id=libfile_b3dcfae7d6d08191b861f5e7e570d592&account_id=personal)

- [001 哥伦比亚 · 高原盐市、河谷金工与咖啡山地](https://chatgpt.com/library?file_id=libfile_2c4b869d93388191bed7d7f0989a76cb&account_id=personal)
- [002 委内瑞拉 · 奥里诺科河网与加勒比海岸](https://chatgpt.com/library?file_id=libfile_baec510e0b508191912e298409b20bf9&account_id=personal)
- [003 厄瓜多尔 · 瓦尔迪维亚陶器与赤道高地](https://chatgpt.com/library?file_id=libfile_af91c78e3770819183a574889d69217f&account_id=personal)

### 10.02 · 中安第斯与的的喀喀湖

[打开分部导读](https://chatgpt.com/library?file_id=libfile_5e873ad1a3188191a21e74df51c86ec9&account_id=personal)

- [001 秘鲁 · 没有统一文字档案的安第斯国家](https://chatgpt.com/library?file_id=libfile_640d151537a48191b43ab7284b6729f1&account_id=personal)
- [002 玻利维亚 · 的的喀喀湖高原与波托西矿山](https://chatgpt.com/library?file_id=libfile_96c6c30337c08191b194ad3e33f6c2b2&account_id=personal)

### 10.03 · 南安第斯、潘帕斯与南锥体

[打开分部导读](https://chatgpt.com/library?file_id=libfile_c45c45ea30908191869565faf996ec7b&account_id=personal)

- [001 智利 · 沙漠绿洲、马普切边地与铜矿](https://chatgpt.com/library?file_id=libfile_3346d2c684088191ad292a7d0567a07e&account_id=personal)
- [002 阿根廷 · 从安第斯道路到潘帕斯牧场](https://chatgpt.com/library?file_id=libfile_050058313c1081918176ac92d6da1dbb&account_id=personal)

### 10.04 · 亚马孙、拉普拉塔低地与圭亚那

[打开分部导读](https://chatgpt.com/library?file_id=libfile_9db9cb234bec819190ae7c679345a8fe&account_id=personal)

- [001 巴拉圭 · 瓜拉尼村庄与河流共和国](https://chatgpt.com/library?file_id=libfile_10247454a1fc819191447bdb3f68ce9a&account_id=personal)
- [002 乌拉圭 · 草原土丘与两大帝国之间的港口](https://chatgpt.com/library?file_id=libfile_c06d9ca17f048191a993d798856c2e84&account_id=personal)
- [003 巴西 · 亚马孙人造土与大西洋种植园](https://chatgpt.com/library?file_id=libfile_e02fa619eb208191a291f78572431e4e&account_id=personal)
- [004 圭亚那 · 河流腹地、排水堤与糖园](https://chatgpt.com/library?file_id=libfile_4eaafc7f1da88191ae065556519bdff6&account_id=personal)
- [005 苏里南 · 沿岸土丘与马龙人河流社会](https://chatgpt.com/library?file_id=libfile_55f7c697df708191920fbe20ee2acc06&account_id=personal)

<a id="part-11"></a>

## 11 编


### 11.01 · 澳大利亚原住民社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_755ce680f7888191af2df4a6debf941a&account_id=personal)

- [001 澳大利亚 · 以土地、季节与亲属关系组织大陆](https://chatgpt.com/library?file_id=libfile_ea3f19698d708191b56dc834f727a815&account_id=personal)

### 11.02 · 古美拉尼西亚与岛链迁徙

[打开分部导读](https://chatgpt.com/library?file_id=libfile_81c224776b1881918b870c566ffc728a&account_id=personal)

- [001 巴布亚新几内亚 · 库克湿地与高地园艺](https://chatgpt.com/library?file_id=libfile_d659a7bc774081919df07a250608a967&account_id=personal)
- [002 所罗门群岛 · 两段海洋之间的岛链](https://chatgpt.com/library?file_id=libfile_cd2383b090f081918b9659650cc3ef80&account_id=personal)
- [003 瓦努阿图 · 特欧玛墓地与多语言岛群](https://chatgpt.com/library?file_id=libfile_6d30515158188191a5ac0b62c89c6412&account_id=personal)
- [004 斐济 · 拉皮塔村落、酋邦与契约劳工](https://chatgpt.com/library?file_id=libfile_d8058fe572dc8191a5a1130c281ad9c5&account_id=personal)

### 11.03 · 古密克罗尼西亚与环礁社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_df00274fee1c81919579aee6a69402ce&account_id=personal)

- [001 基里巴斯 · 会堂、斑兰与跨赤道国家](https://chatgpt.com/library?file_id=libfile_37228e4b8e788191b95fc78e5ed489a4&account_id=personal)
- [002 密克罗尼西亚联邦 · 南马都尔石城与四州差异](https://chatgpt.com/library?file_id=libfile_ab51f97613bc8191b0f06dbdb09b8bdc&account_id=personal)
- [003 马绍尔群岛 · 涌浪航海、环礁土地与核试验迁徙](https://chatgpt.com/library?file_id=libfile_08f86e6763788191bbb001ca7f0d2076&account_id=personal)
- [004 帕劳 · 石村、女性财产权与跨岛石币](https://chatgpt.com/library?file_id=libfile_2330bd03900c8191bc122290983bad22&account_id=personal)
- [005 瑙鲁 · 一圈沿海土地与中央磷矿](https://chatgpt.com/library?file_id=libfile_9ab0ec2575d48191882643dbe35058c4&account_id=personal)

### 11.04 · 古波利尼西亚与远洋社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_9849d91111108191a907aa6596071361&account_id=personal)

- [001 新西兰 · 波利尼西亚航海与两种条约文本](https://chatgpt.com/library?file_id=libfile_4bd24e4d8f308191a03bec2e5eceab46&account_id=personal)
- [002 萨摩亚 · 村庄土地、头衔与分岛历史](https://chatgpt.com/library?file_id=libfile_94ed595e88348191a3d8857322a81a69&account_id=personal)
- [003 汤加 · 航海联盟与保留王权的现代国家](https://chatgpt.com/library?file_id=libfile_0f607138e8cc81919b33b38f1cfe2968&account_id=personal)
- [004 图瓦卢 · 环礁园地、独木舟与分离建国](https://chatgpt.com/library?file_id=libfile_8e3375bbdb608191ab65243bd586cbff&account_id=personal)

<a id="part-12"></a>

## 12 编


### 12.00 · 大航海与早期全球联系

[打开分部导读](https://chatgpt.com/library?file_id=libfile_b59bb95f13e4819185a8c7edbb5dbf6f&account_id=personal)

- [001 谁的航路被接在了一起](https://chatgpt.com/library?file_id=libfile_fbe867131bb0819196bbe81a5389af43&account_id=personal)
- [002 一枚白银背后的矿井、口粮和银税](https://chatgpt.com/library?file_id=libfile_ff9646bd731c819185da21fb2ee7dda9&account_id=personal)
- [003 奴隶船能留下什么，又漏掉谁](https://chatgpt.com/library?file_id=libfile_ddeb13fa1cc481918794fa4f1928746c&account_id=personal)

<a id="part-13"></a>

## 13 编


### 13.00 · 近世国家、殖民统治与革命

[打开分部导读](https://chatgpt.com/library?file_id=libfile_dba5868b8fd48191a416f205508c8c02&account_id=personal)

- [001 为什么相似的帝国地图，统治方式不同](https://chatgpt.com/library?file_id=libfile_c54b1e33cafc8191b79c6624e4e93e7e&account_id=personal)
- [002 三次革命怎样回答公民资格](https://chatgpt.com/library?file_id=libfile_58fb1e8223e88191906ab72ace8da117&account_id=personal)
- [003 从废奴到契约劳工，劳动者能否离开](https://chatgpt.com/library?file_id=libfile_ee31d66a02588191a7760cd5a22b2984&account_id=personal)

<a id="part-14"></a>

## 14 编


### 14.00 · 工业化、民族国家与帝国扩张

[打开分部导读](https://chatgpt.com/library?file_id=libfile_0d2885b085f48191be22ffba27dd8b90&account_id=personal)

- [001 工厂钟声怎样进入家庭](https://chatgpt.com/library?file_id=libfile_21198e2baa388191ab0ef9cb8b209540&account_id=personal)
- [002 铁路为何有时只通向港口](https://chatgpt.com/library?file_id=libfile_e316961174808191bc4ce31ff7f0b6a2&account_id=personal)
- [003 人口普查把谁变成少数群体](https://chatgpt.com/library?file_id=libfile_bd173aa73f048191b3798fdc2b2badc1&account_id=personal)

<a id="part-15"></a>

## 15 编


### 15.00 · 世界大战、去殖民化与当代社会

[打开分部导读](https://chatgpt.com/library?file_id=libfile_beb687f7ef4c8191822a3afd6ef2f748&account_id=personal)

- [001 总体战如何改变配给、劳动与家庭](https://chatgpt.com/library?file_id=libfile_8419ec25c5a48191b453cd5106920626&account_id=personal)
- [002 独立日后，海关、土地和学校由谁管理](https://chatgpt.com/library?file_id=libfile_ed9e7a81cb54819191e24cf9554fc6cb&account_id=personal)
- [003 现代化的三个尺度：寿命、分配和环境](https://chatgpt.com/library?file_id=libfile_21a96ecf0b208191ad6bae4cb71b6c91&account_id=personal)
- [004 没有古代国别章的南极洲](https://chatgpt.com/library?file_id=libfile_0c72291e9c3c819183e42a9257bd50d5&account_id=personal)
