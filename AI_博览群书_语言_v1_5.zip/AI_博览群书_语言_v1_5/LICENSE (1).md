# 教材许可
本仓库中贡献者有权授权的原创教材文字，以知识共享署名—相同方式共享 4.0 国际许可协议（CC BY-SA 4.0）提供。转载或改编时请注明项目名称、章节和来源，说明修改，并按协议要求以相同许可发布改编作品。

[许可说明](https://creativecommons.org/licenses/by-sa/4.0/deed.zh-hans) · [许可法律文本](https://creativecommons.org/licenses/by-sa/4.0/legalcode)

引用的原文、第三方作品和外部网站内容按各自的权利状态处理。
